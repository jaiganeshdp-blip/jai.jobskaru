import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    contractorId: v.optional(v.id("contractors")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let labourers;
    if (args.siteId) {
      labourers = await ctx.db
        .query("labourers")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .collect();
    } else if (user.role === "site_incharge" && user.assignedSiteId) {
      labourers = await ctx.db
        .query("labourers")
        .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
        .collect();
    } else {
      labourers = await ctx.db.query("labourers").collect();
    }

    if (args.contractorId) {
      labourers = labourers.filter((l) => l.contractorId === args.contractorId);
    }

    return labourers;
  },
});

export const get = query({
  args: { id: v.id("labourers") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

export const getDetail = query({
  args: { id: v.id("labourers") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const labourer = await ctx.db.get(args.id);
    if (!labourer) return null;

    const site = await ctx.db.get(labourer.siteId);
    const contractor = labourer.contractorId
      ? await ctx.db.get(labourer.contractorId)
      : null;

    // Last 30 attendance records
    const allAttendance = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", args.id))
      .order("desc")
      .take(60);

    // Salary entries
    const salaryEntries = await ctx.db
      .query("salaryEntries")
      .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", args.id as never))
      .collect();

    // Get all salary entries for this labourer via sheets
    const sheets = await ctx.db.query("salarySheets").collect();
    const sheetIds = new Set(sheets.map((s) => s._id));
    const allSalaryEntries = await Promise.all(
      Array.from(sheetIds).map((sheetId) =>
        ctx.db
          .query("salaryEntries")
          .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", sheetId))
          .collect()
      )
    );
    const myEntries = allSalaryEntries
      .flat()
      .filter((e) => e.labourerId === args.id);

    const totalEarned = myEntries.reduce((s, e) => s + e.netAmount, 0);
    const presentDays = allAttendance.filter((a) => a.status === "present").length;
    const halfDays = allAttendance.filter((a) => a.status === "half_day").length;

    // Attach sheet month info
    const sheetMap = Object.fromEntries(sheets.map((s) => [s._id, s.month]));
    const enrichedEntries = myEntries.map((e) => ({
      ...e,
      month: sheetMap[e.salarySheetId] ?? "—",
    }));

    void salaryEntries; // unused var

    // Advances for this labourer (all time)
    const advances = await ctx.db
      .query("advances")
      .withIndex("by_labourer", (q) => q.eq("labourerId", args.id))
      .order("desc")
      .take(100);

    const totalAdvance = advances.reduce((s, a) => s + a.amount, 0);

    return {
      labourer,
      site,
      contractor,
      attendance: allAttendance,
      salaryEntries: enrichedEntries,
      advances,
      stats: {
        totalEarned,
        totalAdvance,
        presentDays,
        halfDays,
        attendanceRecords: allAttendance.length,
      },
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    mobile: v.optional(v.string()),
    aadhaarNumber: v.optional(v.string()),
    siteId: v.id("sites"),
    contractorId: v.optional(v.id("contractors")),
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))),
    designation: v.optional(v.string()),
    dailyRate: v.number(),
    joinDate: v.optional(v.string()),
    isSafetySupervisor: v.optional(v.boolean()),
    isSiteSupervisor: v.optional(v.boolean()),
    isSiteIncharge: v.optional(v.boolean()),
    workerCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const portalToken = crypto.randomUUID();
    // Auto-generate workerCode if supervisor/incharge and none provided
    let workerCode = args.workerCode?.trim().toUpperCase() || undefined;
    if ((args.isSiteSupervisor || args.isSafetySupervisor || args.isSiteIncharge) && !workerCode) {
      workerCode = "S" + Math.floor(1000 + Math.random() * 9000).toString();
    }
    return await ctx.db.insert("labourers", {
      ...args,
      workerCode,
      isActive: true,
      portalToken,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("labourers"),
    name: v.optional(v.string()),
    mobile: v.optional(v.string()),
    aadhaarNumber: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    contractorId: v.optional(v.id("contractors")),
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))),
    designation: v.optional(v.string()),
    dailyRate: v.optional(v.number()),
    joinDate: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
    isSafetySupervisor: v.optional(v.boolean()),
    isSiteSupervisor: v.optional(v.boolean()),
    isSiteIncharge: v.optional(v.boolean()),
    workerCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("labourers") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});

// Bulk transfer: move selected labourers to a new site and optionally new contractor
export const bulkTransfer = mutation({
  args: {
    labourerIds: v.array(v.id("labourers")),
    toSiteId: v.id("sites"),
    toContractorId: v.optional(v.id("contractors")),
    clearContractor: v.optional(v.boolean()), // set contractorId to undefined
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))),
    transferDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    for (const id of args.labourerIds) {
      const patch: Record<string, unknown> = { siteId: args.toSiteId };
      if (args.clearContractor) {
        patch.contractorId = undefined;
      } else if (args.toContractorId) {
        patch.contractorId = args.toContractorId;
      }
      if (args.labourType) patch.labourType = args.labourType;
      if (args.transferDate) patch.joinDate = args.transferDate;
      await ctx.db.patch(id, patch);
    }
    return { transferred: args.labourerIds.length };
  },
});

export const markAttendance = mutation({
  args: {
    siteId: v.id("sites"),
    labourerId: v.id("labourers"),
    date: v.string(),
    status: v.union(
      v.literal("present"),
      v.literal("absent"),
      v.literal("half_day"),
      v.literal("holiday")
    ),
    overtimeHours: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const existing = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) =>
        q.eq("labourerId", args.labourerId).eq("date", args.date)
      )
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, { status: args.status, overtimeHours: args.overtimeHours, markedBySource: "admin", markedByName: user.name ?? "Admin", markedBy: user._id });
    } else {
      await ctx.db.insert("attendance", {
        siteId: args.siteId,
        labourerId: args.labourerId,
        date: args.date,
        status: args.status,
        overtimeHours: args.overtimeHours,
        markedBy: user._id,
        markedBySource: "admin",
        markedByName: user.name ?? "Admin",
      });
    }
  },
});

// Bulk mark attendance for multiple labourers on a date
export const bulkMarkAttendance = mutation({
  args: {
    siteId: v.id("sites"),
    date: v.string(),
    entries: v.array(
      v.object({
        labourerId: v.id("labourers"),
        status: v.union(
          v.literal("present"),
          v.literal("absent"),
          v.literal("half_day"),
          v.literal("holiday")
        ),
        overtimeHours: v.optional(v.number()),
      })
    ),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    for (const entry of args.entries) {
      const existing = await ctx.db
        .query("attendance")
        .withIndex("by_labourer_date", (q) =>
          q.eq("labourerId", entry.labourerId).eq("date", args.date)
        )
        .unique();
      if (existing) {
        await ctx.db.patch(existing._id, { status: entry.status, overtimeHours: entry.overtimeHours, markedBySource: "admin", markedByName: user.name ?? "Admin", markedBy: user._id });
      } else {
        await ctx.db.insert("attendance", {
          siteId: args.siteId,
          labourerId: entry.labourerId,
          date: args.date,
          status: entry.status,
          overtimeHours: entry.overtimeHours,
          markedBy: user._id,
          markedBySource: "admin",
          markedByName: user.name ?? "Admin",
        });
      }
    }
  },
});

export const getAttendance = query({
  args: { siteId: v.id("sites"), month: v.string() },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const records = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId))
      .collect();
    return records.filter((r) => r.date.startsWith(args.month));
  },
});

// Get attendance for a specific labourer for a month
export const getLabourerAttendance = query({
  args: { labourerId: v.id("labourers"), month: v.string() },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const records = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", args.labourerId))
      .collect();
    return records.filter((r) => r.date.startsWith(args.month));
  },
});

// Monthly summary: per-labourer stats for a site
export const monthlySummary = query({
  args: { siteId: v.id("sites"), month: v.string() },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();

    const records = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId))
      .collect();

    const monthRecords = records.filter((r) => r.date.startsWith(args.month));

    // Advances this month
    const monthStart = `${args.month}-01`;
    const monthEnd = `${args.month}-31`;
    const allAdvances = await ctx.db
      .query("advances")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    const advanceMap: Record<string, number> = {};
    for (const adv of allAdvances) {
      if (adv.date >= monthStart && adv.date <= monthEnd) {
        advanceMap[adv.labourerId] = (advanceMap[adv.labourerId] ?? 0) + adv.amount;
      }
    }

    return labourers.filter((l) => l.isActive).map((l) => {
      const myRecords = monthRecords.filter((r) => r.labourerId === l._id);
      const present = myRecords.filter((r) => r.status === "present").length;
      const halfDay = myRecords.filter((r) => r.status === "half_day").length;
      const absent = myRecords.filter((r) => r.status === "absent").length;
      const holiday = myRecords.filter((r) => r.status === "holiday").length;
      const overtimeHours = myRecords.reduce((s, r) => s + (r.overtimeHours ?? 0), 0);
      const effectiveDays = present + halfDay * 0.5;
      const estimatedWage = effectiveDays * l.dailyRate;
      const totalAdvance = advanceMap[l._id] ?? 0;
      return {
        labourerId: l._id,
        name: l.name,
        designation: l.designation,
        dailyRate: l.dailyRate,
        present,
        halfDay,
        absent,
        holiday,
        unmarked: 0, // computed on frontend
        overtimeHours,
        effectiveDays,
        estimatedWage,
        totalAdvance,
        netEstimate: Math.max(0, estimatedWage - totalAdvance),
      };
    });
  },
});

// ─── Rate Approval: Admin queries pending labour rates ─────────────────────
export const listPendingRates = query({
  args: {},
  handler: async (ctx, args) => {
    void args;
    await getCurrentUser(ctx);
    const all = await ctx.db.query("labourers").collect();
    const pending = all.filter((l) => l.rateApprovalStatus === "pending");
    // Enrich with site name
    return await Promise.all(pending.map(async (l) => {
      const site = await ctx.db.get(l.siteId);
      return { ...l, siteName: site?.name ?? "Unknown Site" };
    }));
  },
});

// ─── Rate Approval: Admin approves / sets final rate ──────────────────────
export const approveRate = mutation({
  args: {
    id: v.id("labourers"),
    finalRate: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    await ctx.db.patch(args.id, {
      dailyRate: args.finalRate,
      rateApprovalStatus: "approved",
    });
  },
});

// Manually create a labourer record for an existing user who has labour role but no labourer record
export const createLabourerForUser = mutation({
  args: {
    userId: v.id("users"),
    siteId: v.id("sites"),
    dailyRate: v.number(),
  },
  handler: async (ctx, args) => {
    const admin = await getCurrentUser(ctx);
    if (admin.role !== "super_admin") throw new Error("Forbidden");

    const user = await ctx.db.get(args.userId);
    if (!user) throw new Error("User not found");

    // If already has a labourer record, skip
    if (user.labourerRef) {
      const existing = await ctx.db.get(user.labourerRef);
      if (existing) throw new Error("Labourer record already exists");
    }

    const labourerId = await ctx.db.insert("labourers", {
      name: user.name ?? "Unknown",
      mobile: user.mobile,
      siteId: args.siteId,
      dailyRate: args.dailyRate,
      isActive: true,
      joinDate: new Date().toISOString().split("T")[0],
      labourType: "departmental",
    });

    await ctx.db.patch(args.userId, {
      labourerRef: labourerId,
      assignedSiteId: args.siteId,
    });

    return labourerId;
  },
});

