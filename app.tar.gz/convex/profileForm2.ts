import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";

// Get current user's profile completion status (for Form 2 redirect)
export const getProfileStatus = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);

    if (user.role === "contractor" && user.contractorRef) {
      const contractor = await ctx.db.get(user.contractorRef);
      if (!contractor) return { role: user.role, isForm2Complete: false, record: null };
      return {
        role: user.role,
        isForm2Complete: !!(contractor.gstNumber && contractor.bankName && contractor.accountNumber && contractor.ifscCode),
        record: {
          name: contractor.name,
          mobile: contractor.mobile,
          gstNumber: contractor.gstNumber,
          panNumber: contractor.panNumber,
          bankName: contractor.bankName,
          accountNumber: contractor.accountNumber,
          ifscCode: contractor.ifscCode,
          address: contractor.address,
        },
      };
    }

    if (user.role === "supplier" && user.supplierRef) {
      const supplier = await ctx.db.get(user.supplierRef);
      if (!supplier) return { role: user.role, isForm2Complete: false, record: null };
      return {
        role: user.role,
        isForm2Complete: !!(supplier.gstNumber && supplier.bankName && supplier.accountNumber && supplier.ifscCode),
        record: {
          name: supplier.name,
          mobile: supplier.mobile,
          gstNumber: supplier.gstNumber,
          panNumber: supplier.panNumber,
          bankName: supplier.bankName,
          accountNumber: supplier.accountNumber,
          ifscCode: supplier.ifscCode,
          address: supplier.address,
        },
      };
    }

    // Not a contractor or supplier
    return { role: user.role, isForm2Complete: true, record: null };
  },
});

// Contractor: Submit Form 2 (GST + bank details)
export const submitContractorForm2 = mutation({
  args: {
    gstNumber: v.string(),
    panNumber: v.optional(v.string()),
    bankName: v.string(),
    accountNumber: v.string(),
    ifscCode: v.string(),
    address: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "contractor" || !user.contractorRef) {
      throw new Error("Not a contractor");
    }

    await ctx.db.patch(user.contractorRef, {
      gstNumber: args.gstNumber,
      panNumber: args.panNumber,
      bankName: args.bankName,
      accountNumber: args.accountNumber,
      ifscCode: args.ifscCode,
      address: args.address,
    });
  },
});

// Supplier: Submit Form 2 (GST + bank details)
export const submitSupplierForm2 = mutation({
  args: {
    gstNumber: v.string(),
    panNumber: v.optional(v.string()),
    bankName: v.string(),
    accountNumber: v.string(),
    ifscCode: v.string(),
    address: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "supplier" || !user.supplierRef) {
      throw new Error("Not a supplier");
    }

    await ctx.db.patch(user.supplierRef, {
      gstNumber: args.gstNumber,
      panNumber: args.panNumber,
      bankName: args.bankName,
      accountNumber: args.accountNumber,
      ifscCode: args.ifscCode,
      address: args.address,
    });
  },
});
