import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";
import { ConvexError } from "convex/values";
import type { Id } from "./_generated/dataModel.d.ts";

// Haversine formula: calculate distance between 2 GPS points in meters
function getDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000; // Earth radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Calculate time status (on-time, late, early)
function getTimeStatus(
  checkinTime: string,
  type: "in" | "out",
  shiftStart?: string,
  shiftEnd?: string,
  graceMinutes?: number
): { status: "on_time" | "late" | "early" | "overtime"; minutesDiff: number } {
  const grace = graceMinutes ?? 15;
  const now = new Date(checkinTime);
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const currentMinutes = hours * 60 + minutes;

  if (type === "in") {
    if (!shiftStart) return { status: "on_time", minutesDiff: 0 };
    const [sh, sm] = shiftStart.split(":").map(Number);
    const shiftStartMinutes = sh * 60 + sm;
    const diff = currentMinutes - shiftStartMinutes;

    if (diff <= grace) return { status: "on_time", minutesDiff: Math.max(0, diff) };
    return { status: "late", minutesDiff: diff };
  } else {
    if (!shiftEnd) return { status: "on_time", minutesDiff: 0 };
    const [eh, em] = shiftEnd.split(":").map(Number);
    const shiftEndMinutes = eh * 60 + em;
    const diff = currentMinutes - shiftEndMinutes;

    if (diff >= -grace && diff <= grace) return { status: "on_time", minutesDiff: 0 };
    if (diff < -grace) return { status: "early", minutesDiff: Math.abs(diff) };
    return { status: "overtime", minutesDiff: diff };
  }
}

// Labour: Check in/out with GPS location
export const checkIn = mutation({
  args: {
    latitude: v.number(),
    longitude: v.number(),
    type: v.optional(v.union(v.literal("in"), v.literal("out"))),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.labourerRef) throw new ConvexError({ message: "Not a labour user", code: "FORBIDDEN" });

    const labourer = await ctx.db.get(user.labourerRef);
    if (!labourer) throw new ConvexError({ message: "Labourer not found", code: "NOT_FOUND" });

    const site = await ctx.db.get(labourer.siteId);
    if (!site) throw new ConvexError({ message: "Site not found", code: "NOT_FOUND" });

    // Calculate distance from site
    const siteLatitude = site.latitude;
    const siteLongitude = site.longitude;
    const geofenceRadius = site.geofenceRadius ?? 200;

    let distanceFromSite = 0;
    let isWithinGeofence = false;

    if (siteLatitude !== undefined && siteLongitude !== undefined) {
      distanceFromSite = getDistanceMeters(args.latitude, args.longitude, siteLatitude, siteLongitude);
      isWithinGeofence = distanceFromSite <= geofenceRadius;
    } else {
      isWithinGeofence = true;
      distanceFromSite = 0;
    }

    const now = new Date();
    const date = now.toISOString().slice(0, 10);
    const checkinTime = now.toISOString();
    const punchType = args.type ?? "in";

    // Calculate time status
    const timeStatus = getTimeStatus(
      checkinTime,
      punchType,
      site.shiftStartTime,
      site.shiftEndTime,
      site.graceMinutes
    );

    await ctx.db.insert("locationCheckins", {
      labourerId: labourer._id,
      siteId: labourer.siteId,
      latitude: args.latitude,
      longitude: args.longitude,
      isWithinGeofence,
      distanceFromSite: Math.round(distanceFromSite),
      checkinTime,
      date,
      type: punchType,
    });

    return {
      isWithinGeofence,
      distanceFromSite: Math.round(distanceFromSite),
      geofenceRadius,
      timeStatus: timeStatus.status,
      minutesDiff: timeStatus.minutesDiff,
      punchType,
    };
  },
});

// Labour portal: Check in/out via token (no auth needed)
export const checkInByToken = mutation({
  args: {
    token: v.string(),
    latitude: v.number(),
    longitude: v.number(),
    type: v.union(v.literal("in"), v.literal("out")),
  },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) throw new ConvexError({ message: "Invalid token", code: "NOT_FOUND" });

    const site = await ctx.db.get(labourer.siteId);
    if (!site) throw new ConvexError({ message: "Site not found", code: "NOT_FOUND" });

    // Calculate distance from site
    const siteLatitude = site.latitude;
    const siteLongitude = site.longitude;
    const geofenceRadius = site.geofenceRadius ?? 200;

    let distanceFromSite = 0;
    let isWithinGeofence = false;

    if (siteLatitude !== undefined && siteLongitude !== undefined) {
      distanceFromSite = getDistanceMeters(args.latitude, args.longitude, siteLatitude, siteLongitude);
      isWithinGeofence = distanceFromSite <= geofenceRadius;
    } else {
      isWithinGeofence = true;
      distanceFromSite = 0;
    }

    const now = new Date();
    const date = now.toISOString().slice(0, 10);
    const checkinTime = now.toISOString();

    // Calculate time status
    const timeStatus = getTimeStatus(
      checkinTime,
      args.type,
      site.shiftStartTime,
      site.shiftEndTime,
      site.graceMinutes
    );

    await ctx.db.insert("locationCheckins", {
      labourerId: labourer._id,
      siteId: labourer.siteId,
      latitude: args.latitude,
      longitude: args.longitude,
      isWithinGeofence,
      distanceFromSite: Math.round(distanceFromSite),
      checkinTime,
      date,
      type: args.type,
    });

    return {
      isWithinGeofence,
      distanceFromSite: Math.round(distanceFromSite),
      geofenceRadius,
      timeStatus: timeStatus.status,
      minutesDiff: timeStatus.minutesDiff,
      punchType: args.type,
      shiftStart: site.shiftStartTime ?? "09:00",
      shiftEnd: site.shiftEndTime ?? "18:00",
    };
  },
});

// Labour: Get my today's check-ins
export const getMyCheckins = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.labourerRef) return [];

    const labourer = await ctx.db.get(user.labourerRef);
    if (!labourer) return [];

    const today = new Date().toISOString().slice(0, 10);
    return await ctx.db
      .query("locationCheckins")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", labourer._id).eq("date", today))
      .order("desc")
      .collect();
  },
});

// Labour portal: Get today's check-ins by token
export const getCheckinsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) return { checkins: [], site: null };

    const site = await ctx.db.get(labourer.siteId);
    const today = new Date().toISOString().slice(0, 10);
    const checkins = await ctx.db
      .query("locationCheckins")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", labourer._id).eq("date", today))
      .order("desc")
      .collect();

    return {
      checkins,
      site: site ? {
        name: site.name,
        shiftStartTime: site.shiftStartTime ?? "09:00",
        shiftEndTime: site.shiftEndTime ?? "18:00",
        graceMinutes: site.graceMinutes ?? 15,
      } : null,
    };
  },
});

// Admin: Get today's location status for all labourers on a site (with IN/OUT)
export const getSiteLocationStatus = query({
  args: { siteId: v.id("sites") },
  handler: async (ctx, args): Promise<Array<{
    labourerId: Id<"labourers">;
    name: string;
    designation: string;
    lastCheckin: string | null;
    lastType: string | null;
    isWithinGeofence: boolean | null;
    distanceFromSite: number | null;
    inTime: string | null;
    outTime: string | null;
    isLate: boolean;
    minutesLate: number;
  }>> => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") return [];

    const today = new Date().toISOString().slice(0, 10);

    const site = await ctx.db.get(args.siteId);
    const graceMinutes = site?.graceMinutes ?? 15;
    const shiftStart = site?.shiftStartTime ?? "09:00";

    // Get all active labourers on this site
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    const activeLabourers = labourers.filter(l => l.isActive);

    // Get today's check-ins for this site
    const todayCheckins = await ctx.db
      .query("locationCheckins")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId).eq("date", today))
      .collect();

    // Group check-ins by labourer
    const checkinsByLabourer = new Map<string, typeof todayCheckins>();
    for (const ci of todayCheckins) {
      const existing = checkinsByLabourer.get(ci.labourerId) ?? [];
      existing.push(ci);
      checkinsByLabourer.set(ci.labourerId, existing);
    }

    return activeLabourers.map(l => {
      const labCheckins = checkinsByLabourer.get(l._id) ?? [];
      // First IN punch
      const inPunch = labCheckins
        .filter(c => c.type === "in" || !c.type) // backward compat: old records without type are treated as "in"
        .sort((a, b) => a.checkinTime.localeCompare(b.checkinTime))[0];
      // Last OUT punch
      const outPunch = labCheckins
        .filter(c => c.type === "out")
        .sort((a, b) => b.checkinTime.localeCompare(a.checkinTime))[0];
      // Latest of all
      const lastCheckin = labCheckins.sort((a, b) => b.checkinTime.localeCompare(a.checkinTime))[0];

      // Check if late
      let isLate = false;
      let minutesLate = 0;
      if (inPunch && shiftStart) {
        const inDate = new Date(inPunch.checkinTime);
        const inMinutes = inDate.getHours() * 60 + inDate.getMinutes();
        const [sh, sm] = shiftStart.split(":").map(Number);
        const shiftMinutes = sh * 60 + sm;
        const diff = inMinutes - shiftMinutes;
        if (diff > graceMinutes) {
          isLate = true;
          minutesLate = diff;
        }
      }

      return {
        labourerId: l._id,
        name: l.name,
        designation: l.designation ?? "Labour",
        lastCheckin: lastCheckin?.checkinTime ?? null,
        lastType: lastCheckin?.type ?? null,
        isWithinGeofence: lastCheckin?.isWithinGeofence ?? null,
        distanceFromSite: lastCheckin?.distanceFromSite ?? null,
        inTime: inPunch?.checkinTime ?? null,
        outTime: outPunch?.checkinTime ?? null,
        isLate,
        minutesLate,
      };
    });
  },
});

// Admin: Update site GPS coordinates and shift timings
export const updateSiteGPS = mutation({
  args: {
    siteId: v.id("sites"),
    latitude: v.number(),
    longitude: v.number(),
    geofenceRadius: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin") throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });

    await ctx.db.patch(args.siteId, {
      latitude: args.latitude,
      longitude: args.longitude,
      geofenceRadius: args.geofenceRadius ?? 200,
    });
  },
});

// Admin: Update site shift timings
export const updateShiftTimings = mutation({
  args: {
    siteId: v.id("sites"),
    shiftStartTime: v.string(),
    shiftEndTime: v.string(),
    graceMinutes: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });
    }

    await ctx.db.patch(args.siteId, {
      shiftStartTime: args.shiftStartTime,
      shiftEndTime: args.shiftEndTime,
      graceMinutes: args.graceMinutes ?? 15,
    });
  },
});
