import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // Users with roles
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    role: v.union(
      v.literal("super_admin"),
      v.literal("site_incharge"),
      v.literal("supplier"),
      v.literal("contractor"),
      v.literal("viewer"),
      v.literal("safety_supervisor"),
      v.literal("site_supervisor"),
      v.literal("labour"),
      v.literal("billing_manager"),   // Billing 1 — approves after site incharge
      v.literal("accounts_manager"),  // Billing 2 / Accounts — makes final payment
      v.literal("pending")
    ),
    // For site_incharge: which site they manage
    assignedSiteId: v.optional(v.id("sites")),
    // For supplier/contractor: reference to their record
    supplierRef: v.optional(v.id("suppliers")),
    contractorRef: v.optional(v.id("contractors")),
    // For supervisors/labour: reference to labourer record
    labourerRef: v.optional(v.id("labourers")),
    companyId: v.optional(v.id("companies")),
    isActive: v.boolean(),
    mobile: v.optional(v.string()),
    requestedRole: v.optional(v.string()),
    registrationNote: v.optional(v.string()),
    // Granular permissions for site_supervisor role (set by super_admin)
    supervisorPermissions: v.optional(v.object({
      canViewLabour: v.boolean(),
      canMarkAttendance: v.boolean(),
      canViewSiteDiary: v.boolean(),
      canAddSiteDiary: v.boolean(),
      canViewMaterials: v.boolean(),
      canRequestMaterials: v.boolean(),
      canViewWorkOrders: v.boolean(),
      canViewSalary: v.boolean(),
      canViewSafety: v.boolean(),
      canAddSafetyReport: v.boolean(),
    })),
    // Universal granular permissions for all roles (set by super_admin)
    userPermissions: v.optional(v.object({
      // Site Operations
      canViewLabour: v.boolean(),
      canMarkAttendance: v.boolean(),
      canViewSiteDiary: v.boolean(),
      canAddSiteDiary: v.boolean(),
      canViewMaterials: v.boolean(),
      canRequestMaterials: v.boolean(),
      canViewWorkOrders: v.boolean(),
      canViewSafety: v.boolean(),
      canAddSafetyReport: v.boolean(),
      canViewSites: v.boolean(),
      // Finance
      canViewSalary: v.boolean(),
      canViewInvoices: v.boolean(),
      canViewPayments: v.boolean(),
      canViewExpenses: v.boolean(),
      canViewPurchaseOrders: v.boolean(),
      canViewVendorBills: v.boolean(),
      canViewIncomingInvoices: v.boolean(),
      canViewBankStatement: v.boolean(),
      canViewGstTracking: v.boolean(),
      canViewBillingDashboard: v.boolean(),
      // Reports & Analytics
      canViewAnalytics: v.boolean(),
      canViewReports: v.boolean(),
      canViewSitePnl: v.boolean(),
      canViewBoq: v.boolean(),
      canViewDeliveryChallans: v.boolean(),
      canViewLabourCorrections: v.boolean(),
      // Master Data
      canViewCompanies: v.boolean(),
      canViewPartners: v.boolean(),
      canViewClients: v.boolean(),
      canViewSuppliers: v.boolean(),
      canViewContractors: v.boolean(),
    })),
  })
    .index("by_token", ["tokenIdentifier"])
    .index("by_role", ["role"]),

  // Registration requests
  registrationRequests: defineTable({
    userId: v.id("users"),
    tokenIdentifier: v.string(),
    name: v.string(),
    email: v.optional(v.string()),
    mobile: v.string(),
    requestedRole: v.union(
      v.literal("contractor"),
      v.literal("supplier"),
      v.literal("site_supervisor"),
      v.literal("safety_supervisor"),
      v.literal("labour"),
      v.literal("other")
    ),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    note: v.optional(v.string()),
    photoStorageId: v.optional(v.string()),
    aadhaarStorageId: v.optional(v.string()),
    panStorageId: v.optional(v.string()),
    status: v.union(
      v.literal("pending"),
      v.literal("approved"),
      v.literal("rejected")
    ),
    adminNote: v.optional(v.string()),
    reviewedAt: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_status", ["status"])
    .index("by_token", ["tokenIdentifier"]),

  // Companies (ABC Builders, XYZ Developers, etc.)
  // Partners (investors/owners in a company)
  partners: defineTable({
    companyId: v.id("companies"),
    name: v.string(),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    sharePercent: v.number(), // 0-100
    capitalInvested: v.optional(v.number()),
    notes: v.optional(v.string()),
    isActive: v.boolean(),
  })
    .index("by_company", ["companyId"]),

  // Partner share in a specific site
  sitePartners: defineTable({
    siteId: v.id("sites"),
    partnerId: v.id("partners"),
    sharePercent: v.number(), // override for this site
  })
    .index("by_site", ["siteId"])
    .index("by_partner", ["partnerId"]),

  companies: defineTable({
    name: v.string(),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    contactPerson: v.string(),
    mobile: v.string(),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_name", ["name"]),

  // Sites / Projects
  sites: defineTable({
    name: v.string(),
    companyId: v.id("companies"),
    clientId: v.optional(v.id("clients")),
    city: v.string(),
    address: v.optional(v.string()),
    siteInchargeId: v.optional(v.id("users")),
    siteInchargeLabourerId: v.optional(v.id("labourers")), // If incharge is a labourer (not a user account)
    siteSupervisorIds: v.optional(v.array(v.id("users"))), // Multiple site supervisors (user accounts)
    siteSupervisorLabourerIds: v.optional(v.array(v.id("labourers"))), // Supervisors from labourers table
    status: v.union(
      v.literal("planning"),
      v.literal("active"),
      v.literal("on_hold"),
      v.literal("completed")
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    description: v.optional(v.string()),
    // GPS Geofencing
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
    geofenceRadius: v.optional(v.number()), // meters, default 200
    // Shift Timings
    shiftStartTime: v.optional(v.string()), // HH:MM format e.g. "09:00"
    shiftEndTime: v.optional(v.string()),   // HH:MM format e.g. "18:00"
    graceMinutes: v.optional(v.number()),   // default 15 minutes
  })
    .index("by_company", ["companyId"])
    .index("by_client", ["clientId"])
    .index("by_status", ["status"]),

  // Clients
  clients: defineTable({
    name: v.string(),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.string(),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    contactPerson: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_name", ["name"]),

  // Suppliers / Shopkeepers
  suppliers: defineTable({
    name: v.string(),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.string(),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    materialCategories: v.optional(v.array(v.string())),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
    portalToken: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_name", ["name"]).index("by_portal_token", ["portalToken"]),

  // Labour Contractors
  contractors: defineTable({
    name: v.string(),
    mobile: v.string(),
    email: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    specialization: v.optional(v.string()),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
    portalToken: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_name", ["name"]).index("by_portal_token", ["portalToken"]),

  // Individual Labourers
  labourers: defineTable({
    name: v.string(),
    mobile: v.optional(v.string()),
    aadhaarNumber: v.optional(v.string()),
    fatherName: v.optional(v.string()),
    whatsappNumber: v.optional(v.string()),
    siteId: v.id("sites"),
    contractorId: v.optional(v.id("contractors")),
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))), // New field
    designation: v.optional(v.string()),
    dailyRate: v.number(),
    suggestedRate: v.optional(v.number()), // Rate suggested by supervisor, pending admin approval
    rateApprovalStatus: v.optional(v.union(v.literal("pending"), v.literal("approved"))), // Rate approval workflow
    joinDate: v.optional(v.string()),
    isActive: v.boolean(),
    portalToken: v.optional(v.string()),
    workerCode: v.optional(v.string()), // Short code for portal login e.g. "S001"
    isSafetySupervisor: v.optional(v.boolean()), // Safety Supervisor flag
    isSiteSupervisor: v.optional(v.boolean()),   // Site Supervisor flag (can mark attendance, advances, reports)
    isSiteIncharge: v.optional(v.boolean()),     // Site Incharge flag (full site management access)
    // Bank details (filled in Form 2 after approval)
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
    isForm2Complete: v.optional(v.boolean()), // Whether Form 2 has been filled
  })
    .index("by_site", ["siteId"])
    .index("by_contractor", ["contractorId"])
    .index("by_portal_token", ["portalToken"])
    .index("by_worker_code", ["workerCode"]),

  // Advances — given to labourers by site supervisor or admin
  advances: defineTable({
    siteId: v.id("sites"),
    labourerId: v.id("labourers"),
    amount: v.number(),
    date: v.string(), // YYYY-MM-DD
    reason: v.optional(v.string()),
    addedByToken: v.optional(v.string()), // supervisor portal token
    addedByUserId: v.optional(v.id("users")), // admin user
  })
    .index("by_site", ["siteId"])
    .index("by_labourer", ["labourerId"])
    .index("by_site_date", ["siteId", "date"]),

  // Supervisor Reports — daily/weekly reports with photos
  supervisorReports: defineTable({
    siteId: v.id("sites"),
    supervisorLabourerId: v.id("labourers"),
    title: v.string(),
    description: v.optional(v.string()),
    reportDate: v.string(), // YYYY-MM-DD
    photoStorageIds: v.optional(v.array(v.string())),
    status: v.union(v.literal("submitted"), v.literal("reviewed")),
    adminNote: v.optional(v.string()),
    reviewedBy: v.optional(v.id("users")),
  })
    .index("by_site", ["siteId"])
    .index("by_supervisor", ["supervisorLabourerId"]),

  // Material Requests — site supervisor requests materials, admin issues PO
  materialRequests: defineTable({
    siteId: v.id("sites"),
    requestedByLabourerId: v.id("labourers"), // supervisor
    itemName: v.string(),
    quantity: v.number(),
    unit: v.string(),
    urgency: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    notes: v.optional(v.string()),
    photoStorageId: v.optional(v.string()),
    status: v.union(
      v.literal("requested"),
      v.literal("po_issued"),
      v.literal("delivered"),
      v.literal("rejected")
    ),
    assignedSupplierId: v.optional(v.id("suppliers")),
    purchaseOrderId: v.optional(v.id("purchaseOrders")),
    adminNote: v.optional(v.string()),
    reviewedBy: v.optional(v.id("users")),
  })
    .index("by_site", ["siteId"])
    .index("by_supervisor", ["requestedByLabourerId"])
    .index("by_status", ["status"]),

  // Attendance
  attendance: defineTable({
    siteId: v.id("sites"),
    labourerId: v.id("labourers"),
    date: v.string(), // ISO date YYYY-MM-DD
    status: v.union(
      v.literal("present"),
      v.literal("absent"),
      v.literal("half_day"),
      v.literal("holiday")
    ),
    overtimeHours: v.optional(v.number()),
    hajriUnits: v.optional(v.number()), // Custom decimal units: 0=absent, 0.5=half day, 1=present, 2=double shift, etc.
    markedBy: v.id("users"),
    markedBySource: v.optional(v.union(v.literal("admin"), v.literal("supervisor"))), // kaun ne bhara
    markedByName: v.optional(v.string()), // supervisor/admin ka naam
  })
    .index("by_site_date", ["siteId", "date"])
    .index("by_labourer_date", ["labourerId", "date"]),

  // Work Orders from clients
  workOrders: defineTable({
    orderNumber: v.string(),
    // "incoming" = Client ne company ko diya, "outgoing" = Company ne contractor ko diya
    orderType: v.optional(v.union(v.literal("incoming"), v.literal("outgoing"))),
    siteId: v.id("sites"),
    clientId: v.optional(v.id("clients")),
    contractorId: v.optional(v.id("contractors")),
    companyId: v.id("companies"),
    description: v.string(),
    totalValue: v.number(),
    status: v.union(
      v.literal("draft"),
      v.literal("active"),
      v.literal("amended"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    issueDate: v.string(),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    terms: v.optional(v.string()),
    version: v.number(),
    parentOrderId: v.optional(v.id("workOrders")),
    // Progress billing: total units (floors/phases) for equal split
    totalUnits: v.optional(v.number()),
    unitLabel: v.optional(v.string()), // e.g. "Floor", "Phase"
  })
    .index("by_site", ["siteId"])
    .index("by_client", ["clientId"])
    .index("by_company", ["companyId"])
    .index("by_order_number", ["orderNumber"]),

  // Progress billing milestones (floors/phases) for a work order
  workOrderMilestones: defineTable({
    workOrderId: v.id("workOrders"),
    siteId: v.id("sites"),
    name: v.string(),           // e.g. "Floor 1", "Floor 1-5"
    unitNumber: v.number(),     // sequential number for ordering
    percentage: v.number(),     // % of total work order value
    amount: v.number(),         // calculated amount
    status: v.union(
      v.literal("pending"),
      v.literal("completed"),   // site incharge marked done
      v.literal("billed"),      // billing team created invoice
    ),
    completedAt: v.optional(v.string()),
    completedBy: v.optional(v.id("users")),
    completionNote: v.optional(v.string()),
    billedAt: v.optional(v.string()),
  })
    .index("by_work_order", ["workOrderId"])
    .index("by_site", ["siteId"])
    .index("by_status", ["status"]),

  // Purchase Orders to Suppliers
  purchaseOrders: defineTable({
    poNumber: v.string(),
    siteId: v.id("sites"),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    companyId: v.id("companies"),
    workOrderId: v.optional(v.id("workOrders")),
    status: v.union(
      v.literal("draft"),
      v.literal("sent"),
      v.literal("partially_received"),
      v.literal("closed"),
      v.literal("cancelled")
    ),
    issueDate: v.string(),
    expectedDeliveryDate: v.optional(v.string()),
    items: v.array(
      v.object({
        name: v.string(),
        quantity: v.number(),
        unit: v.string(),
        ratePerUnit: v.number(),
        totalAmount: v.number(),
      })
    ),
    totalValue: v.number(),
    terms: v.optional(v.string()),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_supplier", ["supplierId"])
    .index("by_po_number", ["poNumber"])
    .index("by_contractor", ["contractorId"]),

  // PO Receipts — when materials arrive against a PO
  poReceipts: defineTable({
    purchaseOrderId: v.id("purchaseOrders"),
    materialId: v.optional(v.id("materials")),
    receivedDate: v.string(),
    receivedItems: v.array(
      v.object({
        itemIndex: v.number(), // index into PO items array
        receivedQuantity: v.number(),
      })
    ),
    notes: v.optional(v.string()),
    receivedBy: v.id("users"),
  }).index("by_po", ["purchaseOrderId"]),

  // Work Order Amendments
  workOrderAmendments: defineTable({
    workOrderId: v.id("workOrders"),
    amendmentNumber: v.number(),
    reason: v.string(),
    previousValue: v.number(),
    newValue: v.number(),
    date: v.string(),
    approvedBy: v.optional(v.id("users")),
  }).index("by_work_order", ["workOrderId"]),

  // Materials / Deliveries
  materials: defineTable({
    siteId: v.id("sites"),
    supplierId: v.id("suppliers"),
    enteredBy: v.id("users"),
    invoiceNumber: v.optional(v.string()),
    vehicleNumber: v.optional(v.string()),
    deliveryDate: v.string(),
    items: v.array(
      v.object({
        name: v.string(),
        quantity: v.number(),
        unit: v.string(),
        ratePerUnit: v.number(),
        totalAmount: v.number(),
      })
    ),
    totalAmount: v.number(),
    photoStorageId: v.optional(v.string()),
    mtcStorageId: v.optional(v.string()),
    billFiles: v.optional(v.array(v.object({
      storageId: v.id("_storage"),
      name: v.string(),
      type: v.string(),
    }))),
    status: v.union(
      v.literal("pending"),
      v.literal("approved"),
      v.literal("rejected")
    ),
    approvedBy: v.optional(v.id("users")),
    notes: v.optional(v.string()),
  })
    .index("by_site", ["siteId"])
    .index("by_supplier", ["supplierId"]),

  // Salary Sheets
  salarySheets: defineTable({
    siteId: v.id("sites"),
    month: v.string(), // YYYY-MM
    status: v.union(
      v.literal("draft"),
      v.literal("submitted"),
      v.literal("approved"),
      v.literal("paid")
    ),
    preparedBy: v.id("users"),
    approvedBy: v.optional(v.id("users")),
    totalAmount: v.number(),
    paidDate: v.optional(v.string()),
  })
    .index("by_site_month", ["siteId", "month"])
    .index("by_status", ["status"]),

  // Salary Sheet Entries (per labourer)
  salaryEntries: defineTable({
    salarySheetId: v.id("salarySheets"),
    labourerId: v.id("labourers"),
    daysWorked: v.number(),
    halfDays: v.number(),
    dailyRate: v.number(),
    grossAmount: v.number(),
    deductions: v.number(),
    netAmount: v.number(),
    paymentMode: v.optional(v.string()),
    notes: v.optional(v.string()),
    // Nasta (food allowance)
    nastaDays: v.optional(v.number()),
    nastaPerDay: v.optional(v.number()),
    nastaAmount: v.optional(v.number()),
  }).index("by_salary_sheet", ["salarySheetId"]),

  // Invoices (to clients)
  invoices: defineTable({
    invoiceNumber: v.string(),
    siteId: v.id("sites"),
    clientId: v.id("clients"),
    workOrderId: v.optional(v.id("workOrders")),
    issueDate: v.string(),
    dueDate: v.optional(v.string()),
    items: v.array(
      v.object({
        description: v.string(),
        quantity: v.number(),
        unit: v.string(),
        rate: v.number(),
        amount: v.number(),
      })
    ),
    subtotal: v.number(),
    taxPercent: v.number(),
    taxAmount: v.number(),
    totalAmount: v.number(),
    status: v.union(
      v.literal("draft"),
      v.literal("sent"),
      v.literal("partial"),
      v.literal("paid"),
      v.literal("overdue"),
      v.literal("cancelled")
    ),
    paidAmount: v.number(),
    notes: v.optional(v.string()),
  })
    .index("by_site", ["siteId"])
    .index("by_client", ["clientId"])
    .index("by_invoice_number", ["invoiceNumber"]),

  // Screensaver slides (admin managed)
  screensaverSlides: defineTable({
    siteId: v.optional(v.id("sites")),
    title: v.string(),
    subtitle: v.optional(v.string()),
    imageStorageId: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    order: v.number(),
    isActive: v.boolean(),
    addedBy: v.id("users"),
  }).index("by_order", ["order"]),

  // Screensaver settings
  screensaverSettings: defineTable({
    idleMinutes: v.number(),
    transitionSeconds: v.number(),
    showStats: v.boolean(),
    theme: v.union(v.literal("dark"), v.literal("light"), v.literal("blur")),
    updatedBy: v.id("users"),
  }),

  // Site expenses (per-site cost tracking)
  siteExpenses: defineTable({
    siteId: v.id("sites"),
    category: v.union(
      v.literal("materials"),
      v.literal("labour_salary"),
      v.literal("contractor_bill"),
      v.literal("transport"),
      v.literal("food_snacks"),
      v.literal("water"),
      v.literal("equipment"),
      v.literal("misc")
    ),
    amount: v.number(),
    description: v.string(),
    date: v.string(),
    vendorName: v.optional(v.string()),
    receiptStorageId: v.optional(v.string()),
    addedBy: v.id("users"),
    workOrderId: v.optional(v.id("workOrders")),
  })
    .index("by_site", ["siteId"])
    .index("by_site_category", ["siteId", "category"]),

  // In-app notifications
  notifications: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("payment_received"),
      v.literal("payment_made"),
      v.literal("work_order_issued"),
      v.literal("work_order_amended"),
      v.literal("salary_processed"),
      v.literal("salary_approved"),
      v.literal("material_approved"),
      v.literal("material_rejected"),
      v.literal("invoice_sent"),
      v.literal("invoice_overdue")
    ),
    title: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    link: v.optional(v.string()), // relative URL to navigate to
    relatedId: v.optional(v.string()), // related document id
  })
    .index("by_user", ["userId"])
    .index("by_user_read", ["userId", "isRead"]),

  // Notification preferences per user
  notificationPreferences: defineTable({
    userId: v.id("users"),
    emailEnabled: v.boolean(),
    inAppEnabled: v.boolean(),
    events: v.object({
      payment_received: v.boolean(),
      payment_made: v.boolean(),
      work_order_issued: v.boolean(),
      work_order_amended: v.boolean(),
      salary_processed: v.boolean(),
      salary_approved: v.boolean(),
      material_approved: v.boolean(),
      material_rejected: v.boolean(),
      invoice_sent: v.boolean(),
      invoice_overdue: v.boolean(),
    }),
    emailAddress: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  // Payments (from clients or to suppliers/contractors)
  payments: defineTable({
    type: v.union(v.literal("received"), v.literal("paid")),
    siteId: v.id("sites"),
    amount: v.number(),
    date: v.string(),
    mode: v.union(
      v.literal("cash"),
      v.literal("cheque"),
      v.literal("neft"),
      v.literal("rtgs"),
      v.literal("upi"),
      v.literal("other")
    ),
    referenceNumber: v.optional(v.string()),
    // For received: from client
    clientId: v.optional(v.id("clients")),
    invoiceId: v.optional(v.id("invoices")),
    // For paid: to supplier or contractor
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    materialId: v.optional(v.id("materials")),
    workOrderId: v.optional(v.id("workOrders")),
    notes: v.optional(v.string()),
    recordedBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_type", ["type"])
    .index("by_work_order", ["workOrderId"]),

  // Vendor Bills (from suppliers and contractors)
  vendorBills: defineTable({
    billNumber: v.string(),
    siteId: v.id("sites"),
    companyId: v.id("companies"),
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    purchaseOrderId: v.optional(v.id("purchaseOrders")),
    workOrderId: v.optional(v.id("workOrders")),
    materialId: v.optional(v.id("materials")),
    // RA Bill fields
    billType: v.optional(v.union(v.literal("ra"), v.literal("final"), v.literal("regular"))),
    raNumber: v.optional(v.number()), // 1 = RA-1, 2 = RA-2, etc.
    raBillItems: v.optional(v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      orderQty: v.number(),
      thisBillQty: v.number(),
      ratePerUnit: v.number(),
      thisBillAmount: v.number(),
    }))),
    billDate: v.string(),
    dueDate: v.optional(v.string()),
    // Generic line items for regular bills/invoices (item, unit, qty, rate)
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    subtotal: v.number(),
    gstPercent: v.number(),
    gstAmount: v.number(),
    totalAmount: v.number(),
    retentionPercent: v.optional(v.number()),
    retentionAmount: v.optional(v.number()),
    balancePayable: v.optional(v.number()),
    paidAmount: v.number(),
    status: v.union(
      v.literal("received"),
      v.literal("verified"),
      v.literal("approved"),
      v.literal("paid"),
      v.literal("disputed")
    ),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    // File attachments (photos, PDFs, Excel scans uploaded by vendor/admin)
    attachments: v.optional(v.array(v.object({
      storageId: v.id("_storage"),
      fileName: v.string(),
      fileType: v.string(), // MIME type
      fileSize: v.number(),
      uploadedAt: v.string(),
    }))),
    verifiedBy: v.optional(v.id("users")),
    approvedBy: v.optional(v.id("users")),
    createdBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_supplier", ["supplierId"])
    .index("by_contractor", ["contractorId"])
    .index("by_status", ["status"])
    .index("by_po", ["purchaseOrderId"])
    .index("by_bill_number", ["billNumber"]),

  // Site Expenses (petty cash, food, water, transport, diesel, etc.)
  expenses: defineTable({
    siteId: v.id("sites"),
    enteredBy: v.id("users"),
    date: v.string(),
    category: v.union(
      v.literal("food"),
      v.literal("water"),
      v.literal("transport"),
      v.literal("diesel"),
      v.literal("tools"),
      v.literal("safety"),
      v.literal("electricity"),
      v.literal("rent"),
      v.literal("miscellaneous")
    ),
    description: v.string(),
    amount: v.number(),
    paymentMode: v.union(
      v.literal("cash"),
      v.literal("upi"),
      v.literal("other")
    ),
    notes: v.optional(v.string()),
  })
    .index("by_site", ["siteId"])
    .index("by_site_date", ["siteId", "date"])
    .index("by_site_category", ["siteId", "category"]),

  // Delivery Challans — submitted by site supervisors, approved by admin
  deliveryChallans: defineTable({
    siteId: v.id("sites"),
    submittedBy: v.id("users"),
    vehicleNumber: v.string(),
    driverName: v.optional(v.string()),
    supplierId: v.optional(v.id("suppliers")),
    deliveryDate: v.string(),
    materialType: v.string(),
    quantity: v.string(),
    unit: v.string(),
    notes: v.optional(v.string()),
    photoStorageIds: v.optional(v.array(v.string())),
    status: v.union(
      v.literal("pending"),
      v.literal("approved"),
      v.literal("rejected")
    ),
    approvedBy: v.optional(v.id("users")),
    rejectionNote: v.optional(v.string()),
    linkedMaterialId: v.optional(v.id("materials")),
  })
    .index("by_site", ["siteId"])
    .index("by_status", ["status"])
    .index("by_submitted_by", ["submittedBy"]),

  // Labour Correction Requests — submitted by labour via portal
  labourCorrectionRequests: defineTable({
    labourerId: v.id("labourers"),
    token: v.string(), // labourer portal token for quick lookup
    requestType: v.union(
      v.literal("attendance"),
      v.literal("advance"),
      v.literal("salary"),
      v.literal("other")
    ),
    month: v.string(), // YYYY-MM
    description: v.string(), // what is wrong
    photoStorageIds: v.optional(v.array(v.string())), // hajri card photos
    status: v.union(
      v.literal("pending"),
      v.literal("resolved"),
      v.literal("rejected")
    ),
    adminNote: v.optional(v.string()),
    resolvedBy: v.optional(v.id("users")),
    resolvedAt: v.optional(v.string()),
  })
    .index("by_labourer", ["labourerId"])
    .index("by_token", ["token"])
    .index("by_status", ["status"]),

  // PPE Stock — helmet, shoes, goggles, gloves, etc.
  ppeStock: defineTable({
    siteId: v.id("sites"),
    itemName: v.string(), // "Helmet", "Safety Shoes", "Goggles", etc.
    category: v.union(
      v.literal("helmet"),
      v.literal("safety_shoes"),
      v.literal("goggles"),
      v.literal("gloves"),
      v.literal("jacket"),
      v.literal("harness"),
      v.literal("mask"),
      v.literal("other")
    ),
    totalQuantity: v.number(),
    availableQuantity: v.number(), // total - distributed
    purchaseDate: v.optional(v.string()),
    supplierId: v.optional(v.id("suppliers")),
    costPerUnit: v.optional(v.number()),
    totalCost: v.optional(v.number()),
    notes: v.optional(v.string()),
    addedBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_site_category", ["siteId", "category"]),

  // PPE Distribution — kisko kya diya
  ppeDistributions: defineTable({
    ppeStockId: v.id("ppeStock"),
    siteId: v.id("sites"),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    itemName: v.string(),
    quantity: v.number(),
    distributedDate: v.string(),
    returnDate: v.optional(v.string()),
    condition: v.optional(v.union(v.literal("new"), v.literal("used"), v.literal("damaged"))),
    notes: v.optional(v.string()),
    distributedBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_stock", ["ppeStockId"])
    .index("by_labourer", ["labourerId"])
    .index("by_contractor", ["contractorId"]),

  // Safety Violations — photo + penalty
  safetyViolations: defineTable({
    siteId: v.id("sites"),
    violationDate: v.string(),
    description: v.string(),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    penaltyAmount: v.optional(v.number()),
    penaltyStatus: v.union(v.literal("none"), v.literal("pending"), v.literal("paid")),
    photoStorageIds: v.optional(v.array(v.string())),
    severity: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    actionTaken: v.optional(v.string()),
    reportedBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_site_date", ["siteId", "violationDate"])
    .index("by_labourer", ["labourerId"])
    .index("by_contractor", ["contractorId"]),

  // Tools & Machines Inventory
  toolsInventory: defineTable({
    siteId: v.id("sites"),
    name: v.string(), // "CM4 Cutter", "Grinder", "Drill Machine"
    type: v.union(
      v.literal("cutter"),
      v.literal("grinder"),
      v.literal("drill"),
      v.literal("cable"),
      v.literal("welding"),
      v.literal("pump"),
      v.literal("generator"),
      v.literal("other")
    ),
    quantity: v.number(),
    unit: v.string(), // "nos", "meter" (for cable)
    condition: v.union(v.literal("good"), v.literal("repair"), v.literal("damaged")),
    purchaseDate: v.optional(v.string()),
    costPerUnit: v.optional(v.number()),
    serialNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
    addedBy: v.id("users"),
  })
    .index("by_site", ["siteId"])
    .index("by_site_type", ["siteId", "type"]),

  // BOQ (Bill of Quantities) — admin uploads, invites vendors to quote rates
  boqProjects: defineTable({
    title: v.string(),             // "Site A - Civil Work BOQ"
    siteId: v.optional(v.id("sites")),
    companyId: v.id("companies"),
    description: v.optional(v.string()),
    excelStorageId: v.string(),    // uploaded Excel file
    excelFileName: v.string(),
    items: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      nos: v.optional(v.number()),
      quantity: v.number(),
      rate: v.optional(v.number()),        // admin rate from Excel
      totalAmount: v.optional(v.number()), // qty * rate
    })),
    status: v.union(
      v.literal("draft"),
      v.literal("invited"),      // invitations sent
      v.literal("comparing"),    // at least one submission received
      v.literal("finalized"),    // admin finalized rates
      v.literal("ordered"),      // work/PO issued
    ),
    token: v.string(),            // public shareable token for vendor access
    deadlineDate: v.optional(v.string()),
    createdBy: v.id("users"),
    comparisonPublished: v.optional(v.boolean()), // when true, vendors can see L1/L2/L3
    comparisonPublishedAt: v.optional(v.string()),
    revisionDeadline: v.optional(v.string()),     // deadline for revised rates
  })
    .index("by_company", ["companyId"])
    .index("by_site", ["siteId"])
    .index("by_token", ["token"])
    .index("by_status", ["status"]),

  // BOQ Invitations — which vendor/supplier/contractor is invited
  boqInvitations: defineTable({
    boqId: v.id("boqProjects"),
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    vendorName: v.string(),
    vendorMobile: v.optional(v.string()),
    vendorEmail: v.optional(v.string()),
    token: v.optional(v.string()),   // unique per-vendor token for direct link
    status: v.union(
      v.literal("invited"),
      v.literal("viewed"),
      v.literal("submitted"),
      v.literal("selected"),
      v.literal("rejected"),
    ),
    invitedAt: v.string(),
    viewedAt: v.optional(v.string()),
    submittedAt: v.optional(v.string()),
  })
    .index("by_boq", ["boqId"])
    .index("by_token", ["token"])
    .index("by_supplier", ["supplierId"])
    .index("by_contractor", ["contractorId"]),

  // BOQ Rate Submissions — vendor fills rates and uploads
  boqSubmissions: defineTable({
    boqId: v.id("boqProjects"),
    invitationId: v.id("boqInvitations"),
    vendorName: v.string(),
    vendorMobile: v.optional(v.string()),
    items: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      totalAmount: v.number(),
      remarks: v.optional(v.string()),
    })),
    totalAmount: v.number(),
    excelStorageId: v.optional(v.string()),  // uploaded filled Excel
    excelFileName: v.optional(v.string()),
    notes: v.optional(v.string()),
    status: v.union(v.literal("submitted"), v.literal("selected"), v.literal("rejected")),
    submittedAt: v.string(),
  })
    .index("by_boq", ["boqId"])
    .index("by_invitation", ["invitationId"]),

  // Banks (per company)
  banks: defineTable({
    companyId: v.id("companies"),
    name: v.string(), // e.g. "HDFC Bank", "SBI", "ICICI"
    accountNumber: v.optional(v.string()),
  }).index("by_company", ["companyId"]),

  // Bank Statement Transactions
  bankStatements: defineTable({
    companyId: v.optional(v.id("companies")), // Each company has separate bank statements
    financialYear: v.string(), // "2026-27"
    bankName: v.string(), // e.g. "HDFC Bank", "SBI"
    accountNumber: v.optional(v.string()),
    date: v.string(), // YYYY-MM-DD
    narration: v.optional(v.string()),
    chequeNo: v.optional(v.string()),
    debit: v.optional(v.number()),
    credit: v.optional(v.number()),
    balance: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    category: v.optional(v.string()), // e.g. "Client Payment", "Vendor Payment", "Salary"
    remarks: v.optional(v.string()),
    addedBy: v.optional(v.id("users")),
  })
    .index("by_financial_year", ["financialYear"])
    .index("by_company_bank_fy", ["bankName", "financialYear"])
    .index("by_date", ["date"]),

  // GST Invoice Tracking (JAI AAINATH INTERIOR / JAI GANESH INTERIOR)
  gstInvoiceTracking: defineTable({
    financialYear: v.string(), // "2026-27"
    ourCompanyName: v.optional(v.string()), // "JAI AAINATH INTERIOR" or "JAI GANESH INTERIOR"
    serialNo: v.optional(v.number()),
    billNo: v.optional(v.string()),
    location: v.optional(v.string()),
    billJai: v.optional(v.string()), // BILL-JAI identifier e.g. "JAI", "A4 VI"
    siteCode: v.optional(v.string()), // Site code e.g. "T07", "A4 VI"
    poNo: v.optional(v.string()),
    companyName: v.string(), // e.g. "CAVALCADE PROPERTIES PVT LTD"
    billType: v.union(v.literal("FINAL"), v.literal("RA BILL"), v.literal("DRAFT")), // Final/RA Bill
    draftInvoiceNo: v.optional(v.string()),
    draftInvoiceDate: v.optional(v.string()), // YYYY-MM-DD
    invoiceStatus: v.union(v.literal("DRAFT"), v.literal("FINAL"), v.literal("SUBMITTED")),
    sesDone: v.optional(v.string()), // SES date or status
    caseId: v.optional(v.string()),
    taxInvoiceNo: v.optional(v.string()),
    taxInvoiceDate: v.optional(v.string()), // YYYY-MM-DD
    amount: v.number(), // base amount before GST
    gstPercent: v.number(), // default 18
    gstAmount: v.number(), // calculated
    billAmount: v.optional(v.number()), // Bill column
    retention: v.optional(v.number()),
    tds: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    utrDate: v.optional(v.string()),
    termsDays: v.optional(v.number()), // Terms of payment days
    dueDate: v.optional(v.string()), // YYYY-MM-DD
    // Payment Advice deductions (from Payment Advice document)
    advanceDeducted: v.optional(v.number()), // Advance recovery deducted
    vendorDocDeducted: v.optional(v.number()), // Vendor document deduction
    netPayable: v.optional(v.number()), // Net amount actually payable after all deductions
    paymentAdviceRef: v.optional(v.string()), // Reference no from Payment Advice doc
    remark: v.optional(v.string()),
    isOverdue: v.optional(v.boolean()),
    bankName: v.optional(v.string()), // Bank name for payment
    addedBy: v.optional(v.id("users")),
  })
    .index("by_financial_year", ["financialYear"])
    .index("by_company", ["companyName"])
    .index("by_our_company_fy", ["ourCompanyName", "financialYear"]),

  // Site Diary — daily progress log entries
  siteDiary: defineTable({
    siteId: v.id("sites"),
    date: v.string(), // YYYY-MM-DD
    weather: v.optional(v.union(
      v.literal("sunny"),
      v.literal("cloudy"),
      v.literal("rainy"),
      v.literal("stormy"),
      v.literal("foggy")
    )),
    manpowerCount: v.optional(v.number()),
    progressNotes: v.string(),
    issues: v.optional(v.string()),
    workDone: v.optional(v.string()),
    materialsUsed: v.optional(v.string()),
    visitorsOnSite: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("submitted"), v.literal("reviewed")),
    photoStorageIds: v.optional(v.array(v.string())),
    submittedBy: v.id("users"),
    reviewedBy: v.optional(v.id("users")),
    reviewNotes: v.optional(v.string()),
  })
    .index("by_site", ["siteId"])
    .index("by_site_date", ["siteId", "date"]),

  // Labour Self-Registration (public, no auth required)
  labourRegistrations: defineTable({
    name: v.string(),
    mobile: v.string(),
    aadhaarNumber: v.optional(v.string()),
    fatherName: v.optional(v.string()),
    age: v.optional(v.number()),
    address: v.optional(v.string()),
    designation: v.string(), // skill/work type: mason, painter, electrician, helper, etc.
    companyId: v.id("companies"),
    siteId: v.id("sites"),
    dailyRateExpected: v.optional(v.number()),
    experience: v.optional(v.string()), // years of experience
    previousWork: v.optional(v.string()), // where worked before
    photoStorageId: v.optional(v.string()),
    aadhaarStorageId: v.optional(v.string()),
    status: v.union(
      v.literal("pending_supervisor"),
      v.literal("supervisor_approved"),
      v.literal("supervisor_rejected"),
      v.literal("admin_approved"),
      v.literal("admin_rejected")
    ),
    supervisorNote: v.optional(v.string()),
    supervisorReviewedAt: v.optional(v.string()),
    adminNote: v.optional(v.string()),
    adminReviewedAt: v.optional(v.string()),
    createdLabourerId: v.optional(v.id("labourers")), // linked after final approval
  })
    .index("by_site", ["siteId"])
    .index("by_status", ["status"])
    .index("by_mobile", ["mobile"])
    .index("by_site_status", ["siteId", "status"]),

  // Labour GPS Location Check-ins
  locationCheckins: defineTable({
    labourerId: v.id("labourers"),
    siteId: v.id("sites"),
    latitude: v.number(),
    longitude: v.number(),
    isWithinGeofence: v.boolean(), // true = on site, false = off site
    distanceFromSite: v.number(), // meters
    checkinTime: v.string(), // ISO timestamp
    date: v.string(), // YYYY-MM-DD
    type: v.optional(v.union(v.literal("in"), v.literal("out"))), // IN or OUT punch
  })
    .index("by_labourer", ["labourerId"])
    .index("by_site_date", ["siteId", "date"])
    .index("by_labourer_date", ["labourerId", "date"]),

  // Incoming Invoice Tracker — bills received FROM suppliers/contractors TO our company
  incomingInvoices: defineTable({
    financialYear: v.string(),           // "2026-27"
    ourCompanyName: v.string(),          // "JAI AAINATH INTERIOR" / "JAI GANESH INTERIOR"
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    vendorName: v.string(),              // Supplier/Contractor name
    vendorId: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    siteName: v.optional(v.string()),
    billNo: v.string(),
    billDate: v.string(),
    dueDate: v.optional(v.string()),
    termsDays: v.optional(v.number()),
    // Item-wise entry (optional). When present, `amount` = sum of item amounts.
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    // Amounts
    amount: v.number(),
    gstPercent: v.number(),
    gstAmount: v.number(),
    totalAmount: v.number(),
    tds: v.optional(v.number()),
    retention: v.optional(v.number()),
    netPayable: v.optional(v.number()),
    paidAmount: v.optional(v.number()),
    // Payment
    utrNo: v.optional(v.string()),
    utrDate: v.optional(v.string()),
    bankName: v.optional(v.string()),
    // Approval workflow status
    // pending_site → pending_billing → pending_superadmin → pending_payment → paid | rejected
    approvalStatus: v.optional(v.union(
      v.literal("pending_site"),        // Waiting for Site Incharge
      v.literal("pending_billing"),     // Waiting for Billing Manager
      v.literal("pending_superadmin"),  // Waiting for Super Admin
      v.literal("pending_payment"),     // Waiting for Accounts Manager to pay
      v.literal("paid"),                // Payment done
      v.literal("rejected")            // Rejected at any stage
    )),
    // Per-stage approval trail
    siteInchargeApprovedBy: v.optional(v.id("users")),
    siteInchargeApprovedAt: v.optional(v.string()),
    siteInchargeNote: v.optional(v.string()),
    billingApprovedBy: v.optional(v.id("users")),
    billingApprovedAt: v.optional(v.string()),
    billingNote: v.optional(v.string()),
    superAdminApprovedBy: v.optional(v.id("users")),
    superAdminApprovedAt: v.optional(v.string()),
    superAdminNote: v.optional(v.string()),
    paidBy: v.optional(v.id("users")),
    paidAt: v.optional(v.string()),
    paymentNote: v.optional(v.string()),
    // Rejection
    rejectedBy: v.optional(v.id("users")),
    rejectedAt: v.optional(v.string()),
    rejectedStage: v.optional(v.string()), // which stage rejected
    rejectionReason: v.optional(v.string()),
    // Legacy status field kept for backward compat
    status: v.optional(v.string()),
    // Invoice Query
    invoiceQuery: v.optional(v.string()),
    remark: v.optional(v.string()),
    serialNo: v.optional(v.number()),
    createdBy: v.optional(v.id("users")),
  })
    .index("by_fy_company", ["financialYear", "ourCompanyName"])
    .index("by_vendor", ["vendorName"])
    .index("by_site", ["siteId"]),

  // Item Master Catalog — reusable items for bill/invoice line entry
  catalogItems: defineTable({
    name: v.string(),
    defaultUnit: v.string(),
    defaultRate: v.number(),
    category: v.optional(v.string()),
    hsnCode: v.optional(v.string()),
    isActive: v.boolean(),
    createdBy: v.optional(v.id("users")),
  })
    .index("by_name", ["name"])
    .index("by_active", ["isActive"]),
});
