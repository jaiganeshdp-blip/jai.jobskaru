import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import { ConvexError } from "convex/values";

// List all catalog items. Optionally only active ones (for pickers).
export const list = query({
  args: { activeOnly: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const items = await ctx.db.query("catalogItems").collect();
    const filtered = args.activeOnly ? items.filter((i) => i.isActive) : items;
    return filtered.sort((a, b) => a.name.localeCompare(b.name));
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    defaultUnit: v.string(),
    defaultRate: v.number(),
    category: v.optional(v.string()),
    hsnCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireSuperAdmin(ctx);
    const name = args.name.trim();
    if (!name) throw new ConvexError({ message: "Item name required", code: "BAD_REQUEST" });

    // Prevent duplicates (case-insensitive)
    const existing = await ctx.db.query("catalogItems").collect();
    if (existing.some((i) => i.name.trim().toLowerCase() === name.toLowerCase())) {
      throw new ConvexError({ message: "Yeh item pehle se maujood hai", code: "CONFLICT" });
    }

    return await ctx.db.insert("catalogItems", {
      name,
      defaultUnit: args.defaultUnit,
      defaultRate: args.defaultRate,
      category: args.category,
      hsnCode: args.hsnCode,
      isActive: true,
      createdBy: user._id,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("catalogItems"),
    name: v.optional(v.string()),
    defaultUnit: v.optional(v.string()),
    defaultRate: v.optional(v.number()),
    category: v.optional(v.string()),
    hsnCode: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    const existing = await ctx.db.get(id);
    if (!existing) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    await ctx.db.patch(id, { ...rest, name: rest.name?.trim() ?? existing.name });
  },
});

export const remove = mutation({
  args: { id: v.id("catalogItems") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
