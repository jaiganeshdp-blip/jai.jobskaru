import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx } from "./_generated/server";

async function requireAuth(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireAuth(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    status: v.optional(v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected"))),
  },
  handler: async (ctx, args): Promise<{
    _id: string;
    _creationTime: number;
    siteId: string;
    submittedBy: string;
    vehicleNumber: string;
    driverName?: string;
    supplierId?: string;
    deliveryDate: string;
    materialType: string;
    quantity: string;
    unit: string;
    notes?: string;
    photoStorageIds?: string[];
    status: "pending" | "approved" | "rejected";
    approvedBy?: string;
    rejectionNote?: string;
    linkedMaterialId?: string;
    siteName: string;
    submittedByName: string;
    supplierName?: string;
    photoUrls: (string | null)[];
  }[]> => {
    await requireAuth(ctx);

    let challans;
    if (args.siteId) {
      challans = await ctx.db
        .query("deliveryChallans")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .order("desc")
        .take(100);
    } else if (args.status) {
      challans = await ctx.db
        .query("deliveryChallans")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .take(100);
    } else {
      challans = await ctx.db.query("deliveryChallans").order("desc").take(100);
    }

    return await Promise.all(
      challans.map(async (c) => {
        const site = await ctx.db.get(c.siteId);
        const submitter = await ctx.db.get(c.submittedBy);
        const supplier = c.supplierId ? await ctx.db.get(c.supplierId) : null;
        const photoUrls = c.photoStorageIds
          ? await Promise.all(c.photoStorageIds.map((id) => ctx.storage.getUrl(id)))
          : [];
        return {
          ...c,
          siteName: site?.name ?? "Unknown",
          submittedByName: submitter?.name ?? "Unknown",
          supplierName: supplier?.name,
          photoUrls,
        };
      })
    );
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    vehicleNumber: v.string(),
    driverName: v.optional(v.string()),
    supplierId: v.optional(v.id("suppliers")),
    deliveryDate: v.string(),
    materialType: v.string(),
    quantity: v.string(),
    unit: v.string(),
    notes: v.optional(v.string()),
    photoStorageIds: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    return await ctx.db.insert("deliveryChallans", {
      ...args,
      submittedBy: user._id,
      status: "pending",
    });
  },
});

export const approve = mutation({
  args: { id: v.id("deliveryChallans") },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new ConvexError({ message: "Not authorized", code: "FORBIDDEN" });
    }
    await ctx.db.patch(args.id, { status: "approved", approvedBy: user._id });
  },
});

export const reject = mutation({
  args: { id: v.id("deliveryChallans"), rejectionNote: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new ConvexError({ message: "Not authorized", code: "FORBIDDEN" });
    }
    await ctx.db.patch(args.id, {
      status: "rejected",
      approvedBy: user._id,
      rejectionNote: args.rejectionNote,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("deliveryChallans") },
  handler: async (ctx, args) => {
    const user = await requireAuth(ctx);
    const challan = await ctx.db.get(args.id);
    if (!challan) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    if (user.role !== "super_admin" && challan.submittedBy !== user._id) {
      throw new ConvexError({ message: "Not authorized", code: "FORBIDDEN" });
    }
    // Delete photos from storage
    if (challan.photoStorageIds) {
      await Promise.all(challan.photoStorageIds.map((id) => ctx.storage.delete(id)));
    }
    await ctx.db.delete(args.id);
  },
});
