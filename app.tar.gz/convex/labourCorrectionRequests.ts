import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { MutationCtx } from "./_generated/server";

// Helper: get authenticated user
async function getUser(ctx: MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

// Generate upload URL (called from labour portal, no auth needed)
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// Labour submits a correction request via portal (token-based, no auth)
export const submitRequest = mutation({
  args: {
    token: v.string(),
    requestType: v.union(
      v.literal("attendance"),
      v.literal("advance"),
      v.literal("salary"),
      v.literal("other")
    ),
    month: v.string(),
    description: v.string(),
    photoStorageIds: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) throw new ConvexError({ message: "Invalid token", code: "NOT_FOUND" });

    return await ctx.db.insert("labourCorrectionRequests", {
      labourerId: labourer._id,
      token: args.token,
      requestType: args.requestType,
      month: args.month,
      description: args.description,
      photoStorageIds: args.photoStorageIds,
      status: "pending",
    });
  },
});

// Labour views their own requests via portal
export const getByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const requests = await ctx.db
      .query("labourCorrectionRequests")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .order("desc")
      .collect();

    return await Promise.all(
      requests.map(async (r) => {
        const photos = r.photoStorageIds
          ? await Promise.all(r.photoStorageIds.map((id) => ctx.storage.getUrl(id)))
          : [];
        return { ...r, photoUrls: photos.filter(Boolean) as string[] };
      })
    );
  },
});

// Admin: list all correction requests
export const list = query({
  args: {
    status: v.optional(v.union(
      v.literal("pending"),
      v.literal("resolved"),
      v.literal("rejected")
    )),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    let req;
    if (args.status) {
      req = await ctx.db
        .query("labourCorrectionRequests")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .collect();
    } else {
      req = await ctx.db.query("labourCorrectionRequests").order("desc").collect();
    }

    return await Promise.all(
      req.map(async (r) => {
        const labourer = await ctx.db.get(r.labourerId);
        const photos = r.photoStorageIds
          ? await Promise.all(r.photoStorageIds.map((id) => ctx.storage.getUrl(id)))
          : [];
        return {
          ...r,
          labourerName: labourer?.name ?? "Unknown",
          labourerMobile: labourer?.mobile,
          photoUrls: photos.filter(Boolean) as string[],
        };
      })
    );
  },
});

// Admin: resolve or reject
export const updateStatus = mutation({
  args: {
    id: v.id("labourCorrectionRequests"),
    status: v.union(v.literal("resolved"), v.literal("rejected")),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getUser(ctx);
    const req = await ctx.db.get(args.id);
    if (!req) throw new ConvexError({ message: "Request not found", code: "NOT_FOUND" });

    await ctx.db.patch(args.id, {
      status: args.status,
      adminNote: args.adminNote,
      resolvedBy: user._id,
      resolvedAt: new Date().toISOString(),
    });
  },
});
