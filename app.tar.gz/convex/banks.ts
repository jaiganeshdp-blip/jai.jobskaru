import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args): Promise<Doc<"banks">[]> => {
    return await ctx.db
      .query("banks")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
  },
});

export const create = mutation({
  args: {
    companyId: v.id("companies"),
    name: v.string(),
    accountNumber: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"banks">> => {
    // Check for duplicate bank name in same company
    const existing = await ctx.db
      .query("banks")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
    const duplicate = existing.find(
      (b) => b.name.toLowerCase().trim() === args.name.toLowerCase().trim()
    );
    if (duplicate) {
      throw new Error("Is naam ki bank pehle se hai");
    }
    return await ctx.db.insert("banks", {
      companyId: args.companyId,
      name: args.name.trim(),
      accountNumber: args.accountNumber?.trim() || undefined,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("banks") },
  handler: async (ctx, args): Promise<null> => {
    await ctx.db.delete(args.id);
    return null;
  },
});
