"use node";

import escapeHtml from "escape-html";
import { Hercules } from "@usehercules/sdk";
import { v } from "convex/values";
import { internalAction } from "./_generated/server";

const hercules = new Hercules({
  apiKey: process.env.HERCULES_API_KEY!,
  apiVersion: "2025-12-09",
});

// Generic email sender used by all notification triggers
export const sendNotificationEmail = internalAction({
  args: {
    to: v.string(),
    subject: v.string(),
    title: v.string(),
    message: v.string(),
    ctaLabel: v.optional(v.string()),
    ctaUrl: v.optional(v.string()),
    senderEmail: v.string(),
  },
  handler: async (_ctx, args) => {
    const cta = args.ctaLabel && args.ctaUrl
      ? `<p style="margin-top:24px;text-align:center;">
           <a href="${escapeHtml(args.ctaUrl)}" style="background:#2563eb;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600;">
             ${escapeHtml(args.ctaLabel)}
           </a>
         </p>`
      : "";

    const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif;">
  <div style="max-width:560px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
    <div style="background:#1e293b;padding:24px;text-align:center;">
      <span style="color:#f59e0b;font-size:22px;font-weight:700;letter-spacing:1px;">JAI SITE MANAGER ERP</span>
    </div>
    <div style="padding:32px;">
      <h2 style="margin:0 0 12px;font-size:20px;color:#0f172a;">${escapeHtml(args.title)}</h2>
      <p style="color:#475569;line-height:1.6;margin:0 0 16px;">${escapeHtml(args.message)}</p>
      ${cta}
    </div>
    <div style="padding:16px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;">
      <p style="color:#94a3b8;font-size:12px;margin:0;">You're receiving this because you have notifications enabled in JAI SITE MANAGER ERP.</p>
    </div>
  </div>
</body>
</html>`;

    try {
      await hercules.email.send({
        from: args.senderEmail,
        to: args.to,
        subject: args.subject,
        html,
      });
    } catch (err) {
      // Log but don't throw — email failure shouldn't break the main flow
      console.error("Email send failed:", err);
    }
  },
});
