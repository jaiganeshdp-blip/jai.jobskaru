import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: { companyId: v.optional(v.id("companies")) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (args.companyId) {
      return await ctx.db
        .query("sites")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId!))
        .collect();
    }
    if (user.role === "site_incharge" && user.assignedSiteId) {
      const site = await ctx.db.get(user.assignedSiteId);
      return site ? [site] : [];
    }
    return await ctx.db.query("sites").collect();
  },
});

export const get = query({
  args: { id: v.id("sites") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

type SiteDetail = {
  site: Doc<"sites">;
  company: Doc<"companies"> | null;
  client: Doc<"clients"> | null;
  siteIncharge: Doc<"users"> | null;
  siteInchargeLabourer: Doc<"labourers"> | null;
  siteSupervisors: Array<Doc<"users">>;
  siteSupervisorLabourers: Array<Doc<"labourers">>;
  labourCount: number;
  activeLabourCount: number;
  workOrderCount: number;
  totalWorkOrderValue: number;
  materialCount: number;
  totalMaterialValue: number;
  pendingMaterialCount: number;
  recentWorkOrders: Array<{
    _id: Id<"workOrders">;
    orderNumber: string;
    description: string;
    totalValue: number;
    status: string;
    issueDate: string;
  }>;
};

// Detailed site info with related counts and totals
export const getDetail = query({
  args: { id: v.id("sites") },
  handler: async (ctx, args): Promise<SiteDetail | null> => {
    await getCurrentUser(ctx);
    const site = await ctx.db.get(args.id);
    if (!site) return null;

    const company = await ctx.db.get(site.companyId);
    const client = site.clientId ? await ctx.db.get(site.clientId) : null;
    const siteIncharge = site.siteInchargeId ? await ctx.db.get(site.siteInchargeId) : null;
    const siteInchargeLabourer = site.siteInchargeLabourerId ? await ctx.db.get(site.siteInchargeLabourerId) : null;
    const siteSupervisors: Array<Doc<"users">> = [];
    if (site.siteSupervisorIds?.length) {
      for (const supId of site.siteSupervisorIds) {
        const sup = await ctx.db.get(supId);
        if (sup) siteSupervisors.push(sup);
      }
    }
    const siteSupervisorLabourers: Array<Doc<"labourers">> = [];
    if (site.siteSupervisorLabourerIds?.length) {
      for (const labId of site.siteSupervisorLabourerIds) {
        const lab = await ctx.db.get(labId);
        if (lab) siteSupervisorLabourers.push(lab);
      }
    }

    // Labour stats
    const labourers = await ctx.db.query("labourers").withIndex("by_site", (q) => q.eq("siteId", args.id)).collect();
    const labourCount = labourers.length;
    const activeLabourCount = labourers.filter((l) => l.isActive).length;

    // Work order stats
    const workOrders = await ctx.db.query("workOrders").withIndex("by_site", (q) => q.eq("siteId", args.id)).collect();
    const workOrderCount = workOrders.length;
    const totalWorkOrderValue = workOrders.reduce((sum, wo) => sum + wo.totalValue, 0);
    const recentWorkOrders = workOrders
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .slice(0, 5)
      .map((wo) => ({
        _id: wo._id,
        orderNumber: wo.orderNumber,
        description: wo.description,
        totalValue: wo.totalValue,
        status: wo.status,
        issueDate: wo.issueDate,
      }));

    // Material stats
    const materials = await ctx.db.query("materials").withIndex("by_site", (q) => q.eq("siteId", args.id)).collect();
    const materialCount = materials.length;
    const totalMaterialValue = materials.reduce((sum, m) => sum + m.totalAmount, 0);
    const pendingMaterialCount = materials.filter((m) => m.status === "pending").length;

    return {
      site,
      company,
      client,
      siteIncharge,
      siteInchargeLabourer,
      siteSupervisors,
      siteSupervisorLabourers,
      labourCount,
      activeLabourCount,
      workOrderCount,
      totalWorkOrderValue,
      materialCount,
      totalMaterialValue,
      pendingMaterialCount,
      recentWorkOrders,
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    companyId: v.id("companies"),
    clientId: v.optional(v.id("clients")),
    city: v.string(),
    address: v.optional(v.string()),
    siteInchargeId: v.optional(v.id("users")),
    siteInchargeLabourerId: v.optional(v.id("labourers")),
    siteSupervisorIds: v.optional(v.array(v.id("users"))),
    siteSupervisorLabourerIds: v.optional(v.array(v.id("labourers"))),
    status: v.union(
      v.literal("planning"),
      v.literal("active"),
      v.literal("on_hold"),
      v.literal("completed")
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    return await ctx.db.insert("sites", args);
  },
});

export const update = mutation({
  args: {
    id: v.id("sites"),
    name: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    clientId: v.optional(v.id("clients")),
    city: v.optional(v.string()),
    address: v.optional(v.string()),
    siteInchargeId: v.optional(v.id("users")),
    siteInchargeLabourerId: v.optional(v.id("labourers")),
    siteSupervisorIds: v.optional(v.array(v.id("users"))),
    siteSupervisorLabourerIds: v.optional(v.array(v.id("labourers"))),
    status: v.optional(
      v.union(
        v.literal("planning"),
        v.literal("active"),
        v.literal("on_hold"),
        v.literal("completed")
      )
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    description: v.optional(v.string()),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
    geofenceRadius: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("sites") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
