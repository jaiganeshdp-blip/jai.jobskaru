import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";

// Helper: get current user
async function getCurrentUser(ctx: MutationCtx | QueryCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  return await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
}

// Helper to normalize approvalStatus (old docs without it = pending_site)
type ApprovalStatus = "pending_site" | "pending_billing" | "pending_superadmin" | "pending_payment" | "paid" | "rejected";
function getStatus(r: { approvalStatus?: ApprovalStatus | null }): ApprovalStatus {
  return r.approvalStatus ?? "pending_site";
}

// ── List ────────────────────────────────────────────────────────────────────
export const list = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
    vendorType: v.optional(v.union(v.literal("supplier"), v.literal("contractor"))),
    vendorName: v.optional(v.string()),
    approvalStatus: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    let rows;
    if (args.financialYear && args.ourCompanyName) {
      rows = await ctx.db
        .query("incomingInvoices")
        .withIndex("by_fy_company", (q) =>
          q.eq("financialYear", args.financialYear!).eq("ourCompanyName", args.ourCompanyName!)
        )
        .order("desc")
        .collect();
    } else {
      rows = await ctx.db.query("incomingInvoices").order("desc").collect();
    }

    if (args.vendorType) rows = rows.filter((r) => r.vendorType === args.vendorType);
    if (args.vendorName) rows = rows.filter((r) => r.vendorName === args.vendorName);
    if (args.approvalStatus) rows = rows.filter((r) => getStatus(r) === args.approvalStatus);

    // Enrich with approver names
    const userIds = new Set<string>();
    for (const r of rows) {
      if (r.siteInchargeApprovedBy) userIds.add(r.siteInchargeApprovedBy);
      if (r.billingApprovedBy) userIds.add(r.billingApprovedBy);
      if (r.superAdminApprovedBy) userIds.add(r.superAdminApprovedBy);
      if (r.paidBy) userIds.add(r.paidBy);
      if (r.rejectedBy) userIds.add(r.rejectedBy);
      if (r.createdBy) userIds.add(r.createdBy);
    }
    const userMap = new Map<string, string>();
    for (const uid of userIds) {
      const u = await ctx.db.get(uid as Id<"users">);
      if (u) userMap.set(uid, u.name ?? u.email ?? "Unknown");
    }

    return rows.map((r) => ({
      ...r,
      approvalStatus: getStatus(r),
      siteInchargeApprovedByName: r.siteInchargeApprovedBy ? userMap.get(r.siteInchargeApprovedBy) : undefined,
      billingApprovedByName: r.billingApprovedBy ? userMap.get(r.billingApprovedBy) : undefined,
      superAdminApprovedByName: r.superAdminApprovedBy ? userMap.get(r.superAdminApprovedBy) : undefined,
      paidByName: r.paidBy ? userMap.get(r.paidBy) : undefined,
      rejectedByName: r.rejectedBy ? userMap.get(r.rejectedBy) : undefined,
      createdByName: r.createdBy ? userMap.get(r.createdBy) : undefined,
    }));
  },
});

// List pending for a specific site (for site incharge)
export const listPendingForSite = query({
  args: { siteId: v.id("sites") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("incomingInvoices")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .order("desc")
      .collect();
    return rows.filter((r) => getStatus(r) === "pending_site");
  },
});

// ── Summary ─────────────────────────────────────────────────────────────────
export const summary = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
    vendorType: v.optional(v.union(v.literal("supplier"), v.literal("contractor"))),
    vendorName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    let rows;
    if (args.financialYear && args.ourCompanyName) {
      rows = await ctx.db
        .query("incomingInvoices")
        .withIndex("by_fy_company", (q) =>
          q.eq("financialYear", args.financialYear!).eq("ourCompanyName", args.ourCompanyName!)
        )
        .collect();
    } else {
      rows = await ctx.db.query("incomingInvoices").collect();
    }

    if (args.vendorType) rows = rows.filter((r) => r.vendorType === args.vendorType);
    if (args.vendorName) rows = rows.filter((r) => r.vendorName === args.vendorName);

    let totalAmount = 0, totalGst = 0, totalBill = 0, totalTds = 0, totalRetention = 0, totalPaid = 0, overdueCount = 0;
    const stageCounts = { pending_site: 0, pending_billing: 0, pending_superadmin: 0, pending_payment: 0, paid: 0, rejected: 0 };
    const today = new Date();

    for (const r of rows) {
      totalAmount += r.amount;
      totalGst += r.gstAmount;
      totalBill += r.totalAmount;
      totalTds += r.tds ?? 0;
      totalRetention += r.retention ?? 0;
      totalPaid += r.paidAmount ?? 0;
      if (r.dueDate && r.approvalStatus !== "paid") {
        const due = new Date(r.dueDate);
        if (due < today) overdueCount++;
      }
      stageCounts[getStatus(r)]++;
    }

    return { totalAmount, totalGst, totalBill, totalTds, totalRetention, totalPaid, overdueCount, count: rows.length, stageCounts };
  },
});

// ── Distinct vendors ─────────────────────────────────────────────────────────
export const distinctVendors = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
    vendorType: v.optional(v.union(v.literal("supplier"), v.literal("contractor"))),
  },
  handler: async (ctx, args) => {
    let rows;
    if (args.financialYear && args.ourCompanyName) {
      rows = await ctx.db
        .query("incomingInvoices")
        .withIndex("by_fy_company", (q) =>
          q.eq("financialYear", args.financialYear!).eq("ourCompanyName", args.ourCompanyName!)
        )
        .collect();
    } else {
      rows = await ctx.db.query("incomingInvoices").collect();
    }
    const filtered = args.vendorType ? rows.filter((r) => r.vendorType === args.vendorType) : rows;
    return [...new Set(filtered.map((r) => r.vendorName))].sort();
  },
});

// ── Create ───────────────────────────────────────────────────────────────────
export const create = mutation({
  args: {
    financialYear: v.string(),
    ourCompanyName: v.string(),
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    vendorName: v.string(),
    vendorId: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    siteName: v.optional(v.string()),
    billNo: v.string(),
    billDate: v.string(),
    dueDate: v.optional(v.string()),
    termsDays: v.optional(v.number()),
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    amount: v.number(),
    gstPercent: v.number(),
    tds: v.optional(v.number()),
    retention: v.optional(v.number()),
    invoiceQuery: v.optional(v.string()),
    remark: v.optional(v.string()),
    serialNo: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    // If item-wise entry provided, derive amount from item totals.
    const itemsTotal = (args.lineItems ?? []).reduce((s, it) => s + (it.amount || 0), 0);
    const baseAmount = (args.lineItems && args.lineItems.length > 0) ? itemsTotal : args.amount;
    const gstAmount = Math.round((baseAmount * args.gstPercent) / 100);
    const totalAmount = baseAmount + gstAmount;
    const netPayable = totalAmount - (args.tds ?? 0) - (args.retention ?? 0);

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    return await ctx.db.insert("incomingInvoices", {
      ...args,
      amount: baseAmount,
      gstAmount,
      totalAmount,
      netPayable,
      approvalStatus: "pending_site",
      createdBy: user?._id,
    });
  },
});

// ── Update basic fields (super admin only) ───────────────────────────────────
export const update = mutation({
  args: {
    id: v.id("incomingInvoices"),
    vendorType: v.optional(v.union(v.literal("supplier"), v.literal("contractor"))),
    vendorName: v.optional(v.string()),
    vendorId: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    siteName: v.optional(v.string()),
    billNo: v.optional(v.string()),
    billDate: v.optional(v.string()),
    dueDate: v.optional(v.string()),
    termsDays: v.optional(v.number()),
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    amount: v.optional(v.number()),
    gstPercent: v.optional(v.number()),
    tds: v.optional(v.number()),
    retention: v.optional(v.number()),
    invoiceQuery: v.optional(v.string()),
    remark: v.optional(v.string()),
    serialNo: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const existing = await ctx.db.get(id);
    if (!existing) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });

    // If item-wise entry provided, derive amount from item totals.
    const itemsTotal = (rest.lineItems ?? []).reduce((s, it) => s + (it.amount || 0), 0);
    const newAmount = (rest.lineItems && rest.lineItems.length > 0)
      ? itemsTotal
      : (rest.amount ?? existing.amount);
    const newGstPercent = rest.gstPercent ?? existing.gstPercent;
    const gstAmount = Math.round((newAmount * newGstPercent) / 100);
    const totalAmount = newAmount + gstAmount;
    const newTds = rest.tds ?? existing.tds ?? 0;
    const newRetention = rest.retention ?? existing.retention ?? 0;
    const netPayable = totalAmount - newTds - newRetention;

    await ctx.db.patch(id, { ...rest, amount: newAmount, gstAmount, totalAmount, netPayable });
  },
});

// ── APPROVAL MUTATIONS ────────────────────────────────────────────────────────

// Stage 1: Site Incharge Approve/Reject
export const siteInchargeApprove = mutation({
  args: {
    id: v.id("incomingInvoices"),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "site_incharge" && user.role !== "super_admin")
      throw new ConvexError({ message: "Only Site Incharge can approve", code: "FORBIDDEN" });

    const invoice = await ctx.db.get(args.id);
    if (!invoice) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    if (invoice.approvalStatus !== "pending_site" && (invoice.approvalStatus !== undefined || getStatus(invoice) !== "pending_site"))
      if (getStatus(invoice) !== "pending_site")
        throw new ConvexError({ message: "Invoice is not pending site approval", code: "BAD_REQUEST" });

    // Site incharge can only approve their own site's invoices
    if (user.role === "site_incharge" && invoice.siteId && user.assignedSiteId !== invoice.siteId)
      throw new ConvexError({ message: "You can only approve invoices for your assigned site", code: "FORBIDDEN" });

    await ctx.db.patch(args.id, {
      approvalStatus: "pending_billing",
      siteInchargeApprovedBy: user._id,
      siteInchargeApprovedAt: new Date().toISOString(),
      siteInchargeNote: args.note,
    });
  },
});

export const siteInchargeReject = mutation({
  args: {
    id: v.id("incomingInvoices"),
    reason: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "site_incharge" && user.role !== "super_admin")
      throw new ConvexError({ message: "Only Site Incharge can reject", code: "FORBIDDEN" });

    const invoice = await ctx.db.get(args.id);
    if (!invoice) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });

    await ctx.db.patch(args.id, {
      approvalStatus: "rejected",
      rejectedBy: user._id,
      rejectedAt: new Date().toISOString(),
      rejectedStage: "site_incharge",
      rejectionReason: args.reason,
    });
  },
});

// Stage 2: Billing Manager Approve/Reject
export const billingApprove = mutation({
  args: {
    id: v.id("incomingInvoices"),
    note: v.optional(v.string()),
    tds: v.optional(v.number()),
    retention: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "billing_manager" && user.role !== "super_admin")
      throw new ConvexError({ message: "Only Billing Manager can approve", code: "FORBIDDEN" });

    const invoice = await ctx.db.get(args.id);
    if (!invoice) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    if (getStatus(invoice) !== "pending_billing")
      throw new ConvexError({ message: "Invoice is not pending billing approval", code: "BAD_REQUEST" });

    const tds = args.tds ?? invoice.tds ?? 0;
    const retention = args.retention ?? invoice.retention ?? 0;
    const netPayable = invoice.totalAmount - tds - retention;

    await ctx.db.patch(args.id, {
      approvalStatus: "pending_superadmin",
      billingApprovedBy: user._id,
      billingApprovedAt: new Date().toISOString(),
      billingNote: args.note,
      tds,
      retention,
      netPayable,
    });
  },
});

export const billingReject = mutation({
  args: { id: v.id("incomingInvoices"), reason: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "billing_manager" && user.role !== "super_admin")
      throw new ConvexError({ message: "Only Billing Manager can reject", code: "FORBIDDEN" });

    await ctx.db.patch(args.id, {
      approvalStatus: "rejected",
      rejectedBy: user._id,
      rejectedAt: new Date().toISOString(),
      rejectedStage: "billing_manager",
      rejectionReason: args.reason,
    });
  },
});

// Stage 3: Super Admin Approve/Reject
export const superAdminApprove = mutation({
  args: { id: v.id("incomingInvoices"), note: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "super_admin")
      throw new ConvexError({ message: "Only Super Admin can approve", code: "FORBIDDEN" });

    const invoice = await ctx.db.get(args.id);
    if (!invoice) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    if (getStatus(invoice) !== "pending_superadmin")
      throw new ConvexError({ message: "Invoice is not pending Super Admin approval", code: "BAD_REQUEST" });

    await ctx.db.patch(args.id, {
      approvalStatus: "pending_payment",
      superAdminApprovedBy: user._id,
      superAdminApprovedAt: new Date().toISOString(),
      superAdminNote: args.note,
    });
  },
});

export const superAdminReject = mutation({
  args: { id: v.id("incomingInvoices"), reason: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "super_admin")
      throw new ConvexError({ message: "Only Super Admin can reject", code: "FORBIDDEN" });

    await ctx.db.patch(args.id, {
      approvalStatus: "rejected",
      rejectedBy: user._id,
      rejectedAt: new Date().toISOString(),
      rejectedStage: "super_admin",
      rejectionReason: args.reason,
    });
  },
});

// Stage 4: Accounts Manager — Mark as Paid
export const markPaid = mutation({
  args: {
    id: v.id("incomingInvoices"),
    paidAmount: v.number(),
    utrNo: v.string(),
    utrDate: v.string(),
    bankName: v.optional(v.string()),
    paymentNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    if (user.role !== "accounts_manager" && user.role !== "super_admin")
      throw new ConvexError({ message: "Only Accounts Manager can record payment", code: "FORBIDDEN" });

    const invoice = await ctx.db.get(args.id);
    if (!invoice) throw new ConvexError({ message: "Not found", code: "NOT_FOUND" });
    if (getStatus(invoice) !== "pending_payment")
      throw new ConvexError({ message: "Invoice is not pending payment", code: "BAD_REQUEST" });

    await ctx.db.patch(args.id, {
      approvalStatus: "paid",
      paidAmount: args.paidAmount,
      utrNo: args.utrNo,
      utrDate: args.utrDate,
      bankName: args.bankName,
      paymentNote: args.paymentNote,
      paidBy: user._id,
      paidAt: new Date().toISOString(),
    });
  },
});

// Send back to previous stage (Super Admin override)
export const sendBack = mutation({
  args: {
    id: v.id("incomingInvoices"),
    toStage: v.union(
      v.literal("pending_site"),
      v.literal("pending_billing"),
      v.literal("pending_superadmin"),
      v.literal("pending_payment")
    ),
    reason: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || user.role !== "super_admin")
      throw new ConvexError({ message: "Only Super Admin can send back", code: "FORBIDDEN" });

    await ctx.db.patch(args.id, {
      approvalStatus: args.toStage,
      rejectionReason: undefined,
      rejectedBy: undefined,
      rejectedAt: undefined,
      rejectedStage: undefined,
      remark: args.reason,
    });
  },
});

// ── Remove ────────────────────────────────────────────────────────────────────
export const remove = mutation({
  args: { id: v.id("incomingInvoices") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.id);
  },
});
