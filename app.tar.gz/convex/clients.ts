import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.db.query("clients").collect();
  },
});

export const get = query({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

type ClientDetail = {
  client: Doc<"clients">;
  sites: Array<{
    _id: Id<"sites">;
    name: string;
    city: string;
    status: string;
  }>;
  workOrderCount: number;
  totalWorkOrderValue: number;
  invoiceCount: number;
  totalInvoiced: number;
  totalPaid: number;
  recentWorkOrders: Array<{
    _id: Id<"workOrders">;
    orderNumber: string;
    description: string;
    totalValue: number;
    status: string;
    issueDate: string;
  }>;
};

// Detailed client info with related sites and work orders
export const getDetail = query({
  args: { id: v.id("clients") },
  handler: async (ctx, args): Promise<ClientDetail | null> => {
    await getCurrentUser(ctx);
    const client = await ctx.db.get(args.id);
    if (!client) return null;

    // Sites linked to this client
    const allSites = await ctx.db.query("sites").withIndex("by_client", (q) => q.eq("clientId", args.id)).collect();
    const sites = allSites.map((s) => ({
      _id: s._id,
      name: s.name,
      city: s.city,
      status: s.status,
    }));

    // Work orders
    const workOrders = await ctx.db.query("workOrders").withIndex("by_client", (q) => q.eq("clientId", args.id)).collect();
    const workOrderCount = workOrders.length;
    const totalWorkOrderValue = workOrders.reduce((sum, wo) => sum + wo.totalValue, 0);
    const recentWorkOrders = workOrders
      .sort((a, b) => b.issueDate.localeCompare(a.issueDate))
      .slice(0, 5)
      .map((wo) => ({
        _id: wo._id,
        orderNumber: wo.orderNumber,
        description: wo.description,
        totalValue: wo.totalValue,
        status: wo.status,
        issueDate: wo.issueDate,
      }));

    // Invoices
    const invoices = await ctx.db.query("invoices").withIndex("by_client", (q) => q.eq("clientId", args.id)).collect();
    const invoiceCount = invoices.length;
    const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalPaid = invoices.reduce((sum, inv) => sum + inv.paidAmount, 0);

    return {
      client,
      sites,
      workOrderCount,
      totalWorkOrderValue,
      invoiceCount,
      totalInvoiced,
      totalPaid,
      recentWorkOrders,
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.string(),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    contactPerson: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    return await ctx.db.insert("clients", { ...args, isActive: true });
  },
});

export const update = mutation({
  args: {
    id: v.id("clients"),
    name: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    contactPerson: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
