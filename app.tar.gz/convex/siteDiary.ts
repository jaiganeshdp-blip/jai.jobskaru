import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { Doc } from "./_generated/dataModel.d.ts";
import type { QueryCtx, MutationCtx } from "./_generated/server.d.ts";

async function getCurrentUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const list = query({
  args: {
    siteId: v.id("sites"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args): Promise<(Doc<"siteDiary"> & {
    submittedByName?: string;
    reviewedByName?: string;
  })[]> => {
    await getCurrentUser(ctx);
    const entries = await ctx.db
      .query("siteDiary")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .order("desc")
      .take(args.limit ?? 100);

    return Promise.all(
      entries.map(async (e) => {
        const submitter = await ctx.db.get(e.submittedBy);
        const reviewer = e.reviewedBy ? await ctx.db.get(e.reviewedBy) : null;
        return {
          ...e,
          submittedByName: submitter?.name,
          reviewedByName: reviewer?.name,
        };
      })
    );
  },
});

export const get = query({
  args: { id: v.id("siteDiary") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const entry = await ctx.db.get(args.id);
    if (!entry) return null;
    const submitter = await ctx.db.get(entry.submittedBy);
    const reviewer = entry.reviewedBy ? await ctx.db.get(entry.reviewedBy) : null;
    const site = await ctx.db.get(entry.siteId);
    return { ...entry, submitter, reviewer, site };
  },
});

export const getByDate = query({
  args: { siteId: v.id("sites"), date: v.string() },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db
      .query("siteDiary")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId).eq("date", args.date))
      .unique();
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    date: v.string(),
    weather: v.optional(v.union(
      v.literal("sunny"),
      v.literal("cloudy"),
      v.literal("rainy"),
      v.literal("stormy"),
      v.literal("foggy")
    )),
    manpowerCount: v.optional(v.number()),
    progressNotes: v.string(),
    issues: v.optional(v.string()),
    workDone: v.optional(v.string()),
    materialsUsed: v.optional(v.string()),
    visitorsOnSite: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("submitted")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    // Check for duplicate date
    const existing = await ctx.db
      .query("siteDiary")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId).eq("date", args.date))
      .unique();
    if (existing) {
      throw new ConvexError({ message: "A diary entry already exists for this date", code: "CONFLICT" });
    }
    return await ctx.db.insert("siteDiary", { ...args, submittedBy: user._id });
  },
});

export const update = mutation({
  args: {
    id: v.id("siteDiary"),
    weather: v.optional(v.union(
      v.literal("sunny"),
      v.literal("cloudy"),
      v.literal("rainy"),
      v.literal("stormy"),
      v.literal("foggy")
    )),
    manpowerCount: v.optional(v.number()),
    progressNotes: v.optional(v.string()),
    issues: v.optional(v.string()),
    workDone: v.optional(v.string()),
    materialsUsed: v.optional(v.string()),
    visitorsOnSite: v.optional(v.string()),
    status: v.optional(v.union(v.literal("draft"), v.literal("submitted"))),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const review = mutation({
  args: {
    id: v.id("siteDiary"),
    reviewNotes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin") {
      throw new ConvexError({ message: "Only super admins can review diary entries", code: "FORBIDDEN" });
    }
    await ctx.db.patch(args.id, {
      status: "reviewed",
      reviewedBy: user._id,
      reviewNotes: args.reviewNotes,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("siteDiary") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });
    }
    await ctx.db.delete(args.id);
  },
});
