import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";

export type UserRole =
  | "super_admin"
  | "site_incharge"
  | "supplier"
  | "contractor"
  | "viewer"
  | "safety_supervisor"
  | "site_supervisor"
  | "labour"
  | "billing_manager"
  | "accounts_manager"
  | "pending";

export async function getCurrentUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({ message: "User not logged in", code: "UNAUTHENTICATED" });
  }
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) {
    throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  }
  return user;
}

export async function requireRole(
  ctx: QueryCtx | MutationCtx,
  allowedRoles: UserRole[]
) {
  const user = await getCurrentUser(ctx);
  if (!allowedRoles.includes(user.role)) {
    throw new ConvexError({ message: "Insufficient permissions", code: "FORBIDDEN" });
  }
  return user;
}

export async function requireSuperAdmin(ctx: QueryCtx | MutationCtx) {
  return requireRole(ctx, ["super_admin"]);
}

export async function requireSiteAccess(
  ctx: QueryCtx | MutationCtx,
  siteId: string
) {
  const user = await getCurrentUser(ctx);
  if (user.role === "super_admin") return user;
  if (user.role === "site_incharge" && user.assignedSiteId === siteId) return user;
  throw new ConvexError({ message: "No access to this site", code: "FORBIDDEN" });
}
