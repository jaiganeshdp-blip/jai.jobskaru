import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";

export const updateCurrentUser = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;

    const existing = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, {
        name: identity.name ?? existing.name,
        email: identity.email ?? existing.email,
      });
      return existing._id;
    }

    // First user becomes super_admin, rest are pending approval
    const userCount = await ctx.db.query("users").take(1);
    const role = userCount.length === 0 ? "super_admin" : "pending";

    return await ctx.db.insert("users", {
      tokenIdentifier: identity.tokenIdentifier,
      name: identity.name,
      email: identity.email,
      role,
      isActive: true,
    });
  },
});

export const getCurrentUserQuery = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
  },
});

export const listUsers = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || user.role !== "super_admin") return [];
    return await ctx.db.query("users").collect();
  },
});

export const toggleUserSuspend = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const current = await getCurrentUser(ctx);
    if (current.role !== "super_admin") throw new Error("Forbidden");
    if (current._id === args.userId) throw new Error("Cannot suspend yourself");
    const user = await ctx.db.get(args.userId);
    if (!user) throw new Error("User not found");
    await ctx.db.patch(args.userId, { isActive: !user.isActive });
  },
});

export const deleteUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const current = await getCurrentUser(ctx);
    if (current.role !== "super_admin") throw new Error("Forbidden");
    if (current._id === args.userId) throw new Error("Cannot delete yourself");
    await ctx.db.delete(args.userId);
  },
});

export const updateUserPermissions = mutation({
  args: {
    userId: v.id("users"),
    userPermissions: v.object({
      canViewLabour: v.boolean(),
      canMarkAttendance: v.boolean(),
      canViewSiteDiary: v.boolean(),
      canAddSiteDiary: v.boolean(),
      canViewMaterials: v.boolean(),
      canRequestMaterials: v.boolean(),
      canViewWorkOrders: v.boolean(),
      canViewSafety: v.boolean(),
      canAddSafetyReport: v.boolean(),
      canViewSites: v.boolean(),
      canViewSalary: v.boolean(),
      canViewInvoices: v.boolean(),
      canViewPayments: v.boolean(),
      canViewExpenses: v.boolean(),
      canViewPurchaseOrders: v.boolean(),
      canViewVendorBills: v.boolean(),
      canViewIncomingInvoices: v.boolean(),
      canViewBankStatement: v.boolean(),
      canViewGstTracking: v.boolean(),
      canViewBillingDashboard: v.boolean(),
      canViewAnalytics: v.boolean(),
      canViewReports: v.boolean(),
      canViewSitePnl: v.boolean(),
      canViewBoq: v.boolean(),
      canViewDeliveryChallans: v.boolean(),
      canViewLabourCorrections: v.boolean(),
      canViewCompanies: v.boolean(),
      canViewPartners: v.boolean(),
      canViewClients: v.boolean(),
      canViewSuppliers: v.boolean(),
      canViewContractors: v.boolean(),
    }),
  },
  handler: async (ctx, args) => {
    const current = await getCurrentUser(ctx);
    if (current.role !== "super_admin") throw new Error("Forbidden");
    await ctx.db.patch(args.userId, { userPermissions: args.userPermissions });
  },
});

export const updateSupervisorPermissions = mutation({
  args: {
    userId: v.id("users"),
    supervisorPermissions: v.object({
      canViewLabour: v.boolean(),
      canMarkAttendance: v.boolean(),
      canViewSiteDiary: v.boolean(),
      canAddSiteDiary: v.boolean(),
      canViewMaterials: v.boolean(),
      canRequestMaterials: v.boolean(),
      canViewWorkOrders: v.boolean(),
      canViewSalary: v.boolean(),
      canViewSafety: v.boolean(),
      canAddSafetyReport: v.boolean(),
    }),
  },
  handler: async (ctx, args) => {
    const current = await getCurrentUser(ctx);
    if (current.role !== "super_admin") throw new Error("Forbidden");
    await ctx.db.patch(args.userId, { supervisorPermissions: args.supervisorPermissions });
  },
});

export const updateUserRole = mutation({
  args: {
    userId: v.id("users"),
    role: v.union(
      v.literal("super_admin"),
      v.literal("site_incharge"),
      v.literal("supplier"),
      v.literal("contractor"),
      v.literal("viewer"),
      v.literal("safety_supervisor"),
      v.literal("site_supervisor"),
      v.literal("labour"),
      v.literal("billing_manager"),
      v.literal("accounts_manager"),
      v.literal("pending")
    ),
    assignedSiteId: v.optional(v.id("sites")),
  },
  handler: async (ctx, args) => {
    const current = await getCurrentUser(ctx);
    if (current.role !== "super_admin") {
      throw new Error("Forbidden");
    }
    await ctx.db.patch(args.userId, {
      role: args.role,
      assignedSiteId: args.assignedSiteId,
    });
  },
});
