import { query } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./lib/auth.ts";

// ─── GST Rate Bucket ─────────────────────────────────────────────────────────
type GstRateBucket = {
  gstPercent: number;
  taxableValue: number;
  gstAmount: number;
  count: number;
};

// ─── Purchase (Input) GST Summary ────────────────────────────────────────────
// Groups incoming invoices by GST % for a given company + FY
export const purchaseGstSummary = query({
  args: {
    financialYear: v.string(),
    ourCompanyName: v.string(),
  },
  handler: async (ctx, args): Promise<{
    byRate: GstRateBucket[];
    totalTaxableValue: number;
    totalGstAmount: number;
    totalInvoices: number;
  }> => {
    await getCurrentUser(ctx);

    const rows = await ctx.db
      .query("incomingInvoices")
      .withIndex("by_fy_company", (q) =>
        q.eq("financialYear", args.financialYear).eq("ourCompanyName", args.ourCompanyName)
      )
      .collect();

    const buckets = new Map<number, GstRateBucket>();

    for (const r of rows) {
      const pct = r.gstPercent;
      const existing = buckets.get(pct) ?? { gstPercent: pct, taxableValue: 0, gstAmount: 0, count: 0 };
      existing.taxableValue += r.amount;
      existing.gstAmount += r.gstAmount;
      existing.count += 1;
      buckets.set(pct, existing);
    }

    const byRate = Array.from(buckets.values()).sort((a, b) => a.gstPercent - b.gstPercent);
    const totalTaxableValue = rows.reduce((s, r) => s + r.amount, 0);
    const totalGstAmount = rows.reduce((s, r) => s + r.gstAmount, 0);

    return { byRate, totalTaxableValue, totalGstAmount, totalInvoices: rows.length };
  },
});

// ─── Sale (Output) GST Summary ───────────────────────────────────────────────
// Groups client invoices by GST % (taxPercent) for all or a filtered set
export const saleGstSummary = query({
  args: {
    financialYear: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{
    byRate: GstRateBucket[];
    totalTaxableValue: number;
    totalGstAmount: number;
    totalInvoices: number;
  }> => {
    const user = await getCurrentUser(ctx);

    let invoices = await ctx.db.query("invoices").order("desc").collect();

    // site_incharge sees only their site
    if (user.role === "site_incharge" && user.assignedSiteId) {
      invoices = invoices.filter((i) => i.siteId === user.assignedSiteId);
    }

    // Optional FY filter — compare issueDate (YYYY-MM-DD) against FY date range
    if (args.financialYear) {
      const [startYY] = args.financialYear.split("-").map(Number);
      const fyStart = new Date(`${startYY}-04-01`).toISOString().split("T")[0];
      const fyEnd = new Date(`${startYY + 1}-03-31`).toISOString().split("T")[0];
      invoices = invoices.filter(
        (i) => i.issueDate >= fyStart && i.issueDate <= fyEnd
      );
    }

    const buckets = new Map<number, GstRateBucket>();

    for (const inv of invoices) {
      const pct = inv.taxPercent;
      const existing = buckets.get(pct) ?? { gstPercent: pct, taxableValue: 0, gstAmount: 0, count: 0 };
      existing.taxableValue += inv.subtotal;
      existing.gstAmount += inv.taxAmount;
      existing.count += 1;
      buckets.set(pct, existing);
    }

    const byRate = Array.from(buckets.values()).sort((a, b) => a.gstPercent - b.gstPercent);
    const totalTaxableValue = invoices.reduce((s, i) => s + i.subtotal, 0);
    const totalGstAmount = invoices.reduce((s, i) => s + i.taxAmount, 0);

    return { byRate, totalTaxableValue, totalGstAmount, totalInvoices: invoices.length };
  },
});

// ─── GST Invoice Tracking Output Summary ─────────────────────────────────────
// Groups gstInvoiceTracking records by GST % for output tax (sale side)
export const gstTrackingOutputSummary = query({
  args: {
    financialYear: v.string(),
    ourCompanyName: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{
    byRate: GstRateBucket[];
    totalTaxableValue: number;
    totalGstAmount: number;
    totalRetention: number;
    totalTds: number;
    totalNetPayable: number;
    totalInvoices: number;
  }> => {
    await getCurrentUser(ctx);

    let rows = await ctx.db
      .query("gstInvoiceTracking")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", args.financialYear))
      .collect();

    if (args.ourCompanyName) {
      rows = rows.filter((r) => r.ourCompanyName === args.ourCompanyName);
    }

    const buckets = new Map<number, GstRateBucket>();

    for (const r of rows) {
      const pct = r.gstPercent;
      const existing = buckets.get(pct) ?? { gstPercent: pct, taxableValue: 0, gstAmount: 0, count: 0 };
      existing.taxableValue += r.amount;
      existing.gstAmount += r.gstAmount;
      existing.count += 1;
      buckets.set(pct, existing);
    }

    const byRate = Array.from(buckets.values()).sort((a, b) => a.gstPercent - b.gstPercent);

    return {
      byRate,
      totalTaxableValue: rows.reduce((s, r) => s + r.amount, 0),
      totalGstAmount: rows.reduce((s, r) => s + r.gstAmount, 0),
      totalRetention: rows.reduce((s, r) => s + (r.retention ?? 0), 0),
      totalTds: rows.reduce((s, r) => s + (r.tds ?? 0), 0),
      totalNetPayable: rows.reduce((s, r) => s + (r.netPayable ?? 0), 0),
      totalInvoices: rows.length,
    };
  },
});
