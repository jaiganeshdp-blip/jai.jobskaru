import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.db.query("contractors").collect();
  },
});

export const get = query({
  args: { id: v.id("contractors") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

type SiteInfo = {
  siteId: Id<"sites">;
  siteName: string;
  companyName: string;
  city: string;
  status: string;
  labourCount: number;
};

type BillInfo = {
  _id: Id<"vendorBills">;
  billNumber: string;
  billDate: string;
  billType: string;
  raNumber: number | undefined;
  siteName: string;
  totalAmount: number;
  paidAmount: number;
  outstanding: number;
  status: string;
  poNumber: string | undefined;
};

type POInfo = {
  _id: Id<"purchaseOrders">;
  poNumber: string;
  issueDate: string;
  siteName: string;
  totalValue: number;
  status: string;
  description: string;
};

type ContractorDetail = {
  contractor: Doc<"contractors">;
  labourCount: number;
  activeLabourCount: number;
  totalPaid: number;
  totalBilled: number;
  totalOutstanding: number;
  workOrderCount: number;
  sites: SiteInfo[];
  bills: BillInfo[];
  purchaseOrders: POInfo[];
  recentPayments: Array<{
    _id: Id<"payments"> | Id<"vendorBills">;
    date: string;
    amount: number;
    mode: string;
    referenceNumber: string | undefined;
    description?: string;
  }>;
  labourers: Array<{
    _id: Id<"labourers">;
    name: string;
    designation: string | undefined;
    dailyRate: number;
    isActive: boolean;
    siteName: string;
  }>;
};

export const getDetail = query({
  args: { id: v.id("contractors") },
  handler: async (ctx, args): Promise<ContractorDetail | null> => {
    await getCurrentUser(ctx);
    const contractor = await ctx.db.get(args.id);
    if (!contractor) return null;

    // Labourers under this contractor
    const labourerDocs = await ctx.db
      .query("labourers")
      .withIndex("by_contractor", (q) => q.eq("contractorId", args.id))
      .collect();

    const labourCount = labourerDocs.length;
    const activeLabourCount = labourerDocs.filter((l) => l.isActive).length;

    // Sites where this contractor's labourers work
    const labourerSiteIds = [...new Set(labourerDocs.map((l) => l.siteId))];

    // Purchase Orders directly for this contractor (by_contractor index)
    const contractorPODocs = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_contractor", (q) => q.eq("contractorId", args.id))
      .collect();

    // All site IDs: from labourers + from POs
    const poSiteIds = contractorPODocs.map((po) => po.siteId as Id<"sites">);
    const allSiteIds = [...new Set([...labourerSiteIds, ...poSiteIds])];

    const siteMap: Record<string, { name: string; companyName: string; city: string; status: string }> = {};
    await Promise.all(
      allSiteIds.map(async (sid) => {
        const site = await ctx.db.get(sid);
        if (site) {
          const company = await ctx.db.get(site.companyId);
          siteMap[sid] = {
            name: site.name,
            companyName: company?.name ?? "—",
            city: site.city,
            status: site.status,
          };
        }
      })
    );

    // Per-site labour count
    const labourBySite: Record<string, number> = {};
    for (const l of labourerDocs) {
      labourBySite[l.siteId] = (labourBySite[l.siteId] ?? 0) + 1;
    }

    const sites: SiteInfo[] = allSiteIds
      .filter((sid) => siteMap[sid])
      .map((sid) => ({
        siteId: sid,
        siteName: siteMap[sid].name,
        companyName: siteMap[sid].companyName,
        city: siteMap[sid].city,
        status: siteMap[sid].status,
        labourCount: labourBySite[sid] ?? 0,
      }));

    const labourers = labourerDocs.slice(0, 10).map((l) => ({
      _id: l._id,
      name: l.name,
      designation: l.designation,
      dailyRate: l.dailyRate,
      isActive: l.isActive,
      siteName: siteMap[l.siteId]?.name ?? "—",
    }));

    // Work orders linked via POs
    const workOrderIdSet = new Set<Id<"workOrders">>();
    for (const po of contractorPODocs) {
      if (po.workOrderId) workOrderIdSet.add(po.workOrderId);
    }
    // Also count work orders from labourer sites
    for (const sid of labourerSiteIds) {
      const wos = await ctx.db
        .query("workOrders")
        .withIndex("by_site", (q) => q.eq("siteId", sid as Id<"sites">))
        .collect();
      for (const wo of wos) workOrderIdSet.add(wo._id);
    }
    const workOrderCount = workOrderIdSet.size;

    // Build PO info list from direct contractor POs
    const purchaseOrders: POInfo[] = await Promise.all(
      contractorPODocs.map(async (po) => {
        const site = await ctx.db.get(po.siteId);
        return {
          _id: po._id,
          poNumber: po.poNumber,
          issueDate: po.issueDate,
          siteName: site?.name ?? "—",
          totalValue: po.totalValue,
          status: po.status,
          description: po.notes ?? "",
        };
      })
    );

    // Vendor Bills for this contractor
    const billDocs = await ctx.db
      .query("vendorBills")
      .withIndex("by_contractor", (q) => q.eq("contractorId", args.id))
      .order("desc")
      .take(100);

    const bills: BillInfo[] = await Promise.all(
      billDocs.map(async (b) => {
        const site = await ctx.db.get(b.siteId);
        const po = b.purchaseOrderId ? await ctx.db.get(b.purchaseOrderId) : null;
        return {
          _id: b._id,
          billNumber: b.billNumber,
          billDate: b.billDate,
          billType: b.billType ?? "regular",
          raNumber: b.raNumber,
          siteName: site?.name ?? "—",
          totalAmount: b.totalAmount,
          paidAmount: b.paidAmount,
          outstanding: b.totalAmount - b.paidAmount,
          status: b.status,
          poNumber: po?.poNumber,
        };
      })
    );

    const totalBilled = bills.reduce((s, b) => s + b.totalAmount, 0);
    const totalOutstanding = bills.reduce((s, b) => s + b.outstanding, 0);

    // Payments to this contractor
    const payments = await ctx.db
      .query("payments")
      .withIndex("by_type", (q) => q.eq("type", "paid"))
      .collect();
    const contractorPayments = payments.filter((p) => p.contractorId === args.id);
    const totalPaidFromPayments = contractorPayments.reduce((s, p) => s + p.amount, 0);

    // Also sum paidAmount from vendor bills (bills can be marked paid without a payments record)
    const totalPaidFromBills = bills.reduce((s, b) => s + b.paidAmount, 0);
    // Use whichever is higher (bills-based is more accurate)
    const totalPaid = Math.max(totalPaidFromPayments, totalPaidFromBills);

    // Build payment history: prefer payments table, fallback to paid bills
    const recentPayments = contractorPayments.length > 0
      ? contractorPayments
          .sort((a, b) => b.date.localeCompare(a.date))
          .slice(0, 10)
          .map((p) => ({
            _id: p._id,
            date: p.date,
            amount: p.amount,
            mode: p.mode,
            referenceNumber: p.referenceNumber,
            description: undefined as string | undefined,
          }))
      : bills
          .filter((b) => b.paidAmount > 0)
          .sort((a, b) => (b.billDate ?? "").localeCompare(a.billDate ?? ""))
          .slice(0, 10)
          .map((b) => ({
            _id: b._id,
            date: b.billDate ?? "",
            amount: b.paidAmount,
            mode: "bill_payment" as const,
            referenceNumber: b.billNumber,
            description: b.poNumber ? `PO: ${b.poNumber}` : b.siteName,
          }));

    return {
      contractor,
      labourCount,
      activeLabourCount,
      totalPaid,
      totalBilled,
      totalOutstanding,
      workOrderCount,
      sites,
      bills,
      purchaseOrders,
      recentPayments,
      labourers,
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    mobile: v.string(),
    email: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    specialization: v.optional(v.string()),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const portalToken = crypto.randomUUID();
    return await ctx.db.insert("contractors", { ...args, isActive: true, portalToken });
  },
});

export const update = mutation({
  args: {
    id: v.id("contractors"),
    name: v.optional(v.string()),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    address: v.optional(v.string()),
    specialization: v.optional(v.string()),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("contractors") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
