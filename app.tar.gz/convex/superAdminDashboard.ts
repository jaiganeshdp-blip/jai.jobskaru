import { v } from "convex/values";
import { query } from "./_generated/server";
import type { QueryCtx } from "./_generated/server";
import { ConvexError } from "convex/values";

// Helper to verify super_admin access
async function requireSuperAdmin(ctx: QueryCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  if (user.role !== "super_admin" && user.role !== "site_incharge") {
    throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });
  }
  return user;
}

// ─── All Sites Summary ──────────────────────────────────────────────────────
// Returns per-site aggregated data for the super admin dashboard
export const getAllSitesSummary = query({
  args: {
    date: v.optional(v.string()), // YYYY-MM-DD, defaults to today
  },
  handler: async (ctx, args): Promise<{
    date: string;
    sites: Array<{
      siteId: string;
      siteName: string;
      city: string;
      status: string;
      companyId: string;
      companyName: string;
      activeLabourers: number;
      totalLabourers: number;
      supervisors: Array<{ name: string; workerCode: string; isSiteSupervisor: boolean; isSafetySupervisor: boolean }>;
      attendance: { present: number; absent: number; halfDay: number; holiday: number; unmarked: number };
      advanceTotal: number;
      pendingMaterialRequests: number;
      totalMaterialRequests: number;
      recentReports: number;
    }>;
    totals: {
      activeSites: number;
      totalLabourers: number;
      presentToday: number;
      absentToday: number;
      advanceTotal: number;
      pendingMaterialRequests: number;
    };
  }> => {
    await requireSuperAdmin(ctx);

    const targetDate = args.date ?? new Date().toISOString().slice(0, 10);
    const monthStr = targetDate.slice(0, 7); // YYYY-MM
    const monthStart = monthStr + "-01";
    const monthEnd = monthStr + "-31";

    // Fetch all sites
    const allSites = await ctx.db.query("sites").collect();
    // Fetch all companies for name lookup
    const allCompanies = await ctx.db.query("companies").collect();
    const companyMap = new Map(allCompanies.map((c) => [c._id, c.name]));

    const siteSummaries = await Promise.all(
      allSites.map(async (site) => {
        // Labourers for this site
        const labourers = await ctx.db
          .query("labourers")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const activeLabourers = labourers.filter((l) => l.isActive);

        // Supervisors
        const supervisors = activeLabourers
          .filter((l) => l.isSiteSupervisor || l.isSafetySupervisor)
          .map((l) => ({
            name: l.name,
            workerCode: l.workerCode ?? "",
            isSiteSupervisor: l.isSiteSupervisor ?? false,
            isSafetySupervisor: l.isSafetySupervisor ?? false,
          }));

        // Attendance for target date
        const attendanceRows = await ctx.db
          .query("attendance")
          .withIndex("by_site_date", (q) => q.eq("siteId", site._id).eq("date", targetDate))
          .collect();

        const markedIds = new Set(attendanceRows.map((a) => a.labourerId));
        const att = { present: 0, absent: 0, halfDay: 0, holiday: 0, unmarked: 0 };
        for (const row of attendanceRows) {
          if (row.status === "present") att.present++;
          else if (row.status === "absent") att.absent++;
          else if (row.status === "half_day") att.halfDay++;
          else if (row.status === "holiday") att.holiday++;
        }
        att.unmarked = activeLabourers.filter((l) => !markedIds.has(l._id)).length;

        // Advances this month for this site
        const advances = await ctx.db
          .query("advances")
          .withIndex("by_site_date", (q) =>
            q.eq("siteId", site._id).gte("date", monthStart).lte("date", monthEnd)
          )
          .collect();
        const advanceTotal = advances.reduce((sum, a) => sum + a.amount, 0);

        // Material requests
        const materialRequests = await ctx.db
          .query("materialRequests")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const pendingMaterialRequests = materialRequests.filter(
          (r) => r.status === "requested"
        ).length;

        // Recent supervisor reports (last 7 days)
        const sevenDaysAgo = new Date(
          new Date(targetDate).getTime() - 7 * 24 * 60 * 60 * 1000
        )
          .toISOString()
          .slice(0, 10);
        const reports = await ctx.db
          .query("supervisorReports")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const recentReports = reports.filter((r) => r.reportDate >= sevenDaysAgo).length;

        return {
          siteId: site._id,
          siteName: site.name,
          city: site.city,
          status: site.status,
          companyId: site.companyId,
          companyName: companyMap.get(site.companyId) ?? "Unknown",
          activeLabourers: activeLabourers.length,
          totalLabourers: labourers.length,
          supervisors,
          attendance: att,
          advanceTotal,
          pendingMaterialRequests,
          totalMaterialRequests: materialRequests.length,
          recentReports,
        };
      })
    );

    // Overall totals
    const totals = siteSummaries.reduce(
      (acc, s) => {
        if (s.status === "active") acc.activeSites++;
        acc.totalLabourers += s.activeLabourers;
        acc.presentToday += s.attendance.present;
        acc.absentToday += s.attendance.absent;
        acc.advanceTotal += s.advanceTotal;
        acc.pendingMaterialRequests += s.pendingMaterialRequests;
        return acc;
      },
      {
        activeSites: 0,
        totalLabourers: 0,
        presentToday: 0,
        absentToday: 0,
        advanceTotal: 0,
        pendingMaterialRequests: 0,
      }
    );

    return { date: targetDate, sites: siteSummaries, totals };
  },
});

// ─── Site Attendance Detail ────────────────────────────────────────────────
// Returns full attendance detail for a specific site + date
export const getSiteAttendanceDetail = query({
  args: {
    siteId: v.id("sites"),
    date: v.string(),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);

    const site = await ctx.db.get(args.siteId);
    if (!site) return null;

    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    const activeLabourers = labourers.filter((l) => l.isActive);

    const attendanceRows = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) => q.eq("siteId", args.siteId).eq("date", args.date))
      .collect();
    const attMap: Record<string, { status: string; overtimeHours?: number }> = {};
    for (const row of attendanceRows) {
      attMap[row.labourerId] = { status: row.status, overtimeHours: row.overtimeHours };
    }

    return {
      site: { _id: site._id, name: site.name, city: site.city },
      labourers: activeLabourers.map((l) => ({
        _id: l._id,
        name: l.name,
        designation: l.designation,
        dailyRate: l.dailyRate,
        attendance: attMap[l._id] ?? null,
      })),
    };
  },
});

// ─── Site Advances Detail ─────────────────────────────────────────────────
export const getSiteAdvancesDetail = query({
  args: {
    siteId: v.id("sites"),
    month: v.string(), // YYYY-MM
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);

    const monthStart = args.month + "-01";
    const monthEnd = args.month + "-31";

    const advances = await ctx.db
      .query("advances")
      .withIndex("by_site_date", (q) =>
        q.eq("siteId", args.siteId).gte("date", monthStart).lte("date", monthEnd)
      )
      .collect();

    const enriched = await Promise.all(
      advances.map(async (adv) => {
        const labourer = await ctx.db.get(adv.labourerId);
        return { ...adv, labourerName: labourer?.name ?? "Unknown" };
      })
    );

    return enriched;
  },
});
