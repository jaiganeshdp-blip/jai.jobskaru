import { query } from "./_generated/server";
import { v } from "convex/values";

// Returns all portal access records for super admin view
export const getAllPortalAccess = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;

    // Fetch all suppliers with portal tokens
    const suppliers = await ctx.db.query("suppliers").collect();
    const supplierPortals = suppliers
      .filter((s) => s.portalToken)
      .map((s) => ({
        type: "supplier" as const,
        id: s._id,
        name: s.name,
        mobile: s.mobile,
        email: s.email,
        portalToken: s.portalToken!,
        portalPath: "/portal/supplier",
        isActive: s.isActive,
      }));

    // Fetch all contractors with portal tokens
    const contractors = await ctx.db.query("contractors").collect();
    const contractorPortals = contractors
      .filter((c) => c.portalToken)
      .map((c) => ({
        type: "contractor" as const,
        id: c._id,
        name: c.name,
        mobile: c.mobile,
        email: c.email,
        portalToken: c.portalToken!,
        portalPath: "/portal/contractor",
        isActive: c.isActive,
      }));

    // Fetch supervisors (site supervisors and safety supervisors) with portal tokens
    const labourers = await ctx.db.query("labourers").collect();
    const supervisorPortals = labourers
      .filter((l) => (l.isSiteSupervisor || l.isSafetySupervisor) && l.portalToken)
      .map((l) => ({
        type: l.isSafetySupervisor ? ("safety_supervisor" as const) : ("supervisor" as const),
        id: l._id,
        name: l.name,
        mobile: l.mobile,
        workerCode: l.workerCode,
        portalToken: l.portalToken!,
        portalPath: l.isSafetySupervisor ? "/portal/safety-supervisor" : "/portal/supervisor",
        isActive: l.isActive,
        siteId: l.siteId,
      }));

    // Get site names for supervisors
    const siteIds = [...new Set(supervisorPortals.map((s) => s.siteId))];
    const siteMap: Record<string, string> = {};
    for (const siteId of siteIds) {
      const site = await ctx.db.get(siteId);
      if (site) siteMap[siteId] = site.name;
    }

    const supervisorPortalsWithSite = supervisorPortals.map((s) => ({
      ...s,
      siteName: siteMap[s.siteId] ?? "—",
    }));

    return {
      suppliers: supplierPortals,
      contractors: contractorPortals,
      supervisors: supervisorPortalsWithSite,
    };
  },
});
