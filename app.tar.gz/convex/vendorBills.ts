import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import type { QueryCtx, MutationCtx } from "./_generated/server.d.ts";

// Helper: get current user
async function getCurrentUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<(Doc<"vendorBills"> & {
    supplierName?: string;
    contractorName?: string;
    siteName?: string;
  })[]> => {
    let bills: Doc<"vendorBills">[] = [];
    if (args.siteId) {
      bills = await ctx.db
        .query("vendorBills")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .order("desc")
        .collect();
    } else if (args.supplierId) {
      bills = await ctx.db
        .query("vendorBills")
        .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
        .order("desc")
        .collect();
    } else if (args.contractorId) {
      bills = await ctx.db
        .query("vendorBills")
        .withIndex("by_contractor", (q) => q.eq("contractorId", args.contractorId))
        .order("desc")
        .collect();
    } else {
      bills = await ctx.db.query("vendorBills").order("desc").take(200);
    }

    if (args.status) {
      bills = bills.filter((b) => b.status === args.status);
    }

    return Promise.all(
      bills.map(async (bill) => {
        const supplier = bill.supplierId ? await ctx.db.get(bill.supplierId) : null;
        const contractor = bill.contractorId ? await ctx.db.get(bill.contractorId) : null;
        const site = await ctx.db.get(bill.siteId);
        return {
          ...bill,
          supplierName: supplier?.name,
          contractorName: contractor?.name,
          siteName: site?.name,
        };
      })
    );
  },
});

export const get = query({
  args: { id: v.id("vendorBills") },
  handler: async (ctx, args) => {
    const bill = await ctx.db.get(args.id);
    if (!bill) return null;
    const supplier = bill.supplierId ? await ctx.db.get(bill.supplierId) : null;
    const contractor = bill.contractorId ? await ctx.db.get(bill.contractorId) : null;
    const site = await ctx.db.get(bill.siteId);
    const po = bill.purchaseOrderId ? await ctx.db.get(bill.purchaseOrderId) : null;
    const material = bill.materialId ? await ctx.db.get(bill.materialId) : null;
    return { ...bill, supplier, contractor, site, po, material };
  },
});

export const summary = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args): Promise<{
    totalBills: number;
    totalAmount: number;
    paidAmount: number;
    outstandingAmount: number;
    byStatus: Record<string, { count: number; amount: number }>;
  }> => {
    let bills: Doc<"vendorBills">[];
    if (args.siteId) {
      bills = await ctx.db
        .query("vendorBills")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .collect();
    } else {
      bills = await ctx.db.query("vendorBills").take(500);
    }

    const byStatus: Record<string, { count: number; amount: number }> = {};
    let totalAmount = 0;
    let paidAmount = 0;

    for (const bill of bills) {
      totalAmount += bill.totalAmount;
      paidAmount += bill.paidAmount;
      if (!byStatus[bill.status]) byStatus[bill.status] = { count: 0, amount: 0 };
      byStatus[bill.status].count++;
      byStatus[bill.status].amount += bill.totalAmount;
    }

    return {
      totalBills: bills.length,
      totalAmount,
      paidAmount,
      outstandingAmount: totalAmount - paidAmount,
      byStatus,
    };
  },
});

export const vendorOutstanding = query({
  args: {},
  handler: async (ctx): Promise<{
    supplierId?: Id<"suppliers">;
    contractorId?: Id<"contractors">;
    vendorName: string;
    vendorType: "supplier" | "contractor";
    totalBilled: number;
    totalPaid: number;
    outstanding: number;
    billCount: number;
  }[]> => {
    const bills = await ctx.db.query("vendorBills").take(500);
    const map = new Map<string, {
      supplierId?: Id<"suppliers">;
      contractorId?: Id<"contractors">;
      vendorName: string;
      vendorType: "supplier" | "contractor";
      totalBilled: number;
      totalPaid: number;
      billCount: number;
    }>();

    for (const bill of bills) {
      const key = bill.supplierId ?? bill.contractorId ?? "unknown";
      if (!map.has(String(key))) {
        const supplier = bill.supplierId ? await ctx.db.get(bill.supplierId) : null;
        const contractor = bill.contractorId ? await ctx.db.get(bill.contractorId) : null;
        map.set(String(key), {
          supplierId: bill.supplierId,
          contractorId: bill.contractorId,
          vendorName: supplier?.name ?? contractor?.name ?? "Unknown",
          vendorType: bill.vendorType,
          totalBilled: 0,
          totalPaid: 0,
          billCount: 0,
        });
      }
      const entry = map.get(String(key))!;
      entry.totalBilled += bill.totalAmount;
      entry.totalPaid += bill.paidAmount;
      entry.billCount++;
    }

    return Array.from(map.values())
      .map((v) => ({ ...v, outstanding: v.totalBilled - v.totalPaid }))
      .sort((a, b) => b.outstanding - a.outstanding);
  },
});

export const create = mutation({
  args: {
    billNumber: v.string(),
    siteId: v.id("sites"),
    companyId: v.id("companies"),
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    purchaseOrderId: v.optional(v.id("purchaseOrders")),
    workOrderId: v.optional(v.id("workOrders")),
    materialId: v.optional(v.id("materials")),
    billDate: v.string(),
    dueDate: v.optional(v.string()),
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    subtotal: v.number(),
    gstPercent: v.number(),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    // If line items provided, derive subtotal from them
    const subtotal = args.lineItems && args.lineItems.length > 0
      ? args.lineItems.reduce((s, i) => s + i.amount, 0)
      : args.subtotal;
    const gstAmount = (subtotal * args.gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;
    return await ctx.db.insert("vendorBills", {
      ...args,
      subtotal,
      gstAmount,
      totalAmount,
      paidAmount: 0,
      status: "received",
      createdBy: user._id,
    });
  },
});

// Get all RA bills linked to a specific PO (for showing history and totals)
export const listByPO = query({
  args: { purchaseOrderId: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();
    return bills.sort((a, b) => (a.raNumber ?? 0) - (b.raNumber ?? 0));
  },
});

// Create RA Bill with PO-based item-wise tracking and amount validation
export const createRABill = mutation({
  args: {
    billNumber: v.string(),
    billDate: v.string(),
    dueDate: v.optional(v.string()),
    siteId: v.id("sites"),
    companyId: v.id("companies"),
    vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    purchaseOrderId: v.id("purchaseOrders"),
    billType: v.union(v.literal("ra"), v.literal("final")),
    raBillItems: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      orderQty: v.number(),
      thisBillQty: v.number(),
      ratePerUnit: v.number(),
      thisBillAmount: v.number(),
    })),
    gstPercent: v.number(),
    retentionPercent: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ billId: Id<"vendorBills">; warning?: string }> => {
    const user = await getCurrentUser(ctx);
    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) throw new ConvexError({ code: "NOT_FOUND", message: "Purchase Order nahi mila" });

    const prevBills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();

    const raNumber = prevBills.length + 1;
    const prevTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
    const subtotal = args.raBillItems.reduce((s, i) => s + i.thisBillAmount, 0);
    const gstAmount = (subtotal * args.gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;
    const retentionPercent = args.retentionPercent ?? 0;
    const retentionAmount = (totalAmount * retentionPercent) / 100;
    const balancePayable = totalAmount - retentionAmount;
    const cumulativeTotal = prevTotal + subtotal;

    let warning: string | undefined;
    if (cumulativeTotal > po.totalValue) {
      warning = `Yeh bill PO value se ₹${(cumulativeTotal - po.totalValue).toLocaleString("en-IN")} zyada hai. PO amendment ki zaroorat hai.`;
    }

    const billId = await ctx.db.insert("vendorBills", {
      billNumber: args.billNumber,
      billDate: args.billDate,
      dueDate: args.dueDate,
      siteId: args.siteId,
      companyId: args.companyId,
      vendorType: args.vendorType,
      supplierId: args.supplierId,
      contractorId: args.contractorId,
      purchaseOrderId: args.purchaseOrderId,
      billType: args.billType,
      raNumber,
      raBillItems: args.raBillItems,
      subtotal,
      gstPercent: args.gstPercent,
      gstAmount,
      totalAmount,
      retentionPercent: retentionPercent || undefined,
      retentionAmount: retentionPercent ? retentionAmount : undefined,
      balancePayable: retentionPercent ? balancePayable : undefined,
      paidAmount: 0,
      status: "received",
      description: `${args.billType === "final" ? "Final Bill" : `RA-${raNumber}`} — PO: ${po.poNumber}`,
      notes: args.notes,
      createdBy: user._id,
    });

    return { billId, warning };
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("vendorBills"),
    status: v.union(
      v.literal("received"),
      v.literal("verified"),
      v.literal("approved"),
      v.literal("paid"),
      v.literal("disputed")
    ),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const bill = await ctx.db.get(args.id);
    if (!bill) throw new ConvexError({ message: "Bill not found", code: "NOT_FOUND" });

    const updates: Partial<Doc<"vendorBills">> = { status: args.status };
    if (args.status === "verified") updates.verifiedBy = user._id;
    if (args.status === "approved") updates.approvedBy = user._id;
    if (args.status === "paid") updates.paidAmount = bill.totalAmount;

    await ctx.db.patch(args.id, updates);
  },
});

export const recordPayment = mutation({
  args: {
    id: v.id("vendorBills"),
    amount: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const bill = await ctx.db.get(args.id);
    if (!bill) throw new ConvexError({ message: "Bill not found", code: "NOT_FOUND" });
    const newPaid = bill.paidAmount + args.amount;
    const newStatus = newPaid >= bill.totalAmount ? "paid" : bill.status;
    await ctx.db.patch(args.id, { paidAmount: newPaid, status: newStatus });
  },
});

export const update = mutation({
  args: {
    id: v.id("vendorBills"),
    billNumber: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    companyId: v.optional(v.id("companies")),
    vendorType: v.optional(v.union(v.literal("supplier"), v.literal("contractor"))),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    billDate: v.optional(v.string()),
    dueDate: v.optional(v.string()),
    lineItems: v.optional(v.array(v.object({
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      amount: v.number(),
    }))),
    subtotal: v.optional(v.number()),
    gstPercent: v.optional(v.number()),
    retentionPercent: v.optional(v.number()),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const { id, ...rest } = args;
    const bill = await ctx.db.get(id);
    if (!bill) throw new ConvexError({ message: "Bill not found", code: "NOT_FOUND" });

    // If line items are provided, subtotal is derived from them
    const subtotal = rest.lineItems && rest.lineItems.length > 0
      ? rest.lineItems.reduce((s, i) => s + i.amount, 0)
      : (rest.subtotal ?? bill.subtotal);
    const gstPercent = rest.gstPercent ?? bill.gstPercent;
    const gstAmount = (subtotal * gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;

    // Recompute retention/balance when relevant
    const retentionPercent = rest.retentionPercent ?? bill.retentionPercent;
    const patch: Partial<Doc<"vendorBills">> = { ...rest, subtotal, gstAmount, totalAmount };
    if (retentionPercent && retentionPercent > 0) {
      const retentionAmount = (totalAmount * retentionPercent) / 100;
      patch.retentionPercent = retentionPercent;
      patch.retentionAmount = retentionAmount;
      patch.balancePayable = totalAmount - retentionAmount;
    }

    // When switching vendor type, clear the opposite reference
    if (rest.vendorType === "supplier") patch.contractorId = undefined;
    if (rest.vendorType === "contractor") patch.supplierId = undefined;

    await ctx.db.patch(id, patch);
  },
});

export const remove = mutation({
  args: { id: v.id("vendorBills") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    await ctx.db.delete(args.id);
  },
});

// Generate upload URL for bill attachment
export const generateAttachmentUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

// Save attachment to a bill
export const addAttachment = mutation({
  args: {
    billId: v.id("vendorBills"),
    storageId: v.id("_storage"),
    fileName: v.string(),
    fileType: v.string(),
    fileSize: v.number(),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const bill = await ctx.db.get(args.billId);
    if (!bill) throw new ConvexError({ message: "Bill not found", code: "NOT_FOUND" });
    const existing = bill.attachments ?? [];
    await ctx.db.patch(args.billId, {
      attachments: [...existing, {
        storageId: args.storageId,
        fileName: args.fileName,
        fileType: args.fileType,
        fileSize: args.fileSize,
        uploadedAt: new Date().toISOString(),
      }],
    });
  },
});

// Remove one attachment from a bill
export const removeAttachment = mutation({
  args: {
    billId: v.id("vendorBills"),
    storageId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const bill = await ctx.db.get(args.billId);
    if (!bill) throw new ConvexError({ message: "Bill not found", code: "NOT_FOUND" });
    await ctx.db.patch(args.billId, {
      attachments: (bill.attachments ?? []).filter((a) => a.storageId !== args.storageId),
    });
    await ctx.storage.delete(args.storageId);
  },
});

// Get attachment URLs for a bill
export const getAttachmentUrls = query({
  args: { billId: v.id("vendorBills") },
  handler: async (ctx, args): Promise<Array<{
    storageId: string;
    fileName: string;
    fileType: string;
    fileSize: number;
    uploadedAt: string;
    url: string | null;
  }>> => {
    const bill = await ctx.db.get(args.billId);
    if (!bill || !bill.attachments) return [];
    return Promise.all(
      bill.attachments.map(async (a) => ({
        ...a,
        storageId: a.storageId,
        url: await ctx.storage.getUrl(a.storageId),
      }))
    );
  },
});
