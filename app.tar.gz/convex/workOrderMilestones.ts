import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

// List milestones for a work order
export const listByWorkOrder = query({
  args: { workOrderId: v.id("workOrders") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const milestones = await ctx.db
      .query("workOrderMilestones")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .collect();
    return milestones.sort((a, b) => a.unitNumber - b.unitNumber);
  },
});

// List all milestones pending billing (status = completed, not billed)
export const listPendingBilling = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    const milestones = await ctx.db
      .query("workOrderMilestones")
      .withIndex("by_status", (q) => q.eq("status", "completed"))
      .collect();

    // Enrich with work order, site info
    const enriched = await Promise.all(
      milestones.map(async (m) => {
        const wo = await ctx.db.get(m.workOrderId);
        const site = await ctx.db.get(m.siteId);
        const client = wo?.clientId ? await ctx.db.get(wo.clientId) : null;
        const completedByUser = m.completedBy ? await ctx.db.get(m.completedBy) : null;
        return {
          ...m,
          workOrderNumber: wo?.orderNumber,
          workOrderValue: wo?.totalValue,
          siteName: site?.name,
          siteCity: site?.city,
          clientName: client?.name,
          completedByName: completedByUser?.name,
        };
      })
    );
    return enriched.sort((a, b) => (a.completedAt ?? "").localeCompare(b.completedAt ?? ""));
  },
});

// Generate equal milestones for a work order
export const generateMilestones = mutation({
  args: {
    workOrderId: v.id("workOrders"),
    totalUnits: v.number(),
    unitLabel: v.string(), // e.g. "Floor", "Phase"
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);

    const wo = await ctx.db.get(args.workOrderId);
    if (!wo) throw new Error("Work order not found");

    // Delete existing milestones first
    const existing = await ctx.db
      .query("workOrderMilestones")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .collect();
    for (const m of existing) {
      await ctx.db.delete(m._id);
    }

    // Save totalUnits on work order
    await ctx.db.patch(args.workOrderId, {
      totalUnits: args.totalUnits,
      unitLabel: args.unitLabel,
    });

    const perUnitAmount = Math.round(wo.totalValue / args.totalUnits);
    const percentage = parseFloat((100 / args.totalUnits).toFixed(4));

    for (let i = 1; i <= args.totalUnits; i++) {
      // Last unit gets any rounding remainder
      const amount = i === args.totalUnits
        ? wo.totalValue - perUnitAmount * (args.totalUnits - 1)
        : perUnitAmount;

      await ctx.db.insert("workOrderMilestones", {
        workOrderId: args.workOrderId,
        siteId: wo.siteId,
        name: `${args.unitLabel} ${i}`,
        unitNumber: i,
        percentage,
        amount,
        status: "pending",
      });
    }
  },
});

// Site incharge marks a milestone as completed
export const markCompleted = mutation({
  args: {
    id: v.id("workOrderMilestones"),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const milestone = await ctx.db.get(args.id);
    if (!milestone) throw new Error("Milestone not found");
    if (milestone.status !== "pending") throw new Error("Only pending milestones can be marked complete");

    await ctx.db.patch(args.id, {
      status: "completed",
      completedAt: new Date().toISOString(),
      completedBy: user._id,
      completionNote: args.note,
    });
  },
});

// Revert a completed milestone back to pending (undo)
export const revertToPending = mutation({
  args: { id: v.id("workOrderMilestones") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const milestone = await ctx.db.get(args.id);
    if (!milestone) throw new Error("Milestone not found");
    if (milestone.status === "billed") throw new Error("Billed milestones cannot be reverted");

    await ctx.db.patch(args.id, {
      status: "pending",
      completedAt: undefined,
      completedBy: undefined,
      completionNote: undefined,
    });
  },
});

// Mark milestone as billed (after invoice is created)
export const markBilled = mutation({
  args: { id: v.id("workOrderMilestones") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    await ctx.db.patch(args.id, {
      status: "billed",
      billedAt: new Date().toISOString(),
    });
  },
});

// Delete all milestones for a work order
export const deleteAll = mutation({
  args: { workOrderId: v.id("workOrders") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const existing = await ctx.db
      .query("workOrderMilestones")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .collect();
    for (const m of existing) {
      await ctx.db.delete(m._id);
    }
  },
});
