import { mutation } from "./_generated/server";
import { requireSuperAdmin } from "./lib/auth.ts";

export const seedTestData = mutation({
  args: {},
  handler: async (ctx) => {
    const admin = await requireSuperAdmin(ctx);

    // 2 Companies
    const company1Id = await ctx.db.insert("companies", {
      name: "Mumbai Constructions Pvt Ltd",
      contactPerson: "Rajesh Kumar",
      mobile: "9876543210",
      email: "rajesh@mumbaiconst.com",
      city: "Mumbai",
      state: "Maharashtra",
      gstNumber: "27AAACM1234F1Z5",
      isActive: true,
    });
    const company2Id = await ctx.db.insert("companies", {
      name: "Pune Developers Ltd",
      contactPerson: "Suresh Patil",
      mobile: "9876543211",
      email: "suresh@punedev.com",
      city: "Pune",
      state: "Maharashtra",
      isActive: true,
    });

    // 2 Clients
    const client1Id = await ctx.db.insert("clients", {
      name: "Sharma Real Estate",
      mobile: "9000000001",
      email: "info@sharmare.com",
      city: "Mumbai",
      contactPerson: "Amit Sharma",
      isActive: true,
    });
    const client2Id = await ctx.db.insert("clients", {
      name: "Patel Infra Projects",
      mobile: "9000000002",
      email: "contact@patelinfra.com",
      city: "Pune",
      contactPerson: "Vijay Patel",
      isActive: true,
    });

    // 2 Sites
    const site1Id = await ctx.db.insert("sites", {
      name: "Andheri Residential Complex",
      companyId: company1Id,
      clientId: client1Id,
      city: "Mumbai",
      address: "Plot 45, Andheri East",
      status: "active",
      startDate: "2024-01-15",
    });
    const site2Id = await ctx.db.insert("sites", {
      name: "Wakad Commercial Tower",
      companyId: company2Id,
      clientId: client2Id,
      city: "Pune",
      address: "Survey No 23, Wakad",
      status: "active",
      startDate: "2024-03-01",
    });

    // 2 Suppliers
    const sup1Token = crypto.randomUUID();
    const sup2Token = crypto.randomUUID();
    const supplier1Id = await ctx.db.insert("suppliers", {
      name: "Steel & Iron Traders",
      mobile: "9111111101",
      email: "steel@traders.com",
      city: "Mumbai",
      materialCategories: ["Steel", "Iron Rods"],
      isActive: true,
      portalToken: sup1Token,
    });
    const supplier2Id = await ctx.db.insert("suppliers", {
      name: "Cement World Suppliers",
      mobile: "9111111102",
      email: "cement@world.com",
      city: "Pune",
      materialCategories: ["Cement", "Sand", "Aggregate"],
      isActive: true,
      portalToken: sup2Token,
    });

    // 2 Contractors
    const con1Token = crypto.randomUUID();
    const con2Token = crypto.randomUUID();
    const contractor1Id = await ctx.db.insert("contractors", {
      name: "Ram Labour Contractor",
      mobile: "9222222201",
      email: "ram@labourco.com",
      specialization: "Civil Work",
      isActive: true,
      portalToken: con1Token,
    });
    const contractor2Id = await ctx.db.insert("contractors", {
      name: "Shiv Contractors",
      mobile: "9222222202",
      email: "shiv@contractors.com",
      specialization: "Electrical & Plumbing",
      isActive: true,
      portalToken: con2Token,
    });

    // 2 Labourers
    const lab1Token = crypto.randomUUID();
    const lab2Token = crypto.randomUUID();
    const labourer1Id = await ctx.db.insert("labourers", {
      name: "Mohan Singh",
      mobile: "8000000001",
      siteId: site1Id,
      contractorId: contractor1Id,
      designation: "Mason",
      dailyRate: 600,
      joinDate: "2024-01-20",
      isActive: true,
      portalToken: lab1Token,
    });
    const labourer2Id = await ctx.db.insert("labourers", {
      name: "Ramesh Yadav",
      mobile: "8000000002",
      siteId: site1Id,
      contractorId: contractor1Id,
      designation: "Helper",
      dailyRate: 400,
      joinDate: "2024-01-22",
      isActive: true,
      portalToken: lab2Token,
    });

    // Attendance for current month
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const attendanceDates = ["01", "02", "03", "04", "05", "06", "07", "08"];
    for (const day of attendanceDates) {
      const date = `${year}-${month}-${day}`;
      await ctx.db.insert("attendance", {
        siteId: site1Id,
        labourerId: labourer1Id,
        date,
        status: day === "04" ? "absent" : day === "06" ? "half_day" : "present",
        markedBy: admin._id,
      });
      await ctx.db.insert("attendance", {
        siteId: site1Id,
        labourerId: labourer2Id,
        date,
        status: day === "05" ? "absent" : "present",
        markedBy: admin._id,
      });
    }

    // 2 Work Orders
    const wo1Id = await ctx.db.insert("workOrders", {
      orderNumber: "WO-2024-001",
      siteId: site1Id,
      clientId: client1Id,
      companyId: company1Id,
      description: "Construction of G+5 residential building including all civil works",
      totalValue: 5000000,
      status: "active",
      issueDate: "2024-01-15",
      startDate: "2024-01-20",
      endDate: "2024-12-31",
      version: 1,
    });
    await ctx.db.insert("workOrders", {
      orderNumber: "WO-2024-002",
      siteId: site2Id,
      clientId: client2Id,
      companyId: company2Id,
      description: "Commercial tower - structural and finishing work",
      totalValue: 8500000,
      status: "active",
      issueDate: "2024-03-01",
      startDate: "2024-03-10",
      endDate: "2025-06-30",
      version: 1,
    });

    // Amendment for WO1
    await ctx.db.insert("workOrderAmendments", {
      workOrderId: wo1Id,
      amendmentNumber: 1,
      reason: "Additional floor added by client request",
      previousValue: 5000000,
      newValue: 6200000,
      date: "2024-04-01",
    });
    await ctx.db.patch(wo1Id, { totalValue: 6200000, status: "amended", version: 2 });

    // 2 Material entries
    await ctx.db.insert("materials", {
      siteId: site1Id,
      supplierId: supplier1Id,
      enteredBy: admin._id,
      invoiceNumber: "INV-S-001",
      vehicleNumber: "MH-04-AB-1234",
      deliveryDate: `${year}-${month}-05`,
      items: [
        { name: "TMT Steel Bar 12mm", quantity: 50, unit: "Quintals", ratePerUnit: 5800, totalAmount: 290000 },
        { name: "Binding Wire", quantity: 10, unit: "Kg", ratePerUnit: 80, totalAmount: 800 },
      ],
      totalAmount: 290800,
      status: "approved",
      approvedBy: admin._id,
    });
    await ctx.db.insert("materials", {
      siteId: site1Id,
      supplierId: supplier2Id,
      enteredBy: admin._id,
      invoiceNumber: "INV-S-002",
      vehicleNumber: "MH-12-CD-5678",
      deliveryDate: `${year}-${month}-07`,
      items: [
        { name: "OPC Cement 53 Grade", quantity: 200, unit: "Bags", ratePerUnit: 380, totalAmount: 76000 },
        { name: "River Sand", quantity: 10, unit: "Brass", ratePerUnit: 4500, totalAmount: 45000 },
      ],
      totalAmount: 121000,
      status: "pending",
    });

    // Salary sheet
    const salarySheetId = await ctx.db.insert("salarySheets", {
      siteId: site1Id,
      month: `${year}-${month}`,
      status: "draft",
      preparedBy: admin._id,
      totalAmount: 8000,
    });
    await ctx.db.insert("salaryEntries", {
      salarySheetId,
      labourerId: labourer1Id,
      daysWorked: 6,
      halfDays: 1,
      dailyRate: 600,
      grossAmount: 3900,
      deductions: 0,
      netAmount: 3900,
      paymentMode: "cash",
    });
    await ctx.db.insert("salaryEntries", {
      salarySheetId,
      labourerId: labourer2Id,
      daysWorked: 7,
      halfDays: 0,
      dailyRate: 400,
      grossAmount: 2800,
      deductions: 0,
      netAmount: 2800,
      paymentMode: "cash",
    });

    return {
      message: "Test data seeded successfully!",
      portalLinks: {
        labourer1: `${lab1Token}`,
        labourer2: `${lab2Token}`,
        supplier1: `${sup1Token}`,
        supplier2: `${sup2Token}`,
        contractor1: `${con1Token}`,
        contractor2: `${con2Token}`,
      },
    };
  },
});
