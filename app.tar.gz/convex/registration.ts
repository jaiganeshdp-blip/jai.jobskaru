import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { ConvexError } from "convex/values";

// Submit registration form (called after login when user is "pending")
export const submitRegistration = mutation({
  args: {
    name: v.string(),
    mobile: v.string(),
    requestedRole: v.union(
      v.literal("contractor"),
      v.literal("supplier"),
      v.literal("site_supervisor"),
      v.literal("safety_supervisor"),
      v.literal("labour"),
      v.literal("other")
    ),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    siteId: v.optional(v.id("sites")),
    note: v.optional(v.string()),
    photoStorageId: v.optional(v.string()),
    aadhaarStorageId: v.optional(v.string()),
    panStorageId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });

    // Check if already submitted
    const existing = await ctx.db
      .query("registrationRequests")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .first();

    if (existing) {
      // Update if still pending
      if (existing.status === "pending") {
        await ctx.db.patch(existing._id, {
          name: args.name,
          mobile: args.mobile,
          requestedRole: args.requestedRole,
          companyId: args.companyId,
          companyName: args.companyName,
          siteId: args.siteId,
          note: args.note,
          photoStorageId: args.photoStorageId,
          aadhaarStorageId: args.aadhaarStorageId,
          panStorageId: args.panStorageId,
        });
        return existing._id;
      }
      return existing._id;
    }

    // Update user name/mobile
    await ctx.db.patch(user._id, {
      name: args.name,
      mobile: args.mobile,
      requestedRole: args.requestedRole,
    });

    return await ctx.db.insert("registrationRequests", {
      userId: user._id,
      tokenIdentifier: identity.tokenIdentifier,
      name: args.name,
      email: identity.email,
      mobile: args.mobile,
      requestedRole: args.requestedRole,
      companyId: args.companyId,
      companyName: args.companyName,
      siteId: args.siteId,
      note: args.note,
      photoStorageId: args.photoStorageId,
      aadhaarStorageId: args.aadhaarStorageId,
      panStorageId: args.panStorageId,
      status: "pending",
    });
  },
});

// Get my registration request
export const getMyRegistration = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    return await ctx.db
      .query("registrationRequests")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .first();
  },
});

// Admin: list all registration requests
export const listRequests = query({
  args: { status: v.optional(v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected"))) },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || user.role !== "super_admin") return [];

    if (args.status) {
      return await ctx.db
        .query("registrationRequests")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .collect();
    }
    return await ctx.db.query("registrationRequests").order("desc").collect();
  },
});

const ROLE_MAP = {
  contractor: "contractor",
  site_supervisor: "site_incharge",
  safety_supervisor: "safety_supervisor",
  labour: "labour",
  other: "viewer",
} as const;

// Admin: approve a registration request
export const approveRequest = mutation({
  args: {
    requestId: v.id("registrationRequests"),
    assignedRole: v.union(
      v.literal("contractor"),
      v.literal("site_incharge"),
      v.literal("safety_supervisor"),
      v.literal("site_supervisor"),
      v.literal("labour"),
      v.literal("supplier"),
      v.literal("billing_manager"),
      v.literal("accounts_manager"),
      v.literal("viewer"),
      v.literal("super_admin")
    ),
    assignedSiteId: v.optional(v.id("sites")),
    contractorRef: v.optional(v.id("contractors")),
    supplierRef: v.optional(v.id("suppliers")),
    labourerRef: v.optional(v.id("labourers")),
    // Auto-create options
    createNewRecord: v.optional(v.boolean()),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const admin = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!admin || admin.role !== "super_admin") throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });

    const req = await ctx.db.get(args.requestId);
    if (!req) throw new ConvexError({ message: "Request not found", code: "NOT_FOUND" });

    // Update registration request
    await ctx.db.patch(args.requestId, {
      status: "approved",
      adminNote: args.adminNote,
      reviewedAt: new Date().toISOString(),
    });

    let finalContractorRef = args.contractorRef;
    let finalSupplierRef = args.supplierRef;
    let finalLabourerRef = args.labourerRef;

    // ---- Auto-create linked record based on role ----

    // Labour: auto-create labourer record
    if (args.assignedRole === "labour" && !args.labourerRef && args.createNewRecord !== false) {
      const siteId = args.assignedSiteId ?? req.siteId;
      if (siteId) {
        finalLabourerRef = await ctx.db.insert("labourers", {
          name: req.name,
          mobile: req.mobile,
          siteId,
          dailyRate: 0,
          isActive: true,
          joinDate: new Date().toISOString().split("T")[0],
          labourType: "departmental",
        });
      }
    }

    // Contractor: auto-create contractor record if createNewRecord is true and no existing ref
    if (args.assignedRole === "contractor" && !args.contractorRef && args.createNewRecord === true) {
      finalContractorRef = await ctx.db.insert("contractors", {
        name: req.name,
        mobile: req.mobile ?? "",
        email: req.email,
        isActive: true,
      });
    }

    // Supplier: auto-create supplier record if createNewRecord is true and no existing ref
    if (args.assignedRole === "supplier" && !args.supplierRef && args.createNewRecord === true) {
      finalSupplierRef = await ctx.db.insert("suppliers", {
        name: req.name,
        mobile: req.mobile ?? "",
        email: req.email,
        isActive: true,
      });
    }

    // Update user role and links
    await ctx.db.patch(req.userId, {
      role: args.assignedRole,
      isActive: true,
      assignedSiteId: args.assignedSiteId,
      contractorRef: finalContractorRef,
      supplierRef: finalSupplierRef,
      labourerRef: finalLabourerRef,
    });

    // Link labourerRef back if newly created
    if (finalLabourerRef && !args.labourerRef) {
      await ctx.db.patch(req.userId, { labourerRef: finalLabourerRef });
    }
  },
});

// Admin: reject a registration request
export const rejectRequest = mutation({
  args: {
    requestId: v.id("registrationRequests"),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const admin = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!admin || admin.role !== "super_admin") throw new ConvexError({ message: "Forbidden", code: "FORBIDDEN" });

    const req = await ctx.db.get(args.requestId);
    if (!req) throw new ConvexError({ message: "Request not found", code: "NOT_FOUND" });

    await ctx.db.patch(args.requestId, {
      status: "rejected",
      adminNote: args.adminNote,
      reviewedAt: new Date().toISOString(),
    });

    // Keep user as pending / deactivate
    await ctx.db.patch(req.userId, { isActive: false });
  },
});

// Generate upload URL for registration documents
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    return await ctx.storage.generateUploadUrl();
  },
});

// Get active companies for dropdown
export const getCompanies = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    return await ctx.db
      .query("companies")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

// Get active sites for a company
export const getSitesByCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    return await ctx.db
      .query("sites")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();
  },
});
