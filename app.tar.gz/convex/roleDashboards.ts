import { query } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { Id } from "./_generated/dataModel.d.ts";

// Dashboard for accounts_manager / billing_manager — finance overview
export const getFinanceDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    totalInvoiced: number;
    totalReceived: number;
    totalExpenses: number;
    pendingVendorBills: number;
    totalVendorBillAmount: number;
    recentInvoices: Array<{ _id: Id<"invoices">; invoiceNumber: string; clientName: string; amount: number; status: string; date: string }>;
    recentVendorBills: Array<{ _id: Id<"vendorBills">; billNumber: string; totalAmount: number; status: string; billDate: string }>;
    activeSitesCount: number;
    thisMonthExpenses: number;
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    const [invoices, vendorBills, sites, expenses] = await Promise.all([
      ctx.db.query("invoices").order("desc").take(200),
      ctx.db.query("vendorBills").order("desc").take(200),
      ctx.db.query("sites").collect(),
      ctx.db.query("siteExpenses").order("desc").take(500),
    ]);

    const totalInvoiced = invoices.reduce((s, inv) => s + inv.totalAmount, 0);
    const totalReceived = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.totalAmount, 0);
    const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);

    const pendingVendorBills = vendorBills.filter(b => b.status === "received" || b.status === "verified");
    const pendingVendorBillAmount = pendingVendorBills.reduce((s, b) => s + b.totalAmount, 0);

    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const thisMonthExpenses = expenses
      .filter(e => e.date.startsWith(currentMonthKey))
      .reduce((s, e) => s + e.amount, 0);

    const recentInvoices = await Promise.all(
      invoices.slice(0, 5).map(async inv => {
        const client = inv.clientId ? await ctx.db.get(inv.clientId) : null;
        return {
          _id: inv._id,
          invoiceNumber: inv.invoiceNumber,
          clientName: client?.name ?? "—",
          amount: inv.totalAmount,
          status: inv.status,
          date: inv.issueDate,
        };
      })
    );

    return {
      totalInvoiced,
      totalReceived,
      totalExpenses,
      pendingVendorBills: pendingVendorBills.length,
      totalVendorBillAmount: pendingVendorBillAmount,
      recentInvoices,
      recentVendorBills: vendorBills.slice(0, 5).map(b => ({
        _id: b._id,
        billNumber: b.billNumber,
        totalAmount: b.totalAmount,
        status: b.status,
        billDate: b.billDate,
      })),
      activeSitesCount: sites.filter(s => s.status === "active").length,
      thisMonthExpenses,
    };
  },
});

// Dashboard for site_incharge — their assigned site only
export const getSiteInchargeDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    siteName: string | null;
    siteCity: string | null;
    todayAttendance: number;
    totalLabour: number;
    activeWorkOrders: number;
    totalWOValue: number;
    thisMonthExpenses: number;
    recentWorkOrders: Array<{ _id: Id<"workOrders">; orderNumber: string; status: string; totalValue: number }>;
    recentAttendance: Array<{ date: string; count: number }>;
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.assignedSiteId) return {
      siteName: null, siteCity: null, todayAttendance: 0, totalLabour: 0,
      activeWorkOrders: 0, totalWOValue: 0, thisMonthExpenses: 0, recentWorkOrders: [], recentAttendance: [],
    };

    const siteId = user.assignedSiteId;
    const [site, labourers, workOrders, expenses] = await Promise.all([
      ctx.db.get(siteId),
      ctx.db.query("labourers").withIndex("by_site", q => q.eq("siteId", siteId)).collect(),
      ctx.db.query("workOrders").withIndex("by_site", q => q.eq("siteId", siteId)).collect(),
      ctx.db.query("siteExpenses").withIndex("by_site", q => q.eq("siteId", siteId)).collect(),
    ]);

    const today = new Date().toISOString().slice(0, 10);
    const attendance = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) => q.eq("siteId", siteId).eq("date", today))
      .collect();

    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const thisMonthExpenses = expenses
      .filter(e => e.date.startsWith(currentMonthKey))
      .reduce((s, e) => s + e.amount, 0);

    const activeWOs = workOrders.filter(w => w.status === "active" || w.status === "amended");

    // Last 7 days attendance
    const recentAttendance: Array<{ date: string; count: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const dayAtt = await ctx.db
        .query("attendance")
        .withIndex("by_site_date", q => q.eq("siteId", siteId).eq("date", dateStr))
        .collect();
      recentAttendance.push({ date: dateStr, count: dayAtt.length });
    }

    return {
      siteName: site?.name ?? null,
      siteCity: site?.city ?? null,
      todayAttendance: attendance.length,
      totalLabour: labourers.length,
      activeWorkOrders: activeWOs.length,
      totalWOValue: activeWOs.reduce((s, w) => s + w.totalValue, 0),
      thisMonthExpenses,
      recentWorkOrders: workOrders
        .sort((a, b) => b._creationTime - a._creationTime)
        .slice(0, 5)
        .map(w => ({ _id: w._id, orderNumber: w.orderNumber, status: w.status, totalValue: w.totalValue })),
      recentAttendance,
    };
  },
});

// Dashboard for viewer — read-only overview
export const getViewerDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    totalSites: number;
    activeSites: number;
    totalLabour: number;
    activeLabour: number;
    totalWorkOrders: number;
    activeWorkOrders: number;
    totalWOValue: number;
    recentSites: Array<{ _id: Id<"sites">; name: string; city: string; status: string }>;
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    const [sites, labourers, workOrders] = await Promise.all([
      ctx.db.query("sites").collect(),
      ctx.db.query("labourers").collect(),
      ctx.db.query("workOrders").collect(),
    ]);

    const activeSites = sites.filter(s => s.status === "active");
    const activeWOs = workOrders.filter(w => w.status === "active" || w.status === "amended");

    return {
      totalSites: sites.length,
      activeSites: activeSites.length,
      totalLabour: labourers.length,
      activeLabour: labourers.filter(l => l.isActive).length,
      totalWorkOrders: workOrders.length,
      activeWorkOrders: activeWOs.length,
      totalWOValue: activeWOs.reduce((s, w) => s + w.totalValue, 0),
      recentSites: activeSites.slice(0, 6).map(s => ({ _id: s._id, name: s.name, city: s.city, status: s.status })),
    };
  },
});

// Dashboard data for a contractor (linked via user.contractorRef)
export const getContractorDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    contractor: { _id: Id<"contractors">; name: string; mobile: string } | null;
    pendingBills: number;
    totalBillAmount: number;
    recentBills: Array<{ _id: Id<"vendorBills">; billNumber: string; totalAmount: number; status: string; billDate: string }>;
    totalPaid: number;
    sites: string[];
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.contractorRef) return { contractor: null, pendingBills: 0, totalBillAmount: 0, recentBills: [], totalPaid: 0, sites: [] };

    const contractor = await ctx.db.get(user.contractorRef);
    if (!contractor) return { contractor: null, pendingBills: 0, totalBillAmount: 0, recentBills: [], totalPaid: 0, sites: [] };

    const allBills = await ctx.db
      .query("vendorBills")
      .withIndex("by_contractor", (q) => q.eq("contractorId", contractor._id))
      .collect();

    const pending = allBills.filter(b => b.status === "received" || b.status === "verified");
    const recentBills = allBills
      .sort((a, b) => b._creationTime - a._creationTime)
      .slice(0, 5)
      .map(b => ({ _id: b._id, billNumber: b.billNumber, totalAmount: b.totalAmount, status: b.status, billDate: b.billDate }));

    const totalPaid = allBills.filter(b => b.status === "paid").reduce((s, b) => s + b.totalAmount, 0);

    const siteIds = [...new Set(allBills.map(b => b.siteId))] as Id<"sites">[];
    const sites = await Promise.all(siteIds.map(id => ctx.db.get(id)));
    const siteNames = sites.filter(Boolean).map(s => s!.name);

    return {
      contractor: { _id: contractor._id, name: contractor.name, mobile: contractor.mobile },
      pendingBills: pending.length,
      totalBillAmount: allBills.reduce((s, b) => s + b.totalAmount, 0),
      recentBills,
      totalPaid,
      sites: siteNames,
    };
  },
});

// Dashboard data for site supervisor / site incharge
export const getSiteSupervisorDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    siteName: string | null;
    todayAttendance: number;
    totalLabour: number;
    recentWorkOrders: Array<{ _id: Id<"workOrders">; orderNumber: string; status: string; totalValue: number }>;
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.assignedSiteId) return { siteName: null, todayAttendance: 0, totalLabour: 0, recentWorkOrders: [] };

    const site = await ctx.db.get(user.assignedSiteId);
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
      .collect();

    const today = new Date().toISOString().slice(0, 10);
    const attendance = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) => q.eq("siteId", user.assignedSiteId!).eq("date", today))
      .collect();

    const workOrders = await ctx.db
      .query("workOrders")
      .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
      .order("desc")
      .take(5);

    return {
      siteName: site?.name ?? null,
      todayAttendance: attendance.length,
      totalLabour: labourers.length,
      recentWorkOrders: workOrders.map(w => ({ _id: w._id, orderNumber: w.orderNumber, status: w.status, totalValue: w.totalValue })),
    };
  },
});

// Dashboard data for labour (linked via user.labourerRef)
export const getLabourDashboard = query({
  args: {},
  handler: async (ctx): Promise<{
    name: string | null;
    siteName: string | null;
    thisMonthDays: number;
    dailyRate: number | null;
    workerCode: string | null;
    monthlySalary: Array<{
      month: string; // "2026-07"
      monthLabel: string; // "July 2026"
      daysPresent: number;
      halfDays: number;
      calculatedSalary: number;
      totalAdvance: number;
      netPayable: number;
    }>;
    advances: Array<{
      date: string;
      amount: number;
      reason: string;
    }>;
    totalAdvanceThisMonth: number;
  }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || !user.labourerRef) return { name: null, siteName: null, thisMonthDays: 0, dailyRate: null, workerCode: null, monthlySalary: [], advances: [], totalAdvanceThisMonth: 0 };

    const labourer = await ctx.db.get(user.labourerRef);
    if (!labourer) return { name: null, siteName: null, thisMonthDays: 0, dailyRate: null, workerCode: null, monthlySalary: [], advances: [], totalAdvanceThisMonth: 0 };

    const site = await ctx.db.get(labourer.siteId);

    // Get all attendance for this labourer
    const allAttendance = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", labourer._id))
      .collect();

    // Get all advances for this labourer
    const allAdvances = await ctx.db
      .query("advances")
      .withIndex("by_labourer", (q) => q.eq("labourerId", labourer._id))
      .collect();

    // Current month info
    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const monthStart = `${currentMonthKey}-01`;
    const monthEnd = `${currentMonthKey}-31`;
    const thisMonthDays = allAttendance.filter(a => a.date >= monthStart && a.date <= monthEnd && a.status === "present").length;

    // Group attendance by month
    const monthMap = new Map<string, { present: number; halfDay: number }>();
    for (const a of allAttendance) {
      const monthKey = a.date.slice(0, 7); // "YYYY-MM"
      const existing = monthMap.get(monthKey) ?? { present: 0, halfDay: 0 };
      if (a.status === "present") existing.present += 1;
      if (a.status === "half_day") existing.halfDay += 1;
      monthMap.set(monthKey, existing);
    }

    // Group advances by month
    const advanceMonthMap = new Map<string, number>();
    for (const adv of allAdvances) {
      const monthKey = adv.date.slice(0, 7);
      advanceMonthMap.set(monthKey, (advanceMonthMap.get(monthKey) ?? 0) + adv.amount);
    }

    // Month name helper
    const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    // Build monthly salary list (sorted desc)
    const allMonths = [...new Set([...monthMap.keys(), ...advanceMonthMap.keys()])].sort().reverse();
    const monthlySalary = allMonths.map(monthKey => {
      const att = monthMap.get(monthKey) ?? { present: 0, halfDay: 0 };
      const totalAdvance = advanceMonthMap.get(monthKey) ?? 0;
      const effectiveDays = att.present + (att.halfDay * 0.5);
      const calculatedSalary = effectiveDays * labourer.dailyRate;
      const [year, month] = monthKey.split("-");
      const monthLabel = `${MONTH_NAMES[parseInt(month) - 1]} ${year}`;
      return {
        month: monthKey,
        monthLabel,
        daysPresent: att.present,
        halfDays: att.halfDay,
        calculatedSalary,
        totalAdvance,
        netPayable: calculatedSalary - totalAdvance,
      };
    });

    // Advances list (recent first, last 20)
    const advances = allAdvances
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 20)
      .map(a => ({
        date: a.date,
        amount: a.amount,
        reason: a.reason ?? "",
      }));

    // This month total advance
    const totalAdvanceThisMonth = advanceMonthMap.get(currentMonthKey) ?? 0;

    return {
      name: labourer.name,
      siteName: site?.name ?? null,
      thisMonthDays,
      dailyRate: labourer.dailyRate,
      workerCode: labourer.workerCode ?? null,
      monthlySalary,
      advances,
      totalAdvanceThisMonth,
    };
  },
});
