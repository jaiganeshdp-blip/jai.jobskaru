import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";

async function getUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const list = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args) => {
    await getUser(ctx);
    if (args.siteId) {
      return await ctx.db.query("safetyViolations").withIndex("by_site", (q) => q.eq("siteId", args.siteId!)).order("desc").collect();
    }
    return await ctx.db.query("safetyViolations").order("desc").collect();
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    violationDate: v.string(),
    description: v.string(),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    penaltyAmount: v.optional(v.number()),
    penaltyStatus: v.union(v.literal("none"), v.literal("pending"), v.literal("paid")),
    photoStorageIds: v.optional(v.array(v.string())),
    severity: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    actionTaken: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getUser(ctx);
    return await ctx.db.insert("safetyViolations", { ...args, reportedBy: user._id });
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("safetyViolations"),
    penaltyStatus: v.union(v.literal("none"), v.literal("pending"), v.literal("paid")),
    actionTaken: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getUser(ctx);
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("safetyViolations") },
  handler: async (ctx, args) => {
    await getUser(ctx);
    await ctx.db.delete(args.id);
  },
});

export const getPhotoUrl = query({
  args: { storageId: v.string() },
  handler: async (ctx, args) => {
    await getUser(ctx);
    return await ctx.storage.getUrl(args.storageId);
  },
});
