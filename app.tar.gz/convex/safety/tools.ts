import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";

async function getUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const list = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args) => {
    await getUser(ctx);
    if (args.siteId) {
      return await ctx.db.query("toolsInventory").withIndex("by_site", (q) => q.eq("siteId", args.siteId!)).collect();
    }
    return await ctx.db.query("toolsInventory").collect();
  },
});

export const add = mutation({
  args: {
    siteId: v.id("sites"),
    name: v.string(),
    type: v.union(
      v.literal("cutter"), v.literal("grinder"), v.literal("drill"),
      v.literal("cable"), v.literal("welding"), v.literal("pump"),
      v.literal("generator"), v.literal("other")
    ),
    quantity: v.number(),
    unit: v.string(),
    condition: v.union(v.literal("good"), v.literal("repair"), v.literal("damaged")),
    purchaseDate: v.optional(v.string()),
    costPerUnit: v.optional(v.number()),
    serialNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getUser(ctx);
    return await ctx.db.insert("toolsInventory", { ...args, addedBy: user._id });
  },
});

export const update = mutation({
  args: {
    id: v.id("toolsInventory"),
    name: v.optional(v.string()),
    quantity: v.optional(v.number()),
    condition: v.optional(v.union(v.literal("good"), v.literal("repair"), v.literal("damaged"))),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getUser(ctx);
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("toolsInventory") },
  handler: async (ctx, args) => {
    await getUser(ctx);
    await ctx.db.delete(args.id);
  },
});
