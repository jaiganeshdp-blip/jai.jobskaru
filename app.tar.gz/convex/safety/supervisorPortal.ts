import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx } from "../_generated/server";

// Get supervisor by workerCode (no auth needed — Worker ID-based login)
async function getSupervisorByToken(ctx: QueryCtx | MutationCtx, token: string) {
  const labourer = await ctx.db
    .query("labourers")
    .withIndex("by_worker_code", (q) => q.eq("workerCode", token.trim().toUpperCase()))
    .unique();
  if (!labourer || !labourer.isSafetySupervisor) {
    throw new ConvexError({ message: "Safety Supervisor nahi mila", code: "NOT_FOUND" });
  }
  return labourer;
}

// Login query — validate Worker Code
export const login = query({
  args: { workerCode: v.string() },
  handler: async (ctx, args): Promise<{ success: boolean; name?: string; siteId?: string }> => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!labourer || !labourer.isSafetySupervisor) return { success: false };
    return { success: true, name: labourer.name, siteId: labourer.siteId };
  },
});

// Full portal data for a safety supervisor
export const getPortalData = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const site = await ctx.db.get(supervisor.siteId);

    // All labourers on the same site
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .collect();

    // PPE stock for this site
    const ppeStock = await ctx.db
      .query("ppeStock")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .collect();

    // PPE distributions for this site
    const distributions = await ctx.db
      .query("ppeDistributions")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .collect();

    // Safety violations for this site
    const violations = await ctx.db
      .query("safetyViolations")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .order("desc")
      .collect();

    // Tools for this site
    const tools = await ctx.db
      .query("toolsInventory")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .collect();

    // Resolve photo URLs for violations
    const violationsWithPhotos = await Promise.all(
      violations.map(async (v) => {
        const photoUrls = await Promise.all(
          (v.photoStorageIds ?? []).map((id) => ctx.storage.getUrl(id))
        );
        return { ...v, photoUrls: photoUrls.filter(Boolean) as string[] };
      })
    );

    return {
      supervisor,
      site,
      labourers,
      ppeStock,
      distributions,
      violations: violationsWithPhotos,
      tools,
    };
  },
});

// Add PPE stock (by supervisor, for their site)
export const addStock = mutation({
  args: {
    token: v.string(),
    itemName: v.string(),
    category: v.union(
      v.literal("helmet"), v.literal("safety_shoes"), v.literal("goggles"),
      v.literal("gloves"), v.literal("jacket"), v.literal("harness"),
      v.literal("mask"), v.literal("other")
    ),
    totalQuantity: v.number(),
    purchaseDate: v.optional(v.string()),
    costPerUnit: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const { token, ...rest } = args;
    // We need a userId-like reference — use a system user approach by searching for the first super_admin
    const adminUser = await ctx.db.query("users").withIndex("by_role", (q) => q.eq("role", "super_admin")).first();
    if (!adminUser) throw new ConvexError({ message: "Admin not found", code: "NOT_FOUND" });
    const totalCost = rest.costPerUnit ? rest.costPerUnit * rest.totalQuantity : undefined;
    return await ctx.db.insert("ppeStock", {
      ...rest,
      siteId: supervisor.siteId,
      totalCost,
      availableQuantity: rest.totalQuantity,
      addedBy: adminUser._id,
    });
  },
});

// Distribute PPE (by supervisor)
export const distribute = mutation({
  args: {
    token: v.string(),
    ppeStockId: v.id("ppeStock"),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    itemName: v.string(),
    quantity: v.number(),
    distributedDate: v.string(),
    condition: v.optional(v.union(v.literal("new"), v.literal("used"), v.literal("damaged"))),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const adminUser = await ctx.db.query("users").withIndex("by_role", (q) => q.eq("role", "super_admin")).first();
    if (!adminUser) throw new ConvexError({ message: "Admin not found", code: "NOT_FOUND" });
    const stock = await ctx.db.get(args.ppeStockId);
    if (!stock) throw new ConvexError({ message: "Stock nahi mila", code: "NOT_FOUND" });
    if (stock.availableQuantity < args.quantity) {
      throw new ConvexError({ message: `Sirf ${stock.availableQuantity} available hain`, code: "BAD_REQUEST" });
    }
    await ctx.db.patch(args.ppeStockId, { availableQuantity: stock.availableQuantity - args.quantity });
    const { token, ...rest } = args;
    return await ctx.db.insert("ppeDistributions", {
      ...rest,
      siteId: supervisor.siteId,
      distributedBy: adminUser._id,
    });
  },
});

// Record violation (by supervisor)
export const generateUploadUrl = mutation({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    await getSupervisorByToken(ctx, args.token);
    return await ctx.storage.generateUploadUrl();
  },
});

export const addViolation = mutation({
  args: {
    token: v.string(),
    violationDate: v.string(),
    description: v.string(),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    penaltyAmount: v.optional(v.number()),
    penaltyStatus: v.union(v.literal("none"), v.literal("pending"), v.literal("paid")),
    photoStorageIds: v.optional(v.array(v.string())),
    severity: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    actionTaken: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const adminUser = await ctx.db.query("users").withIndex("by_role", (q) => q.eq("role", "super_admin")).first();
    if (!adminUser) throw new ConvexError({ message: "Admin not found", code: "NOT_FOUND" });
    const { token, ...rest } = args;
    return await ctx.db.insert("safetyViolations", {
      ...rest,
      siteId: supervisor.siteId,
      reportedBy: adminUser._id,
    });
  },
});

// Update violation penalty status
export const updateViolationStatus = mutation({
  args: {
    token: v.string(),
    id: v.id("safetyViolations"),
    penaltyStatus: v.union(v.literal("none"), v.literal("pending"), v.literal("paid")),
    actionTaken: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const violation = await ctx.db.get(args.id);
    if (!violation || violation.siteId !== supervisor.siteId) {
      throw new ConvexError({ message: "Violation nahi mila", code: "NOT_FOUND" });
    }
    await ctx.db.patch(args.id, { penaltyStatus: args.penaltyStatus, actionTaken: args.actionTaken });
  },
});

// Add tool/machine (by supervisor)
export const addTool = mutation({
  args: {
    token: v.string(),
    name: v.string(),
    type: v.union(
      v.literal("cutter"), v.literal("grinder"), v.literal("drill"),
      v.literal("cable"), v.literal("welding"), v.literal("pump"),
      v.literal("generator"), v.literal("other")
    ),
    quantity: v.number(),
    unit: v.string(),
    condition: v.union(v.literal("good"), v.literal("repair"), v.literal("damaged")),
    purchaseDate: v.optional(v.string()),
    costPerUnit: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const adminUser = await ctx.db.query("users").withIndex("by_role", (q) => q.eq("role", "super_admin")).first();
    if (!adminUser) throw new ConvexError({ message: "Admin not found", code: "NOT_FOUND" });
    const { token, ...rest } = args;
    return await ctx.db.insert("toolsInventory", {
      ...rest,
      siteId: supervisor.siteId,
      addedBy: adminUser._id,
    });
  },
});

// ─── My Account: salary, attendance, advances for the supervisor themselves ──
export const getMyAccount = query({
  args: { token: v.string(), month: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const site = await ctx.db.get(supervisor.siteId);
    const targetMonth = args.month ?? new Date().toISOString().slice(0, 7);
    const monthStart = targetMonth + "-01";
    const monthEnd = targetMonth + "-31";

    // Attendance for this supervisor this month
    const attendanceRows = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) =>
        q.eq("siteId", supervisor.siteId).gte("date", monthStart).lte("date", monthEnd)
      )
      .collect();
    const myAttendance = attendanceRows.filter((a) => a.labourerId === supervisor._id);

    const presentDays = myAttendance.filter((a) => a.status === "present").length;
    const halfDays = myAttendance.filter((a) => a.status === "half_day").length;
    const absentDays = myAttendance.filter((a) => a.status === "absent").length;

    // Advances for this supervisor this month
    const advances = await ctx.db
      .query("advances")
      .withIndex("by_site_date", (q) =>
        q.eq("siteId", supervisor.siteId).gte("date", monthStart).lte("date", monthEnd)
      )
      .collect();
    const myAdvances = advances.filter((a) => a.labourerId === supervisor._id);
    const totalAdvance = myAdvances.reduce((s, a) => s + a.amount, 0);

    // Salary sheet entry for this supervisor this month
    const salarySheets = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) =>
        q.eq("siteId", supervisor.siteId).eq("month", targetMonth)
      )
      .collect();

    let salaryEntry = null;
    if (salarySheets.length > 0) {
      const entries = await ctx.db
        .query("salaryEntries")
        .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", salarySheets[0]._id))
        .collect();
      salaryEntry = entries.find((e) => e.labourerId === supervisor._id) ?? null;
    }

    return {
      supervisor,
      site: site ? { name: (site as { name?: string }).name ?? "—", city: (site as { city?: string }).city } : null,
      targetMonth,
      presentDays,
      halfDays,
      absentDays,
      myAdvances,
      totalAdvance,
      salaryEntry,
      myAttendance,
    };
  },
});

export const updateToolCondition = mutation({
  args: {
    token: v.string(),
    id: v.id("toolsInventory"),
    condition: v.union(v.literal("good"), v.literal("repair"), v.literal("damaged")),
  },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.token);
    const tool = await ctx.db.get(args.id);
    if (!tool || tool.siteId !== supervisor.siteId) {
      throw new ConvexError({ message: "Tool nahi mila", code: "NOT_FOUND" });
    }
    await ctx.db.patch(args.id, { condition: args.condition });
  },
});
