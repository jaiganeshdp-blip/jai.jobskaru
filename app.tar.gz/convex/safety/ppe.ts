import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";

async function getUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

// ---- PPE Stock ----

export const generateUploadUrl = mutation({ args: {}, handler: async (ctx) => {
  await getUser(ctx);
  return await ctx.storage.generateUploadUrl();
}});

export const listStock = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args) => {
    await getUser(ctx);
    if (args.siteId) {
      return await ctx.db.query("ppeStock").withIndex("by_site", (q) => q.eq("siteId", args.siteId!)).collect();
    }
    return await ctx.db.query("ppeStock").collect();
  },
});

export const addStock = mutation({
  args: {
    siteId: v.id("sites"),
    itemName: v.string(),
    category: v.union(
      v.literal("helmet"), v.literal("safety_shoes"), v.literal("goggles"),
      v.literal("gloves"), v.literal("jacket"), v.literal("harness"),
      v.literal("mask"), v.literal("other")
    ),
    totalQuantity: v.number(),
    purchaseDate: v.optional(v.string()),
    supplierId: v.optional(v.id("suppliers")),
    costPerUnit: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getUser(ctx);
    const totalCost = args.costPerUnit ? args.costPerUnit * args.totalQuantity : undefined;
    return await ctx.db.insert("ppeStock", {
      ...args,
      totalCost,
      availableQuantity: args.totalQuantity,
      addedBy: user._id,
    });
  },
});

export const updateStock = mutation({
  args: {
    id: v.id("ppeStock"),
    itemName: v.optional(v.string()),
    totalQuantity: v.optional(v.number()),
    availableQuantity: v.optional(v.number()),
    costPerUnit: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getUser(ctx);
    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
  },
});

export const removeStock = mutation({
  args: { id: v.id("ppeStock") },
  handler: async (ctx, args) => {
    await getUser(ctx);
    await ctx.db.delete(args.id);
  },
});

// ---- PPE Distribution ----

export const listDistributions = query({
  args: { siteId: v.optional(v.id("sites")), labourerId: v.optional(v.id("labourers")), contractorId: v.optional(v.id("contractors")) },
  handler: async (ctx, args) => {
    await getUser(ctx);
    let rows;
    if (args.labourerId) {
      rows = await ctx.db.query("ppeDistributions").withIndex("by_labourer", (q) => q.eq("labourerId", args.labourerId!)).collect();
    } else if (args.contractorId) {
      rows = await ctx.db.query("ppeDistributions").withIndex("by_contractor", (q) => q.eq("contractorId", args.contractorId!)).collect();
    } else if (args.siteId) {
      rows = await ctx.db.query("ppeDistributions").withIndex("by_site", (q) => q.eq("siteId", args.siteId!)).collect();
    } else {
      rows = await ctx.db.query("ppeDistributions").collect();
    }
    return rows;
  },
});

export const distribute = mutation({
  args: {
    ppeStockId: v.id("ppeStock"),
    siteId: v.id("sites"),
    recipientType: v.union(v.literal("labour"), v.literal("contractor")),
    labourerId: v.optional(v.id("labourers")),
    contractorId: v.optional(v.id("contractors")),
    itemName: v.string(),
    quantity: v.number(),
    distributedDate: v.string(),
    condition: v.optional(v.union(v.literal("new"), v.literal("used"), v.literal("damaged"))),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getUser(ctx);
    const stock = await ctx.db.get(args.ppeStockId);
    if (!stock) throw new ConvexError({ message: "Stock not found", code: "NOT_FOUND" });
    if (stock.availableQuantity < args.quantity) {
      throw new ConvexError({ message: `Sirf ${stock.availableQuantity} available hain`, code: "BAD_REQUEST" });
    }
    await ctx.db.patch(args.ppeStockId, { availableQuantity: stock.availableQuantity - args.quantity });
    return await ctx.db.insert("ppeDistributions", { ...args, distributedBy: user._id });
  },
});

export const removeDistribution = mutation({
  args: { id: v.id("ppeDistributions") },
  handler: async (ctx, args) => {
    await getUser(ctx);
    const dist = await ctx.db.get(args.id);
    if (dist) {
      // Restore stock
      const stock = await ctx.db.get(dist.ppeStockId);
      if (stock) await ctx.db.patch(dist.ppeStockId, { availableQuantity: stock.availableQuantity + dist.quantity });
    }
    await ctx.db.delete(args.id);
  },
});
