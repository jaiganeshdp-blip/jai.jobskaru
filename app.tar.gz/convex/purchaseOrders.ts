import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

const itemValidator = v.object({
  name: v.string(),
  quantity: v.number(),
  unit: v.string(),
  ratePerUnit: v.number(),
  totalAmount: v.number(),
});

const statusValidator = v.union(
  v.literal("draft"),
  v.literal("sent"),
  v.literal("partially_received"),
  v.literal("closed"),
  v.literal("cancelled")
);

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    supplierId: v.optional(v.id("suppliers")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let pos;
    const effectiveSiteId = args.siteId ?? (user.role === "site_incharge" ? user.assignedSiteId : undefined);

    if (effectiveSiteId) {
      pos = await ctx.db
        .query("purchaseOrders")
        .withIndex("by_site", (q) => q.eq("siteId", effectiveSiteId))
        .collect();
    } else if (args.supplierId) {
      pos = await ctx.db
        .query("purchaseOrders")
        .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId!))
        .collect();
    } else {
      pos = await ctx.db.query("purchaseOrders").collect();
    }

    if (args.status && args.status !== "all") {
      pos = pos.filter((p) => p.status === args.status);
    }

    const enriched = await Promise.all(
      pos.map(async (po) => {
        const site = await ctx.db.get(po.siteId);
        const supplier = po.supplierId ? await ctx.db.get(po.supplierId) : null;
        const contractor = po.contractorId ? await ctx.db.get(po.contractorId) : null;
        const company = await ctx.db.get(po.companyId);
        const receipts = await ctx.db
          .query("poReceipts")
          .withIndex("by_po", (q) => q.eq("purchaseOrderId", po._id))
          .collect();
        return {
          ...po,
          siteName: site?.name ?? "Unknown",
          supplierName: supplier?.name ?? contractor?.name ?? "Unknown",
          companyName: company?.name ?? "Unknown",
          receiptCount: receipts.length,
        };
      })
    );

    return enriched.sort((a, b) => b.issueDate.localeCompare(a.issueDate));
  },
});

export const getDetail = query({
  args: { id: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const po = await ctx.db.get(args.id);
    if (!po) return null;

    const site = await ctx.db.get(po.siteId);
    const supplier = po.supplierId ? await ctx.db.get(po.supplierId) : null;
    const contractor = po.contractorId ? await ctx.db.get(po.contractorId) : null;
    const company = await ctx.db.get(po.companyId);
    const workOrder = po.workOrderId ? await ctx.db.get(po.workOrderId) : null;

    const receiptDocs = await ctx.db
      .query("poReceipts")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.id))
      .collect();

    const receipts = await Promise.all(
      receiptDocs.map(async (r) => {
        const receiver = await ctx.db.get(r.receivedBy);
        return {
          _id: r._id as string,
          receivedDate: r.receivedDate,
          receivedItems: r.receivedItems,
          notes: r.notes,
          receivedByName: receiver?.name ?? "Unknown",
        };
      })
    );

    // Compute total received qty per item index
    const receivedQtyByItem: Record<number, number> = {};
    for (const receipt of receiptDocs) {
      for (const ri of receipt.receivedItems) {
        receivedQtyByItem[ri.itemIndex] = (receivedQtyByItem[ri.itemIndex] ?? 0) + ri.receivedQuantity;
      }
    }

    return { po, site, supplier, contractor, company, workOrder, receipts, receivedQtyByItem };
  },
});

export const create = mutation({
  args: {
    poNumber: v.string(),
    siteId: v.id("sites"),
    supplierId: v.id("suppliers"),
    companyId: v.id("companies"),
    workOrderId: v.optional(v.id("workOrders")),
    status: statusValidator,
    issueDate: v.string(),
    expectedDeliveryDate: v.optional(v.string()),
    items: v.array(itemValidator),
    totalValue: v.number(),
    terms: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const existing = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_po_number", (q) => q.eq("poNumber", args.poNumber))
      .first();
    if (existing) throw new Error("PO number already exists");
    return await ctx.db.insert("purchaseOrders", { ...args, createdBy: user._id });
  },
});

export const update = mutation({
  args: {
    id: v.id("purchaseOrders"),
    status: v.optional(statusValidator),
    expectedDeliveryDate: v.optional(v.string()),
    terms: v.optional(v.string()),
    notes: v.optional(v.string()),
    items: v.optional(v.array(itemValidator)),
    totalValue: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("purchaseOrders"),
    status: statusValidator,
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") throw new Error("Forbidden");
    await ctx.db.patch(args.id, { status: args.status });
  },
});

export const recordReceipt = mutation({
  args: {
    purchaseOrderId: v.id("purchaseOrders"),
    materialId: v.optional(v.id("materials")),
    receivedDate: v.string(),
    receivedItems: v.array(
      v.object({ itemIndex: v.number(), receivedQuantity: v.number() })
    ),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) throw new Error("Purchase order not found");

    await ctx.db.insert("poReceipts", {
      purchaseOrderId: args.purchaseOrderId,
      materialId: args.materialId,
      receivedDate: args.receivedDate,
      receivedItems: args.receivedItems,
      notes: args.notes,
      receivedBy: user._id,
    });

    // Compute total received per item to decide status
    const allReceipts = await ctx.db
      .query("poReceipts")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();

    const receivedQty: Record<number, number> = {};
    for (const r of allReceipts) {
      for (const ri of r.receivedItems) {
        receivedQty[ri.itemIndex] = (receivedQty[ri.itemIndex] ?? 0) + ri.receivedQuantity;
      }
    }

    const allFulfilled = po.items.every((item, idx) => (receivedQty[idx] ?? 0) >= item.quantity);
    const anyReceived = po.items.some((_, idx) => (receivedQty[idx] ?? 0) > 0);

    if (allFulfilled) {
      await ctx.db.patch(args.purchaseOrderId, { status: "closed" });
    } else if (anyReceived) {
      await ctx.db.patch(args.purchaseOrderId, { status: "partially_received" });
    }
  },
});

export const remove = mutation({
  args: { id: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    // Delete associated receipts
    const receipts = await ctx.db
      .query("poReceipts")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.id))
      .collect();
    for (const r of receipts) await ctx.db.delete(r._id);
    await ctx.db.delete(args.id);
  },
});
