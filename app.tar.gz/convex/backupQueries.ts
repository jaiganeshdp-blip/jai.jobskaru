import { internalQuery } from "./_generated/server";
import { v } from "convex/values";

const TABLES = [
  "users", "companies", "sites", "clients", "suppliers", "contractors",
  "labourers", "attendance", "workOrders", "purchaseOrders", "poReceipts",
  "workOrderAmendments", "materials", "salarySheets", "salaryEntries",
  "invoices", "expenses", "siteDiary", "deliveryChallans",
  "payments", "vendorBills", "siteExpenses", "notifications",
  "notificationPreferences", "screensaverSlides", "screensaverSettings",
] as const;

type TableName = typeof TABLES[number];

export const getUserByToken = internalQuery({
  args: { tokenIdentifier: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", args.tokenIdentifier))
      .unique();
  },
});

export const getTableRows = internalQuery({
  args: { table: v.string() },
  handler: async (ctx, args): Promise<unknown[]> => {
    const tableName = args.table as TableName;
    return await ctx.db.query(tableName).take(8192);
  },
});
