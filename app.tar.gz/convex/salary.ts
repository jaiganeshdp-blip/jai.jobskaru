import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireRole } from "./lib/auth.ts";
import { internal } from "./_generated/api.js";

// List salary sheets with filters
export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    month: v.optional(v.string()),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    let sheets = await ctx.db.query("salarySheets").collect();

    // Site incharge only sees their site
    if (user.role === "site_incharge" && user.assignedSiteId) {
      sheets = sheets.filter((s) => s.siteId === user.assignedSiteId);
    }
    if (args.siteId) sheets = sheets.filter((s) => s.siteId === args.siteId);
    if (args.month) sheets = sheets.filter((s) => s.month === args.month);
    if (args.status) sheets = sheets.filter((s) => s.status === args.status);

    // Enrich with site info
    const enriched = await Promise.all(
      sheets.map(async (sheet) => {
        const site = await ctx.db.get(sheet.siteId);
        const preparedByUser = await ctx.db.get(sheet.preparedBy);
        const entries = await ctx.db
          .query("salaryEntries")
          .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", sheet._id))
          .collect();
        return {
          ...sheet,
          siteName: site?.name ?? "Unknown",
          preparedByName: preparedByUser?.name ?? "Unknown",
          labourCount: entries.length,
        };
      })
    );

    return enriched.sort((a, b) => b.month.localeCompare(a.month));
  },
});

// Get sheet detail with all entries
export const getDetail = query({
  args: { id: v.id("salarySheets") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const sheet = await ctx.db.get(args.id);
    if (!sheet) return null;

    const site = await ctx.db.get(sheet.siteId);
    const preparedByUser = await ctx.db.get(sheet.preparedBy);
    const approvedByUser = sheet.approvedBy ? await ctx.db.get(sheet.approvedBy) : null;

    const entries = await ctx.db
      .query("salaryEntries")
      .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", args.id))
      .collect();

    const enrichedEntries = await Promise.all(
      entries.map(async (entry) => {
        const labourer = await ctx.db.get(entry.labourerId);
        const contractor = labourer?.contractorId
          ? await ctx.db.get(labourer.contractorId)
          : null;
        // Advances for this labourer in this month
        const monthStart = `${sheet.month}-01`;
        const monthEnd = `${sheet.month}-31`;
        const allAdv = await ctx.db
          .query("advances")
          .withIndex("by_labourer", (q) => q.eq("labourerId", entry.labourerId))
          .collect();
        const advances = allAdv.filter((a) => a.date >= monthStart && a.date <= monthEnd);
        const totalAdvance = advances.reduce((s, a) => s + a.amount, 0);
        return {
          ...entry,
          labourerName: labourer?.name ?? "Unknown",
          designation: labourer?.designation ?? "",
          contractorName: contractor?.name ?? "",
          totalAdvance,
          advances,
        };
      })
    );

    return {
      ...sheet,
      siteName: site?.name ?? "Unknown",
      siteCity: site?.city ?? "",
      preparedByName: preparedByUser?.name ?? "Unknown",
      approvedByName: approvedByUser?.name ?? "",
      entries: enrichedEntries,
    };
  },
});

// Generate salary sheet for a site+month from attendance data
export const generate = mutation({
  args: {
    siteId: v.id("sites"),
    month: v.string(), // YYYY-MM
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    // Check no existing sheet
    const existing = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) =>
        q.eq("siteId", args.siteId).eq("month", args.month)
      )
      .first();
    if (existing) throw new Error("Salary sheet already exists for this month");

    // Get all active labourers for site
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    const activeLabourers = labourers.filter((l) => l.isActive);

    // Get attendance for the month
    const monthStart = `${args.month}-01`;
    const monthEnd = `${args.month}-31`;

    const sheetId = await ctx.db.insert("salarySheets", {
      siteId: args.siteId,
      month: args.month,
      status: "draft",
      preparedBy: user._id,
      totalAmount: 0,
      paidDate: undefined,
    });

    let totalAmount = 0;

    // Advance totals for this site+month
    const allAdvances = await ctx.db
      .query("advances")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    const advanceMap: Record<string, number> = {};
    for (const adv of allAdvances) {
      if (adv.date >= monthStart && adv.date <= monthEnd) {
        advanceMap[adv.labourerId] = (advanceMap[adv.labourerId] ?? 0) + adv.amount;
      }
    }

    for (const labourer of activeLabourers) {
      // Count attendance for the month
      const attendance = await ctx.db
        .query("attendance")
        .withIndex("by_labourer_date", (q) => q.eq("labourerId", labourer._id))
        .collect();

      const monthAttendance = attendance.filter(
        (a) => a.date >= monthStart && a.date <= monthEnd
      );

      const daysWorked = monthAttendance.filter((a) => a.status === "present").length;
      const halfDays = monthAttendance.filter((a) => a.status === "half_day").length;
      const effectiveDays = daysWorked + halfDays * 0.5;
      const grossAmount = effectiveDays * labourer.dailyRate;
      const advanceDeduction = advanceMap[labourer._id] ?? 0;
      const deductions = advanceDeduction;
      const netAmount = Math.max(0, grossAmount - deductions);

      await ctx.db.insert("salaryEntries", {
        salarySheetId: sheetId,
        labourerId: labourer._id,
        daysWorked,
        halfDays,
        dailyRate: labourer.dailyRate,
        grossAmount,
        deductions,
        netAmount,
        paymentMode: undefined,
        notes: advanceDeduction > 0 ? `Advance kaat gaya: ₹${advanceDeduction}` : undefined,
      });

      totalAmount += netAmount;
    }

    await ctx.db.patch(sheetId, { totalAmount });
    return sheetId;
  },
});

// Create empty salary sheet (manual entry)
export const createManual = mutation({
  args: {
    siteId: v.id("sites"),
    month: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    const existing = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) =>
        q.eq("siteId", args.siteId).eq("month", args.month)
      )
      .first();
    if (existing) throw new Error("Salary sheet already exists for this month");

    return await ctx.db.insert("salarySheets", {
      siteId: args.siteId,
      month: args.month,
      status: "draft",
      preparedBy: user._id,
      totalAmount: 0,
    });
  },
});

// Update a salary entry
export const updateEntry = mutation({
  args: {
    entryId: v.id("salaryEntries"),
    daysWorked: v.number(),
    halfDays: v.number(),
    dailyRate: v.number(),
    deductions: v.number(),
    paymentMode: v.optional(v.string()),
    notes: v.optional(v.string()),
    nastaDays: v.optional(v.number()),
    nastaPerDay: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const { entryId, nastaDays, nastaPerDay, ...fields } = args;
    const grossAmount = (fields.daysWorked + fields.halfDays * 0.5) * fields.dailyRate;
    const nastaAmount = (nastaDays ?? 0) * (nastaPerDay ?? 0);
    const netAmount = grossAmount + nastaAmount - fields.deductions;
    await ctx.db.patch(entryId, {
      ...fields,
      grossAmount,
      netAmount,
      nastaDays,
      nastaPerDay,
      nastaAmount,
    });

    // Recalculate sheet total
    const entry = await ctx.db.get(entryId);
    if (entry) {
      const allEntries = await ctx.db
        .query("salaryEntries")
        .withIndex("by_salary_sheet", (q) =>
          q.eq("salarySheetId", entry.salarySheetId)
        )
        .collect();
      const total = allEntries.reduce((sum, e) => {
        if (e._id === entryId) return sum + netAmount;
        return sum + e.netAmount;
      }, 0);
      await ctx.db.patch(entry.salarySheetId, { totalAmount: total });
    }
  },
});

// Add labourer entry to sheet
export const addEntry = mutation({
  args: {
    salarySheetId: v.id("salarySheets"),
    labourerId: v.id("labourers"),
    daysWorked: v.number(),
    halfDays: v.number(),
    dailyRate: v.number(),
    deductions: v.number(),
    paymentMode: v.optional(v.string()),
    notes: v.optional(v.string()),
    nastaDays: v.optional(v.number()),
    nastaPerDay: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const nastaAmount = (args.nastaDays ?? 0) * (args.nastaPerDay ?? 0);
    const grossAmount = (args.daysWorked + args.halfDays * 0.5) * args.dailyRate;
    const netAmount = grossAmount + nastaAmount - args.deductions;

    await ctx.db.insert("salaryEntries", {
      salarySheetId: args.salarySheetId,
      labourerId: args.labourerId,
      daysWorked: args.daysWorked,
      halfDays: args.halfDays,
      dailyRate: args.dailyRate,
      grossAmount,
      deductions: args.deductions,
      netAmount,
      paymentMode: args.paymentMode,
      notes: args.notes,
      nastaDays: args.nastaDays,
      nastaPerDay: args.nastaPerDay,
      nastaAmount,
    });

    // Recalculate sheet total
    const allEntries = await ctx.db
      .query("salaryEntries")
      .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", args.salarySheetId))
      .collect();
    const total = allEntries.reduce((sum, e) => sum + e.netAmount, 0) + netAmount;
    await ctx.db.patch(args.salarySheetId, { totalAmount: total });
  },
});

// Remove entry
export const removeEntry = mutation({
  args: { entryId: v.id("salaryEntries") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const entry = await ctx.db.get(args.entryId);
    if (!entry) return;
    await ctx.db.delete(args.entryId);

    // Recalculate
    const allEntries = await ctx.db
      .query("salaryEntries")
      .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", entry.salarySheetId))
      .collect();
    const total = allEntries
      .filter((e) => e._id !== args.entryId)
      .reduce((sum, e) => sum + e.netAmount, 0);
    await ctx.db.patch(entry.salarySheetId, { totalAmount: total });
  },
});

// Submit for approval (site incharge → super admin)
export const submit = mutation({
  args: { id: v.id("salarySheets") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    await ctx.db.patch(args.id, { status: "submitted" });
    const sheet = await ctx.db.get(args.id);
    const site = sheet ? await ctx.db.get(sheet.siteId) : null;
    const monthLabel = sheet ? new Date(`${sheet.month}-01`).toLocaleDateString("en-IN", { month: "long", year: "numeric" }) : "";
    await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
      type: "salary_processed",
      title: "Salary Sheet Submitted",
      message: `Salary sheet for ${site?.name ?? ""} (${monthLabel}) submitted for approval — ₹${(sheet?.totalAmount ?? 0).toLocaleString("en-IN")}`,
      link: `/salary/${args.id}`,
      relatedId: args.id,
    });
  },
});

// Approve sheet (super admin)
export const approve = mutation({
  args: { id: v.id("salarySheets") },
  handler: async (ctx, args) => {
    const user = await requireRole(ctx, ["super_admin"]);
    await ctx.db.patch(args.id, { status: "approved", approvedBy: user._id });
    const sheet = await ctx.db.get(args.id);
    const site = sheet ? await ctx.db.get(sheet.siteId) : null;
    const monthLabel = sheet ? new Date(`${sheet.month}-01`).toLocaleDateString("en-IN", { month: "long", year: "numeric" }) : "";
    await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
      type: "salary_approved",
      title: "Salary Sheet Approved",
      message: `Salary sheet for ${site?.name ?? ""} (${monthLabel}) approved — ₹${(sheet?.totalAmount ?? 0).toLocaleString("en-IN")}`,
      link: `/salary/${args.id}`,
      relatedId: args.id,
    });
  },
});

// Mark as paid
export const markPaid = mutation({
  args: {
    id: v.id("salarySheets"),
    paidDate: v.string(),
  },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin"]);
    await ctx.db.patch(args.id, { status: "paid", paidDate: args.paidDate });
  },
});

// Delete sheet - any status (super_admin only)
export const remove = mutation({
  args: { id: v.id("salarySheets") },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin"]);
    const sheet = await ctx.db.get(args.id);
    if (!sheet) return;

    const entries = await ctx.db
      .query("salaryEntries")
      .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", args.id))
      .collect();
    for (const entry of entries) await ctx.db.delete(entry._id);
    await ctx.db.delete(args.id);
  },
});
