import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import { internal } from "./_generated/api.js";

const itemValidator = v.object({
  name: v.string(),
  quantity: v.number(),
  unit: v.string(),
  ratePerUnit: v.number(),
  totalAmount: v.number(),
});

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    supplierId: v.optional(v.id("suppliers")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let records;
    if (args.siteId) {
      records = await ctx.db
        .query("materials")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .collect();
    } else if (args.supplierId) {
      records = await ctx.db
        .query("materials")
        .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId!))
        .collect();
    } else if (user.role === "site_incharge" && user.assignedSiteId) {
      records = await ctx.db
        .query("materials")
        .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
        .collect();
    } else {
      records = await ctx.db.query("materials").collect();
    }

    if (args.status && args.status !== "all") {
      records = records.filter((r) => r.status === args.status);
    }

    // Enrich with site and supplier names
    const enriched = await Promise.all(
      records.map(async (r) => {
        const site = await ctx.db.get(r.siteId);
        const supplier = await ctx.db.get(r.supplierId);
        const enteredBy = await ctx.db.get(r.enteredBy);
        return {
          ...r,
          siteName: site?.name,
          supplierName: supplier?.name,
          enteredByName: enteredBy?.name,
        };
      })
    );

    return enriched.sort((a, b) => b.deliveryDate.localeCompare(a.deliveryDate));
  },
});

export const get = query({
  args: { id: v.id("materials") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const record = await ctx.db.get(args.id);
    if (!record) return null;
    const site = await ctx.db.get(record.siteId);
    const supplier = await ctx.db.get(record.supplierId);
    const enteredBy = await ctx.db.get(record.enteredBy);
    const approvedBy = record.approvedBy ? await ctx.db.get(record.approvedBy) : null;
    // Resolve bill file URLs
    const billFilesWithUrls = await Promise.all(
      (record.billFiles ?? []).map(async (f) => ({
        ...f,
        url: await ctx.storage.getUrl(f.storageId),
      }))
    );
    return { ...record, site, supplier, enteredByUser: enteredBy, approvedByUser: approvedBy, billFilesWithUrls };
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    supplierId: v.id("suppliers"),
    invoiceNumber: v.optional(v.string()),
    vehicleNumber: v.optional(v.string()),
    deliveryDate: v.string(),
    items: v.array(itemValidator),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const totalAmount = args.items.reduce((s, i) => s + i.totalAmount, 0);
    return await ctx.db.insert("materials", {
      ...args,
      totalAmount,
      status: "pending",
      enteredBy: user._id,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("materials"),
    invoiceNumber: v.optional(v.string()),
    vehicleNumber: v.optional(v.string()),
    deliveryDate: v.optional(v.string()),
    items: v.optional(v.array(itemValidator)),
    notes: v.optional(v.string()),
    supplierId: v.optional(v.id("suppliers")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const { id, items, ...rest } = args;
    if (items !== undefined) {
      const totalAmount = items.reduce((s, i) => s + i.totalAmount, 0);
      await ctx.db.patch(id, { ...rest, items, totalAmount });
    } else {
      await ctx.db.patch(id, rest);
    }
  },
});

export const approve = mutation({
  args: { id: v.id("materials") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin") throw new Error("Only super admin can approve");
    await ctx.db.patch(args.id, { status: "approved", approvedBy: user._id });
    const mat = await ctx.db.get(args.id);
    const site = mat ? await ctx.db.get(mat.siteId) : null;
    const supplier = mat ? await ctx.db.get(mat.supplierId) : null;
    await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
      type: "material_approved",
      title: "Material Delivery Approved",
      message: `Delivery from ${supplier?.name ?? "supplier"} at ${site?.name ?? ""} approved — ₹${(mat?.totalAmount ?? 0).toLocaleString("en-IN")}`,
      link: `/materials/${args.id}`,
      relatedId: args.id,
    });
  },
});

export const reject = mutation({
  args: { id: v.id("materials"), notes: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin") throw new Error("Only super admin can reject");
    await ctx.db.patch(args.id, { status: "rejected", approvedBy: user._id, notes: args.notes });
    const mat = await ctx.db.get(args.id);
    const site = mat ? await ctx.db.get(mat.siteId) : null;
    const supplier = mat ? await ctx.db.get(mat.supplierId) : null;
    await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
      type: "material_rejected",
      title: "Material Delivery Rejected",
      message: `Delivery from ${supplier?.name ?? "supplier"} at ${site?.name ?? ""} rejected${args.notes ? `: ${args.notes}` : ""}`,
      link: `/materials/${args.id}`,
      relatedId: args.id,
    });
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const addBillFiles = mutation({
  args: {
    id: v.id("materials"),
    files: v.array(v.object({
      storageId: v.id("_storage"),
      name: v.string(),
      type: v.string(),
    })),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const record = await ctx.db.get(args.id);
    if (!record) throw new Error("Not found");
    const existing = record.billFiles ?? [];
    await ctx.db.patch(args.id, { billFiles: [...existing, ...args.files] });
  },
});

export const removeBillFile = mutation({
  args: { id: v.id("materials"), storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin" && user.role !== "site_incharge") {
      throw new Error("Forbidden");
    }
    const record = await ctx.db.get(args.id);
    if (!record) throw new Error("Not found");
    await ctx.storage.delete(args.storageId);
    const updated = (record.billFiles ?? []).filter((f) => f.storageId !== args.storageId);
    await ctx.db.patch(args.id, { billFiles: updated });
  },
});

export const remove = mutation({
  args: { id: v.id("materials") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
