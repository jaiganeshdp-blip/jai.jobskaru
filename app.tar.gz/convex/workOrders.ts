import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    clientId: v.optional(v.id("clients")),
    status: v.optional(v.string()),
    orderType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let workOrders;
    if (args.siteId) {
      workOrders = await ctx.db
        .query("workOrders")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .collect();
    } else if (user.role === "site_incharge" && user.assignedSiteId) {
      workOrders = await ctx.db
        .query("workOrders")
        .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
        .collect();
    } else {
      workOrders = await ctx.db.query("workOrders").collect();
    }

    if (args.clientId) {
      workOrders = workOrders.filter((wo) => wo.clientId === args.clientId);
    }
    if (args.status && args.status !== "all") {
      workOrders = workOrders.filter((wo) => wo.status === args.status);
    }
    if (args.orderType && args.orderType !== "all") {
      workOrders = workOrders.filter((wo) => (wo.orderType ?? "incoming") === args.orderType);
    }

    // Enrich with site, client, contractor, company names
    const enriched = await Promise.all(
      workOrders.map(async (wo) => {
        const site = await ctx.db.get(wo.siteId);
        const client = wo.clientId ? await ctx.db.get(wo.clientId) : null;
        const contractor = wo.contractorId ? await ctx.db.get(wo.contractorId) : null;
        const company = await ctx.db.get(wo.companyId);
        const amendmentCount = (
          await ctx.db
            .query("workOrderAmendments")
            .withIndex("by_work_order", (q) => q.eq("workOrderId", wo._id))
            .collect()
        ).length;
        return {
          ...wo,
          siteName: site?.name,
          clientName: client?.name,
          contractorName: contractor?.name,
          companyName: company?.name,
          amendmentCount,
        };
      })
    );

    return enriched.sort((a, b) => b._creationTime - a._creationTime);
  },
});

export const get = query({
  args: { id: v.id("workOrders") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

export const getDetail = query({
  args: { id: v.id("workOrders") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const wo = await ctx.db.get(args.id);
    if (!wo) return null;

    const site = await ctx.db.get(wo.siteId);
    const client = wo.clientId ? await ctx.db.get(wo.clientId) : null;
    const contractor = wo.contractorId ? await ctx.db.get(wo.contractorId) : null;
    const company = await ctx.db.get(wo.companyId);

    const amendments = await ctx.db
      .query("workOrderAmendments")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.id))
      .order("asc")
      .collect();

    // Enrich amendments with approver names
    const enrichedAmendments = await Promise.all(
      amendments.map(async (a) => {
        const approver = a.approvedBy ? await ctx.db.get(a.approvedBy) : null;
        return { ...a, approverName: approver?.name };
      })
    );

    // Get materials cost for this site
    const materials = await ctx.db
      .query("materials")
      .withIndex("by_site", (q) => q.eq("siteId", wo.siteId))
      .collect();
    const materialsCost = materials.reduce((s, m) => s + m.totalAmount, 0);

    // Salary cost
    const salarySheets = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) => q.eq("siteId", wo.siteId))
      .collect();
    const salaryCost = salarySheets.reduce((s, sh) => s + sh.totalAmount, 0);

    // Get related invoices
    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_site", (q) => q.eq("siteId", wo.siteId))
      .collect();
    const invoicesForWO = invoices.filter((inv) => inv.workOrderId === args.id);
    const invoicedAmount = invoicesForWO.reduce((s, inv) => s + inv.totalAmount, 0);
    const invoicePaidAmount = invoicesForWO.reduce((s, inv) => s + inv.paidAmount, 0);

    // Get direct payments linked to this work order
    const directPayments = await ctx.db
      .query("payments")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.id))
      .collect();
    const receivedFromClient = directPayments
      .filter((p) => p.type === "received")
      .reduce((s, p) => s + p.amount, 0);
    const paidToVendors = directPayments
      .filter((p) => p.type === "paid")
      .reduce((s, p) => s + p.amount, 0);

    const totalReceived = receivedFromClient + invoicePaidAmount;
    const balanceDue = wo.totalValue - totalReceived;

    return {
      workOrder: wo,
      site,
      client,
      contractor,
      company,
      amendments: enrichedAmendments,
      financials: {
        totalValue: wo.totalValue,
        materialsCost,
        salaryCost,
        invoicedAmount,
        invoicePaidAmount,
        receivedFromClient,
        paidToVendors,
        totalReceived,
        balanceDue,
        totalCost: materialsCost + salaryCost,
        margin: wo.totalValue - (materialsCost + salaryCost),
      },
    };
  },
});

export const getAmendments = query({
  args: { workOrderId: v.id("workOrders") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db
      .query("workOrderAmendments")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .order("asc")
      .collect();
  },
});

export const create = mutation({
  args: {
    orderNumber: v.string(),
    orderType: v.optional(v.union(v.literal("incoming"), v.literal("outgoing"))),
    siteId: v.id("sites"),
    clientId: v.optional(v.id("clients")),
    contractorId: v.optional(v.id("contractors")),
    companyId: v.id("companies"),
    description: v.string(),
    totalValue: v.number(),
    status: v.union(
      v.literal("draft"),
      v.literal("active"),
      v.literal("amended"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    issueDate: v.string(),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    terms: v.optional(v.string()),
    totalUnits: v.optional(v.number()),
    unitLabel: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    // Check unique order number
    const existing = await ctx.db
      .query("workOrders")
      .withIndex("by_order_number", (q) => q.eq("orderNumber", args.orderNumber))
      .first();
    if (existing) throw new Error("Order number already exists");
    return await ctx.db.insert("workOrders", { ...args, version: 1 });
  },
});

export const update = mutation({
  args: {
    id: v.id("workOrders"),
    orderNumber: v.optional(v.string()),
    orderType: v.optional(v.union(v.literal("incoming"), v.literal("outgoing"))),
    siteId: v.optional(v.id("sites")),
    clientId: v.optional(v.id("clients")),
    contractorId: v.optional(v.id("contractors")),
    companyId: v.optional(v.id("companies")),
    description: v.optional(v.string()),
    totalValue: v.optional(v.number()),
    status: v.optional(
      v.union(
        v.literal("draft"),
        v.literal("active"),
        v.literal("amended"),
        v.literal("completed"),
        v.literal("cancelled")
      )
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    terms: v.optional(v.string()),
    totalUnits: v.optional(v.number()),
    unitLabel: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const addAmendment = mutation({
  args: {
    workOrderId: v.id("workOrders"),
    reason: v.string(),
    newValue: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (user.role !== "super_admin") throw new Error("Forbidden");
    const wo = await ctx.db.get(args.workOrderId);
    if (!wo) throw new Error("Work order not found");

    const amendments = await ctx.db
      .query("workOrderAmendments")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .collect();

    await ctx.db.insert("workOrderAmendments", {
      workOrderId: args.workOrderId,
      amendmentNumber: amendments.length + 1,
      reason: args.reason,
      previousValue: wo.totalValue,
      newValue: args.newValue,
      date: new Date().toISOString().split("T")[0],
      approvedBy: user._id,
    });

    await ctx.db.patch(args.workOrderId, {
      totalValue: args.newValue,
      status: "amended",
      version: wo.version + 1,
    });
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("workOrders"),
    status: v.union(
      v.literal("draft"),
      v.literal("active"),
      v.literal("amended"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.patch(args.id, { status: args.status });
  },
});

export const remove = mutation({
  args: { id: v.id("workOrders") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
