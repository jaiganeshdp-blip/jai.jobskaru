import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

// List partners for a company
export const list = query({
  args: { companyId: v.optional(v.id("companies")) },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    if (args.companyId) {
      return await ctx.db
        .query("partners")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId!))
        .collect();
    }
    return await ctx.db.query("partners").collect();
  },
});

export const get = query({
  args: { id: v.id("partners") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    companyId: v.id("companies"),
    name: v.string(),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    sharePercent: v.number(),
    capitalInvested: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    return await ctx.db.insert("partners", { ...args, isActive: true });
  },
});

export const update = mutation({
  args: {
    id: v.id("partners"),
    name: v.optional(v.string()),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    sharePercent: v.optional(v.number()),
    capitalInvested: v.optional(v.number()),
    notes: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("partners") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    // Also remove site partner links
    const siteLinks = await ctx.db
      .query("sitePartners")
      .withIndex("by_partner", (q) => q.eq("partnerId", args.id))
      .collect();
    for (const link of siteLinks) await ctx.db.delete(link._id);
    await ctx.db.delete(args.id);
  },
});

// ---- Site Partner Links ----

export const listSitePartners = query({
  args: { siteId: v.id("sites") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const links = await ctx.db
      .query("sitePartners")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    return await Promise.all(
      links.map(async (link) => {
        const partner = await ctx.db.get(link.partnerId);
        return { ...link, partnerName: partner?.name ?? "Unknown", partnerMobile: partner?.mobile };
      })
    );
  },
});

export const addSitePartner = mutation({
  args: {
    siteId: v.id("sites"),
    partnerId: v.id("partners"),
    sharePercent: v.number(),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    // Check if already linked
    const existing = await ctx.db
      .query("sitePartners")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();
    if (existing.some((l) => l.partnerId === args.partnerId)) {
      throw new Error("Partner already added to this site");
    }
    return await ctx.db.insert("sitePartners", args);
  },
});

export const updateSitePartner = mutation({
  args: { id: v.id("sitePartners"), sharePercent: v.number() },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.patch(args.id, { sharePercent: args.sharePercent });
  },
});

export const removeSitePartner = mutation({
  args: { id: v.id("sitePartners") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});

// Partner P&L dashboard - all companies, all partners, profit/loss per site
export const getPnLDashboard = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);

    const companies = await ctx.db.query("companies").collect();
    const allPartners = await ctx.db.query("partners").collect();
    const allSites = await ctx.db.query("sites").collect();
    const allSitePartners = await ctx.db.query("sitePartners").collect();

    // For each site, calculate revenue and cost
    const sitePnL = await Promise.all(
      allSites.map(async (site) => {
        // Revenue = approved work orders + invoices
        const workOrders = await ctx.db
          .query("workOrders")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const revenue = workOrders
          .filter((wo) => wo.status === "completed" || wo.status === "active")
          .reduce((s, wo) => s + wo.totalValue, 0);

        // Costs = materials + salary + expenses + work orders paid
        const materials = await ctx.db
          .query("materials")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const materialCost = materials
          .filter((m) => m.status === "approved")
          .reduce((s, m) => s + m.totalAmount, 0);

        const salarySheets = await ctx.db
          .query("salarySheets")
          .withIndex("by_site_month", (q) => q.eq("siteId", site._id))
          .collect();
        const salaryCost = salarySheets
          .filter((s) => s.status === "paid" || s.status === "approved")
          .reduce((s, sh) => s + sh.totalAmount, 0);

        const expenses = await ctx.db
          .query("expenses")
          .withIndex("by_site", (q) => q.eq("siteId", site._id))
          .collect();
        const expenseCost = expenses.reduce((s, e) => s + e.amount, 0);

        const totalCost = materialCost + salaryCost + expenseCost;
        const profit = revenue - totalCost;

        // Site partners
        const sitePartnerLinks = allSitePartners.filter((sp) => sp.siteId === site._id);

        return {
          siteId: site._id,
          siteName: site.name,
          siteCity: site.city,
          siteStatus: site.status,
          companyId: site.companyId,
          revenue,
          totalCost,
          materialCost,
          salaryCost,
          expenseCost,
          profit,
          partners: sitePartnerLinks.map((sp) => {
            const partner = allPartners.find((p) => p._id === sp.partnerId);
            const partnerShare = (sp.sharePercent / 100) * profit;
            return {
              partnerId: sp.partnerId,
              sitePartnerId: sp._id,
              partnerName: partner?.name ?? "Unknown",
              sharePercent: sp.sharePercent,
              profitShare: partnerShare,
            };
          }),
        };
      })
    );

    // Aggregate per partner
    const partnerTotals = allPartners.map((partner) => {
      const relevantSites = sitePnL.filter((s) =>
        s.partners.some((p) => p.partnerId === partner._id)
      );
      const totalProfitShare = relevantSites.reduce((sum, site) => {
        const link = site.partners.find((p) => p.partnerId === partner._id);
        return sum + (link?.profitShare ?? 0);
      }, 0);
      const company = companies.find((c) => c._id === partner.companyId);
      return {
        partnerId: partner._id,
        partnerName: partner.name,
        companyName: company?.name ?? "Unknown",
        companyId: partner.companyId,
        sharePercent: partner.sharePercent,
        totalProfitShare,
        siteCount: relevantSites.length,
        isActive: partner.isActive,
      };
    });

    return {
      sitePnL,
      partnerTotals,
      companies,
    };
  },
});
