import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { internal } from "./_generated/api.js";
import type { Id } from "./_generated/dataModel.d.ts";

// Public: Get active companies (for form dropdown)
export const getActiveCompanies = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("companies")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();
  },
});

// Public: Get active sites for a company (for form dropdown)
export const getSitesByCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("sites")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();
  },
});

// Public: Submit labour registration (no auth required)
export const submitLabourRegistration = mutation({
  args: {
    name: v.string(),
    mobile: v.string(),
    aadhaarNumber: v.optional(v.string()),
    fatherName: v.optional(v.string()),
    age: v.optional(v.number()),
    address: v.optional(v.string()),
    designation: v.string(),
    companyId: v.id("companies"),
    siteId: v.id("sites"),
    dailyRateExpected: v.optional(v.number()),
    experience: v.optional(v.string()),
    previousWork: v.optional(v.string()),
    photoStorageId: v.optional(v.string()),
    aadhaarStorageId: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<string> => {
    // Verify company and site exist
    const company = await ctx.db.get(args.companyId);
    if (!company) throw new Error("Company not found");
    const site = await ctx.db.get(args.siteId);
    if (!site) throw new Error("Site not found");

    const registrationId = await ctx.db.insert("labourRegistrations", {
      ...args,
      status: "pending_supervisor",
    });

    // Schedule welcome messages (email, SMS, WhatsApp)
    // These run in background — won't block the form submission
    await ctx.scheduler.runAfter(0, internal.labourWelcomeMessages.sendWelcomeSms, {
      mobile: args.mobile,
      workerName: args.name,
      companyName: company.name,
      siteName: site.name,
    });

    await ctx.scheduler.runAfter(0, internal.labourWelcomeMessages.sendWelcomeWhatsApp, {
      mobile: args.mobile,
      workerName: args.name,
      companyName: company.name,
      siteName: site.name,
      designation: args.designation,
    });

    return registrationId;
  },
});

// Public: Check registration status by mobile number
export const checkStatusByMobile = query({
  args: { mobile: v.string() },
  handler: async (ctx, args) => {
    const registrations = await ctx.db
      .query("labourRegistrations")
      .withIndex("by_mobile", (q) => q.eq("mobile", args.mobile))
      .order("desc")
      .take(5);

    return registrations.map((r) => ({
      _id: r._id,
      name: r.name,
      designation: r.designation,
      status: r.status,
      supervisorNote: r.supervisorNote,
      adminNote: r.adminNote,
      _creationTime: r._creationTime,
    }));
  },
});

// Public: Generate upload URL for photo/aadhaar
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// Public: Get storage URL
export const getStorageUrl = query({
  args: { storageId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});

// ─── Supervisor: Get pending registrations for their site ────────────────
export const getPendingForSite = query({
  args: { workerCode: v.string() },
  handler: async (ctx, args): Promise<Array<{
    _id: Id<"labourRegistrations">;
    _creationTime: number;
    name: string;
    mobile: string;
    fatherName?: string;
    aadhaarNumber?: string;
    age?: number;
    address?: string;
    designation: string;
    companyName: string;
    siteName: string;
    dailyRateExpected?: number;
    experience?: string;
    previousWork?: string;
    status: string;
    photoUrl?: string;
    aadhaarUrl?: string;
  }>> => {
    // Validate supervisor
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor) return [];
    if (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor && !supervisor.isSiteIncharge) return [];

    // Get registrations for this site that are pending supervisor review
    const registrations = await ctx.db
      .query("labourRegistrations")
      .withIndex("by_site_status", (q) =>
        q.eq("siteId", supervisor.siteId).eq("status", "pending_supervisor")
      )
      .order("desc")
      .collect();

    // Enrich with company/site names and photo URLs
    return await Promise.all(
      registrations.map(async (reg) => {
        const company = await ctx.db.get(reg.companyId);
        const site = await ctx.db.get(reg.siteId);
        const photoUrl = reg.photoStorageId ? await ctx.storage.getUrl(reg.photoStorageId) : undefined;
        const aadhaarUrl = reg.aadhaarStorageId ? await ctx.storage.getUrl(reg.aadhaarStorageId) : undefined;
        return {
          _id: reg._id,
          _creationTime: reg._creationTime,
          name: reg.name,
          mobile: reg.mobile,
          fatherName: reg.fatherName,
          aadhaarNumber: reg.aadhaarNumber,
          age: reg.age,
          address: reg.address,
          designation: reg.designation,
          companyName: company?.name ?? "Unknown",
          siteName: site?.name ?? "Unknown",
          dailyRateExpected: reg.dailyRateExpected,
          experience: reg.experience,
          previousWork: reg.previousWork,
          status: reg.status,
          photoUrl: photoUrl ?? undefined,
          aadhaarUrl: aadhaarUrl ?? undefined,
        };
      })
    );
  },
});

// ─── Supervisor: Approve a registration (forward to admin) ───────────────
export const supervisorApprove = mutation({
  args: {
    workerCode: v.string(),
    registrationId: v.id("labourRegistrations"),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor && !supervisor.isSiteIncharge)) {
      throw new Error("Unauthorized");
    }

    const reg = await ctx.db.get(args.registrationId);
    if (!reg) throw new Error("Registration not found");
    if (reg.siteId !== supervisor.siteId) throw new Error("Not your site");

    await ctx.db.patch(args.registrationId, {
      status: "supervisor_approved",
      supervisorNote: args.note,
      supervisorReviewedAt: new Date().toISOString(),
    });
  },
});

// ─── Supervisor: Reject a registration ───────────────────────────────────
export const supervisorReject = mutation({
  args: {
    workerCode: v.string(),
    registrationId: v.id("labourRegistrations"),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor && !supervisor.isSiteIncharge)) {
      throw new Error("Unauthorized");
    }

    const reg = await ctx.db.get(args.registrationId);
    if (!reg) throw new Error("Registration not found");
    if (reg.siteId !== supervisor.siteId) throw new Error("Not your site");

    await ctx.db.patch(args.registrationId, {
      status: "supervisor_rejected",
      supervisorNote: args.note,
      supervisorReviewedAt: new Date().toISOString(),
    });
  },
});

// ─── Admin: List supervisor-approved registrations ───────────────────────
export const listForAdmin = query({
  args: { status: v.optional(v.string()) },
  handler: async (ctx, args): Promise<Array<{
    _id: Id<"labourRegistrations">;
    _creationTime: number;
    name: string;
    mobile: string;
    fatherName?: string;
    aadhaarNumber?: string;
    age?: number;
    address?: string;
    designation: string;
    companyName: string;
    siteName: string;
    siteId: Id<"sites">;
    companyId: Id<"companies">;
    dailyRateExpected?: number;
    experience?: string;
    previousWork?: string;
    status: string;
    supervisorNote?: string;
    supervisorReviewedAt?: string;
    adminNote?: string;
    photoUrl?: string;
    aadhaarUrl?: string;
  }>> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || user.role !== "super_admin") return [];

    const filterStatus = args.status ?? "supervisor_approved";
    const registrations = await ctx.db
      .query("labourRegistrations")
      .withIndex("by_status", (q) => q.eq("status", filterStatus as "supervisor_approved"))
      .order("desc")
      .collect();

    return await Promise.all(
      registrations.map(async (reg) => {
        const company = await ctx.db.get(reg.companyId);
        const site = await ctx.db.get(reg.siteId);
        const photoUrl = reg.photoStorageId ? await ctx.storage.getUrl(reg.photoStorageId) : undefined;
        const aadhaarUrl = reg.aadhaarStorageId ? await ctx.storage.getUrl(reg.aadhaarStorageId) : undefined;
        return {
          _id: reg._id,
          _creationTime: reg._creationTime,
          name: reg.name,
          mobile: reg.mobile,
          fatherName: reg.fatherName,
          aadhaarNumber: reg.aadhaarNumber,
          age: reg.age,
          address: reg.address,
          designation: reg.designation,
          companyName: company?.name ?? "Unknown",
          siteName: site?.name ?? "Unknown",
          siteId: reg.siteId,
          companyId: reg.companyId,
          dailyRateExpected: reg.dailyRateExpected,
          experience: reg.experience,
          previousWork: reg.previousWork,
          status: reg.status,
          supervisorNote: reg.supervisorNote,
          supervisorReviewedAt: reg.supervisorReviewedAt,
          adminNote: reg.adminNote,
          photoUrl: photoUrl ?? undefined,
          aadhaarUrl: aadhaarUrl ?? undefined,
        };
      })
    );
  },
});

// ─── Admin: Approve a labour registration (creates labourer record) ──────
export const adminApprove = mutation({
  args: {
    registrationId: v.id("labourRegistrations"),
    dailyRate: v.number(),
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))),
    contractorId: v.optional(v.id("contractors")),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Not authenticated");
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || user.role !== "super_admin") throw new Error("Forbidden");

    const reg = await ctx.db.get(args.registrationId);
    if (!reg) throw new Error("Registration not found");
    if (reg.status !== "supervisor_approved") throw new Error("Not approved by supervisor yet");

    // Create labourer record
    const labourerId = await ctx.db.insert("labourers", {
      name: reg.name,
      mobile: reg.mobile,
      aadhaarNumber: reg.aadhaarNumber,
      fatherName: reg.fatherName,
      siteId: reg.siteId,
      contractorId: args.contractorId,
      labourType: args.labourType,
      designation: reg.designation,
      dailyRate: args.dailyRate,
      joinDate: new Date().toISOString().slice(0, 10),
      isActive: true,
      portalToken: crypto.randomUUID(),
    });

    // Update registration status
    await ctx.db.patch(args.registrationId, {
      status: "admin_approved",
      adminNote: args.adminNote,
      adminReviewedAt: new Date().toISOString(),
      createdLabourerId: labourerId,
    });

    return labourerId;
  },
});

// ─── Admin: Reject a labour registration ─────────────────────────────────
export const adminReject = mutation({
  args: {
    registrationId: v.id("labourRegistrations"),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Not authenticated");
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user || user.role !== "super_admin") throw new Error("Forbidden");

    const reg = await ctx.db.get(args.registrationId);
    if (!reg) throw new Error("Registration not found");

    await ctx.db.patch(args.registrationId, {
      status: "admin_rejected",
      adminNote: args.adminNote,
      adminReviewedAt: new Date().toISOString(),
    });
  },
});

// ─── Public: Get approved registration by mobile (for Form 2) ─────────────
export const getApprovedByMobile = query({
  args: { mobile: v.string() },
  handler: async (ctx, args) => {
    // Find registrations that have been admin-approved and created a labourer
    const registrations = await ctx.db
      .query("labourRegistrations")
      .withIndex("by_mobile", (q) => q.eq("mobile", args.mobile))
      .collect();

    const approved = registrations.filter((r) => r.status === "admin_approved" && r.createdLabourerId);

    // For each approved registration, check if Form 2 is already filled
    const results = await Promise.all(
      approved.map(async (reg) => {
        if (!reg.createdLabourerId) return null;
        const labourer = await ctx.db.get(reg.createdLabourerId);
        if (!labourer) return null;
        return {
          registrationId: reg._id,
          labourerId: labourer._id,
          name: labourer.name,
          fatherName: labourer.fatherName ?? reg.fatherName,
          mobile: labourer.mobile ?? reg.mobile,
          designation: labourer.designation ?? reg.designation,
          isForm2Complete: labourer.isForm2Complete ?? false,
          whatsappNumber: labourer.whatsappNumber,
          bankName: labourer.bankName,
          accountNumber: labourer.accountNumber,
          ifscCode: labourer.ifscCode,
        };
      })
    );

    return results.filter((r) => r !== null);
  },
});

// ─── Public: Submit Form 2 details (bank, WhatsApp, father name) ──────────
export const submitForm2 = mutation({
  args: {
    labourerId: v.id("labourers"),
    mobile: v.string(), // for verification
    fatherName: v.string(),
    whatsappNumber: v.string(),
    bankName: v.string(),
    accountNumber: v.string(),
    ifscCode: v.string(),
  },
  handler: async (ctx, args) => {
    const labourer = await ctx.db.get(args.labourerId);
    if (!labourer) throw new Error("Labourer not found");

    // Verify mobile matches
    if (labourer.mobile !== args.mobile) {
      throw new Error("Mobile number mismatch");
    }

    await ctx.db.patch(args.labourerId, {
      fatherName: args.fatherName,
      whatsappNumber: args.whatsappNumber,
      bankName: args.bankName,
      accountNumber: args.accountNumber,
      ifscCode: args.ifscCode,
      isForm2Complete: true,
    });

    return args.labourerId;
  },
});
