import { query } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./lib/auth.ts";

// ─── Purchase Register (item-wise) ────────────────────────────────────────────
// Flattens item-wise line items from incoming invoices (supplier / sub-contractor
// purchase bills) into one row per item.
export const purchaseItems = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);

    let rows;
    if (args.financialYear && args.ourCompanyName) {
      rows = await ctx.db
        .query("incomingInvoices")
        .withIndex("by_fy_company", (q) =>
          q.eq("financialYear", args.financialYear!).eq("ourCompanyName", args.ourCompanyName!)
        )
        .order("desc")
        .collect();
    } else {
      rows = await ctx.db.query("incomingInvoices").order("desc").collect();
    }

    const items: Array<{
      key: string;
      billNo: string;
      billDate: string;
      vendorName: string;
      vendorType: string;
      siteName?: string;
      ourCompanyName: string;
      gstPercent: number;
      description: string;
      unit: string;
      quantity: number;
      ratePerUnit: number;
      amount: number;
      hasItems: boolean;
    }> = [];

    for (const r of rows) {
      if (Array.isArray(r.lineItems) && r.lineItems.length > 0) {
        r.lineItems.forEach((it, i) => {
          items.push({
            key: `${r._id}-${i}`,
            billNo: r.billNo,
            billDate: r.billDate,
            vendorName: r.vendorName,
            vendorType: r.vendorType,
            siteName: r.siteName,
            ourCompanyName: r.ourCompanyName,
            gstPercent: r.gstPercent,
            description: it.description,
            unit: it.unit,
            quantity: it.quantity,
            ratePerUnit: it.ratePerUnit,
            amount: it.amount,
            hasItems: true,
          });
        });
      } else {
        // Bill without item-wise entry — show one summary row.
        items.push({
          key: `${r._id}-x`,
          billNo: r.billNo,
          billDate: r.billDate,
          vendorName: r.vendorName,
          vendorType: r.vendorType,
          siteName: r.siteName,
          ourCompanyName: r.ourCompanyName,
          gstPercent: r.gstPercent,
          description: "(No item-wise entry)",
          unit: "-",
          quantity: 1,
          ratePerUnit: r.amount,
          amount: r.amount,
          hasItems: false,
        });
      }
    }

    return items;
  },
});

// ─── Sale Register (item-wise) ────────────────────────────────────────────────
// Flattens line items from client sale invoices into one row per item.
export const saleItems = query({
  args: {
    siteId: v.optional(v.id("sites")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let invoices = await ctx.db.query("invoices").order("desc").collect();
    if (user.role === "site_incharge" && user.assignedSiteId) {
      invoices = invoices.filter((i) => i.siteId === user.assignedSiteId);
    }
    if (args.siteId) invoices = invoices.filter((i) => i.siteId === args.siteId);

    const siteNames = new Map<string, string>();
    const clientNames = new Map<string, string>();

    const items: Array<{
      key: string;
      invoiceNumber: string;
      issueDate: string;
      clientName: string;
      siteName: string;
      status: string;
      taxPercent: number;
      description: string;
      unit: string;
      quantity: number;
      rate: number;
      amount: number;
    }> = [];

    for (const inv of invoices) {
      if (!siteNames.has(inv.siteId)) {
        const site = await ctx.db.get(inv.siteId);
        siteNames.set(inv.siteId, site?.name ?? "Unknown");
      }
      if (!clientNames.has(inv.clientId)) {
        const client = await ctx.db.get(inv.clientId);
        clientNames.set(inv.clientId, client?.name ?? "Unknown");
      }
      const siteName = siteNames.get(inv.siteId) ?? "Unknown";
      const clientName = clientNames.get(inv.clientId) ?? "Unknown";

      inv.items.forEach((it, i) => {
        items.push({
          key: `${inv._id}-${i}`,
          invoiceNumber: inv.invoiceNumber,
          issueDate: inv.issueDate,
          clientName,
          siteName,
          status: inv.status,
          taxPercent: inv.taxPercent,
          description: it.description,
          unit: it.unit,
          quantity: it.quantity,
          rate: it.rate,
          amount: it.amount,
        });
      });
    }

    return items;
  },
});
