import { v } from "convex/values";
import { mutation, query, internalMutation } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";
import type { Id } from "./_generated/dataModel.d.ts";

const ALL_EVENTS = {
  payment_received: true,
  payment_made: true,
  work_order_issued: true,
  work_order_amended: true,
  salary_processed: true,
  salary_approved: true,
  material_approved: true,
  material_rejected: true,
  invoice_sent: true,
  invoice_overdue: true,
} as const;

export const list = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const notifs = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .take(args.limit ?? 50);
    return notifs;
  },
});

export const unreadCount = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_user_read", (q) => q.eq("userId", user._id).eq("isRead", false))
      .collect();
    return unread.length;
  },
});

export const markRead = mutation({
  args: { id: v.id("notifications") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    await ctx.db.patch(args.id, { isRead: true });
  },
});

export const markAllRead = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_user_read", (q) => q.eq("userId", user._id).eq("isRead", false))
      .collect();
    for (const n of unread) await ctx.db.patch(n._id, { isRead: true });
  },
});

// Internal mutation to create a notification for a specific user
export const createForUser = internalMutation({
  args: {
    userId: v.id("users"),
    type: v.union(
      v.literal("payment_received"),
      v.literal("payment_made"),
      v.literal("work_order_issued"),
      v.literal("work_order_amended"),
      v.literal("salary_processed"),
      v.literal("salary_approved"),
      v.literal("material_approved"),
      v.literal("material_rejected"),
      v.literal("invoice_sent"),
      v.literal("invoice_overdue")
    ),
    title: v.string(),
    message: v.string(),
    link: v.optional(v.string()),
    relatedId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Check user's preferences
    const prefs = await ctx.db
      .query("notificationPreferences")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .first();

    // Default: all events enabled if no prefs set
    const inAppEnabled = prefs ? prefs.inAppEnabled && prefs.events[args.type] : true;
    if (!inAppEnabled) return;

    await ctx.db.insert("notifications", {
      userId: args.userId,
      type: args.type,
      title: args.title,
      message: args.message,
      isRead: false,
      link: args.link,
      relatedId: args.relatedId,
    });
  },
});

// Internal mutation to broadcast to all super_admins
export const broadcastToAdmins = internalMutation({
  args: {
    type: v.union(
      v.literal("payment_received"),
      v.literal("payment_made"),
      v.literal("work_order_issued"),
      v.literal("work_order_amended"),
      v.literal("salary_processed"),
      v.literal("salary_approved"),
      v.literal("material_approved"),
      v.literal("material_rejected"),
      v.literal("invoice_sent"),
      v.literal("invoice_overdue")
    ),
    title: v.string(),
    message: v.string(),
    link: v.optional(v.string()),
    relatedId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const admins = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "super_admin"))
      .collect();

    for (const admin of admins) {
      const prefs = await ctx.db
        .query("notificationPreferences")
        .withIndex("by_user", (q) => q.eq("userId", admin._id))
        .first();
      const inAppEnabled = prefs ? prefs.inAppEnabled && prefs.events[args.type] : true;
      if (!inAppEnabled) continue;

      await ctx.db.insert("notifications", {
        userId: admin._id,
        type: args.type,
        title: args.title,
        message: args.message,
        isRead: false,
        link: args.link,
        relatedId: args.relatedId,
      });
    }
  },
});

// Get preferences for the current user
export const getPreferences = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    const prefs = await ctx.db
      .query("notificationPreferences")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .first();
    return prefs ?? {
      userId: user._id,
      emailEnabled: true,
      inAppEnabled: true,
      events: ALL_EVENTS,
      emailAddress: user.email,
    };
  },
});

// Save preferences
export const savePreferences = mutation({
  args: {
    emailEnabled: v.boolean(),
    inAppEnabled: v.boolean(),
    events: v.object({
      payment_received: v.boolean(),
      payment_made: v.boolean(),
      work_order_issued: v.boolean(),
      work_order_amended: v.boolean(),
      salary_processed: v.boolean(),
      salary_approved: v.boolean(),
      material_approved: v.boolean(),
      material_rejected: v.boolean(),
      invoice_sent: v.boolean(),
      invoice_overdue: v.boolean(),
    }),
    emailAddress: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const existing = await ctx.db
      .query("notificationPreferences")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .first();
    if (existing) {
      await ctx.db.patch(existing._id, args);
    } else {
      await ctx.db.insert("notificationPreferences", { userId: user._id, ...args });
    }
  },
});
