import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx } from "./_generated/server.d.ts";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

/**
 * Self-service backend for authenticated vendor logins (role = contractor / supplier).
 *
 * Every function resolves the vendor from the logged-in user's `contractorRef` /
 * `supplierRef` — never from a client-supplied id — so a vendor can only ever
 * read or write their OWN data (POs, work orders, bills, payments).
 */

type VendorRef =
  | { type: "contractor"; contractorId: Id<"contractors">; record: Doc<"contractors"> }
  | { type: "supplier"; supplierId: Id<"suppliers">; record: Doc<"suppliers"> }
  | null;

// Resolve the vendor record linked to the currently authenticated user.
async function resolveVendor(ctx: QueryCtx | MutationCtx): Promise<VendorRef> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) return null;

  if (user.role === "contractor" && user.contractorRef) {
    const record = await ctx.db.get(user.contractorRef);
    if (record) return { type: "contractor", contractorId: record._id, record };
  }
  if (user.role === "supplier" && user.supplierRef) {
    const record = await ctx.db.get(user.supplierRef);
    if (record) return { type: "supplier", supplierId: record._id, record };
  }
  return null;
}

// Basic profile + link status for the logged-in vendor.
export const getProfile = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<{
    type: "contractor" | "supplier";
    name: string;
    mobile: string;
    subtitle: string;
  } | null> => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return null;
    if (vendor.type === "contractor") {
      return {
        type: "contractor",
        name: vendor.record.name,
        mobile: vendor.record.mobile,
        subtitle: vendor.record.specialization ?? "Contractor",
      };
    }
    return {
      type: "supplier",
      name: vendor.record.name,
      mobile: vendor.record.mobile,
      subtitle: (vendor.record.materialCategories ?? []).join(", ") || "Supplier",
    };
  },
});

// Purchase Orders assigned to this vendor.
export const getPurchaseOrders = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<
    Array<{
      _id: Id<"purchaseOrders">;
      poNumber: string;
      siteName: string;
      companyName: string;
      totalValue: number;
      status: string;
      issueDate: string;
      items: Array<{ name: string; quantity: number; unit: string; ratePerUnit: number; totalAmount: number }>;
    }>
  > => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return [];

    const pos =
      vendor.type === "contractor"
        ? await ctx.db
            .query("purchaseOrders")
            .withIndex("by_contractor", (q) => q.eq("contractorId", vendor.contractorId))
            .collect()
        : await ctx.db
            .query("purchaseOrders")
            .withIndex("by_supplier", (q) => q.eq("supplierId", vendor.supplierId))
            .collect();

    return Promise.all(
      pos.map(async (po) => {
        const site = await ctx.db.get(po.siteId);
        const company = await ctx.db.get(po.companyId);
        return {
          _id: po._id,
          poNumber: po.poNumber,
          siteName: site?.name ?? "—",
          companyName: company?.name ?? "—",
          totalValue: po.totalValue,
          status: po.status,
          issueDate: po.issueDate,
          items: po.items,
        };
      }),
    );
  },
});

// Work orders relevant to this vendor (contractors only; via their POs).
export const getWorkOrders = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<
    Array<{
      _id: Id<"workOrders">;
      orderNumber: string;
      description: string;
      totalValue: number;
      status: string;
      issueDate: string;
      siteName: string;
    }>
  > => {
    const vendor = await resolveVendor(ctx);
    if (!vendor || vendor.type !== "contractor") return [];

    const contractorPOs = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_contractor", (q) => q.eq("contractorId", vendor.contractorId))
      .collect();

    const workOrderIdSet = new Set<Id<"workOrders">>();
    for (const po of contractorPOs) {
      if (po.workOrderId) workOrderIdSet.add(po.workOrderId);
    }

    const results = [];
    for (const woId of workOrderIdSet) {
      const order = await ctx.db.get(woId);
      if (!order) continue;
      const site = await ctx.db.get(order.siteId);
      results.push({
        _id: order._id,
        orderNumber: order.orderNumber,
        description: order.description,
        totalValue: order.totalValue,
        status: order.status,
        issueDate: order.issueDate,
        siteName: site?.name ?? "Unknown",
      });
    }
    return results;
  },
});

// Bills/invoices submitted by this vendor.
export const getBills = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<
    Array<
      Doc<"vendorBills"> & { siteName: string; companyName: string; poNumber?: string }
    >
  > => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return [];

    const bills =
      vendor.type === "contractor"
        ? await ctx.db
            .query("vendorBills")
            .withIndex("by_contractor", (q) => q.eq("contractorId", vendor.contractorId))
            .order("desc")
            .take(100)
        : await ctx.db
            .query("vendorBills")
            .withIndex("by_supplier", (q) => q.eq("supplierId", vendor.supplierId))
            .order("desc")
            .take(100);

    return Promise.all(
      bills.map(async (b) => {
        const site = await ctx.db.get(b.siteId);
        const po = b.purchaseOrderId ? await ctx.db.get(b.purchaseOrderId) : null;
        const company = await ctx.db.get(b.companyId);
        return {
          ...b,
          siteName: site?.name ?? "—",
          poNumber: po?.poNumber,
          companyName: company?.name ?? "—",
        };
      }),
    );
  },
});

// Payments received by this vendor (direct payments + paid portions of bills).
export const getPayments = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<
    Array<{
      _id: string;
      amount: number;
      date: string;
      referenceNumber?: string;
      mode?: string;
    }>
  > => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return [];

    const paidPayments = await ctx.db
      .query("payments")
      .withIndex("by_type", (q) => q.eq("type", "paid"))
      .collect();

    const directPayments = paidPayments
      .filter((p) =>
        vendor.type === "contractor"
          ? p.contractorId === vendor.contractorId
          : p.supplierId === vendor.supplierId,
      )
      .map((p) => ({
        _id: p._id as string,
        amount: p.amount,
        date: p.date,
        referenceNumber: p.referenceNumber,
        mode: p.mode,
      }));

    const bills =
      vendor.type === "contractor"
        ? await ctx.db
            .query("vendorBills")
            .withIndex("by_contractor", (q) => q.eq("contractorId", vendor.contractorId))
            .collect()
        : await ctx.db
            .query("vendorBills")
            .withIndex("by_supplier", (q) => q.eq("supplierId", vendor.supplierId))
            .collect();

    const billPayments = bills
      .filter((b) => b.paidAmount > 0)
      .map((b) => ({
        _id: b._id as string,
        amount: b.paidAmount,
        date: b.billDate,
      }));

    return [...directPayments, ...billPayments];
  },
});

// Previous bills for one of the vendor's own POs (for cumulative RA calc).
export const getPrevBillsByPO = query({
  args: { purchaseOrderId: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return [];
    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) return [];
    const ownsPO =
      vendor.type === "contractor"
        ? po.contractorId === vendor.contractorId
        : po.supplierId === vendor.supplierId;
    if (!ownsPO) return [];

    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();
    return bills.sort((a, b) => (a.raNumber ?? 0) - (b.raNumber ?? 0));
  },
});

// Vendor submits their own bill / invoice against one of their POs.
export const submitBill = mutation({
  args: {
    purchaseOrderId: v.id("purchaseOrders"),
    billNumber: v.string(),
    billDate: v.string(),
    billType: v.union(v.literal("ra"), v.literal("final")),
    raBillItems: v.array(
      v.object({
        srNo: v.number(),
        description: v.string(),
        unit: v.string(),
        orderQty: v.number(),
        thisBillQty: v.number(),
        ratePerUnit: v.number(),
        thisBillAmount: v.number(),
      }),
    ),
    gstPercent: v.number(),
    retentionPercent: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ billId: Id<"vendorBills">; warning?: string }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });

    const vendor = await resolveVendor(ctx);
    if (!vendor) throw new ConvexError({ message: "Vendor record link nahi hua", code: "FORBIDDEN" });

    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) throw new ConvexError({ code: "NOT_FOUND", message: "PO nahi mila" });
    const ownsPO =
      vendor.type === "contractor"
        ? po.contractorId === vendor.contractorId
        : po.supplierId === vendor.supplierId;
    if (!ownsPO) throw new ConvexError({ code: "FORBIDDEN", message: "Yeh PO aapke liye nahi hai" });

    const prevBills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();

    const raNumber = prevBills.length + 1;
    const prevTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
    const subtotal = args.raBillItems.reduce((s, i) => s + i.thisBillAmount, 0);
    const gstAmount = (subtotal * args.gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;
    const retentionPercent = args.retentionPercent ?? 0;
    const retentionAmount = (totalAmount * retentionPercent) / 100;
    const balancePayable = totalAmount - retentionAmount;
    const cumulativeTotal = prevTotal + subtotal;

    let warning: string | undefined;
    if (cumulativeTotal > po.totalValue) {
      warning = `Bill PO value se ₹${(cumulativeTotal - po.totalValue).toLocaleString("en-IN")} zyada hai.`;
    }

    const billId = await ctx.db.insert("vendorBills", {
      billNumber: args.billNumber,
      billDate: args.billDate,
      siteId: po.siteId,
      companyId: po.companyId,
      vendorType: vendor.type,
      contractorId: vendor.type === "contractor" ? vendor.contractorId : undefined,
      supplierId: vendor.type === "supplier" ? vendor.supplierId : undefined,
      purchaseOrderId: args.purchaseOrderId,
      billType: args.billType,
      raNumber,
      raBillItems: args.raBillItems,
      subtotal,
      gstPercent: args.gstPercent,
      gstAmount,
      totalAmount,
      retentionPercent: retentionPercent || undefined,
      retentionAmount: retentionPercent ? retentionAmount : undefined,
      balancePayable: retentionPercent ? balancePayable : undefined,
      paidAmount: 0,
      status: "received",
      description: `${args.billType === "final" ? "Final Bill" : `RA-${raNumber}`} — PO: ${po.poNumber}`,
      notes: args.notes,
      createdBy: user._id,
    });

    return { billId, warning };
  },
});

// Upload URL + attachment for the vendor's own bill.
export const generateBillUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) throw new ConvexError({ message: "Vendor record link nahi hua", code: "FORBIDDEN" });
    return await ctx.storage.generateUploadUrl();
  },
});

export const addBillAttachment = mutation({
  args: {
    billId: v.id("vendorBills"),
    storageId: v.id("_storage"),
    fileName: v.string(),
    fileType: v.string(),
    fileSize: v.number(),
  },
  handler: async (ctx, args) => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) throw new ConvexError({ message: "Vendor record link nahi hua", code: "FORBIDDEN" });
    const bill = await ctx.db.get(args.billId);
    const ownsBill =
      bill &&
      (vendor.type === "contractor"
        ? bill.contractorId === vendor.contractorId
        : bill.supplierId === vendor.supplierId);
    if (!ownsBill) throw new ConvexError({ code: "FORBIDDEN", message: "Bill not found" });
    const existing = bill!.attachments ?? [];
    await ctx.db.patch(args.billId, {
      attachments: [
        ...existing,
        {
          storageId: args.storageId,
          fileName: args.fileName,
          fileType: args.fileType,
          fileSize: args.fileSize,
          uploadedAt: new Date().toISOString(),
        },
      ],
    });
  },
});

export const getBillAttachmentUrls = query({
  args: { billId: v.id("vendorBills") },
  handler: async (
    ctx,
    args,
  ): Promise<Array<{ storageId: string; url: string | null; fileName: string; fileType: string }>> => {
    const vendor = await resolveVendor(ctx);
    if (!vendor) return [];
    const bill = await ctx.db.get(args.billId);
    const ownsBill =
      bill &&
      (vendor.type === "contractor"
        ? bill.contractorId === vendor.contractorId
        : bill.supplierId === vendor.supplierId);
    if (!ownsBill || !bill!.attachments) return [];
    return Promise.all(
      bill!.attachments.map(async (a) => ({
        storageId: a.storageId as string,
        url: await ctx.storage.getUrl(a.storageId),
        fileName: a.fileName,
        fileType: a.fileType,
      })),
    );
  },
});
