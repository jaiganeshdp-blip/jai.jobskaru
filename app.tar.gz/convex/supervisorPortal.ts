import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { QueryCtx } from "./_generated/server";

// ─── Token-based auth helper ───────────────────────────────────────────────
async function getSupervisorByToken(ctx: QueryCtx, token: string) {
  const supervisor = await ctx.db
    .query("labourers")
    .withIndex("by_worker_code", (q) => q.eq("workerCode", token.trim().toUpperCase()))
    .unique();
  if (!supervisor) return null;
  if (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor) return null;
  return supervisor;
}

// ─── Login (validate Worker ID) ──────────────────────────────────────────
export const login = query({
  args: { workerCode: v.string() },
  handler: async (ctx, args): Promise<{ success: boolean; supervisorId?: string; name?: string; siteId?: string; isSafetySupervisor?: boolean; isSiteSupervisor?: boolean }> => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();

    if (!supervisor) return { success: false };
    if (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor) return { success: false };

    return {
      success: true,
      supervisorId: supervisor._id,
      name: supervisor.name,
      siteId: supervisor.siteId,
      isSafetySupervisor: supervisor.isSafetySupervisor ?? false,
      isSiteSupervisor: supervisor.isSiteSupervisor ?? false,
    };
  },
});

// ─── Get portal data (labourers of the site, attendance, advances, etc.) ──
export const getPortalData = query({
  args: { workerCode: v.string(), date: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const supervisor = await getSupervisorByToken(ctx, args.workerCode);
    if (!supervisor) return null;

    const site = await ctx.db.get(supervisor.siteId);
    if (!site || !("name" in site)) return null;

    // All active labourers on the site
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .collect();
    const activeLabourers = labourers.filter((l) => l.isActive);

    // Today's attendance if date given
    const targetDate = args.date ?? new Date().toISOString().slice(0, 10);
    const attendanceRows = await ctx.db
      .query("attendance")
      .withIndex("by_site_date", (q) =>
        q.eq("siteId", supervisor.siteId).eq("date", targetDate)
      )
      .collect();
    const attendanceMap: Record<string, string> = {};
    const attendanceUnitsMap: Record<string, number> = {};
    const attendanceSourceMap: Record<string, { source: string; markedByName?: string }> = {};
    for (const row of attendanceRows) {
      attendanceMap[row.labourerId] = row.status;
      if (row.hajriUnits !== undefined) attendanceUnitsMap[row.labourerId] = row.hajriUnits;
      attendanceSourceMap[row.labourerId] = {
        source: row.markedBySource ?? "admin",
        markedByName: row.markedByName,
      };
    }

    // Advances this month
    const monthStart = targetDate.slice(0, 7) + "-01";
    const monthEnd = targetDate.slice(0, 7) + "-31";
    const advances = await ctx.db
      .query("advances")
      .withIndex("by_site_date", (q) =>
        q.eq("siteId", supervisor.siteId).gte("date", monthStart).lte("date", monthEnd)
      )
      .collect();
    const advanceMap: Record<string, number> = {};
    for (const adv of advances) {
      advanceMap[adv.labourerId] = (advanceMap[adv.labourerId] ?? 0) + adv.amount;
    }

    // Supervisor reports
    const reports = await ctx.db
      .query("supervisorReports")
      .withIndex("by_supervisor", (q) => q.eq("supervisorLabourerId", supervisor._id))
      .order("desc")
      .take(20);

    // Material requests for this site
    const materialRequests = await ctx.db
      .query("materialRequests")
      .withIndex("by_site", (q) => q.eq("siteId", supervisor.siteId))
      .order("desc")
      .take(30);

    // Enrich material requests with supplier info + PO details
    const enrichedRequests = await Promise.all(
      materialRequests.map(async (req) => {
        const supplier = req.assignedSupplierId
          ? await ctx.db.get(req.assignedSupplierId)
          : null;
        const po = req.purchaseOrderId ? await ctx.db.get(req.purchaseOrderId) : null;
        // Resolve photo URL from storage
        const photoUrl = req.photoStorageId
          ? await ctx.storage.getUrl(req.photoStorageId)
          : null;
        return {
          ...req,
          supplierName: supplier?.name,
          supplierMobile: supplier?.mobile,
          poNumber: po?.poNumber,
          poExpectedDelivery: po?.expectedDeliveryDate,
          poTotalValue: po?.totalValue,
          photoUrl: photoUrl ?? undefined,
        };
      })
    );

    // Salary entries this month (nasta, PT, deductions)
    const salarySheets = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) =>
        q.eq("siteId", supervisor.siteId).eq("month", targetDate.slice(0, 7))
      )
      .collect();

    const salaryEntries =
      salarySheets.length > 0
        ? await ctx.db
            .query("salaryEntries")
            .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", salarySheets[0]._id))
            .collect()
        : [];

    // Photo URLs for reports
    const reportsWithUrls = await Promise.all(
      reports.map(async (report) => {
        const urls = report.photoStorageIds
          ? await Promise.all(
              report.photoStorageIds.map((sid) => ctx.storage.getUrl(sid))
            )
          : [];
        return { ...report, photoUrls: urls.filter(Boolean) as string[] };
      })
    );

    return {
      supervisor: {
        _id: supervisor._id,
        name: supervisor.name,
        workerCode: supervisor.workerCode,
        isSiteSupervisor: supervisor.isSiteSupervisor,
        isSafetySupervisor: supervisor.isSafetySupervisor,
      },
      site: { _id: site._id, name: site.name, city: site.city },
      labourers: activeLabourers,
      attendanceMap,
      attendanceUnitsMap,
      attendanceSourceMap,
      targetDate,
      advanceMap,
      advances,
      reports: reportsWithUrls,
      materialRequests: enrichedRequests,
      salaryEntries,
    };
  },
});

// ─── Mark attendance (single labourer) ────────────────────────────────────
export const markAttendance = mutation({
  args: {
    workerCode: v.string(),
    labourerId: v.id("labourers"),
    date: v.string(),
    status: v.union(
      v.literal("present"),
      v.literal("absent"),
      v.literal("half_day"),
      v.literal("holiday")
    ),
    overtimeHours: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor)) {
      throw new Error("Unauthorized");
    }

    // Need a dummy user id — use a system approach: find any super_admin user
    // We store markedBy as supervisor's labourer ID cast as never (workaround since attendance.markedBy is users Id)
    // Instead, let's find if there's a system user, otherwise skip markedBy validation by using a query
    // Actually we need a users._id for markedBy. Let's get first super_admin user.
    const adminUser = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "super_admin"))
      .first();
    if (!adminUser) throw new Error("No admin user found");

    const existing = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) =>
        q.eq("labourerId", args.labourerId).eq("date", args.date)
      )
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, {
        status: args.status,
        overtimeHours: args.overtimeHours,
        markedBySource: "supervisor",
        markedByName: supervisor.name,
      });
    } else {
      await ctx.db.insert("attendance", {
        siteId: supervisor.siteId,
        labourerId: args.labourerId,
        date: args.date,
        status: args.status,
        overtimeHours: args.overtimeHours,
        markedBy: adminUser._id,
        markedBySource: "supervisor",
        markedByName: supervisor.name,
      });
    }
  },
});

// ─── Bulk mark attendance ─────────────────────────────────────────────────
export const bulkMarkAttendance = mutation({
  args: {
    workerCode: v.string(),
    date: v.string(),
    entries: v.array(
      v.object({
        labourerId: v.id("labourers"),
        status: v.union(
          v.literal("present"),
          v.literal("absent"),
          v.literal("half_day"),
          v.literal("holiday")
        ),
        overtimeHours: v.optional(v.number()),
        hajriUnits: v.optional(v.number()),
      })
    ),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor)) {
      throw new Error("Unauthorized");
    }

    const adminUser = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "super_admin"))
      .first();
    if (!adminUser) throw new Error("No admin user found");

    for (const entry of args.entries) {
      const existing = await ctx.db
        .query("attendance")
        .withIndex("by_labourer_date", (q) =>
          q.eq("labourerId", entry.labourerId).eq("date", args.date)
        )
        .unique();
      if (existing) {
        await ctx.db.patch(existing._id, {
          status: entry.status,
          overtimeHours: entry.overtimeHours,
          hajriUnits: entry.hajriUnits,
          markedBySource: "supervisor",
          markedByName: supervisor.name,
        });
      } else {
        await ctx.db.insert("attendance", {
          siteId: supervisor.siteId,
          labourerId: entry.labourerId,
          date: args.date,
          status: entry.status,
          overtimeHours: entry.overtimeHours,
          hajriUnits: entry.hajriUnits,
          markedBy: adminUser._id,
          markedBySource: "supervisor",
          markedByName: supervisor.name,
        });
      }
    }
  },
});

// ─── Add advance ──────────────────────────────────────────────────────────
export const addAdvance = mutation({
  args: {
    workerCode: v.string(),
    labourerId: v.id("labourers"),
    amount: v.number(),
    date: v.string(),
    reason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor)) {
      throw new Error("Unauthorized");
    }
    await ctx.db.insert("advances", {
      siteId: supervisor.siteId,
      labourerId: args.labourerId,
      amount: args.amount,
      date: args.date,
      reason: args.reason,
      addedByToken: args.workerCode,
    });
  },
});

// ─── Generate upload URL ──────────────────────────────────────────────────
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => ctx.storage.generateUploadUrl(),
});

// ─── Submit report with photos ────────────────────────────────────────────
export const submitReport = mutation({
  args: {
    workerCode: v.string(),
    title: v.string(),
    description: v.optional(v.string()),
    reportDate: v.string(),
    photoStorageIds: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor)) {
      throw new Error("Unauthorized");
    }
    await ctx.db.insert("supervisorReports", {
      siteId: supervisor.siteId,
      supervisorLabourerId: supervisor._id,
      title: args.title,
      description: args.description,
      reportDate: args.reportDate,
      photoStorageIds: args.photoStorageIds,
      status: "submitted",
    });
  },
});

// ─── Submit material request ──────────────────────────────────────────────
export const submitMaterialRequest = mutation({
  args: {
    workerCode: v.string(),
    itemName: v.string(),
    quantity: v.number(),
    unit: v.string(),
    urgency: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    notes: v.optional(v.string()),
    photoStorageId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor)) {
      throw new Error("Unauthorized");
    }
    await ctx.db.insert("materialRequests", {
      siteId: supervisor.siteId,
      requestedByLabourerId: supervisor._id,
      itemName: args.itemName,
      quantity: args.quantity,
      unit: args.unit,
      urgency: args.urgency,
      notes: args.notes,
      photoStorageId: args.photoStorageId,
      status: "requested",
    });
  },
});

// ─── Admin: list all supervisor reports ──────────────────────────────────
export const listReports = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args) => {
    let reports;
    if (args.siteId) {
      reports = await ctx.db
        .query("supervisorReports")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .order("desc")
        .take(50);
    } else {
      reports = await ctx.db.query("supervisorReports").order("desc").take(50);
    }
    return await Promise.all(
      reports.map(async (r) => {
        const supervisor = await ctx.db.get(r.supervisorLabourerId);
        const site = await ctx.db.get(r.siteId);
        const urls = r.photoStorageIds
          ? await Promise.all(r.photoStorageIds.map((sid) => ctx.storage.getUrl(sid)))
          : [];
        return {
          ...r,
          supervisorName: supervisor?.name ?? "Unknown",
          siteName: site?.name ?? "Unknown",
          photoUrls: urls.filter(Boolean) as string[],
        };
      })
    );
  },
});

// ─── Admin: list material requests ───────────────────────────────────────
export const listMaterialRequests = query({
  args: { siteId: v.optional(v.id("sites")), status: v.optional(v.string()) },
  handler: async (ctx, args) => {
    let requests;
    if (args.siteId) {
      requests = await ctx.db
        .query("materialRequests")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .order("desc")
        .take(50);
    } else {
      requests = await ctx.db.query("materialRequests").order("desc").take(100);
    }
    if (args.status) {
      requests = requests.filter((r) => r.status === args.status);
    }
    return await Promise.all(
      requests.map(async (r) => {
        const supervisor = await ctx.db.get(r.requestedByLabourerId);
        const site = await ctx.db.get(r.siteId);
        const supplier = r.assignedSupplierId ? await ctx.db.get(r.assignedSupplierId) : null;
        const po = r.purchaseOrderId ? await ctx.db.get(r.purchaseOrderId) : null;
        const photoUrl = r.photoStorageId ? await ctx.storage.getUrl(r.photoStorageId) : null;
        return {
          ...r,
          supervisorName: supervisor?.name ?? "Unknown",
          siteName: site?.name ?? "Unknown",
          supplierName: supplier?.name,
          supplierMobile: supplier?.mobile,
          poNumber: po?.poNumber,
          poExpectedDelivery: po?.expectedDeliveryDate,
          poTotalValue: po?.totalValue,
          photoUrl,
        };
      })
    );
  },
});

// ─── Admin: assign supplier & issue PO ───────────────────────────────────
export const assignSupplierToRequest = mutation({
  args: {
    requestId: v.id("materialRequests"),
    supplierId: v.id("suppliers"),
    adminNote: v.optional(v.string()),
    purchaseOrderId: v.optional(v.id("purchaseOrders")),
  },
  handler: async (ctx, args) => {
    const { requestId, ...rest } = args;
    await ctx.db.patch(requestId, {
      ...rest,
      status: "po_issued",
    });
  },
});

// ─── Admin: Issue a real PO from material request ─────────────────────────
export const issuePOForRequest = mutation({
  args: {
    requestId: v.id("materialRequests"),
    supplierId: v.id("suppliers"),
    ratePerUnit: v.number(),
    expectedDeliveryDate: v.optional(v.string()),
    adminNote: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<string> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Not authenticated");
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new Error("User not found");

    const req = await ctx.db.get(args.requestId);
    if (!req) throw new Error("Request not found");

    const site = await ctx.db.get(req.siteId);
    if (!site) throw new Error("Site not found");

    const totalAmount = req.quantity * args.ratePerUnit;
    const poNumber = `MR-${req.siteId.toString().slice(-4).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;

    const poId = await ctx.db.insert("purchaseOrders", {
      poNumber,
      siteId: req.siteId,
      supplierId: args.supplierId,
      companyId: site.companyId,
      status: "sent",
      issueDate: new Date().toISOString().slice(0, 10),
      expectedDeliveryDate: args.expectedDeliveryDate,
      items: [
        {
          name: req.itemName,
          quantity: req.quantity,
          unit: req.unit,
          ratePerUnit: args.ratePerUnit,
          totalAmount,
        },
      ],
      totalValue: totalAmount,
      notes: args.adminNote,
      createdBy: user._id,
    });

    await ctx.db.patch(args.requestId, {
      assignedSupplierId: args.supplierId,
      purchaseOrderId: poId,
      adminNote: args.adminNote,
      reviewedBy: user._id,
      status: "po_issued",
    });

    return poId;
  },
});

// ─── Admin: reject material request ──────────────────────────────────────
export const rejectMaterialRequest = mutation({
  args: { requestId: v.id("materialRequests"), adminNote: v.optional(v.string()) },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.requestId, {
      status: "rejected",
      adminNote: args.adminNote,
    });
  },
});

// ─── Admin: mark material request as delivered ────────────────────────────
export const markDelivered = mutation({
  args: { requestId: v.id("materialRequests") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.requestId, { status: "delivered" });
  },
});

// ─── Supervisor: Add new labourer to their site ───────────────────────────
export const addLabourer = mutation({
  args: {
    workerCode: v.string(),
    name: v.string(),
    mobile: v.optional(v.string()),
    designation: v.optional(v.string()),
    dailyRate: v.number(),
    labourType: v.optional(v.union(v.literal("contractor"), v.literal("departmental"))),
    contractorId: v.optional(v.id("contractors")),
    joinDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const supervisor = await ctx.db
      .query("labourers")
      .withIndex("by_worker_code", (q) => q.eq("workerCode", args.workerCode.trim().toUpperCase()))
      .unique();
    if (!supervisor || (!supervisor.isSiteSupervisor && !supervisor.isSafetySupervisor && !supervisor.isSiteIncharge)) {
      throw new Error("Unauthorized");
    }
    const { workerCode: _wc, dailyRate, ...rest } = args;
    void _wc;
    // Supervisor-added labourers have their rate as "suggested" pending admin approval
    return await ctx.db.insert("labourers", {
      ...rest,
      dailyRate: 0, // Will be set by admin when approving
      suggestedRate: dailyRate, // Supervisor's suggested rate
      rateApprovalStatus: "pending",
      siteId: supervisor.siteId,
      isActive: true,
      portalToken: crypto.randomUUID(),
    });
  },
});

// ─── Admin: list advances ─────────────────────────────────────────────────
export const listAdvances = query({
  args: { siteId: v.optional(v.id("sites")), month: v.optional(v.string()) },
  handler: async (ctx, args) => {
    let advances;
    if (args.siteId && args.month) {
      const start = args.month + "-01";
      const end = args.month + "-31";
      advances = await ctx.db
        .query("advances")
        .withIndex("by_site_date", (q) =>
          q.eq("siteId", args.siteId!).gte("date", start).lte("date", end)
        )
        .collect();
    } else if (args.siteId) {
      advances = await ctx.db
        .query("advances")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .order("desc")
        .take(100);
    } else {
      advances = await ctx.db.query("advances").order("desc").take(100);
    }
    return await Promise.all(
      advances.map(async (adv) => {
        const labourer = await ctx.db.get(adv.labourerId);
        const site = await ctx.db.get(adv.siteId);
        return {
          ...adv,
          labourerName: labourer?.name ?? "Unknown",
          siteName: site?.name ?? "Unknown",
        };
      })
    );
  },
});
