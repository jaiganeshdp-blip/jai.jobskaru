"use node";
import { action } from "./_generated/server";
import { ConvexError } from "convex/values";
import { internal } from "./_generated/api";

const TABLES = [
  "users", "companies", "sites", "clients", "suppliers", "contractors",
  "labourers", "attendance", "workOrders", "purchaseOrders", "poReceipts",
  "workOrderAmendments", "materials", "salarySheets", "salaryEntries",
  "invoices", "expenses", "siteDiary", "deliveryChallans",
  "payments", "vendorBills", "siteExpenses", "notifications",
  "notificationPreferences", "screensaverSlides", "screensaverSettings",
] as const;

export const exportAll = action({
  args: {},
  handler: async (ctx): Promise<{ tables: Record<string, unknown[]>; exportedAt: string; version: string }> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });

    const user = await ctx.runQuery(internal.backupQueries.getUserByToken, { tokenIdentifier: identity.tokenIdentifier });
    if (!user || user.role !== "super_admin") {
      throw new ConvexError({ message: "Only super admins can export data", code: "FORBIDDEN" });
    }

    const result: Record<string, unknown[]> = {};
    for (const table of TABLES) {
      const rows = await ctx.runQuery(internal.backupQueries.getTableRows, { table });
      result[table] = rows;
    }

    return {
      tables: result,
      exportedAt: new Date().toISOString(),
      version: "1.0",
    };
  },
});
