import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireRole } from "./lib/auth.ts";
import { internal } from "./_generated/api.js";

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    clientId: v.optional(v.id("clients")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    let invoices = await ctx.db.query("invoices").collect();

    if (user.role === "site_incharge" && user.assignedSiteId) {
      invoices = invoices.filter((i) => i.siteId === user.assignedSiteId);
    }
    if (args.siteId) invoices = invoices.filter((i) => i.siteId === args.siteId);
    if (args.clientId) invoices = invoices.filter((i) => i.clientId === args.clientId);
    if (args.status) invoices = invoices.filter((i) => i.status === args.status);

    const enriched = await Promise.all(
      invoices.map(async (inv) => {
        const site = await ctx.db.get(inv.siteId);
        const client = await ctx.db.get(inv.clientId);
        const workOrder = inv.workOrderId ? await ctx.db.get(inv.workOrderId) : null;
        return {
          ...inv,
          siteName: site?.name ?? "Unknown",
          clientName: client?.name ?? "Unknown",
          workOrderNumber: workOrder?.orderNumber ?? null,
        };
      })
    );

    return enriched.sort((a, b) => b.issueDate.localeCompare(a.issueDate));
  },
});

export const getDetail = query({
  args: { id: v.id("invoices") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    const inv = await ctx.db.get(args.id);
    if (!inv) return null;

    const site = await ctx.db.get(inv.siteId);
    const client = await ctx.db.get(inv.clientId);
    const workOrder = inv.workOrderId ? await ctx.db.get(inv.workOrderId) : null;

    // Payments for this invoice
    const allPayments = await ctx.db
      .query("payments")
      .withIndex("by_site", (q) => q.eq("siteId", inv.siteId))
      .collect();
    const invoicePayments = allPayments.filter((p) => p.invoiceId === args.id);

    const enrichedPayments = await Promise.all(
      invoicePayments.map(async (p) => {
        const recorder = await ctx.db.get(p.recordedBy);
        return { ...p, recordedByName: recorder?.name ?? "Unknown" };
      })
    );

    return {
      ...inv,
      siteName: site?.name ?? "Unknown",
      siteCity: site?.city ?? "",
      clientName: client?.name ?? "Unknown",
      clientMobile: client?.mobile ?? "",
      clientGst: client?.gstNumber ?? "",
      workOrderNumber: workOrder?.orderNumber ?? null,
      payments: enrichedPayments.sort((a, b) => b.date.localeCompare(a.date)),
    };
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    clientId: v.id("clients"),
    workOrderId: v.optional(v.id("workOrders")),
    issueDate: v.string(),
    dueDate: v.optional(v.string()),
    items: v.array(
      v.object({
        description: v.string(),
        quantity: v.number(),
        unit: v.string(),
        rate: v.number(),
        amount: v.number(),
      })
    ),
    taxPercent: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    // Auto-generate invoice number
    const existing = await ctx.db.query("invoices").collect();
    const nextNum = existing.length + 1;
    const invoiceNumber = `INV-${String(nextNum).padStart(4, "0")}`;

    const subtotal = args.items.reduce((s, i) => s + i.amount, 0);
    const taxAmount = (subtotal * args.taxPercent) / 100;
    const totalAmount = subtotal + taxAmount;

    return await ctx.db.insert("invoices", {
      invoiceNumber,
      siteId: args.siteId,
      clientId: args.clientId,
      workOrderId: args.workOrderId,
      issueDate: args.issueDate,
      dueDate: args.dueDate,
      items: args.items,
      subtotal,
      taxPercent: args.taxPercent,
      taxAmount,
      totalAmount,
      status: "draft",
      paidAmount: 0,
      notes: args.notes,
    });
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("invoices"),
    status: v.union(
      v.literal("draft"),
      v.literal("sent"),
      v.literal("partial"),
      v.literal("paid"),
      v.literal("overdue"),
      v.literal("cancelled")
    ),
  },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin", "site_incharge"]);
    await ctx.db.patch(args.id, { status: args.status });

    // Notify on invoice sent or overdue
    if (args.status === "sent" || args.status === "overdue") {
      const inv = await ctx.db.get(args.id);
      const client = inv ? await ctx.db.get(inv.clientId) : null;
      const type = args.status === "sent" ? "invoice_sent" : "invoice_overdue";
      const title = args.status === "sent" ? "Invoice Sent" : "Invoice Overdue";
      await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
        type,
        title,
        message: `Invoice ${inv?.invoiceNumber ?? ""} for ${client?.name ?? "client"} — ₹${(inv?.totalAmount ?? 0).toLocaleString("en-IN")}`,
        link: `/invoices/${args.id}`,
        relatedId: args.id,
      });
    }
  },
});

export const remove = mutation({
  args: { id: v.id("invoices") },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin"]);
    const inv = await ctx.db.get(args.id);
    if (!inv) return;
    if (inv.status !== "draft") throw new Error("Only draft invoices can be deleted");
    await ctx.db.delete(args.id);
  },
});

export const recordPayment = mutation({
  args: {
    invoiceId: v.id("invoices"),
    amount: v.number(),
    date: v.string(),
    mode: v.union(
      v.literal("cash"),
      v.literal("cheque"),
      v.literal("neft"),
      v.literal("rtgs"),
      v.literal("upi"),
      v.literal("other")
    ),
    referenceNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const inv = await ctx.db.get(args.invoiceId);
    if (!inv) throw new Error("Invoice not found");

    await ctx.db.insert("payments", {
      type: "received",
      siteId: inv.siteId,
      clientId: inv.clientId,
      invoiceId: args.invoiceId,
      amount: args.amount,
      date: args.date,
      mode: args.mode,
      referenceNumber: args.referenceNumber,
      notes: args.notes,
      recordedBy: user._id,
    });

    // Update paidAmount and status
    const newPaid = inv.paidAmount + args.amount;
    let newStatus: "draft" | "sent" | "partial" | "paid" | "overdue" | "cancelled" = inv.status;
    if (newPaid >= inv.totalAmount) {
      newStatus = "paid";
    } else if (newPaid > 0) {
      newStatus = "partial";
    }
    await ctx.db.patch(args.invoiceId, { paidAmount: newPaid, status: newStatus });

    // Notify on payment received
    const site = await ctx.db.get(inv.siteId);
    const client = inv.clientId ? await ctx.db.get(inv.clientId) : null;
    await ctx.scheduler.runAfter(0, internal.notificationDispatch.dispatchToAdmins, {
      type: "payment_received",
      title: "Payment Received",
      message: `₹${args.amount.toLocaleString("en-IN")} received from ${client?.name ?? "client"} (${site?.name ?? ""}) via ${args.mode.toUpperCase()}`,
      link: `/invoices/${args.invoiceId}`,
      relatedId: args.invoiceId,
    });
  },
});
