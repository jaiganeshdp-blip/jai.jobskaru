import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.db.query("suppliers").collect();
  },
});

export const get = query({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);
    return await ctx.db.get(args.id);
  },
});

type BillFileWithUrl = {
  storageId: string;
  name: string;
  type: string;
  url: string | null;
  materialId: Id<"materials">;
  deliveryDate: string;
  invoiceNumber: string | undefined;
};

type ChallanPhotoWithUrl = {
  storageId: string;
  url: string | null;
  challanId: string;
  deliveryDate: string;
  materialType: string;
};

type SupplierDetail = {
  supplier: Doc<"suppliers">;
  materialCount: number;
  totalMaterialValue: number;
  pendingMaterialCount: number;
  approvedMaterialCount: number;
  totalPaid: number;
  totalOutstanding: number;
  recentMaterials: Array<{
    _id: Id<"materials">;
    deliveryDate: string;
    invoiceNumber: string | undefined;
    totalAmount: number;
    status: string;
    siteName: string;
  }>;
  recentPayments: Array<{
    _id: Id<"payments"> | Id<"vendorBills">;
    date: string;
    amount: number;
    mode: string;
    referenceNumber: string | undefined;
    description?: string;
  }>;
  billFiles: BillFileWithUrl[];
  challanPhotos: ChallanPhotoWithUrl[];
};

export const getDetail = query({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args): Promise<SupplierDetail | null> => {
    await getCurrentUser(ctx);
    const supplier = await ctx.db.get(args.id);
    if (!supplier) return null;

    const materials = await ctx.db
      .query("materials")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.id))
      .collect();

    const materialCount = materials.length;
    const totalMaterialValue = materials.reduce((s, m) => s + m.totalAmount, 0);
    const pendingMaterialCount = materials.filter((m) => m.status === "pending").length;
    const approvedMaterialCount = materials.filter((m) => m.status === "approved").length;

    // Fetch site names for materials
    const siteIds = [...new Set(materials.map((m) => m.siteId))];
    const siteMap: Record<string, string> = {};
    await Promise.all(
      siteIds.map(async (sid) => {
        const site = await ctx.db.get(sid);
        if (site) siteMap[sid] = site.name;
      })
    );

    const recentMaterials = materials
      .sort((a, b) => b.deliveryDate.localeCompare(a.deliveryDate))
      .slice(0, 6)
      .map((m) => ({
        _id: m._id,
        deliveryDate: m.deliveryDate,
        invoiceNumber: m.invoiceNumber,
        totalAmount: m.totalAmount,
        status: m.status,
        siteName: siteMap[m.siteId] ?? "—",
      }));

    // Payments to this supplier
    const payments = await ctx.db
      .query("payments")
      .withIndex("by_type", (q) => q.eq("type", "paid"))
      .collect();
    const supplierPayments = payments.filter((p) => p.supplierId === args.id);
    const totalPaidFromPayments = supplierPayments.reduce((s, p) => s + p.amount, 0);

    // Also check vendor bills paidAmount (bills can be marked paid without a payments record)
    const vendorBillDocs = await ctx.db
      .query("vendorBills")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.id))
      .collect();
    const totalPaidFromBills = vendorBillDocs.reduce((s, b) => s + b.paidAmount, 0);
    const totalPaid = Math.max(totalPaidFromPayments, totalPaidFromBills);
    const totalOutstanding = totalMaterialValue - totalPaid;

    const recentPayments = supplierPayments.length > 0
      ? supplierPayments
          .sort((a, b) => b.date.localeCompare(a.date))
          .slice(0, 5)
          .map((p) => ({
            _id: p._id,
            date: p.date,
            amount: p.amount,
            mode: p.mode,
            referenceNumber: p.referenceNumber,
            description: undefined as string | undefined,
          }))
      : vendorBillDocs
          .filter((b) => b.paidAmount > 0)
          .sort((a, b) => b.billDate.localeCompare(a.billDate))
          .slice(0, 5)
          .map((b) => ({
            _id: b._id,
            date: b.billDate,
            amount: b.paidAmount,
            mode: "bill_payment" as const,
            referenceNumber: b.billNumber,
            description: b.description ?? b.billNumber,
          }));

    return {
      supplier,
      materialCount,
      totalMaterialValue,
      pendingMaterialCount,
      approvedMaterialCount,
      totalPaid,
      totalOutstanding,
      recentMaterials,
      recentPayments,
      billFiles: await (async () => {
        const result: BillFileWithUrl[] = [];
        for (const m of materials) {
          if (!m.billFiles) continue;
          for (const f of m.billFiles) {
            const url = await ctx.storage.getUrl(f.storageId);
            result.push({
              storageId: f.storageId,
              name: f.name,
              type: f.type,
              url,
              materialId: m._id,
              deliveryDate: m.deliveryDate,
              invoiceNumber: m.invoiceNumber,
            });
          }
        }
        return result;
      })(),
      challanPhotos: await (async () => {
        const challans = await ctx.db
          .query("deliveryChallans")
          .collect();
        const filtered = challans.filter((c) => c.supplierId === args.id);
        const result: ChallanPhotoWithUrl[] = [];
        for (const c of filtered) {
          if (!c.photoStorageIds) continue;
          for (const sid of c.photoStorageIds) {
            const url = await ctx.storage.getUrl(sid);
            result.push({
              storageId: sid,
              url,
              challanId: c._id,
              deliveryDate: c.deliveryDate,
              materialType: c.materialType,
            });
          }
        }
        return result;
      })(),
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.string(),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    materialCategories: v.optional(v.array(v.string())),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const portalToken = crypto.randomUUID();
    return await ctx.db.insert("suppliers", { ...args, isActive: true, portalToken });
  },
});

export const update = mutation({
  args: {
    id: v.id("suppliers"),
    name: v.optional(v.string()),
    gstNumber: v.optional(v.string()),
    panNumber: v.optional(v.string()),
    mobile: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    materialCategories: v.optional(v.array(v.string())),
    bankName: v.optional(v.string()),
    accountNumber: v.optional(v.string()),
    ifscCode: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});
