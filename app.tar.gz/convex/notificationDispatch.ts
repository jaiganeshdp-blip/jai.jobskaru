import { v } from "convex/values";
import { internalMutation, internalAction } from "./_generated/server";
import { internal } from "./_generated/api.js";

const EVENT_TYPE = v.union(
  v.literal("payment_received"),
  v.literal("payment_made"),
  v.literal("work_order_issued"),
  v.literal("work_order_amended"),
  v.literal("salary_processed"),
  v.literal("salary_approved"),
  v.literal("material_approved"),
  v.literal("material_rejected"),
  v.literal("invoice_sent"),
  v.literal("invoice_overdue")
);

// Single entry point: creates in-app notif + schedules email for all super_admins
export const dispatchToAdmins = internalAction({
  args: {
    type: EVENT_TYPE,
    title: v.string(),
    message: v.string(),
    link: v.optional(v.string()),
    relatedId: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<void> => {
    // Create in-app notifications
    await ctx.runMutation(internal.notifications.broadcastToAdmins, {
      type: args.type,
      title: args.title,
      message: args.message,
      link: args.link,
      relatedId: args.relatedId,
    });

    // Send emails to admins who have email enabled
    await ctx.runAction(internal.notificationDispatch.emailAdmins, {
      type: args.type,
      title: args.title,
      message: args.message,
      link: args.link,
    });
  },
});

export const emailAdmins = internalAction({
  args: {
    type: EVENT_TYPE,
    title: v.string(),
    message: v.string(),
    link: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<void> => {
    const senderEmail = process.env.CONSTRUCTPRO_SENDER_EMAIL;
    if (!senderEmail) return; // Email not configured yet

    const admins: Array<{
      email?: string;
      emailEnabled: boolean;
      events: Record<string, boolean>;
    }> = await ctx.runQuery(internal.notificationDispatch.getAdminEmailPrefs, {});

    for (const admin of admins) {
      if (!admin.email) continue;
      if (!admin.emailEnabled) continue;
      if (!admin.events[args.type]) continue;

      await ctx.runAction(internal.emails.sendNotificationEmail, {
        to: admin.email,
        subject: `JAI SITE MANAGER ERP: ${args.title}`,
        title: args.title,
        message: args.message,
        ctaLabel: args.link ? "View in JAI SITE MANAGER ERP" : undefined,
        ctaUrl: args.link,
        senderEmail,
      });
    }
  },
});

import { internalQuery } from "./_generated/server";

export const getAdminEmailPrefs = internalQuery({
  args: {},
  handler: async (ctx): Promise<Array<{
    email?: string;
    emailEnabled: boolean;
    events: Record<string, boolean>;
  }>> => {
    const admins = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "super_admin"))
      .collect();

    return await Promise.all(
      admins.map(async (admin) => {
        const prefs = await ctx.db
          .query("notificationPreferences")
          .withIndex("by_user", (q) => q.eq("userId", admin._id))
          .first();
        return {
          email: admin.email,
          emailEnabled: prefs?.emailEnabled ?? true,
          events: (prefs?.events ?? {
            payment_received: true,
            payment_made: true,
            work_order_issued: true,
            work_order_amended: true,
            salary_processed: true,
            salary_approved: true,
            material_approved: true,
            material_rejected: true,
            invoice_sent: true,
            invoice_overdue: true,
          }) as Record<string, boolean>,
        };
      })
    );
  },
});
