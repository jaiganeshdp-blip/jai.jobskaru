/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as analytics from "../analytics.js";
import type * as backup from "../backup.js";
import type * as backupQueries from "../backupQueries.js";
import type * as bankStatements from "../bankStatements.js";
import type * as banks from "../banks.js";
import type * as boq_invitations from "../boq/invitations.js";
import type * as boq_projects from "../boq/projects.js";
import type * as boq_submissions from "../boq/submissions.js";
import type * as catalogItems from "../catalogItems.js";
import type * as clients from "../clients.js";
import type * as companies from "../companies.js";
import type * as contractors from "../contractors.js";
import type * as dashboard from "../dashboard.js";
import type * as deliveryChallans from "../deliveryChallans.js";
import type * as emails from "../emails.js";
import type * as expenses from "../expenses.js";
import type * as geofencing from "../geofencing.js";
import type * as gstInvoiceTracking from "../gstInvoiceTracking.js";
import type * as gstSummary from "../gstSummary.js";
import type * as incomingInvoices from "../incomingInvoices.js";
import type * as invoices from "../invoices.js";
import type * as labourCorrectionRequests from "../labourCorrectionRequests.js";
import type * as labourRegistration from "../labourRegistration.js";
import type * as labourWelcomeMessages from "../labourWelcomeMessages.js";
import type * as labourers from "../labourers.js";
import type * as lib_auth from "../lib/auth.js";
import type * as materials from "../materials.js";
import type * as myVendor from "../myVendor.js";
import type * as notificationDispatch from "../notificationDispatch.js";
import type * as notifications from "../notifications.js";
import type * as partners from "../partners.js";
import type * as payments from "../payments.js";
import type * as portal_contractor from "../portal/contractor.js";
import type * as portal_labour from "../portal/labour.js";
import type * as portal_supplier from "../portal/supplier.js";
import type * as portalAccess from "../portalAccess.js";
import type * as profileForm2 from "../profileForm2.js";
import type * as purchaseOrders from "../purchaseOrders.js";
import type * as registration from "../registration.js";
import type * as roleDashboards from "../roleDashboards.js";
import type * as safety_ppe from "../safety/ppe.js";
import type * as safety_supervisorPortal from "../safety/supervisorPortal.js";
import type * as safety_tools from "../safety/tools.js";
import type * as safety_violations from "../safety/violations.js";
import type * as salary from "../salary.js";
import type * as salePurchaseRegister from "../salePurchaseRegister.js";
import type * as screensaver from "../screensaver.js";
import type * as seed from "../seed.js";
import type * as siteDiary from "../siteDiary.js";
import type * as sites from "../sites.js";
import type * as superAdminDashboard from "../superAdminDashboard.js";
import type * as supervisorPortal from "../supervisorPortal.js";
import type * as suppliers from "../suppliers.js";
import type * as users from "../users.js";
import type * as vendorBills from "../vendorBills.js";
import type * as workOrderMilestones from "../workOrderMilestones.js";
import type * as workOrders from "../workOrders.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  analytics: typeof analytics;
  backup: typeof backup;
  backupQueries: typeof backupQueries;
  bankStatements: typeof bankStatements;
  banks: typeof banks;
  "boq/invitations": typeof boq_invitations;
  "boq/projects": typeof boq_projects;
  "boq/submissions": typeof boq_submissions;
  catalogItems: typeof catalogItems;
  clients: typeof clients;
  companies: typeof companies;
  contractors: typeof contractors;
  dashboard: typeof dashboard;
  deliveryChallans: typeof deliveryChallans;
  emails: typeof emails;
  expenses: typeof expenses;
  geofencing: typeof geofencing;
  gstInvoiceTracking: typeof gstInvoiceTracking;
  gstSummary: typeof gstSummary;
  incomingInvoices: typeof incomingInvoices;
  invoices: typeof invoices;
  labourCorrectionRequests: typeof labourCorrectionRequests;
  labourRegistration: typeof labourRegistration;
  labourWelcomeMessages: typeof labourWelcomeMessages;
  labourers: typeof labourers;
  "lib/auth": typeof lib_auth;
  materials: typeof materials;
  myVendor: typeof myVendor;
  notificationDispatch: typeof notificationDispatch;
  notifications: typeof notifications;
  partners: typeof partners;
  payments: typeof payments;
  "portal/contractor": typeof portal_contractor;
  "portal/labour": typeof portal_labour;
  "portal/supplier": typeof portal_supplier;
  portalAccess: typeof portalAccess;
  profileForm2: typeof profileForm2;
  purchaseOrders: typeof purchaseOrders;
  registration: typeof registration;
  roleDashboards: typeof roleDashboards;
  "safety/ppe": typeof safety_ppe;
  "safety/supervisorPortal": typeof safety_supervisorPortal;
  "safety/tools": typeof safety_tools;
  "safety/violations": typeof safety_violations;
  salary: typeof salary;
  salePurchaseRegister: typeof salePurchaseRegister;
  screensaver: typeof screensaver;
  seed: typeof seed;
  siteDiary: typeof siteDiary;
  sites: typeof sites;
  superAdminDashboard: typeof superAdminDashboard;
  supervisorPortal: typeof supervisorPortal;
  suppliers: typeof suppliers;
  users: typeof users;
  vendorBills: typeof vendorBills;
  workOrderMilestones: typeof workOrderMilestones;
  workOrders: typeof workOrders;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
