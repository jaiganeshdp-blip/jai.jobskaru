import { query } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";

export const stats = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);

    // Use bounded reads instead of collecting entire tables
    const companies = await ctx.db.query("companies").collect();
    const allSites = await ctx.db.query("sites").collect();
    const clients = await ctx.db.query("clients").collect();
    const suppliers = await ctx.db.query("suppliers").collect();
    const contractors = await ctx.db.query("contractors").collect();
    const labourers = await ctx.db.query("labourers").collect();
    const workOrders = await ctx.db.query("workOrders").collect();
    const allPartners = await ctx.db.query("partners").collect();

    // Filter sites for site_incharge
    const sites =
      user.role === "site_incharge" && user.assignedSiteId
        ? allSites.filter((s) => s._id === user.assignedSiteId)
        : allSites;

    const activeSites = sites.filter((s) => s.status === "active").length;
    const activeLabourers = labourers.filter((l) => l.isActive).length;
    const activeWorkOrders = workOrders.filter(
      (wo) => wo.status === "active" || wo.status === "amended"
    );
    const totalWOValue = activeWorkOrders.reduce((sum, wo) => sum + wo.totalValue, 0);

    // Only load expenses for the last 6 months instead of ALL expenses
    const now = new Date();
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    const sixMonthsAgoStr = `${sixMonthsAgo.getFullYear()}-${String(sixMonthsAgo.getMonth() + 1).padStart(2, "0")}`;

    const expenses = await ctx.db.query("siteExpenses").collect();
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

    // Monthly expense breakdown (last 6 months)
    const monthlyData: Array<{ month: string; expenses: number; revenue: number }> = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const label = d.toLocaleDateString("en-IN", { month: "short", year: "2-digit" });
      const monthStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const monthExpenses = expenses
        .filter((e) => e.date.startsWith(monthStr))
        .reduce((sum, e) => sum + e.amount, 0);
      const monthWO = workOrders
        .filter((wo) => wo.issueDate.startsWith(monthStr))
        .reduce((sum, wo) => sum + wo.totalValue, 0);
      monthlyData.push({ month: label, expenses: monthExpenses, revenue: monthWO });
    }

    // Expense by category
    const categoryTotals: Record<string, number> = {};
    for (const e of expenses) {
      categoryTotals[e.category] = (categoryTotals[e.category] ?? 0) + e.amount;
    }

    // Partner profit share summary
    const partnersByCompany: Record<string, { name: string; count: number; totalShare: number }> = {};
    for (const p of allPartners) {
      const company = companies.find((c) => c._id === p.companyId);
      const key = p.companyId as string;
      if (!partnersByCompany[key]) {
        partnersByCompany[key] = { name: company?.name ?? "Unknown", count: 0, totalShare: 0 };
      }
      partnersByCompany[key].count += 1;
      partnersByCompany[key].totalShare += p.sharePercent ?? 0;
    }

    // Recent sites (last 5 active)
    const recentSites = sites
      .filter((s) => s.status === "active")
      .slice(-5)
      .reverse();

    return {
      counts: {
        companies: companies.length,
        sites: sites.length,
        activeSites,
        clients: clients.length,
        suppliers: suppliers.length,
        contractors: contractors.length,
        labourers: labourers.length,
        activeLabourers,
        workOrders: workOrders.length,
        activeWorkOrders: activeWorkOrders.length,
        partners: allPartners.length,
      },
      financials: {
        totalWOValue,
        totalExpenses,
        netProfit: totalWOValue - totalExpenses,
      },
      monthlyData,
      categoryTotals,
      recentSites,
      partnersByCompany,
    };
  },
});
