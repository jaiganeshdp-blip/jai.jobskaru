import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireSuperAdmin } from "./lib/auth.ts";

export const getSlides = query({
  args: {},
  handler: async (ctx) => {
    const slides = await ctx.db
      .query("screensaverSlides")
      .withIndex("by_order")
      .collect();
    return slides.filter((s) => s.isActive);
  },
});

export const getAllSlides = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);
    return await ctx.db.query("screensaverSlides").withIndex("by_order").collect();
  },
});

export const getSettings = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("screensaverSettings").take(1);
    return all[0] ?? null;
  },
});

export const addSlide = mutation({
  args: {
    siteId: v.optional(v.id("sites")),
    title: v.string(),
    subtitle: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    order: v.number(),
  },
  handler: async (ctx, args) => {
    const user = await requireSuperAdmin(ctx);
    return await ctx.db.insert("screensaverSlides", {
      ...args,
      isActive: true,
      addedBy: user._id,
    });
  },
});

export const updateSlide = mutation({
  args: {
    id: v.id("screensaverSlides"),
    title: v.optional(v.string()),
    subtitle: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    order: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const removeSlide = mutation({
  args: { id: v.id("screensaverSlides") },
  handler: async (ctx, args) => {
    await requireSuperAdmin(ctx);
    await ctx.db.delete(args.id);
  },
});

export const saveSettings = mutation({
  args: {
    idleMinutes: v.number(),
    transitionSeconds: v.number(),
    showStats: v.boolean(),
    theme: v.union(v.literal("dark"), v.literal("light"), v.literal("blur")),
  },
  handler: async (ctx, args) => {
    const user = await requireSuperAdmin(ctx);
    const existing = await ctx.db.query("screensaverSettings").take(1);
    if (existing[0]) {
      await ctx.db.patch(existing[0]._id, { ...args, updatedBy: user._id });
    } else {
      await ctx.db.insert("screensaverSettings", { ...args, updatedBy: user._id });
    }
  },
});
