import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

export const list = query({
  args: {
    companyId: v.id("companies"),
    financialYear: v.optional(v.string()),
    bankName: v.optional(v.string()),
    dateFrom: v.optional(v.string()),
    dateTo: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Doc<"bankStatements">[]> => {
    const fy = args.financialYear ?? "2026-27";

    let rows: Doc<"bankStatements">[];
    if (args.bankName) {
      rows = await ctx.db
        .query("bankStatements")
        .withIndex("by_company_bank_fy", (q) =>
          q.eq("bankName", args.bankName!).eq("financialYear", fy)
        )
        .order("asc")
        .collect();
    } else {
      rows = await ctx.db
        .query("bankStatements")
        .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
        .order("asc")
        .collect();
    }

    // Filter by company
    rows = rows.filter((r) => r.companyId === args.companyId);

    // Date range filter
    if (args.dateFrom) {
      rows = rows.filter((r) => r.date >= args.dateFrom!);
    }
    if (args.dateTo) {
      rows = rows.filter((r) => r.date <= args.dateTo!);
    }

    return rows;
  },
});

export const summary = query({
  args: {
    companyId: v.id("companies"),
    financialYear: v.optional(v.string()),
    bankName: v.optional(v.string()),
    dateFrom: v.optional(v.string()),
    dateTo: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{
    totalCredit: number;
    totalDebit: number;
    latestBalance: number;
    txCount: number;
  }> => {
    const fy = args.financialYear ?? "2026-27";

    let rows = await ctx.db
      .query("bankStatements")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
      .collect();

    // Filter by company
    rows = rows.filter((r) => r.companyId === args.companyId);

    if (args.bankName) {
      rows = rows.filter((r) => r.bankName === args.bankName);
    }

    // Date range filter
    if (args.dateFrom) {
      rows = rows.filter((r) => r.date >= args.dateFrom!);
    }
    if (args.dateTo) {
      rows = rows.filter((r) => r.date <= args.dateTo!);
    }

    let totalCredit = 0, totalDebit = 0, latestBalance = 0;
    for (const r of rows) {
      totalCredit += r.credit ?? 0;
      totalDebit += r.debit ?? 0;
      if (r.balance !== undefined) latestBalance = r.balance;
    }
    return { totalCredit, totalDebit, latestBalance, txCount: rows.length };
  },
});

export const distinctBanks = query({
  args: {
    companyId: v.id("companies"),
    financialYear: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<string[]> => {
    const fy = args.financialYear ?? "2026-27";
    const set = new Set<string>();

    // Banks from banks table (master list)
    const banksList = await ctx.db
      .query("banks")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
    for (const b of banksList) {
      set.add(b.name);
    }

    // Banks from existing transactions
    const rows = await ctx.db
      .query("bankStatements")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
      .collect();
    for (const r of rows) {
      if (r.companyId === args.companyId) set.add(r.bankName);
    }
    return Array.from(set).sort();
  },
});

export const create = mutation({
  args: {
    companyId: v.id("companies"),
    financialYear: v.string(),
    bankName: v.string(),
    accountNumber: v.optional(v.string()),
    date: v.string(),
    narration: v.optional(v.string()),
    chequeNo: v.optional(v.string()),
    debit: v.optional(v.number()),
    credit: v.optional(v.number()),
    balance: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    category: v.optional(v.string()),
    remarks: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"bankStatements">> => {
    return await ctx.db.insert("bankStatements", { ...args });
  },
});

export const bulkCreate = mutation({
  args: {
    rows: v.array(v.object({
      companyId: v.id("companies"),
      financialYear: v.string(),
      bankName: v.string(),
      accountNumber: v.optional(v.string()),
      date: v.string(),
      narration: v.optional(v.string()),
      chequeNo: v.optional(v.string()),
      debit: v.optional(v.number()),
      credit: v.optional(v.number()),
      balance: v.optional(v.number()),
      utrNo: v.optional(v.string()),
      category: v.optional(v.string()),
      remarks: v.optional(v.string()),
    })),
  },
  handler: async (ctx, args): Promise<number> => {
    for (const row of args.rows) {
      await ctx.db.insert("bankStatements", row);
    }
    return args.rows.length;
  },
});

export const update = mutation({
  args: {
    id: v.id("bankStatements"),
    bankName: v.optional(v.string()),
    date: v.optional(v.string()),
    narration: v.optional(v.string()),
    chequeNo: v.optional(v.string()),
    debit: v.optional(v.number()),
    credit: v.optional(v.number()),
    balance: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    category: v.optional(v.string()),
    remarks: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<void> => {
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("bankStatements") },
  handler: async (ctx, args): Promise<void> => {
    await ctx.db.delete(args.id);
  },
});

export const removeByCompanyBankYear = mutation({
  args: { companyId: v.id("companies"), financialYear: v.string(), bankName: v.string() },
  handler: async (ctx, args): Promise<number> => {
    const rows = await ctx.db
      .query("bankStatements")
      .withIndex("by_company_bank_fy", (q) =>
        q.eq("bankName", args.bankName).eq("financialYear", args.financialYear)
      )
      .collect();
    const filtered = rows.filter((r) => r.companyId === args.companyId);
    for (const r of filtered) await ctx.db.delete(r._id);
    return filtered.length;
  },
});

// Migrate old records without companyId to a specific company
export const migrateToCompany = mutation({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args): Promise<number> => {
    const rows = await ctx.db
      .query("bankStatements")
      .collect();
    let count = 0;
    for (const r of rows) {
      if (!r.companyId) {
        await ctx.db.patch(r._id, { companyId: args.companyId });
        count++;
      }
    }
    return count;
  },
});
