import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

// List all GST invoices for a financial year + optional filters
export const list = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()), // filter to JAI AAINATH or JAI GANESH
    companyName: v.optional(v.string()),    // client company filter
    invoiceStatus: v.optional(v.union(v.literal("DRAFT"), v.literal("FINAL"), v.literal("SUBMITTED"))),
  },
  handler: async (ctx, args): Promise<Doc<"gstInvoiceTracking">[]> => {
    const fy = args.financialYear ?? "2026-27";
    let rows = await ctx.db
      .query("gstInvoiceTracking")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
      .order("asc")
      .collect();

    if (args.ourCompanyName) {
      rows = rows.filter((r) => r.ourCompanyName === args.ourCompanyName);
    }
    if (args.companyName) {
      rows = rows.filter((r) => r.companyName === args.companyName);
    }
    if (args.invoiceStatus) {
      rows = rows.filter((r) => r.invoiceStatus === args.invoiceStatus);
    }

    // Compute days outstanding & overdue on the fly
    const today = new Date();
    return rows.map((r) => {
      if (r.dueDate) {
        const due = new Date(r.dueDate);
        const diff = Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
        return { ...r, isOverdue: diff > 0 };
      }
      return r;
    });
  },
});

// Summary totals
export const summary = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
    companyName: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{
    totalAmount: number;
    totalGst: number;
    totalBilling: number;
    totalRetention: number;
    totalTds: number;
    overdueCount: number;
  }> => {
    const fy = args.financialYear ?? "2026-27";
    let rows = await ctx.db
      .query("gstInvoiceTracking")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
      .collect();

    if (args.ourCompanyName) {
      rows = rows.filter((r) => r.ourCompanyName === args.ourCompanyName);
    }
    if (args.companyName) {
      rows = rows.filter((r) => r.companyName === args.companyName);
    }

    const today = new Date();
    let totalAmount = 0;
    let totalGst = 0;
    let totalBilling = 0;
    let totalRetention = 0;
    let totalTds = 0;
    let overdueCount = 0;

    for (const r of rows) {
      totalAmount += r.amount;
      totalGst += r.gstAmount;
      totalBilling += r.billAmount ?? 0;
      totalRetention += r.retention ?? 0;
      totalTds += r.tds ?? 0;
      if (r.dueDate) {
        const due = new Date(r.dueDate);
        if (Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24)) > 0) {
          overdueCount++;
        }
      }
    }

    return { totalAmount, totalGst, totalBilling, totalRetention, totalTds, overdueCount };
  },
});

// Distinct client company names for filter dropdown (filtered by ourCompanyName)
export const distinctCompanies = query({
  args: {
    financialYear: v.optional(v.string()),
    ourCompanyName: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<string[]> => {
    const fy = args.financialYear ?? "2026-27";
    let rows = await ctx.db
      .query("gstInvoiceTracking")
      .withIndex("by_financial_year", (q) => q.eq("financialYear", fy))
      .collect();
    if (args.ourCompanyName) {
      rows = rows.filter((r) => r.ourCompanyName === args.ourCompanyName);
    }
    const set = new Set<string>();
    for (const r of rows) set.add(r.companyName);
    return Array.from(set).sort();
  },
});

// Get single invoice
export const get = query({
  args: { id: v.id("gstInvoiceTracking") },
  handler: async (ctx, args): Promise<Doc<"gstInvoiceTracking"> | null> => {
    return await ctx.db.get(args.id);
  },
});

// Create invoice
export const create = mutation({
  args: {
    financialYear: v.string(),
    ourCompanyName: v.optional(v.string()),
    serialNo: v.optional(v.number()),
    billNo: v.optional(v.string()),
    location: v.optional(v.string()),
    billJai: v.optional(v.string()),
    siteCode: v.optional(v.string()),
    poNo: v.optional(v.string()),
    companyName: v.string(),
    billType: v.union(v.literal("FINAL"), v.literal("RA BILL"), v.literal("DRAFT")),
    draftInvoiceNo: v.optional(v.string()),
    draftInvoiceDate: v.optional(v.string()),
    invoiceStatus: v.union(v.literal("DRAFT"), v.literal("FINAL"), v.literal("SUBMITTED")),
    sesDone: v.optional(v.string()),
    caseId: v.optional(v.string()),
    taxInvoiceNo: v.optional(v.string()),
    taxInvoiceDate: v.optional(v.string()),
    amount: v.number(),
    gstPercent: v.number(),
    billAmount: v.optional(v.number()),
    retention: v.optional(v.number()),
    tds: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    utrDate: v.optional(v.string()),
    termsDays: v.optional(v.number()),
    dueDate: v.optional(v.string()),
    advanceDeducted: v.optional(v.number()),
    vendorDocDeducted: v.optional(v.number()),
    netPayable: v.optional(v.number()),
    paymentAdviceRef: v.optional(v.string()),
    bankName: v.optional(v.string()),
    remark: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"gstInvoiceTracking">> => {
    const gstAmount = (args.amount * args.gstPercent) / 100;
    return await ctx.db.insert("gstInvoiceTracking", {
      ...args,
      gstAmount,
      isOverdue: false,
    });
  },
});

// Update invoice
export const update = mutation({
  args: {
    id: v.id("gstInvoiceTracking"),
    ourCompanyName: v.optional(v.string()),
    serialNo: v.optional(v.number()),
    billNo: v.optional(v.string()),
    location: v.optional(v.string()),
    billJai: v.optional(v.string()),
    siteCode: v.optional(v.string()),
    poNo: v.optional(v.string()),
    companyName: v.optional(v.string()),
    billType: v.optional(v.union(v.literal("FINAL"), v.literal("RA BILL"), v.literal("DRAFT"))),
    draftInvoiceNo: v.optional(v.string()),
    draftInvoiceDate: v.optional(v.string()),
    invoiceStatus: v.optional(v.union(v.literal("DRAFT"), v.literal("FINAL"), v.literal("SUBMITTED"))),
    sesDone: v.optional(v.string()),
    caseId: v.optional(v.string()),
    taxInvoiceNo: v.optional(v.string()),
    taxInvoiceDate: v.optional(v.string()),
    amount: v.optional(v.number()),
    gstPercent: v.optional(v.number()),
    billAmount: v.optional(v.number()),
    retention: v.optional(v.number()),
    tds: v.optional(v.number()),
    utrNo: v.optional(v.string()),
    utrDate: v.optional(v.string()),
    termsDays: v.optional(v.number()),
    dueDate: v.optional(v.string()),
    advanceDeducted: v.optional(v.number()),
    vendorDocDeducted: v.optional(v.number()),
    netPayable: v.optional(v.number()),
    paymentAdviceRef: v.optional(v.string()),
    bankName: v.optional(v.string()),
    remark: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<void> => {
    const { id, amount, gstPercent, ...rest } = args;
    const existing = await ctx.db.get(id);
    if (!existing) return;

    const newAmount = amount ?? existing.amount;
    const newGstPercent = gstPercent ?? existing.gstPercent;
    const gstAmount = (newAmount * newGstPercent) / 100;

    await ctx.db.patch(id, {
      ...rest,
      ...(amount !== undefined ? { amount } : {}),
      ...(gstPercent !== undefined ? { gstPercent } : {}),
      gstAmount,
    });
  },
});

// Delete invoice
export const remove = mutation({
  args: { id: v.id("gstInvoiceTracking") },
  handler: async (ctx, args): Promise<void> => {
    await ctx.db.delete(args.id);
  },
});
