"use node";

import { v } from "convex/values";
import { internalAction } from "./_generated/server";
import { Hercules } from "@usehercules/sdk";

const hercules = new Hercules({
  apiKey: process.env.HERCULES_API_KEY!,
  apiVersion: "2025-12-09",
});

// Send welcome email to registered labour
export const sendWelcomeEmail = internalAction({
  args: {
    toEmail: v.string(),
    workerName: v.string(),
    companyName: v.string(),
    siteName: v.string(),
    designation: v.string(),
  },
  handler: async (_ctx, args) => {
    const senderEmail = process.env.CONSTRUCTPRO_SENDER_EMAIL;
    if (!senderEmail) {
      console.log("Sender email not configured, skipping welcome email");
      return;
    }

    const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif;">
  <div style="max-width:560px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
    <div style="background:#1e293b;padding:24px;text-align:center;">
      <span style="color:#f59e0b;font-size:22px;font-weight:700;letter-spacing:1px;">JAI SITE MANAGER ERP</span>
    </div>
    <div style="padding:32px;">
      <h2 style="margin:0 0 12px;font-size:22px;color:#0f172a;">🙏 Welcome to ${args.companyName}!</h2>
      <p style="color:#475569;line-height:1.8;margin:0 0 16px;font-size:16px;">
        Namaste <strong>${args.workerName}</strong> ji,<br><br>
        Aapka registration form mil gaya hai. Aapki details:<br>
        <strong>Company:</strong> ${args.companyName}<br>
        <strong>Site:</strong> ${args.siteName}<br>
        <strong>Kaam:</strong> ${args.designation}<br><br>
        Aapka form supervisor ke paas verify hone ke liye bheja gaya hai. 
        Jab approve hoga tab aapko kaam shuru karne ka message aayega.
      </p>
      <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:16px;margin-top:16px;">
        <p style="margin:0;color:#92400e;font-size:14px;">
          ⏳ Status: <strong>Verification Pending</strong><br>
          Supervisor verify karega, phir admin final approve karega.
        </p>
      </div>
    </div>
    <div style="padding:16px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;">
      <p style="color:#94a3b8;font-size:12px;margin:0;">JAI AAINATH GROUP — Construction Site Management</p>
    </div>
  </div>
</body>
</html>`;

    try {
      await hercules.email.send({
        from: senderEmail,
        to: args.toEmail,
        subject: `🙏 Welcome to ${args.companyName} — JAI SITE MANAGER ERP`,
        html,
      });
      console.log(`Welcome email sent to ${args.toEmail}`);
    } catch (err) {
      console.error("Welcome email failed:", err);
    }
  },
});

// Send welcome SMS via MSG91 (requires MSG91_AUTH_KEY and MSG91_SENDER_ID secrets)
export const sendWelcomeSms = internalAction({
  args: {
    mobile: v.string(),
    workerName: v.string(),
    companyName: v.string(),
    siteName: v.string(),
  },
  handler: async (_ctx, args) => {
    const authKey = process.env.MSG91_AUTH_KEY;
    const senderId = process.env.MSG91_SENDER_ID;
    const templateId = process.env.MSG91_WELCOME_TEMPLATE_ID;

    if (!authKey || !senderId) {
      console.log("MSG91 not configured, skipping SMS");
      return;
    }

    // MSG91 Send SMS API
    const mobile = args.mobile.startsWith("91") ? args.mobile : `91${args.mobile}`;

    const body = {
      sender: senderId,
      route: "4", // Transactional route
      country: "91",
      sms: [
        {
          message: `Namaste ${args.workerName} ji! Welcome to ${args.companyName}. Aapka registration ${args.siteName} site ke liye mil gaya hai. Supervisor verify karega. - JAI SITE MANAGER ERP`,
          to: [mobile],
        },
      ],
      ...(templateId ? { DLT_TE_ID: templateId } : {}),
    };

    try {
      const response = await fetch("https://api.msg91.com/api/v5/flow/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authkey: authKey,
        },
        body: JSON.stringify(body),
      });
      const result = await response.json();
      console.log("SMS result:", result);
    } catch (err) {
      console.error("SMS send failed:", err);
    }
  },
});

// Send welcome WhatsApp message via MSG91 WhatsApp API
export const sendWelcomeWhatsApp = internalAction({
  args: {
    mobile: v.string(),
    workerName: v.string(),
    companyName: v.string(),
    siteName: v.string(),
    designation: v.string(),
  },
  handler: async (_ctx, args) => {
    const authKey = process.env.MSG91_AUTH_KEY;
    const whatsappTemplateId = process.env.MSG91_WHATSAPP_WELCOME_TEMPLATE;

    if (!authKey) {
      console.log("MSG91 not configured, skipping WhatsApp");
      return;
    }

    const mobile = args.mobile.startsWith("91") ? args.mobile : `91${args.mobile}`;

    // MSG91 WhatsApp API
    const body = {
      integrated_number: process.env.MSG91_WHATSAPP_NUMBER || "",
      content_type: "template",
      payload: {
        messaging_product: "whatsapp",
        type: "template",
        template: {
          name: whatsappTemplateId || "labour_welcome",
          language: { code: "hi", policy: "deterministic" },
          namespace: process.env.MSG91_WHATSAPP_NAMESPACE || "",
          to_and_components: [
            {
              to: [mobile],
              components: {
                body_1: { type: "text", value: args.workerName },
                body_2: { type: "text", value: args.companyName },
                body_3: { type: "text", value: args.siteName },
                body_4: { type: "text", value: args.designation },
              },
            },
          ],
        },
      },
    };

    try {
      const response = await fetch("https://api.msg91.com/api/v5/whatsapp/whatsapp-outbound-message/bulk/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authkey: authKey,
        },
        body: JSON.stringify(body),
      });
      const result = await response.json();
      console.log("WhatsApp result:", result);
    } catch (err) {
      console.error("WhatsApp send failed:", err);
    }
  },
});
