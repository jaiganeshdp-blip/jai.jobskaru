import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser, requireRole } from "./lib/auth.ts";

const paymentMode = v.union(
  v.literal("cash"),
  v.literal("cheque"),
  v.literal("neft"),
  v.literal("rtgs"),
  v.literal("upi"),
  v.literal("other")
);

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    type: v.optional(v.union(v.literal("received"), v.literal("paid"))),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let payments;
    if (args.siteId) {
      payments = await ctx.db
        .query("payments")
        .withIndex("by_site", (q) => q.eq("siteId", args.siteId!))
        .collect();
    } else if (user.role === "site_incharge" && user.assignedSiteId) {
      payments = await ctx.db
        .query("payments")
        .withIndex("by_site", (q) => q.eq("siteId", user.assignedSiteId!))
        .collect();
    } else {
      payments = await ctx.db.query("payments").collect();
    }

    if (args.type) payments = payments.filter((p) => p.type === args.type);

    const enriched = await Promise.all(
      payments.map(async (p) => {
        const site = await ctx.db.get(p.siteId);
        const client = p.clientId ? await ctx.db.get(p.clientId) : null;
        const supplier = p.supplierId ? await ctx.db.get(p.supplierId) : null;
        const contractor = p.contractorId ? await ctx.db.get(p.contractorId) : null;
        const recorder = await ctx.db.get(p.recordedBy);
        return {
          ...p,
          siteName: site?.name ?? "Unknown",
          partyName: client?.name ?? supplier?.name ?? contractor?.name ?? "—",
          recordedByName: recorder?.name ?? "Unknown",
        };
      })
    );

    return enriched.sort((a, b) => b.date.localeCompare(a.date));
  },
});

export const listByWorkOrder = query({
  args: { workOrderId: v.id("workOrders") },
  handler: async (ctx, args): Promise<Array<{
    _id: string;
    type: "received" | "paid";
    amount: number;
    date: string;
    mode: string;
    referenceNumber?: string;
    notes?: string;
    partyName: string;
    recordedByName: string;
  }>> => {
    await getCurrentUser(ctx);
    const payments = await ctx.db
      .query("payments")
      .withIndex("by_work_order", (q) => q.eq("workOrderId", args.workOrderId))
      .collect();

    const enriched = await Promise.all(
      payments.map(async (p) => {
        const client = p.clientId ? await ctx.db.get(p.clientId) : null;
        const supplier = p.supplierId ? await ctx.db.get(p.supplierId) : null;
        const contractor = p.contractorId ? await ctx.db.get(p.contractorId) : null;
        const recorder = await ctx.db.get(p.recordedBy);
        return {
          _id: p._id as string,
          type: p.type,
          amount: p.amount,
          date: p.date,
          mode: p.mode,
          referenceNumber: p.referenceNumber,
          notes: p.notes,
          partyName: client?.name ?? supplier?.name ?? contractor?.name ?? "—",
          recordedByName: recorder?.name ?? "Unknown",
        };
      })
    );

    return enriched.sort((a, b) => b.date.localeCompare(a.date));
  },
});

export const recordFromClient = mutation({
  args: {
    siteId: v.id("sites"),
    clientId: v.id("clients"),
    workOrderId: v.optional(v.id("workOrders")),
    invoiceId: v.optional(v.id("invoices")),
    amount: v.number(),
    date: v.string(),
    mode: paymentMode,
    referenceNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    return await ctx.db.insert("payments", {
      type: "received",
      siteId: args.siteId,
      clientId: args.clientId,
      workOrderId: args.workOrderId,
      invoiceId: args.invoiceId,
      amount: args.amount,
      date: args.date,
      mode: args.mode,
      referenceNumber: args.referenceNumber,
      notes: args.notes,
      recordedBy: user._id,
    });
  },
});

export const recordToSupplier = mutation({
  args: {
    siteId: v.id("sites"),
    supplierId: v.id("suppliers"),
    materialId: v.optional(v.id("materials")),
    workOrderId: v.optional(v.id("workOrders")),
    amount: v.number(),
    date: v.string(),
    mode: paymentMode,
    referenceNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    return await ctx.db.insert("payments", {
      type: "paid",
      siteId: args.siteId,
      supplierId: args.supplierId,
      materialId: args.materialId,
      workOrderId: args.workOrderId,
      amount: args.amount,
      date: args.date,
      mode: args.mode,
      referenceNumber: args.referenceNumber,
      notes: args.notes,
      recordedBy: user._id,
    });
  },
});

export const recordToContractor = mutation({
  args: {
    siteId: v.id("sites"),
    contractorId: v.id("contractors"),
    workOrderId: v.optional(v.id("workOrders")),
    amount: v.number(),
    date: v.string(),
    mode: paymentMode,
    referenceNumber: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    return await ctx.db.insert("payments", {
      type: "paid",
      siteId: args.siteId,
      contractorId: args.contractorId,
      workOrderId: args.workOrderId,
      amount: args.amount,
      date: args.date,
      mode: args.mode,
      referenceNumber: args.referenceNumber,
      notes: args.notes,
      recordedBy: user._id,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("payments") },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin"]);
    await ctx.db.delete(args.id);
  },
});
