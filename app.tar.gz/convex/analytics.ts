import { query } from "./_generated/server";
import { v } from "convex/values";
import { getCurrentUser } from "./lib/auth.ts";

// Company-wide P&L summary
export const companyPnL = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);

    const sites = await ctx.db.query("sites").collect();
    const workOrders = await ctx.db.query("workOrders").collect();
    const expenses = await ctx.db.query("expenses").collect();
    const vendorBills = await ctx.db.query("vendorBills").collect();
    const salarySheets = await ctx.db.query("salarySheets").collect();
    const payments = await ctx.db.query("payments").collect();
    const companies = await ctx.db.query("companies").collect();

    // Per-site summary
    const siteSummaries = sites.map((site) => {
      const siteWOs = workOrders.filter((wo) => wo.siteId === site._id && wo.status !== "cancelled");
      const woValue = siteWOs.reduce((s, wo) => s + wo.totalValue, 0);

      const siteExpenses = expenses.filter((e) => e.siteId === site._id);
      const expenseTotal = siteExpenses.reduce((s, e) => s + e.amount, 0);

      const siteBills = vendorBills.filter((b) => b.siteId === site._id && b.status !== "disputed");
      const billTotal = siteBills.reduce((s, b) => s + b.totalAmount, 0);

      const siteSalaries = salarySheets.filter((ss) => ss.siteId === site._id && ss.status === "paid");
      const salaryTotal = siteSalaries.reduce((s, ss) => s + ss.totalAmount, 0);

      const received = payments
        .filter((p) => p.siteId === site._id && p.type === "received")
        .reduce((s, p) => s + p.amount, 0);
      const paid = payments
        .filter((p) => p.siteId === site._id && p.type === "paid")
        .reduce((s, p) => s + p.amount, 0);

      const totalCost = expenseTotal + billTotal + salaryTotal;
      const margin = woValue > 0 ? Math.round(((woValue - totalCost) / woValue) * 100) : 0;

      const company = companies.find((c) => c._id === site.companyId);

      return {
        siteId: site._id,
        siteName: site.name,
        companyName: company?.name ?? "—",
        status: site.status,
        woValue,
        totalCost,
        grossProfit: woValue - totalCost,
        margin,
        received,
        outstanding: woValue - received,
        expenseTotal,
        billTotal,
        salaryTotal,
      };
    });

    // Overall totals
    const totalWOValue = siteSummaries.reduce((s, x) => s + x.woValue, 0);
    const totalCost = siteSummaries.reduce((s, x) => s + x.totalCost, 0);
    const totalReceived = siteSummaries.reduce((s, x) => s + x.received, 0);
    const totalOutstanding = siteSummaries.reduce((s, x) => s + x.outstanding, 0);

    // Top 5 sites by WO value
    const topSites = [...siteSummaries]
      .sort((a, b) => b.woValue - a.woValue)
      .slice(0, 5);

    return {
      siteSummaries,
      topSites,
      totals: {
        woValue: totalWOValue,
        cost: totalCost,
        grossProfit: totalWOValue - totalCost,
        margin: totalWOValue > 0 ? Math.round(((totalWOValue - totalCost) / totalWOValue) * 100) : 0,
        received: totalReceived,
        outstanding: totalOutstanding,
      },
    };
  },
});

// Monthly trends (last 12 months)
export const monthlyTrends = query({
  args: { months: v.optional(v.number()) },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);

    const count = args.months ?? 12;
    const workOrders = await ctx.db.query("workOrders").collect();
    const expenses = await ctx.db.query("expenses").collect();
    const vendorBills = await ctx.db.query("vendorBills").collect();
    const salarySheets = await ctx.db.query("salarySheets").collect();
    const payments = await ctx.db.query("payments").collect();

    const now = new Date();
    const data: Array<{
      month: string;
      label: string;
      revenue: number;
      expenses: number;
      salaries: number;
      bills: number;
      received: number;
      totalCost: number;
      profit: number;
    }> = [];

    for (let i = count - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("en-IN", { month: "short", year: "2-digit" });

      const revenue = workOrders
        .filter((wo) => wo.issueDate.startsWith(monthStr) && wo.status !== "cancelled")
        .reduce((s, wo) => s + wo.totalValue, 0);

      const monthExpenses = expenses
        .filter((e) => e.date.startsWith(monthStr))
        .reduce((s, e) => s + e.amount, 0);

      const monthBills = vendorBills
        .filter((b) => b.billDate.startsWith(monthStr) && b.status !== "disputed")
        .reduce((s, b) => s + b.totalAmount, 0);

      const monthSalaries = salarySheets
        .filter((ss) => ss.month === monthStr && ss.status === "paid")
        .reduce((s, ss) => s + ss.totalAmount, 0);

      const received = payments
        .filter((p) => p.date.startsWith(monthStr) && p.type === "received")
        .reduce((s, p) => s + p.amount, 0);

      const totalCost = monthExpenses + monthBills + monthSalaries;

      data.push({
        month: monthStr,
        label,
        revenue,
        expenses: monthExpenses,
        salaries: monthSalaries,
        bills: monthBills,
        received,
        totalCost,
        profit: revenue - totalCost,
      });
    }

    return data;
  },
});

// Expense category breakdown across all sites or single site
export const expenseCategoryBreakdown = query({
  args: { siteId: v.optional(v.id("sites")) },
  handler: async (ctx, args) => {
    await getCurrentUser(ctx);

    let expensesQ = ctx.db.query("expenses");
    const allExpenses = await expensesQ.collect();
    const filtered = args.siteId
      ? allExpenses.filter((e) => e.siteId === args.siteId)
      : allExpenses;

    const byCategory: Record<string, number> = {};
    for (const e of filtered) {
      byCategory[e.category] = (byCategory[e.category] ?? 0) + e.amount;
    }

    const total = Object.values(byCategory).reduce((s, v) => s + v, 0);
    return { byCategory, total };
  },
});

// Company-level KPIs
export const companyKPIs = query({
  args: {},
  handler: async (ctx) => {
    await getCurrentUser(ctx);

    const companies = await ctx.db.query("companies").collect();
    const sites = await ctx.db.query("sites").collect();
    const workOrders = await ctx.db.query("workOrders").collect();
    const labourers = await ctx.db.query("labourers").collect();
    const payments = await ctx.db.query("payments").collect();

    const companySummaries = companies.map((company) => {
      const companySites = sites.filter((s) => s.companyId === company._id);
      const activeSites = companySites.filter((s) => s.status === "active").length;
      const companyWOs = workOrders.filter(
        (wo) => wo.companyId === company._id && wo.status !== "cancelled"
      );
      const woValue = companyWOs.reduce((s, wo) => s + wo.totalValue, 0);
      const siteIds = new Set(companySites.map((s) => s._id));
      const labourCount = labourers.filter(
        (l) => siteIds.has(l.siteId) && l.isActive
      ).length;
      const totalReceived = payments
        .filter((p) => siteIds.has(p.siteId) && p.type === "received")
        .reduce((s, p) => s + p.amount, 0);

      return {
        companyId: company._id,
        companyName: company.name,
        totalSites: companySites.length,
        activeSites,
        woValue,
        labourCount,
        totalReceived,
      };
    });

    return companySummaries;
  },
});
