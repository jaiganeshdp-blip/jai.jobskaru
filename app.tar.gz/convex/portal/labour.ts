import { v } from "convex/values";
import { query } from "../_generated/server";

// Public portal query - no auth required, uses token
export const getByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) return null;

    const site = await ctx.db.get(labourer.siteId);
    const contractor = labourer.contractorId
      ? await ctx.db.get(labourer.contractorId)
      : null;

    return {
      labourer,
      site,
      contractor,
    };
  },
});

export const getAttendanceByToken = query({
  args: { token: v.string(), month: v.string() },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) return [];

    const allAttendance = await ctx.db
      .query("attendance")
      .withIndex("by_labourer_date", (q) => q.eq("labourerId", labourer._id))
      .collect();

    // Filter by month (YYYY-MM)
    return allAttendance.filter((a) => a.date.startsWith(args.month));
  },
});

export const getSalaryByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const labourer = await ctx.db
      .query("labourers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!labourer) return [];

    const allSheets = await ctx.db
      .query("salarySheets")
      .withIndex("by_site_month", (q) => q.eq("siteId", labourer.siteId))
      .collect();

    const results = [];

    for (const sheet of allSheets) {
      const entries = await ctx.db
        .query("salaryEntries")
        .withIndex("by_salary_sheet", (q) => q.eq("salarySheetId", sheet._id))
        .collect();
      const myEntry = entries.find((e) => e.labourerId === labourer._id);
      if (myEntry) {
        results.push({ sheet, entry: myEntry });
      }
    }

    return results;
  },
});
