import { v } from "convex/values";
import { query, mutation } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { Id } from "../_generated/dataModel.d.ts";

// Public portal query - no auth required, uses token
export const getByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return null;
    return { contractor };
  },
});

export const getWorkOrdersByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args): Promise<Array<{
    _id: string;
    orderNumber: string;
    description: string;
    totalValue: number;
    status: string;
    issueDate: string;
    version: number;
    siteName: string;
    amendments: Array<{
      _id: string;
      amendmentNumber: number;
      reason: string;
      previousValue: number;
      newValue: number;
      date: string;
    }>;
  }>> => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return [];

    // Get work order IDs via POs assigned to this contractor
    const contractorPOs = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_contractor", (q) => q.eq("contractorId", contractor._id))
      .collect();

    const workOrderIdSet = new Set<Id<"workOrders">>();
    const siteIdMap: Record<string, Id<"sites">> = {};
    for (const po of contractorPOs) {
      if (po.workOrderId) {
        workOrderIdSet.add(po.workOrderId);
        siteIdMap[po.workOrderId] = po.siteId;
      }
    }

    // Also check labourer-based sites
    const labourers = await ctx.db
      .query("labourers")
      .withIndex("by_contractor", (q) => q.eq("contractorId", contractor._id))
      .collect();
    const labourerSiteIds = [...new Set(labourers.map((l) => l.siteId))];
    for (const siteId of labourerSiteIds) {
      const orders = await ctx.db
        .query("workOrders")
        .withIndex("by_site", (q) => q.eq("siteId", siteId))
        .collect();
      for (const o of orders) workOrderIdSet.add(o._id);
    }

    const results = [];
    for (const woId of workOrderIdSet) {
      const order = await ctx.db.get(woId);
      if (!order) continue;
      const site = await ctx.db.get(order.siteId);
      const amendments = await ctx.db
        .query("workOrderAmendments")
        .withIndex("by_work_order", (q) => q.eq("workOrderId", order._id))
        .collect();
      results.push({
        _id: order._id,
        orderNumber: order.orderNumber,
        description: order.description,
        totalValue: order.totalValue,
        status: order.status,
        issueDate: order.issueDate,
        version: order.version,
        siteName: site?.name ?? "Unknown",
        amendments,
      });
    }
    return results;
  },
});

export const getPaymentsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args): Promise<Array<{
    _id: string;
    amount: number;
    date: string;
    referenceNumber?: string;
    mode?: string;
  }>> => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .collect();
    if (!contractor.length) return [];
    const c = contractor[0];

    const payments = await ctx.db
      .query("payments")
      .withIndex("by_type", (q) => q.eq("type", "paid"))
      .collect();

    const directPayments = payments
      .filter((p) => p.contractorId === c._id)
      .map((p) => ({
        _id: p._id as string,
        amount: p.amount,
        date: p.date,
        referenceNumber: p.referenceNumber,
        mode: p.mode,
      }));

    // Also include payments derived from paid vendorBills
    const paidBills = await ctx.db
      .query("vendorBills")
      .collect();
    const billPayments = paidBills
      .filter((b) => b.contractorId === c._id && b.paidAmount > 0)
      .map((b) => ({
        _id: b._id as string,
        amount: b.paidAmount,
        date: b.billDate,
        referenceNumber: undefined,
        mode: undefined,
      }));

    // Merge bill payments (paidAmount > 0) with direct payments
    return [...directPayments, ...billPayments];
  },
});

// Get all POs for this contractor via portal token
export const getPOsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return [];

    // Fetch POs directly by contractorId
    const contractorPOs = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_contractor", (q) => q.eq("contractorId", contractor._id))
      .collect();

    return Promise.all(contractorPOs.map(async (po) => {
      const site = await ctx.db.get(po.siteId);
      const company = await ctx.db.get(po.companyId);
      return {
        _id: po._id,
        poNumber: po.poNumber,
        siteName: site?.name ?? "—",
        companyName: company?.name ?? "—",
        siteId: po.siteId,
        companyId: po.companyId,
        totalValue: po.totalValue,
        status: po.status,
        issueDate: po.issueDate,
        items: po.items,
      };
    }));
  },
});

// Get bills submitted by this contractor
export const getBillsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return [];

    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_contractor", (q) => q.eq("contractorId", contractor._id))
      .order("desc")
      .take(50);

    return Promise.all(bills.map(async (b) => {
      const site = await ctx.db.get(b.siteId);
      const po = b.purchaseOrderId ? await ctx.db.get(b.purchaseOrderId) : null;
      const company = await ctx.db.get(b.companyId);
      return {
        ...b,
        siteName: site?.name ?? "—",
        poNumber: po?.poNumber,
        companyName: company?.name ?? "—",
      };
    }));
  },
});

// Get prev bills for a specific PO (for cumulative calc)
export const getPrevBillsByPO = query({
  args: { token: v.string(), purchaseOrderId: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return [];

    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();
    return bills.sort((a, b) => (a.raNumber ?? 0) - (b.raNumber ?? 0));
  },
});

// Generate upload URL for portal bill attachments (token-based)
export const generateUploadUrl = mutation({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });
    return await ctx.storage.generateUploadUrl();
  },
});

// Add attachment to bill from portal (token-based)
export const addBillAttachment = mutation({
  args: {
    token: v.string(),
    billId: v.id("vendorBills"),
    storageId: v.id("_storage"),
    fileName: v.string(),
    fileType: v.string(),
    fileSize: v.number(),
  },
  handler: async (ctx, args) => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });
    const bill = await ctx.db.get(args.billId);
    if (!bill || bill.contractorId !== contractor._id) throw new ConvexError({ code: "FORBIDDEN", message: "Bill not found" });
    const existing = bill.attachments ?? [];
    await ctx.db.patch(args.billId, {
      attachments: [...existing, {
        storageId: args.storageId,
        fileName: args.fileName,
        fileType: args.fileType,
        fileSize: args.fileSize,
        uploadedAt: new Date().toISOString(),
      }],
    });
  },
});

// Get attachment URLs for a bill (portal, token-based)
export const getBillAttachmentUrls = query({
  args: { token: v.string(), billId: v.id("vendorBills") },
  handler: async (ctx, args): Promise<Array<{ storageId: string; url: string | null; fileName: string; fileType: string }>> => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) return [];
    const bill = await ctx.db.get(args.billId);
    if (!bill || !bill.attachments) return [];
    return Promise.all(bill.attachments.map(async (a) => ({
      storageId: a.storageId as string,
      url: await ctx.storage.getUrl(a.storageId),
      fileName: a.fileName,
      fileType: a.fileType,
    })));
  },
});

// Submit RA bill from contractor portal (token-based, no Convex auth)
export const submitRABill = mutation({
  args: {
    token: v.string(),
    purchaseOrderId: v.id("purchaseOrders"),
    billNumber: v.string(),
    billDate: v.string(),
    billType: v.union(v.literal("ra"), v.literal("final")),
    raBillItems: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      orderQty: v.number(),
      thisBillQty: v.number(),
      ratePerUnit: v.number(),
      thisBillAmount: v.number(),
    })),
    gstPercent: v.number(),
    retentionPercent: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ billId: Id<"vendorBills">; warning?: string }> => {
    const contractor = await ctx.db
      .query("contractors")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!contractor) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });

    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) throw new ConvexError({ code: "NOT_FOUND", message: "PO nahi mila" });
    if (po.contractorId !== contractor._id) throw new ConvexError({ code: "FORBIDDEN", message: "Yeh PO aapke liye nahi hai" });

    const prevBills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();

    const raNumber = prevBills.length + 1;
    const prevTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
    const subtotal = args.raBillItems.reduce((s, i) => s + i.thisBillAmount, 0);
    const gstAmount = (subtotal * args.gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;
    const retentionPercent = args.retentionPercent ?? 0;
    const retentionAmount = (totalAmount * retentionPercent) / 100;
    const balancePayable = totalAmount - retentionAmount;
    const cumulativeTotal = prevTotal + subtotal;

    let warning: string | undefined;
    if (cumulativeTotal > po.totalValue) {
      warning = `Bill PO value se ₹${(cumulativeTotal - po.totalValue).toLocaleString("en-IN")} zyada hai.`;
    }

    // Get a valid createdBy user (system or first user)
    const anyUser = await ctx.db.query("users").first();
    if (!anyUser) throw new ConvexError({ code: "NOT_FOUND", message: "No users in system" });

    const billId = await ctx.db.insert("vendorBills", {
      billNumber: args.billNumber,
      billDate: args.billDate,
      siteId: po.siteId,
      companyId: po.companyId,
      vendorType: "contractor",
      contractorId: contractor._id,
      purchaseOrderId: args.purchaseOrderId,
      billType: args.billType,
      raNumber,
      raBillItems: args.raBillItems,
      subtotal,
      gstPercent: args.gstPercent,
      gstAmount,
      totalAmount,
      retentionPercent: retentionPercent || undefined,
      retentionAmount: retentionPercent ? retentionAmount : undefined,
      balancePayable: retentionPercent ? balancePayable : undefined,
      paidAmount: 0,
      status: "received",
      description: `${args.billType === "final" ? "Final Bill" : `RA-${raNumber}`} — PO: ${po.poNumber} (Portal)`,
      notes: args.notes,
      createdBy: anyUser._id,
    });

    return { billId, warning };
  },
});
