import { v } from "convex/values";
import { query, mutation } from "../_generated/server";
import { ConvexError } from "convex/values";
import type { Id } from "../_generated/dataModel.d.ts";

// Public portal query - no auth required, uses token
export const getByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return null;
    return { supplier };
  },
});

export const getMaterialsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];

    const materials = await ctx.db
      .query("materials")
      .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
      .collect();

    const results = [];
    for (const mat of materials) {
      const site = await ctx.db.get(mat.siteId);
      results.push({ ...mat, siteName: site?.name ?? "Unknown" });
    }
    return results;
  },
});

export const getPaymentsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args): Promise<Array<{
    _id: string;
    amount: number;
    date: string;
    referenceNumber?: string;
    mode?: string;
  }>> => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];

    const payments = await ctx.db
      .query("payments")
      .withIndex("by_type", (q) => q.eq("type", "paid"))
      .collect();

    const directPayments = payments
      .filter((p) => p.supplierId === supplier._id)
      .map((p) => ({
        _id: p._id as string,
        amount: p.amount,
        date: p.date,
        referenceNumber: p.referenceNumber,
        mode: p.mode,
      }));

    // Also include payments derived from paid vendorBills
    const paidBills = await ctx.db
      .query("vendorBills")
      .collect();
    const billPayments = paidBills
      .filter((b) => b.supplierId === supplier._id && b.paidAmount > 0)
      .map((b) => ({
        _id: b._id as string,
        amount: b.paidAmount,
        date: b.billDate,
        referenceNumber: undefined,
        mode: undefined,
      }));

    return [...directPayments, ...billPayments];
  },
});

// Get POs for this supplier via portal token
export const getPOsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];

    const pos = await ctx.db
      .query("purchaseOrders")
      .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
      .collect();

    return Promise.all(pos.map(async (po) => {
      const site = await ctx.db.get(po.siteId);
      const company = await ctx.db.get(po.companyId);
      return {
        _id: po._id,
        poNumber: po.poNumber,
        siteName: site?.name ?? "—",
        companyName: company?.name ?? "—",
        siteId: po.siteId,
        companyId: po.companyId,
        totalValue: po.totalValue,
        status: po.status,
        issueDate: po.issueDate,
        items: po.items,
      };
    }));
  },
});

// Get bills submitted by this supplier
export const getBillsByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];

    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
      .order("desc")
      .take(50);

    return Promise.all(bills.map(async (b) => {
      const site = await ctx.db.get(b.siteId);
      const po = b.purchaseOrderId ? await ctx.db.get(b.purchaseOrderId) : null;
      const company = await ctx.db.get(b.companyId);
      return {
        ...b,
        siteName: site?.name ?? "—",
        poNumber: po?.poNumber,
        companyName: company?.name ?? "—",
      };
    }));
  },
});

// Get prev bills for a PO (for cumulative calc)
export const getPrevBillsByPO = query({
  args: { token: v.string(), purchaseOrderId: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];

    const bills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();
    return bills.sort((a, b) => (a.raNumber ?? 0) - (b.raNumber ?? 0));
  },
});

// Generate upload URL (token-based) — used for both bill attachments and challan uploads
export const generateUploadUrl = mutation({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });
    return await ctx.storage.generateUploadUrl();
  },
});

// Add challan / delivery document to a materials record (token-based)
export const addChallanAttachment = mutation({
  args: {
    token: v.string(),
    materialId: v.id("materials"),
    storageId: v.id("_storage"),
    fileName: v.string(),
    fileType: v.string(),
  },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });
    const mat = await ctx.db.get(args.materialId);
    if (!mat || mat.supplierId !== supplier._id)
      throw new ConvexError({ code: "FORBIDDEN", message: "Record not found" });
    const existing = mat.billFiles ?? [];
    await ctx.db.patch(args.materialId, {
      billFiles: [...existing, { storageId: args.storageId, name: args.fileName, type: args.fileType }],
    });
  },
});

// Get challan attachment URLs for a materials record (token-based)
export const getChallanAttachmentUrls = query({
  args: { token: v.string(), materialId: v.id("materials") },
  handler: async (ctx, args): Promise<Array<{ storageId: string; url: string | null; fileName: string; fileType: string }>> => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];
    const mat = await ctx.db.get(args.materialId);
    if (!mat || !mat.billFiles) return [];
    return Promise.all(mat.billFiles.map(async (f) => ({
      storageId: f.storageId as string,
      url: await ctx.storage.getUrl(f.storageId),
      fileName: f.name,
      fileType: f.type,
    })));
  },
});

// Add attachment to bill from portal (token-based)
export const addBillAttachment = mutation({
  args: {
    token: v.string(),
    billId: v.id("vendorBills"),
    storageId: v.id("_storage"),
    fileName: v.string(),
    fileType: v.string(),
    fileSize: v.number(),
  },
  handler: async (ctx, args) => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });
    const bill = await ctx.db.get(args.billId);
    if (!bill || bill.supplierId !== supplier._id) throw new ConvexError({ code: "FORBIDDEN", message: "Bill not found" });
    const existing = bill.attachments ?? [];
    await ctx.db.patch(args.billId, {
      attachments: [...existing, {
        storageId: args.storageId,
        fileName: args.fileName,
        fileType: args.fileType,
        fileSize: args.fileSize,
        uploadedAt: new Date().toISOString(),
      }],
    });
  },
});

// Get attachment URLs for a bill (portal, token-based)
export const getBillAttachmentUrls = query({
  args: { token: v.string(), billId: v.id("vendorBills") },
  handler: async (ctx, args): Promise<Array<{ storageId: string; url: string | null; fileName: string; fileType: string }>> => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) return [];
    const bill = await ctx.db.get(args.billId);
    if (!bill || !bill.attachments) return [];
    return Promise.all(bill.attachments.map(async (a) => ({
      storageId: a.storageId as string,
      url: await ctx.storage.getUrl(a.storageId),
      fileName: a.fileName,
      fileType: a.fileType,
    })));
  },
});

// Submit RA bill from supplier portal (token-based, no Convex auth)
export const submitRABill = mutation({
  args: {
    token: v.string(),
    purchaseOrderId: v.id("purchaseOrders"),
    billNumber: v.string(),
    billDate: v.string(),
    billType: v.union(v.literal("ra"), v.literal("final")),
    raBillItems: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      orderQty: v.number(),
      thisBillQty: v.number(),
      ratePerUnit: v.number(),
      thisBillAmount: v.number(),
    })),
    gstPercent: v.number(),
    retentionPercent: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ billId: Id<"vendorBills">; warning?: string }> => {
    const supplier = await ctx.db
      .query("suppliers")
      .withIndex("by_portal_token", (q) => q.eq("portalToken", args.token))
      .unique();
    if (!supplier) throw new ConvexError({ code: "FORBIDDEN", message: "Invalid portal token" });

    const po = await ctx.db.get(args.purchaseOrderId);
    if (!po) throw new ConvexError({ code: "NOT_FOUND", message: "PO nahi mila" });
    if (po.supplierId !== supplier._id) throw new ConvexError({ code: "FORBIDDEN", message: "Yeh PO aapke liye nahi hai" });

    const prevBills = await ctx.db
      .query("vendorBills")
      .withIndex("by_po", (q) => q.eq("purchaseOrderId", args.purchaseOrderId))
      .collect();

    const raNumber = prevBills.length + 1;
    const prevTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
    const subtotal = args.raBillItems.reduce((s, i) => s + i.thisBillAmount, 0);
    const gstAmount = (subtotal * args.gstPercent) / 100;
    const totalAmount = subtotal + gstAmount;
    const retentionPercent = args.retentionPercent ?? 0;
    const retentionAmount = (totalAmount * retentionPercent) / 100;
    const balancePayable = totalAmount - retentionAmount;
    const cumulativeTotal = prevTotal + subtotal;

    let warning: string | undefined;
    if (cumulativeTotal > po.totalValue) {
      warning = `Bill PO value se ₹${(cumulativeTotal - po.totalValue).toLocaleString("en-IN")} zyada hai.`;
    }

    const anyUser = await ctx.db.query("users").first();
    if (!anyUser) throw new ConvexError({ code: "NOT_FOUND", message: "No users in system" });

    const billId = await ctx.db.insert("vendorBills", {
      billNumber: args.billNumber,
      billDate: args.billDate,
      siteId: po.siteId,
      companyId: po.companyId,
      vendorType: "supplier",
      supplierId: supplier._id,
      purchaseOrderId: args.purchaseOrderId,
      billType: args.billType,
      raNumber,
      raBillItems: args.raBillItems,
      subtotal,
      gstPercent: args.gstPercent,
      gstAmount,
      totalAmount,
      retentionPercent: retentionPercent || undefined,
      retentionAmount: retentionPercent ? retentionAmount : undefined,
      balancePayable: retentionPercent ? balancePayable : undefined,
      paidAmount: 0,
      status: "received",
      description: `${args.billType === "final" ? "Final Bill" : `RA-${raNumber}`} — PO: ${po.poNumber} (Portal)`,
      notes: args.notes,
      createdBy: anyUser._id,
    });

    return { billId, warning };
  },
});
