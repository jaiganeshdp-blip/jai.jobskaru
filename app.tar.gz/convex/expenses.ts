import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./lib/auth.ts";

export type ExpenseCategory =
  | "food" | "water" | "transport" | "diesel"
  | "tools" | "safety" | "electricity" | "rent" | "miscellaneous";

const categoryValidator = v.union(
  v.literal("food"),
  v.literal("water"),
  v.literal("transport"),
  v.literal("diesel"),
  v.literal("tools"),
  v.literal("safety"),
  v.literal("electricity"),
  v.literal("rent"),
  v.literal("miscellaneous")
);

const paymentModeValidator = v.union(
  v.literal("cash"),
  v.literal("upi"),
  v.literal("other")
);

export const list = query({
  args: {
    siteId: v.optional(v.id("sites")),
    category: v.optional(v.string()),
    fromDate: v.optional(v.string()),
    toDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);

    let expenses;
    const effectiveSiteId = args.siteId ?? (user.role === "site_incharge" ? user.assignedSiteId : undefined);

    if (effectiveSiteId) {
      expenses = await ctx.db
        .query("expenses")
        .withIndex("by_site", (q) => q.eq("siteId", effectiveSiteId))
        .collect();
    } else {
      expenses = await ctx.db.query("expenses").collect();
    }

    if (args.category && args.category !== "all") {
      expenses = expenses.filter((e) => e.category === args.category);
    }
    if (args.fromDate) {
      expenses = expenses.filter((e) => e.date >= args.fromDate!);
    }
    if (args.toDate) {
      expenses = expenses.filter((e) => e.date <= args.toDate!);
    }

    const enriched = await Promise.all(
      expenses.map(async (e) => {
        const site = await ctx.db.get(e.siteId);
        const enteredBy = await ctx.db.get(e.enteredBy);
        return {
          ...e,
          siteName: site?.name ?? "Unknown",
          enteredByName: enteredBy?.name ?? "Unknown",
        };
      })
    );

    return enriched.sort((a, b) => b.date.localeCompare(a.date));
  },
});

export const summary = query({
  args: { siteId: v.id("sites") },
  handler: async (ctx, args): Promise<{
    total: number;
    byCategory: Record<string, number>;
    thisMonth: number;
    lastMonth: number;
    recentCount: number;
  }> => {
    await getCurrentUser(ctx);
    const expenses = await ctx.db
      .query("expenses")
      .withIndex("by_site", (q) => q.eq("siteId", args.siteId))
      .collect();

    const now = new Date();
    const thisMonthStr = now.toISOString().slice(0, 7);
    const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthStr = lastMonthDate.toISOString().slice(0, 7);

    const byCategory: Record<string, number> = {};
    let total = 0;
    let thisMonth = 0;
    let lastMonth = 0;

    for (const e of expenses) {
      total += e.amount;
      byCategory[e.category] = (byCategory[e.category] ?? 0) + e.amount;
      if (e.date.startsWith(thisMonthStr)) thisMonth += e.amount;
      if (e.date.startsWith(lastMonthStr)) lastMonth += e.amount;
    }

    return {
      total,
      byCategory,
      thisMonth,
      lastMonth,
      recentCount: expenses.length,
    };
  },
});

export const create = mutation({
  args: {
    siteId: v.id("sites"),
    date: v.string(),
    category: categoryValidator,
    description: v.string(),
    amount: v.number(),
    paymentMode: paymentModeValidator,
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    // Site incharge can only add to their assigned site
    if (user.role === "site_incharge" && user.assignedSiteId !== args.siteId) {
      throw new Error("You can only add expenses for your assigned site");
    }
    return await ctx.db.insert("expenses", {
      ...args,
      enteredBy: user._id,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("expenses"),
    date: v.optional(v.string()),
    category: v.optional(categoryValidator),
    description: v.optional(v.string()),
    amount: v.optional(v.number()),
    paymentMode: v.optional(paymentModeValidator),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const expense = await ctx.db.get(args.id);
    if (!expense) throw new Error("Expense not found");
    // Site incharge can only edit their own entries
    if (user.role === "site_incharge" && expense.enteredBy !== user._id) {
      throw new Error("You can only edit your own expense entries");
    }
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const remove = mutation({
  args: { id: v.id("expenses") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const expense = await ctx.db.get(args.id);
    if (!expense) throw new Error("Expense not found");
    if (user.role === "site_incharge" && expense.enteredBy !== user._id) {
      throw new Error("You can only delete your own expense entries");
    }
    await ctx.db.delete(args.id);
  },
});
