import { mutation, query } from "../_generated/server";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";
import type { Id } from "../_generated/dataModel.d.ts";

// Helper — get authenticated admin user
async function requireAdmin(ctx: MutationCtx | QueryCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Login required" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user || !["super_admin", "site_incharge"].includes(user.role)) {
    throw new ConvexError({ code: "FORBIDDEN", message: "Admins only" });
  }
  return user;
}

// List all BOQ projects (admin)
export const list = query({
  args: { companyId: v.optional(v.id("companies")), status: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    let q = ctx.db.query("boqProjects");
    if (args.companyId) {
      const results = await q.withIndex("by_company", (qi) => qi.eq("companyId", args.companyId!)).collect();
      return results;
    }
    return await q.order("desc").take(100);
  },
});

// Get single BOQ project
export const get = query({
  args: { id: v.id("boqProjects") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

// Get BOQ by public token (for vendor portal — no auth)
export const getByToken = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("boqProjects")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .unique();
  },
});

// Create a new BOQ project
export const create = mutation({
  args: {
    title: v.string(),
    siteId: v.optional(v.id("sites")),
    companyId: v.id("companies"),
    description: v.optional(v.string()),
    excelStorageId: v.string(),
    excelFileName: v.string(),
    items: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      nos: v.optional(v.number()),
      quantity: v.number(),
      rate: v.optional(v.number()),
      totalAmount: v.optional(v.number()),
    })),
    deadlineDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireAdmin(ctx);
    const token = `boq_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    return await ctx.db.insert("boqProjects", {
      ...args,
      status: "draft",
      token,
      createdBy: user._id,
    });
  },
});

// Update BOQ deadline
export const updateDeadline = mutation({
  args: {
    id: v.id("boqProjects"),
    deadlineDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.patch(args.id, { deadlineDate: args.deadlineDate });
  },
});


export const updateStatus = mutation({
  args: {
    id: v.id("boqProjects"),
    status: v.union(
      v.literal("draft"),
      v.literal("invited"),
      v.literal("comparing"),
      v.literal("finalized"),
      v.literal("ordered"),
    ),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.patch(args.id, { status: args.status });
  },
});

// Generate upload URL for BOQ Excel
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

// Get file URL for stored Excel
export const getFileUrl = query({
  args: { storageId: v.string() },
  handler: async (ctx, args): Promise<string | null> => {
    return await ctx.storage.getUrl(args.storageId as Id<"_storage">);
  },
});

// Publish comparison to vendors — they can now see L1/L2/L3 rankings
export const publishComparison = mutation({
  args: {
    id: v.id("boqProjects"),
    revisionDeadline: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.patch(args.id, {
      comparisonPublished: true,
      comparisonPublishedAt: new Date().toISOString(),
      revisionDeadline: args.revisionDeadline,
    });
  },
});

// Issue Purchase Order from a selected BOQ submission
export const issuePurchaseOrder = mutation({
  args: {
    boqId: v.id("boqProjects"),
    submissionId: v.id("boqSubmissions"),
    supplierId: v.optional(v.id("suppliers")),
    contractorId: v.optional(v.id("contractors")),
    siteId: v.id("sites"),
    companyId: v.id("companies"),
    expectedDeliveryDate: v.optional(v.string()),
    terms: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"purchaseOrders">> => {
    const user = await requireAdmin(ctx);

    const submission = await ctx.db.get(args.submissionId);
    if (!submission) throw new ConvexError({ code: "NOT_FOUND", message: "Submission nahi mili" });
    if (!args.supplierId && !args.contractorId) throw new ConvexError({ code: "BAD_REQUEST", message: "Supplier ya Contractor zaroori hai PO ke liye" });

    // Auto-generate PO number
    const existing = await ctx.db.query("purchaseOrders").order("desc").take(1);
    const lastNum = existing.length > 0
      ? parseInt(existing[0].poNumber.replace(/\D/g, "")) || 0
      : 0;
    const poNumber = `PO-${String(lastNum + 1).padStart(4, "0")}`;

    const poId = await ctx.db.insert("purchaseOrders", {
      poNumber,
      siteId: args.siteId,
      supplierId: args.supplierId,
      contractorId: args.contractorId,
      companyId: args.companyId,
      status: "sent",
      issueDate: new Date().toISOString().split("T")[0],
      expectedDeliveryDate: args.expectedDeliveryDate,
      items: submission.items.map((item) => ({
        name: item.description,
        quantity: item.quantity,
        unit: item.unit,
        ratePerUnit: item.ratePerUnit,
        totalAmount: item.totalAmount,
      })),
      totalValue: submission.totalAmount,
      terms: args.terms,
      notes: args.notes,
      createdBy: user._id,
    });

    // Mark BOQ as ordered
    await ctx.db.patch(args.boqId, { status: "ordered" });
    // Mark submission as selected
    await ctx.db.patch(args.submissionId, { status: "selected" });

    return poId;
  },
});
