import { mutation, query } from "../_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";

// List all submissions for a BOQ
export const listByBoq = query({
  args: { boqId: v.id("boqProjects") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("boqSubmissions")
      .withIndex("by_boq", (q) => q.eq("boqId", args.boqId))
      .collect();
  },
});

// Submit rates (called from vendor portal — no auth needed)
export const submit = mutation({
  args: {
    boqId: v.id("boqProjects"),
    invitationId: v.id("boqInvitations"),
    vendorName: v.string(),
    vendorMobile: v.optional(v.string()),
    items: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      totalAmount: v.number(),
      remarks: v.optional(v.string()),
    })),
    totalAmount: v.number(),
    excelStorageId: v.optional(v.string()),
    excelFileName: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const now = new Date().toISOString();

    // Mark invitation as submitted
    await ctx.db.patch(args.invitationId, {
      status: "submitted",
      submittedAt: now,
    });

    // Update BOQ status to comparing (if not already finalized/ordered)
    const boq = await ctx.db.get(args.boqId);
    if (boq && boq.status === "invited") {
      await ctx.db.patch(args.boqId, { status: "comparing" });
    }

    return await ctx.db.insert("boqSubmissions", {
      ...args,
      status: "submitted",
      submittedAt: now,
    });
  },
});

// Generate upload URL for vendor submitted Excel
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// Admin: select a submission (finalize)
export const select = mutation({
  args: { submissionId: v.id("boqSubmissions") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Login required" });

    await ctx.db.patch(args.submissionId, { status: "selected" });
    const sub = await ctx.db.get(args.submissionId);
    if (sub) {
      await ctx.db.patch(sub.invitationId, { status: "selected" });
      await ctx.db.patch(sub.boqId, { status: "finalized" });
    }
  },
});

// Admin: reject a submission
export const reject = mutation({
  args: { submissionId: v.id("boqSubmissions") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Login required" });
    await ctx.db.patch(args.submissionId, { status: "rejected" });
    const sub = await ctx.db.get(args.submissionId);
    if (sub) await ctx.db.patch(sub.invitationId, { status: "rejected" });
  },
});

// Vendor: submit revised rates (after L1/L2/L3 published)
export const revise = mutation({
  args: {
    boqId: v.id("boqProjects"),
    invitationId: v.id("boqInvitations"),
    vendorName: v.string(),
    vendorMobile: v.optional(v.string()),
    items: v.array(v.object({
      srNo: v.number(),
      description: v.string(),
      unit: v.string(),
      quantity: v.number(),
      ratePerUnit: v.number(),
      totalAmount: v.number(),
      remarks: v.optional(v.string()),
    })),
    totalAmount: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const now = new Date().toISOString();
    // Mark old submission as superseded by updating status to "submitted" (overwrite)
    const existing = await ctx.db
      .query("boqSubmissions")
      .withIndex("by_invitation", (q) => q.eq("invitationId", args.invitationId))
      .first();
    if (existing) {
      await ctx.db.patch(existing._id, {
        items: args.items,
        totalAmount: args.totalAmount,
        notes: args.notes,
        status: "submitted",
        submittedAt: now,
        vendorName: args.vendorName,
        vendorMobile: args.vendorMobile,
      });
      return existing._id;
    }
    // No existing submission — create new
    return await ctx.db.insert("boqSubmissions", {
      boqId: args.boqId,
      invitationId: args.invitationId,
      vendorName: args.vendorName,
      vendorMobile: args.vendorMobile,
      items: args.items,
      totalAmount: args.totalAmount,
      notes: args.notes,
      status: "submitted",
      submittedAt: now,
    });
  },
});
