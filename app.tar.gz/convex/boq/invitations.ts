import { mutation, query } from "../_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";

// List invitations for a BOQ
export const listByBoq = query({
  args: { boqId: v.id("boqProjects") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("boqInvitations")
      .withIndex("by_boq", (q) => q.eq("boqId", args.boqId))
      .collect();
  },
});

// Get invitation by id
export const get = query({
  args: { id: v.id("boqInvitations") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

// Get invitation by unique vendor token (for direct link portal)
export const getByVendorToken = query({
  args: { vendorToken: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("boqInvitations")
      .withIndex("by_token", (q) => q.eq("token", args.vendorToken))
      .unique();
  },
});

// Invite vendors (batch insert invitations with unique tokens)
export const invite = mutation({
  args: {
    boqId: v.id("boqProjects"),
    vendors: v.array(v.object({
      vendorType: v.union(v.literal("supplier"), v.literal("contractor")),
      supplierId: v.optional(v.id("suppliers")),
      contractorId: v.optional(v.id("contractors")),
      vendorName: v.string(),
      vendorMobile: v.optional(v.string()),
      vendorEmail: v.optional(v.string()),
    })),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Login required" });

    const now = new Date().toISOString();
    const results: Array<{ id: string; token: string }> = [];
    for (const vendor of args.vendors) {
      // Generate a unique per-vendor token
      const token = `vinv_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      const id = await ctx.db.insert("boqInvitations", {
        boqId: args.boqId,
        ...vendor,
        token,
        status: "invited",
        invitedAt: now,
      });
      results.push({ id, token });
    }
    // Update BOQ status to invited
    await ctx.db.patch(args.boqId, { status: "invited" });
    return results;
  },
});

// Mark invitation as viewed (called when vendor opens the link)
export const markViewed = mutation({
  args: { id: v.id("boqInvitations") },
  handler: async (ctx, args) => {
    const inv = await ctx.db.get(args.id);
    if (!inv) return;
    if (inv.status === "invited") {
      await ctx.db.patch(args.id, {
        status: "viewed",
        viewedAt: new Date().toISOString(),
      });
    }
  },
});
