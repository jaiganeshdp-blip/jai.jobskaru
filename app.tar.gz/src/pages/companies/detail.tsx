import { useParams, Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  ArrowLeft, Building2, MapPin, Phone, Mail, FileText,
  Users, IndianRupee, Activity,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(0)}K`;
  return `₹${n}`;
}

export default function CompanyDetail() {
  const { id } = useParams<{ id: string }>();
  const company = useQuery(api.companies.get, id ? { id: id as Id<"companies"> } : "skip");
  const sites = useQuery(api.sites.list, { companyId: id ? id as Id<"companies"> : undefined });
  const allWorkOrders = useQuery(api.workOrders.list, {});
  const allLabourers = useQuery(api.labourers.list, {});

  const isLoading = !company || !sites;

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  // Compute per-site stats
  const siteIds = new Set(sites.map((s) => s._id));
  const siteWorkOrders = (allWorkOrders ?? []).filter((wo) => siteIds.has(wo.siteId));
  const totalWOValue = siteWorkOrders.reduce((sum, wo) => sum + wo.totalValue, 0);
  const totalLabourers = (allLabourers ?? []).filter((l) => siteIds.has(l.siteId)).length;
  const activeSites = sites.filter((s) => s.status === "active").length;

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      <Link to="/companies">
        <Button variant="ghost" size="sm" className="cursor-pointer gap-1 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Companies
        </Button>
      </Link>

      {/* Header */}
      <div className="rounded-xl bg-gradient-to-br from-blue-700 to-blue-900 text-white p-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Building2 className="w-5 h-5 text-blue-200" />
              <span className="text-blue-200 text-sm">Construction Company</span>
            </div>
            <h1 className="text-3xl font-bold">{company.name}</h1>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-blue-100">
              {company.contactPerson && (
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> {company.contactPerson}
                </span>
              )}
              {company.mobile && (
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" /> {company.mobile}
                </span>
              )}
              {company.email && (
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5" /> {company.email}
                </span>
              )}
              {company.gstNumber && (
                <span className="flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5" /> GST: {company.gstNumber}
                </span>
              )}
              {company.city && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" /> {company.city}{company.state ? `, ${company.state}` : ""}
                </span>
              )}
            </div>
          </div>
          <Badge variant="secondary" className="bg-white/20 text-white border-0 self-start">
            {company.isActive ? "Active" : "Inactive"}
          </Badge>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{sites.length}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Total Sites</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-green-600">{activeSites}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Active Sites</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-orange-600">{totalLabourers}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Total Labour</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-xl font-bold text-emerald-600">{formatINR(totalWOValue)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">WO Value</p>
          </CardContent>
        </Card>
      </div>

      {/* Sites table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <MapPin className="w-4 h-4" /> Sites & Projects ({sites.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {sites.length === 0 ? (
            <div className="text-muted-foreground text-sm py-8 text-center">
              No sites assigned to this company yet
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Site Name</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">City</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Labour</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">WO Value</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sites.map((site) => {
                    const siteWOs = (allWorkOrders ?? []).filter((wo) => wo.siteId === site._id);
                    const siteWOVal = siteWOs.reduce((s, wo) => s + wo.totalValue, 0);
                    const siteLabour = (allLabourers ?? []).filter((l) => l.siteId === site._id).length;
                    return (
                      <tr key={site._id} className="hover:bg-muted/30">
                        <td className="px-4 py-3">
                          <Link to={`/sites/${site._id}`} className="font-medium text-primary hover:underline flex items-center gap-1">
                            {site.name} <span className="text-xs">↗</span>
                          </Link>
                          {site.address && <p className="text-xs text-muted-foreground truncate max-w-[200px]">{site.address}</p>}
                        </td>
                        <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{site.city}</td>
                        <td className="px-4 py-3 hidden sm:table-cell">
                          <span className="flex items-center gap-1 text-muted-foreground">
                            <Users className="w-3 h-3" /> {siteLabour}
                          </span>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <span className="flex items-center gap-1 font-medium text-emerald-600">
                            <IndianRupee className="w-3 h-3" /> {formatINR(siteWOVal)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <Badge
                            variant={site.status === "active" ? "default" : "secondary"}
                            className="capitalize"
                          >
                            {site.status.replace("_", " ")}
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Company details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="w-4 h-4" /> Company Info
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            {[
              { label: "GST Number", value: company.gstNumber },
              { label: "PAN Number", value: company.panNumber },
              { label: "City", value: company.city },
              { label: "State", value: company.state },
              { label: "Address", value: company.address },
              { label: "Email", value: company.email },
            ].map(({ label, value }) =>
              value ? (
                <div key={label}>
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="font-medium">{value}</p>
                </div>
              ) : null
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
