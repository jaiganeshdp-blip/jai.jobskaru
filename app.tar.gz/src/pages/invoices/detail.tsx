import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { toast } from "sonner";
import { ArrowLeft, Printer, Plus, CheckCircle, AlertCircle, Download } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { downloadInvoicePDF } from "@/lib/pdf-exports.ts";

const STATUS_CONFIG = {
  draft:     { label: "Draft",     color: "bg-zinc-700 text-zinc-200" },
  sent:      { label: "Sent",      color: "bg-blue-700 text-blue-100" },
  partial:   { label: "Partial",   color: "bg-amber-700 text-amber-100" },
  paid:      { label: "Paid",      color: "bg-green-700 text-green-100" },
  overdue:   { label: "Overdue",   color: "bg-red-700 text-red-100" },
  cancelled: { label: "Cancelled", color: "bg-zinc-800 text-zinc-400" },
} as const;

function formatINR(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

function RecordPaymentDialog({
  invoiceId,
  maxAmount,
  onClose,
}: {
  invoiceId: Id<"invoices">;
  maxAmount: number;
  onClose: () => void;
}) {
  const recordPayment = useMutation(api.invoices.recordPayment);
  const [amount, setAmount] = useState(String(maxAmount));
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [mode, setMode] = useState<"cash" | "cheque" | "neft" | "rtgs" | "upi" | "other">("neft");
  const [ref, setRef] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return toast.error("Enter a valid amount");
    setSaving(true);
    try {
      await recordPayment({ invoiceId, amount: amt, date, mode, referenceNumber: ref || undefined, notes: notes || undefined });
      toast.success("Payment recorded");
      onClose();
    } catch {
      toast.error("Failed to record payment");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Record Payment</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Amount (₹)</Label>
              <Input type="number" min="1" max={maxAmount} value={amount} onChange={(e) => setAmount(e.target.value)} />
              <p className="text-xs text-muted-foreground">Max: {formatINR(maxAmount)}</p>
            </div>
            <div className="space-y-1">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Payment Mode</Label>
              <Select value={mode} onValueChange={(v) => setMode(v as typeof mode)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["cash", "cheque", "neft", "rtgs", "upi", "other"].map((m) => (
                    <SelectItem key={m} value={m}>{m.toUpperCase()}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Reference / Cheque No.</Label>
              <Input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Optional" />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Notes</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving..." : "Record Payment"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function InvoiceDetailInner({ id }: { id: Id<"invoices"> }) {
  const navigate = useNavigate();
  const inv = useQuery(api.invoices.getDetail, { id });
  const updateStatus = useMutation(api.invoices.updateStatus);
  const [payOpen, setPayOpen] = useState(false);

  if (inv === undefined) {
    return (
      <div className="p-6 space-y-4">
        {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
      </div>
    );
  }
  if (!inv) return <div className="p-6 text-muted-foreground">Invoice not found.</div>;

  const cfg = STATUS_CONFIG[inv.status as keyof typeof STATUS_CONFIG];
  const outstanding = inv.totalAmount - inv.paidAmount;
  const paidPct = inv.totalAmount > 0 ? Math.min(100, (inv.paidAmount / inv.totalAmount) * 100) : 0;
  const canPay = !["paid", "cancelled"].includes(inv.status) && outstanding > 0;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate("/invoices")}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold font-mono">{inv.invoiceNumber}</h1>
            <Badge className={cfg.color}>{cfg.label}</Badge>
            {inv.workOrderNumber && (
              <span className="text-sm text-muted-foreground">WO: {inv.workOrderNumber}</span>
            )}
          </div>
          <p className="text-muted-foreground text-sm">{inv.clientName} · {inv.siteName}, {inv.siteCity}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-1" /> Print
          </Button>
          <Button variant="ghost" size="sm" onClick={() => {
            downloadInvoicePDF({
              invoiceNumber: inv.invoiceNumber,
              issueDate: inv.issueDate,
              dueDate: inv.dueDate ?? undefined,
              status: inv.status,
              clientName: inv.clientName,
              clientMobile: inv.clientMobile ?? undefined,
              clientGst: inv.clientGst ?? undefined,
              siteName: inv.siteName,
              siteCity: inv.siteCity,
              workOrderNumber: inv.workOrderNumber ?? undefined,
              items: inv.items,
              subtotal: inv.subtotal,
              taxPercent: inv.taxPercent,
              taxAmount: inv.taxAmount,
              totalAmount: inv.totalAmount,
              paidAmount: inv.paidAmount,
              notes: inv.notes ?? undefined,
            });
            toast.success("Invoice PDF downloaded");
          }}>
            <Download className="h-4 w-4 mr-1" /> PDF
          </Button>
          {inv.status === "draft" && (
            <Button size="sm" variant="ghost"
              onClick={() => updateStatus({ id, status: "sent" }).then(() => toast.success("Marked as sent"))}>
              <CheckCircle className="h-4 w-4 mr-1 text-blue-400" /> Mark Sent
            </Button>
          )}
          {!["paid", "cancelled"].includes(inv.status) && (
            <Button size="sm" variant="ghost"
              onClick={() => updateStatus({ id, status: "overdue" }).then(() => toast.success("Marked overdue"))}>
              <AlertCircle className="h-4 w-4 mr-1 text-red-400" /> Mark Overdue
            </Button>
          )}
          {canPay && (
            <Button size="sm" onClick={() => setPayOpen(true)}>
              <Plus className="h-4 w-4 mr-1" /> Record Payment
            </Button>
          )}
        </div>
      </div>

      {/* Bill-to & Dates */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground text-xs mb-1">Bill To</p>
            <p className="font-semibold">{inv.clientName}</p>
            {inv.clientMobile && <p className="text-muted-foreground">{inv.clientMobile}</p>}
            {inv.clientGst && <p className="text-muted-foreground text-xs">GST: {inv.clientGst}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground text-xs mb-1">Issue Date</p>
            <p className="font-semibold">{new Date(inv.issueDate).toLocaleDateString("en-IN")}</p>
            {inv.dueDate && (
              <>
                <p className="text-muted-foreground text-xs mt-1">Due Date</p>
                <p className="font-semibold">{new Date(inv.dueDate).toLocaleDateString("en-IN")}</p>
              </>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground text-xs mb-1">Total Amount</p>
            <p className="font-bold text-xl text-primary">{formatINR(inv.totalAmount)}</p>
            <p className="text-muted-foreground text-xs mt-1">incl. {inv.taxPercent}% GST</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground text-xs mb-1">Payment Status</p>
            <p className="font-bold text-green-400">{formatINR(inv.paidAmount)} paid</p>
            {outstanding > 0 && <p className="text-amber-400 text-xs mt-0.5">{formatINR(outstanding)} outstanding</p>}
            <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-green-500 rounded-full transition-all" style={{ width: `${paidPct}%` }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Line Items */}
      <Card>
        <CardHeader><CardTitle className="text-base">Line Items</CardTitle></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3">#</th>
                  <th className="text-left px-4 py-3">Description</th>
                  <th className="text-right px-4 py-3">Qty</th>
                  <th className="text-left px-4 py-3">Unit</th>
                  <th className="text-right px-4 py-3">Rate</th>
                  <th className="text-right px-4 py-3">Amount</th>
                </tr>
              </thead>
              <tbody>
                {inv.items.map((item, i) => (
                  <tr key={i} className="border-t border-border/50">
                    <td className="px-4 py-3 text-muted-foreground">{i + 1}</td>
                    <td className="px-4 py-3">{item.description}</td>
                    <td className="px-4 py-3 text-right">{item.quantity}</td>
                    <td className="px-4 py-3 text-muted-foreground">{item.unit}</td>
                    <td className="px-4 py-3 text-right">{formatINR(item.rate)}</td>
                    <td className="px-4 py-3 text-right font-medium">{formatINR(item.amount)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="border-t border-border bg-muted/30">
                <tr>
                  <td colSpan={5} className="px-4 py-2 text-right text-muted-foreground text-sm">Subtotal</td>
                  <td className="px-4 py-2 text-right font-medium">{formatINR(inv.subtotal)}</td>
                </tr>
                <tr>
                  <td colSpan={5} className="px-4 py-2 text-right text-muted-foreground text-sm">GST ({inv.taxPercent}%)</td>
                  <td className="px-4 py-2 text-right font-medium">{formatINR(inv.taxAmount)}</td>
                </tr>
                <tr className="border-t border-border">
                  <td colSpan={5} className="px-4 py-3 text-right font-bold">Total</td>
                  <td className="px-4 py-3 text-right font-bold text-primary text-lg">{formatINR(inv.totalAmount)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
          {inv.notes && (
            <div className="px-4 py-3 border-t text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Notes: </span>{inv.notes}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Payment History</CardTitle>
            {canPay && (
              <Button size="sm" onClick={() => setPayOpen(true)}>
                <Plus className="h-4 w-4 mr-1" /> Record Payment
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {inv.payments.length === 0 ? (
            <div className="px-4 py-8 text-center text-muted-foreground text-sm">No payments recorded yet.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3">Date</th>
                  <th className="text-right px-4 py-3">Amount</th>
                  <th className="text-left px-4 py-3">Mode</th>
                  <th className="text-left px-4 py-3">Reference</th>
                  <th className="text-left px-4 py-3">Recorded By</th>
                  <th className="text-left px-4 py-3">Notes</th>
                </tr>
              </thead>
              <tbody>
                {inv.payments.map((p) => (
                  <tr key={p._id} className="border-t border-border/50">
                    <td className="px-4 py-3">{new Date(p.date).toLocaleDateString("en-IN")}</td>
                    <td className="px-4 py-3 text-right font-semibold text-green-400">{formatINR(p.amount)}</td>
                    <td className="px-4 py-3 uppercase text-muted-foreground">{p.mode}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.referenceNumber || "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.recordedByName}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      {payOpen && (
        <RecordPaymentDialog
          invoiceId={id}
          maxAmount={outstanding}
          onClose={() => setPayOpen(false)}
        />
      )}
    </div>
  );
}

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  if (!id) return null;
  return (
    <Authenticated>
      <InvoiceDetailInner id={id as Id<"invoices">} />
    </Authenticated>
  );
}
