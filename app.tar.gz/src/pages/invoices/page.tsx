import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { toast } from "sonner";
import {
  Receipt, Plus, Eye, Trash2, TrendingUp, TrendingDown, Clock, CheckCircle, X, UserPlus,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar } from "@/components/bulk-delete-bar.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { QuickAddClientDialog, QuickAddSupplierDialog, QuickAddContractorDialog } from "./_components/quick-add-dialogs.tsx";

const STATUS_CONFIG = {
  draft:     { label: "Draft",     color: "bg-zinc-700 text-zinc-200" },
  sent:      { label: "Sent",      color: "bg-blue-700 text-blue-100" },
  partial:   { label: "Partial",   color: "bg-amber-700 text-amber-100" },
  paid:      { label: "Paid",      color: "bg-green-700 text-green-100" },
  overdue:   { label: "Overdue",   color: "bg-red-700 text-red-100" },
  cancelled: { label: "Cancelled", color: "bg-zinc-800 text-zinc-400" },
} as const;

function formatINR(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

type Item = { description: string; quantity: number; unit: string; rate: number; amount: number };

function CreateInvoiceDialog({ onClose }: { onClose: () => void }) {
  const sites = useQuery(api.sites.list, {});
  const clients = useQuery(api.clients.list, {});
  const workOrders = useQuery(api.workOrders.list, {});
  const create = useMutation(api.invoices.create);

  const [siteId, setSiteId] = useState("");
  const [clientId, setClientId] = useState("");
  const [workOrderId, setWorkOrderId] = useState("none");
  const [issueDate, setIssueDate] = useState(new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = useState("");
  const [taxPercent, setTaxPercent] = useState("18");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<Item[]>([
    { description: "", quantity: 1, unit: "nos", rate: 0, amount: 0 },
  ]);
  const [saving, setSaving] = useState(false);
  const [quickAddClient, setQuickAddClient] = useState(false);
  const [quickAddSupplier, setQuickAddSupplier] = useState(false);
  const [quickAddContractor, setQuickAddContractor] = useState(false);
  const navigate = useNavigate();

  const updateItem = (i: number, field: keyof Item, val: string) => {
    setItems((prev) => {
      const next = [...prev];
      const item = { ...next[i] };
      if (field === "description" || field === "unit") {
        (item[field] as string) = val;
      } else {
        (item[field] as number) = parseFloat(val) || 0;
      }
      item.amount = item.quantity * item.rate;
      next[i] = item;
      return next;
    });
  };

  const subtotal = items.reduce((s, i) => s + i.amount, 0);
  const tax = (subtotal * (parseFloat(taxPercent) || 0)) / 100;
  const total = subtotal + tax;

  const filteredWOs = siteId
    ? (workOrders ?? []).filter((wo) => wo.siteId === siteId)
    : (workOrders ?? []);

  const handleSubmit = async () => {
    if (!siteId || !clientId) return toast.error("Select site and client");
    if (items.some((i) => !i.description)) return toast.error("Fill all item descriptions");
    setSaving(true);
    try {
      const id = await create({
        siteId: siteId as Id<"sites">,
        clientId: clientId as Id<"clients">,
        workOrderId: workOrderId !== "none" ? (workOrderId as Id<"workOrders">) : undefined,
        issueDate,
        dueDate: dueDate || undefined,
        items,
        taxPercent: parseFloat(taxPercent) || 0,
        notes: notes || undefined,
      });
      toast.success("Invoice created");
      onClose();
      navigate(`/invoices/${id}`);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Invoice</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>Site</Label>
              <Select value={siteId} onValueChange={setSiteId}>
                <SelectTrigger><SelectValue placeholder="Select site" /></SelectTrigger>
                <SelectContent>
                  {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Client</Label>
              <div className="flex gap-1.5">
                <Select value={clientId} onValueChange={setClientId}>
                  <SelectTrigger className="flex-1"><SelectValue placeholder="Select client" /></SelectTrigger>
                  <SelectContent>
                    {(clients ?? []).map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  className="h-9 px-2 cursor-pointer shrink-0"
                  title="Naya Client Add Karein"
                  onClick={() => setQuickAddClient(true)}
                >
                  <UserPlus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              <Label>Work Order (optional)</Label>
              <Select value={workOrderId} onValueChange={setWorkOrderId}>
                <SelectTrigger><SelectValue placeholder="Link work order" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {filteredWOs.map((w) => <SelectItem key={w._id} value={w._id}>{w.orderNumber}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>GST % (Tax)</Label>
              <Input type="number" min="0" max="28" value={taxPercent} onChange={(e) => setTaxPercent(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Issue Date</Label>
              <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Due Date</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
          </div>

          {/* Quick add: Supplier & Contractor */}
          <div className="flex gap-2">
            <Button
              type="button"
              size="sm"
              variant="secondary"
              className="h-8 text-xs cursor-pointer gap-1.5"
              onClick={() => setQuickAddSupplier(true)}
            >
              <UserPlus className="h-3.5 w-3.5" /> New Supplier
            </Button>
            <Button
              type="button"
              size="sm"
              variant="secondary"
              className="h-8 text-xs cursor-pointer gap-1.5"
              onClick={() => setQuickAddContractor(true)}
            >
              <UserPlus className="h-3.5 w-3.5" /> New Contractor
            </Button>
          </div>

          {/* Line Items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Line Items</Label>
              <Button size="sm" variant="ghost" onClick={() =>
                setItems((p) => [...p, { description: "", quantity: 1, unit: "nos", rate: 0, amount: 0 }])
              }>
                <Plus className="h-4 w-4 mr-1" /> Add Row
              </Button>
            </div>
            <div className="rounded-lg border overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left px-3 py-2">Description</th>
                    <th className="text-right px-3 py-2 w-20">Qty</th>
                    <th className="text-left px-3 py-2 w-20">Unit</th>
                    <th className="text-right px-3 py-2 w-24">Rate (₹)</th>
                    <th className="text-right px-3 py-2 w-28">Amount (₹)</th>
                    <th className="w-8"></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, i) => (
                    <tr key={i} className="border-t border-border/50">
                      <td className="px-2 py-1">
                        <Input
                          value={item.description}
                          onChange={(e) => updateItem(i, "description", e.target.value)}
                          placeholder="Item description"
                          className="h-8 border-0 bg-transparent focus-visible:ring-0"
                        />
                      </td>
                      <td className="px-2 py-1">
                        <Input
                          type="number" min="0" value={item.quantity}
                          onChange={(e) => updateItem(i, "quantity", e.target.value)}
                          className="h-8 text-right border-0 bg-transparent focus-visible:ring-0"
                        />
                      </td>
                      <td className="px-2 py-1">
                        <Input
                          value={item.unit}
                          onChange={(e) => updateItem(i, "unit", e.target.value)}
                          className="h-8 border-0 bg-transparent focus-visible:ring-0"
                        />
                      </td>
                      <td className="px-2 py-1">
                        <Input
                          type="number" min="0" value={item.rate}
                          onChange={(e) => updateItem(i, "rate", e.target.value)}
                          className="h-8 text-right border-0 bg-transparent focus-visible:ring-0"
                        />
                      </td>
                      <td className="px-3 py-2 text-right font-medium">{formatINR(item.amount)}</td>
                      <td className="px-1 py-1">
                        {items.length > 1 && (
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0"
                            onClick={() => setItems((p) => p.filter((_, j) => j !== i))}>
                            <X className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex flex-col items-end gap-1 mt-2 text-sm">
              <div className="flex gap-8 text-muted-foreground">
                <span>Subtotal</span><span>{formatINR(subtotal)}</span>
              </div>
              <div className="flex gap-8 text-muted-foreground">
                <span>GST ({taxPercent}%)</span><span>{formatINR(tax)}</span>
              </div>
              <div className="flex gap-8 font-bold text-base border-t pt-1">
                <span>Total</span><span className="text-primary">{formatINR(total)}</span>
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <Label>Notes</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Payment terms, bank details, etc." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving}>{saving ? "Creating..." : "Create Invoice"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

      {/* Quick Add Dialogs - outside parent dialog to avoid nesting issues */}
      <QuickAddClientDialog
        open={quickAddClient}
        onOpenChange={setQuickAddClient}
        onCreated={(id) => setClientId(id)}
      />
      <QuickAddSupplierDialog
        open={quickAddSupplier}
        onOpenChange={setQuickAddSupplier}
      />
      <QuickAddContractorDialog
        open={quickAddContractor}
        onOpenChange={setQuickAddContractor}
      />
    </>
  );
}

function InvoicesPageInner() {
  const navigate = useNavigate();
  const invoices = useQuery(api.invoices.list, {});
  const remove = useMutation(api.invoices.remove);
  const updateStatus = useMutation(api.invoices.updateStatus);

  const [filterStatus, setFilterStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const filtered = (invoices ?? []).filter((inv) => {
    if (filterStatus !== "all" && inv.status !== filterStatus) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.clientName.toLowerCase().includes(q) ||
        inv.siteName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());
  const allFilteredSelected = filtered.length > 0 && filtered.every((inv) => selectedIds.has(inv._id));
  const toggleAll = () => {
    if (allFilteredSelected) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((inv) => next.delete(inv._id));
        return next;
      });
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((inv) => next.add(inv._id));
        return next;
      });
    }
  };
  const handleBulkDelete = async () => {
    const ids = Array.from(selectedIds);
    await Promise.all(ids.map((id) => remove({ id: id as Id<"invoices"> })));
    toast.success(`Deleted ${ids.length} invoice${ids.length !== 1 ? "s" : ""}`);
    clearSelection();
  };

  // Summary
  const total = (invoices ?? []).reduce((s, i) => s + i.totalAmount, 0);
  const totalPaid = (invoices ?? []).filter((i) => i.status === "paid").reduce((s, i) => s + i.paidAmount, 0);
  const totalPending = (invoices ?? []).filter((i) => !["paid", "cancelled"].includes(i.status)).reduce((s, i) => s + (i.totalAmount - i.paidAmount), 0);
  const overdue = (invoices ?? []).filter((i) => i.status === "overdue").length;

  if (!invoices) return (
    <div className="p-6 space-y-4">
      {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Invoices & Payments</h1>
          <p className="text-muted-foreground text-sm mt-1">Client invoices and payment tracking</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" /> New Invoice
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Invoiced", value: formatINR(total), icon: Receipt, color: "bg-blue-500/10 text-blue-400" },
          { label: "Total Collected", value: formatINR(totalPaid), icon: TrendingUp, color: "bg-green-500/10 text-green-400" },
          { label: "Outstanding", value: formatINR(totalPending), icon: Clock, color: "bg-amber-500/10 text-amber-400" },
          { label: "Overdue", value: `${overdue} invoice${overdue !== 1 ? "s" : ""}`, icon: TrendingDown, color: "bg-red-500/10 text-red-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <Card key={label}>
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${color.split(" ")[0]}`}>
                  <Icon className={`h-5 w-5 ${color.split(" ")[1]}`} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="text-lg font-bold">{value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Input
          placeholder="Search invoice, client, site..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-64"
        />
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-36">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            {Object.entries(STATUS_CONFIG).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Receipt className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No invoices found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          <BulkDeleteBar
            selectedCount={selectedIds.size}
            itemLabel="invoice"
            onDelete={handleBulkDelete}
            onClear={clearSelection}
          />
          {/* Select All row */}
          <div className="flex items-center gap-3 px-1 py-1">
            <Checkbox
              checked={allFilteredSelected}
              onCheckedChange={toggleAll}
              id="select-all-invoices"
            />
            <label htmlFor="select-all-invoices" className="text-sm text-muted-foreground cursor-pointer select-none">
              Select all ({filtered.length})
            </label>
          </div>
          {filtered.map((inv) => {
            const cfg = STATUS_CONFIG[inv.status as keyof typeof STATUS_CONFIG];
            const outstanding = inv.totalAmount - inv.paidAmount;
            const pct = inv.totalAmount > 0 ? Math.min(100, (inv.paidAmount / inv.totalAmount) * 100) : 0;
            return (
              <Card key={inv._id} className="hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => navigate(`/invoices/${inv._id}`)}>
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-4">
                      <Checkbox
                        checked={selectedIds.has(inv._id)}
                        onCheckedChange={() => toggleSelect(inv._id)}
                        onClick={(e) => e.stopPropagation()}
                        className="shrink-0"
                      />
                      <div className="p-2.5 rounded-lg bg-primary/10">
                        <Receipt className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold font-mono">{inv.invoiceNumber}</span>
                          <span className="text-muted-foreground">·</span>
                          <span className="text-sm">{inv.clientName}</span>
                          {inv.workOrderNumber && (
                            <>
                              <span className="text-muted-foreground">·</span>
                              <span className="text-xs text-muted-foreground">WO: {inv.workOrderNumber}</span>
                            </>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <span>{inv.siteName}</span>
                          <span>·</span>
                          <span>{new Date(inv.issueDate).toLocaleDateString("en-IN")}</span>
                          {inv.dueDate && (
                            <>
                              <span>·</span>
                              <span>Due: {new Date(inv.dueDate).toLocaleDateString("en-IN")}</span>
                            </>
                          )}
                        </div>
                        {/* Payment progress */}
                        {inv.paidAmount > 0 && inv.status !== "paid" && (
                          <div className="mt-2 flex items-center gap-2">
                            <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-green-500 rounded-full" style={{ width: `${pct}%` }} />
                            </div>
                            <span className="text-xs text-muted-foreground">{formatINR(inv.paidAmount)} paid</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
                      <div className="text-right">
                        <p className="font-bold text-lg">{formatINR(inv.totalAmount)}</p>
                        {outstanding > 0 && inv.status !== "cancelled" && (
                          <p className="text-xs text-amber-400">{formatINR(outstanding)} due</p>
                        )}
                      </div>
                      <Badge className={cfg.color}>{cfg.label}</Badge>
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" onClick={() => navigate(`/invoices/${inv._id}`)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        {inv.status === "draft" && (
                          <>
                            <Button size="sm" variant="ghost"
                              onClick={() => updateStatus({ id: inv._id, status: "sent" }).then(() => toast.success("Marked as sent"))}>
                              <CheckCircle className="h-4 w-4 text-blue-400" />
                            </Button>
                            <Button size="sm" variant="ghost"
                              onClick={async () => { try { await remove({ id: inv._id }); toast.success("Deleted"); } catch { toast.error("Cannot delete"); } }}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {createOpen && <CreateInvoiceDialog onClose={() => setCreateOpen(false)} />}
    </div>
  );
}

export default function InvoicesPage() {
  return (
    <Authenticated>
      <InvoicesPageInner />
    </Authenticated>
  );
}
