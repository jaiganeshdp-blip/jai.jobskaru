import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { toast } from "sonner";
import { UserPlus } from "lucide-react";

// ── Quick Add Client ─────────────────────────────────────────────────────────
export function QuickAddClientDialog({
  open, onOpenChange, onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated?: (id: string) => void;
}) {
  const createClient = useMutation(api.clients.create);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [contactPerson, setContactPerson] = useState("");

  const reset = () => {
    setName("");
    setMobile("");
    setEmail("");
    setGstNumber("");
    setAddress("");
    setCity("");
    setContactPerson("");
  };

  const handleSubmit = async () => {
    if (!name.trim()) return toast.error("Client name required");
    if (!mobile.trim()) return toast.error("Mobile number required");
    setSaving(true);
    try {
      const id = await createClient({
        name: name.trim(),
        mobile: mobile.trim(),
        email: email.trim() || undefined,
        gstNumber: gstNumber.trim() || undefined,
        address: address.trim() || undefined,
        city: city.trim() || undefined,
        contactPerson: contactPerson.trim() || undefined,
      });
      toast.success(`Client "${name}" add ho gaya!`);
      onCreated?.(id);
      reset();
      onOpenChange(false);
    } catch {
      toast.error("Client add nahi hua");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-primary" />
            Naya Client Add Karein
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1">
            <Label>Client Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Company ya person ka naam" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Mobile *</Label>
              <Input value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="9876543210" />
            </div>
            <div className="space-y-1">
              <Label>Email</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>GST Number</Label>
              <Input value={gstNumber} onChange={(e) => setGstNumber(e.target.value)} placeholder="22AAAAA0000A1Z5" />
            </div>
            <div className="space-y-1">
              <Label>Contact Person</Label>
              <Input value={contactPerson} onChange={(e) => setContactPerson(e.target.value)} placeholder="Naam" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Address</Label>
              <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Address" />
            </div>
            <div className="space-y-1">
              <Label>City</Label>
              <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving} className="cursor-pointer">
            {saving ? "Saving..." : "Add Client"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Quick Add Supplier ───────────────────────────────────────────────────────
export function QuickAddSupplierDialog({
  open, onOpenChange, onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated?: (id: string) => void;
}) {
  const createSupplier = useMutation(api.suppliers.create);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");

  const reset = () => {
    setName("");
    setMobile("");
    setEmail("");
    setGstNumber("");
    setAddress("");
    setCity("");
  };

  const handleSubmit = async () => {
    if (!name.trim()) return toast.error("Supplier name required");
    if (!mobile.trim()) return toast.error("Mobile number required");
    setSaving(true);
    try {
      const id = await createSupplier({
        name: name.trim(),
        mobile: mobile.trim(),
        email: email.trim() || undefined,
        gstNumber: gstNumber.trim() || undefined,
        address: address.trim() || undefined,
        city: city.trim() || undefined,
      });
      toast.success(`Supplier "${name}" add ho gaya!`);
      onCreated?.(id);
      reset();
      onOpenChange(false);
    } catch {
      toast.error("Supplier add nahi hua");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-primary" />
            Naya Supplier Add Karein
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1">
            <Label>Supplier Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Supplier ka naam" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Mobile *</Label>
              <Input value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="9876543210" />
            </div>
            <div className="space-y-1">
              <Label>Email</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>GST Number</Label>
              <Input value={gstNumber} onChange={(e) => setGstNumber(e.target.value)} placeholder="22AAAAA0000A1Z5" />
            </div>
            <div className="space-y-1">
              <Label>City</Label>
              <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Address</Label>
            <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Full address" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving} className="cursor-pointer">
            {saving ? "Saving..." : "Add Supplier"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Quick Add Contractor ─────────────────────────────────────────────────────
export function QuickAddContractorDialog({
  open, onOpenChange, onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated?: (id: string) => void;
}) {
  const createContractor = useMutation(api.contractors.create);
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [address, setAddress] = useState("");
  const [specialization, setSpecialization] = useState("");

  const reset = () => {
    setName("");
    setMobile("");
    setEmail("");
    setGstNumber("");
    setAddress("");
    setSpecialization("");
  };

  const handleSubmit = async () => {
    if (!name.trim()) return toast.error("Contractor name required");
    if (!mobile.trim()) return toast.error("Mobile number required");
    setSaving(true);
    try {
      const id = await createContractor({
        name: name.trim(),
        mobile: mobile.trim(),
        email: email.trim() || undefined,
        gstNumber: gstNumber.trim() || undefined,
        address: address.trim() || undefined,
        specialization: specialization.trim() || undefined,
      });
      toast.success(`Contractor "${name}" add ho gaya!`);
      onCreated?.(id);
      reset();
      onOpenChange(false);
    } catch {
      toast.error("Contractor add nahi hua");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-primary" />
            Naya Contractor Add Karein
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1">
            <Label>Contractor Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Contractor ka naam" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Mobile *</Label>
              <Input value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="9876543210" />
            </div>
            <div className="space-y-1">
              <Label>Email</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>GST Number</Label>
              <Input value={gstNumber} onChange={(e) => setGstNumber(e.target.value)} placeholder="22AAAAA0000A1Z5" />
            </div>
            <div className="space-y-1">
              <Label>Specialization</Label>
              <Input value={specialization} onChange={(e) => setSpecialization(e.target.value)} placeholder="Electrical, Plumbing..." />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Address</Label>
            <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Full address" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving} className="cursor-pointer">
            {saving ? "Saving..." : "Add Contractor"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
