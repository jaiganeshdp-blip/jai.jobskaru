import { Link, useNavigate } from "react-router-dom";
import { SignInButton } from "@/components/ui/signin.tsx";
import { motion } from "motion/react";
import { Building2, HardHat, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Authenticated, Unauthenticated, AuthLoading } from "convex/react";
import { Skeleton } from "@/components/ui/skeleton.tsx";

export default function Index() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[oklch(0.14_0.025_250)] text-white flex flex-col">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <HardHat className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">JAI SITE MANAGER ERP</span>
        </div>
        <AuthLoading>
          <Skeleton className="h-9 w-24 bg-white/10" />
        </AuthLoading>
        <Unauthenticated>
          <SignInButton />
        </Unauthenticated>
        <Authenticated>
          <Button onClick={() => navigate("/dashboard")} className="cursor-pointer">
            Go to Dashboard
          </Button>
        </Authenticated>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" as const }}
        >
          <div className="inline-flex items-center gap-2 bg-primary/20 border border-primary/30 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-6">
            <Building2 className="w-4 h-4" />
            Multi-Company Construction Management
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-balance mb-6">
            JAI SITE MANAGER ERP
          </h1>
          <p className="text-lg text-white/60 max-w-xl mx-auto mb-10 text-balance">
            Secure access portal for system administrators, company owners, site managers, supervisors, contractors, suppliers and labour.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Unauthenticated>
              <SignInButton />
            </Unauthenticated>
            <Authenticated>
              <Button size="lg" onClick={() => navigate("/dashboard")} className="cursor-pointer">
                Open Dashboard
              </Button>
            </Authenticated>
          </div>
        </motion.div>

        {/* Feature grid */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" as const }}
          className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-20 max-w-3xl w-full"
        >
          {[
            { icon: Building2, label: "Multi-Company", desc: "Manage 5-7 companies" },
            { icon: HardHat, label: "Site Incharge", desc: "Per-site control" },
            { icon: BarChart3, label: "P&L Reports", desc: "Cost vs revenue" },
          ].map((f) => (
            <div key={f.label} className="bg-white/5 border border-white/10 rounded-xl p-5 text-left">
              <f.icon className="w-6 h-6 text-primary mb-3" />
              <div className="font-semibold">{f.label}</div>
              <div className="text-sm text-white/50">{f.desc}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
