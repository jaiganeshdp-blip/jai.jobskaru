import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2, Package, AlertTriangle, Wrench, ShieldCheck, HardHat, Link, Home } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

// ---- PPE Category labels ----
const PPE_CATEGORIES = [
  { value: "helmet", label: "Helmet" },
  { value: "safety_shoes", label: "Safety Shoes (Juta)" },
  { value: "goggles", label: "Goggles" },
  { value: "gloves", label: "Gloves (Handgous)" },
  { value: "jacket", label: "Safety Jacket" },
  { value: "harness", label: "Harness" },
  { value: "mask", label: "Mask" },
  { value: "other", label: "Other" },
] as const;

const TOOL_TYPES = [
  { value: "cutter", label: "CM4 Cutter" },
  { value: "grinder", label: "Grinder" },
  { value: "drill", label: "Drill Machine" },
  { value: "cable", label: "Cable (Running Meter)" },
  { value: "welding", label: "Welding Machine" },
  { value: "pump", label: "Water Pump" },
  { value: "generator", label: "Generator" },
  { value: "other", label: "Other" },
] as const;

// ---- Schemas ----
const ppeStockSchema = z.object({
  siteId: z.string().min(1, "Site required"),
  itemName: z.string().min(1, "Item name required"),
  category: z.enum(["helmet","safety_shoes","goggles","gloves","jacket","harness","mask","other"]),
  totalQuantity: z.coerce.number().min(1),
  purchaseDate: z.string().optional(),
  costPerUnit: z.coerce.number().optional(),
  notes: z.string().optional(),
});
type PpeStockForm = z.infer<typeof ppeStockSchema>;

const distributeSchema = z.object({
  recipientType: z.enum(["labour", "contractor"]),
  labourerId: z.string().optional(),
  contractorId: z.string().optional(),
  quantity: z.coerce.number().min(1),
  distributedDate: z.string().min(1, "Date required"),
  condition: z.enum(["new", "used", "damaged"]).optional(),
  notes: z.string().optional(),
});
type DistributeForm = z.infer<typeof distributeSchema>;

const violationSchema = z.object({
  siteId: z.string().min(1, "Site required"),
  violationDate: z.string().min(1, "Date required"),
  description: z.string().min(1, "Description required"),
  recipientType: z.enum(["labour", "contractor"]),
  labourerId: z.string().optional(),
  contractorId: z.string().optional(),
  severity: z.enum(["low", "medium", "high"]),
  penaltyAmount: z.coerce.number().optional(),
  penaltyStatus: z.enum(["none", "pending", "paid"]),
  actionTaken: z.string().optional(),
});
type ViolationForm = z.infer<typeof violationSchema>;

const toolSchema = z.object({
  siteId: z.string().min(1, "Site required"),
  name: z.string().min(1, "Name required"),
  type: z.enum(["cutter","grinder","drill","cable","welding","pump","generator","other"]),
  quantity: z.coerce.number().min(1),
  unit: z.string().min(1, "Unit required"),
  condition: z.enum(["good", "repair", "damaged"]),
  purchaseDate: z.string().optional(),
  costPerUnit: z.coerce.number().optional(),
  serialNumber: z.string().optional(),
  notes: z.string().optional(),
});
type ToolForm = z.infer<typeof toolSchema>;

// ---- Helpers ----
function severityColor(s: string) {
  if (s === "high") return "bg-red-500/10 text-red-500";
  if (s === "medium") return "bg-orange-500/10 text-orange-500";
  return "bg-yellow-500/10 text-yellow-500";
}
function conditionColor(c: string) {
  if (c === "good") return "text-green-500";
  if (c === "repair") return "text-orange-500";
  return "text-red-500";
}

// =================== PPE STOCK TAB ===================
function PpeStockTab() {
  const sites = useQuery(api.sites.list, {});
  const stock = useQuery(api.safety.ppe.listStock, {});
  const distributions = useQuery(api.safety.ppe.listDistributions, {});
  const labourers = useQuery(api.labourers.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const addStock = useMutation(api.safety.ppe.addStock);
  const distribute = useMutation(api.safety.ppe.distribute);
  const removeStock = useMutation(api.safety.ppe.removeStock);
  const removeDistrib = useMutation(api.safety.ppe.removeDistribution);

  const [filterSite, setFilterSite] = useState("all");
  const [stockDialog, setStockDialog] = useState(false);
  const [distributeDialog, setDistributeDialog] = useState<string | null>(null); // ppeStockId
  const [distTab, setDistTab] = useState<"stock" | "history">("stock");

  const stockForm = useForm<PpeStockForm>({ resolver: zodResolver(ppeStockSchema), defaultValues: { totalQuantity: 1, category: "helmet" } });
  const distForm = useForm<DistributeForm>({ resolver: zodResolver(distributeSchema), defaultValues: { recipientType: "labour", quantity: 1, distributedDate: new Date().toISOString().slice(0,10) } });

  const filteredStock = (stock ?? []).filter(s => filterSite === "all" || s.siteId === filterSite);
  const siteMap = Object.fromEntries((sites ?? []).map(s => [s._id, s.name]));
  const labourMap = Object.fromEntries((labourers ?? []).map(l => [l._id, l.name]));
  const contractorMap = Object.fromEntries((contractors ?? []).map(c => [c._id, c.name]));

  async function onAddStock(data: PpeStockForm) {
    try {
      await addStock({ ...data, siteId: data.siteId as Id<"sites">, supplierId: undefined });
      toast.success("PPE stock add ho gaya");
      setStockDialog(false);
      stockForm.reset();
    } catch { toast.error("Kuch galat hua"); }
  }

  async function onDistribute(data: DistributeForm) {
    if (!distributeDialog) return;
    const stockItem = (stock ?? []).find(s => s._id === distributeDialog);
    if (!stockItem) return;
    try {
      await distribute({
        ppeStockId: distributeDialog as Id<"ppeStock">,
        siteId: stockItem.siteId,
        recipientType: data.recipientType,
        labourerId: data.labourerId ? data.labourerId as Id<"labourers"> : undefined,
        contractorId: data.contractorId ? data.contractorId as Id<"contractors"> : undefined,
        itemName: stockItem.itemName,
        quantity: data.quantity,
        distributedDate: data.distributedDate,
        condition: data.condition,
        notes: data.notes,
      });
      toast.success("Vitran ho gaya");
      setDistributeDialog(null);
      distForm.reset();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Kuch galat hua";
      toast.error(msg);
    }
  }

  const recipientType = distForm.watch("recipientType");

  return (
    <div className="space-y-4">
      {/* Summary cards */}
      {stock && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {PPE_CATEGORIES.slice(0,4).map(cat => {
            const total = (stock ?? []).filter(s => s.category === cat.value).reduce((a, b) => a + b.totalQuantity, 0);
            const avail = (stock ?? []).filter(s => s.category === cat.value).reduce((a, b) => a + b.availableQuantity, 0);
            return (
              <Card key={cat.value} className="py-3">
                <CardContent className="px-4 py-0">
                  <p className="text-xs text-muted-foreground">{cat.label}</p>
                  <p className="text-xl font-bold">{avail} <span className="text-xs text-muted-foreground">/ {total}</span></p>
                  <p className="text-xs text-muted-foreground">Available / Total</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          <Select value={filterSite} onValueChange={setFilterSite}>
            <SelectTrigger className="w-44 cursor-pointer"><SelectValue placeholder="All Sites" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sites</SelectItem>
              {sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" className={`cursor-pointer ${distTab === "stock" ? "bg-muted" : ""}`} onClick={() => setDistTab("stock")}>Stock</Button>
            <Button variant="ghost" size="sm" className={`cursor-pointer ${distTab === "history" ? "bg-muted" : ""}`} onClick={() => setDistTab("history")}>Vitran History</Button>
          </div>
        </div>
        <Button onClick={() => setStockDialog(true)} className="cursor-pointer" size="sm">
          <Plus className="w-4 h-4 mr-1" /> Add PPE Stock
        </Button>
      </div>

      {distTab === "stock" ? (
        !stock ? <Skeleton className="h-40 w-full" /> :
        filteredStock.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon"><HardHat /></EmptyMedia>
              <EmptyTitle>Koi PPE stock nahi</EmptyTitle>
              <EmptyDescription>Add PPE items jaise helmet, goggles, gloves</EmptyDescription>
            </EmptyHeader>
            <EmptyContent><Button size="sm" onClick={() => setStockDialog(true)} className="cursor-pointer">Add Stock</Button></EmptyContent>
          </Empty>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Item</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Available</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Total</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Cost/Unit</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredStock.map(item => (
                    <tr key={item._id} className="hover:bg-muted/30">
                      <td className="px-4 py-3">
                        <p className="font-medium">{item.itemName}</p>
                        <p className="text-xs text-muted-foreground capitalize">{item.category.replace("_"," ")}</p>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs hidden sm:table-cell">{siteMap[item.siteId] ?? "—"}</td>
                      <td className="px-4 py-3">
                        <span className={`font-bold text-lg ${item.availableQuantity === 0 ? "text-red-500" : item.availableQuantity < 3 ? "text-orange-500" : "text-green-500"}`}>
                          {item.availableQuantity}
                        </span>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell text-muted-foreground">{item.totalQuantity}</td>
                      <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground">{item.costPerUnit ? `₹${item.costPerUnit}` : "—"}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Button size="sm" variant="ghost" className="cursor-pointer text-orange-500 hover:text-orange-500 text-xs h-7 px-2"
                            onClick={() => { setDistributeDialog(item._id); distForm.reset({ recipientType: "labour", quantity: 1, distributedDate: new Date().toISOString().slice(0,10) }); }}>
                            Vitran
                          </Button>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                            onClick={async () => { await removeStock({ id: item._id }); toast.success("Deleted"); }}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : (
        // Distribution History
        !distributions ? <Skeleton className="h-40 w-full" /> :
        distributions.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon"><Package /></EmptyMedia>
              <EmptyTitle>Koi vitran nahi hua</EmptyTitle>
              <EmptyDescription>PPE distribution records yahan dikhenge</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Item</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Kisko Diya</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Qty</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Date</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {distributions.map(d => (
                    <tr key={d._id} className="hover:bg-muted/30">
                      <td className="px-4 py-3">
                        <p className="font-medium">{d.itemName}</p>
                        {d.condition && <p className="text-xs capitalize text-muted-foreground">{d.condition}</p>}
                      </td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-sm">
                          {d.labourerId ? (labourMap[d.labourerId] ?? "Labour") : d.contractorId ? (contractorMap[d.contractorId] ?? "Contractor") : "—"}
                        </p>
                        <p className="text-xs text-muted-foreground capitalize">{d.recipientType}</p>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell">{d.quantity}</td>
                      <td className="px-4 py-3 hidden md:table-cell text-muted-foreground text-xs">{d.distributedDate}</td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end">
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                            onClick={async () => { await removeDistrib({ id: d._id }); toast.success("Removed"); }}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      )}

      {/* Add Stock Dialog */}
      <Dialog open={stockDialog} onOpenChange={setStockDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>PPE Stock Add Karo</DialogTitle></DialogHeader>
          <Form {...stockForm}>
            <form onSubmit={stockForm.handleSubmit(onAddStock)} className="space-y-3">
              <FormField control={stockForm.control} name="siteId" render={({ field }) => (
                <FormItem>
                  <FormLabel>Site *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Site chuniye" /></SelectTrigger></FormControl>
                    <SelectContent>{sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={stockForm.control} name="category" render={({ field }) => (
                <FormItem>
                  <FormLabel>Category *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Category" /></SelectTrigger></FormControl>
                    <SelectContent>{PPE_CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={stockForm.control} name="itemName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Item Name *</FormLabel>
                  <FormControl><Input placeholder="e.g. ISI Helmet Red" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-3">
                <FormField control={stockForm.control} name="totalQuantity" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity *</FormLabel>
                    <FormControl><Input type="number" placeholder="10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={stockForm.control} name="costPerUnit" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cost/Unit (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="250" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={stockForm.control} name="purchaseDate" render={({ field }) => (
                <FormItem>
                  <FormLabel>Kharid Date</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={stockForm.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl><Input placeholder="Optional notes" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setStockDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Add Stock</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Distribute Dialog */}
      <Dialog open={!!distributeDialog} onOpenChange={() => setDistributeDialog(null)}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>PPE Vitran Karo</DialogTitle>
          </DialogHeader>
          <Form {...distForm}>
            <form onSubmit={distForm.handleSubmit(onDistribute)} className="space-y-3">
              <FormField control={distForm.control} name="recipientType" render={({ field }) => (
                <FormItem>
                  <FormLabel>Kisko Dena Hai</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="labour">Labour</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              {recipientType === "labour" ? (
                <FormField control={distForm.control} name="labourerId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labour chuniye</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Labour" /></SelectTrigger></FormControl>
                      <SelectContent>{labourers?.map(l => <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              ) : (
                <FormField control={distForm.control} name="contractorId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contractor chuniye</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Contractor" /></SelectTrigger></FormControl>
                      <SelectContent>{contractors?.map(c => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              )}
              <div className="grid grid-cols-2 gap-3">
                <FormField control={distForm.control} name="quantity" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity *</FormLabel>
                    <FormControl><Input type="number" min={1} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={distForm.control} name="distributedDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={distForm.control} name="condition" render={({ field }) => (
                <FormItem>
                  <FormLabel>Condition</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Condition" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="used">Used</SelectItem>
                      <SelectItem value="damaged">Damaged</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDistributeDialog(null)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Vitran Karo</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =================== VIOLATIONS TAB ===================
function ViolationsTab() {
  const sites = useQuery(api.sites.list, {});
  const violations = useQuery(api.safety.violations.list, {});
  const labourers = useQuery(api.labourers.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const createViolation = useMutation(api.safety.violations.create);
  const updateStatus = useMutation(api.safety.violations.updateStatus);
  const removeViolation = useMutation(api.safety.violations.remove);
  const generateUploadUrl = useMutation(api.safety.ppe.generateUploadUrl);

  const [filterSite, setFilterSite] = useState("all");
  const [dialog, setDialog] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);

  const form = useForm<ViolationForm>({
    resolver: zodResolver(violationSchema),
    defaultValues: { recipientType: "labour", severity: "medium", penaltyStatus: "none", violationDate: new Date().toISOString().slice(0,10) },
  });

  const siteMap = Object.fromEntries((sites ?? []).map(s => [s._id, s.name]));
  const labourMap = Object.fromEntries((labourers ?? []).map(l => [l._id, l.name]));
  const contractorMap = Object.fromEntries((contractors ?? []).map(c => [c._id, c.name]));

  const filtered = (violations ?? []).filter(v => filterSite === "all" || v.siteId === filterSite);
  const recipientType = form.watch("recipientType");

  async function onSubmit(data: ViolationForm) {
    try {
      const photoStorageIds: string[] = [];
      for (const file of photos) {
        const uploadUrl = await generateUploadUrl();
        const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
        const { storageId } = await res.json() as { storageId: string };
        photoStorageIds.push(storageId);
      }
      await createViolation({
        ...data,
        siteId: data.siteId as Id<"sites">,
        labourerId: data.labourerId ? data.labourerId as Id<"labourers"> : undefined,
        contractorId: data.contractorId ? data.contractorId as Id<"contractors"> : undefined,
        photoStorageIds: photoStorageIds.length > 0 ? photoStorageIds : undefined,
      });
      toast.success("Violation record ho gaya");
      setDialog(false);
      setPhotos([]);
      form.reset();
    } catch { toast.error("Kuch galat hua"); }
  }

  return (
    <div className="space-y-4">
      {violations && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Total Violations", value: violations.length, color: "text-foreground" },
            { label: "High Severity", value: violations.filter(v => v.severity === "high").length, color: "text-red-500" },
            { label: "Penalty Pending", value: violations.filter(v => v.penaltyStatus === "pending").length, color: "text-orange-500" },
          ].map(s => (
            <Card key={s.label} className="py-3">
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="flex gap-2 items-center justify-between flex-wrap">
        <Select value={filterSite} onValueChange={setFilterSite}>
          <SelectTrigger className="w-44 cursor-pointer"><SelectValue placeholder="All Sites" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={() => setDialog(true)} className="cursor-pointer" size="sm">
          <Plus className="w-4 h-4 mr-1" /> Add Violation
        </Button>
      </div>

      {!violations ? <Skeleton className="h-40 w-full" /> :
      filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><AlertTriangle /></EmptyMedia>
            <EmptyTitle>Koi violation nahi</EmptyTitle>
            <EmptyDescription>Safety violations yahan record honge</EmptyDescription>
          </EmptyHeader>
          <EmptyContent><Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer">Add Violation</Button></EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-3">
          {filtered.map(v => (
            <Card key={v._id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded font-medium capitalize ${severityColor(v.severity)}`}>{v.severity}</span>
                      <span className="text-xs text-muted-foreground">{siteMap[v.siteId] ?? "—"} · {v.violationDate}</span>
                    </div>
                    <p className="font-medium text-sm">{v.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {v.labourerId ? labourMap[v.labourerId] ?? "Labour" : v.contractorId ? contractorMap[v.contractorId] ?? "Contractor" : "—"}
                    </p>
                    {v.penaltyAmount && (
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-sm font-medium">Penalty: ₹{v.penaltyAmount.toLocaleString("en-IN")}</span>
                        <Badge variant={v.penaltyStatus === "paid" ? "default" : "secondary"} className="text-xs capitalize">
                          {v.penaltyStatus}
                        </Badge>
                        {v.penaltyStatus === "pending" && (
                          <Button size="sm" variant="ghost" className="cursor-pointer text-green-500 h-6 px-2 text-xs"
                            onClick={async () => { await updateStatus({ id: v._id, penaltyStatus: "paid" }); toast.success("Penalty paid marked"); }}>
                            Mark Paid
                          </Button>
                        )}
                      </div>
                    )}
                    {v.photoStorageIds && v.photoStorageIds.length > 0 && (
                      <p className="text-xs text-muted-foreground mt-1">{v.photoStorageIds.length} photo(s) attached</p>
                    )}
                  </div>
                  <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive flex-shrink-0"
                    onClick={async () => { await removeViolation({ id: v._id }); toast.success("Deleted"); }}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add Violation Dialog */}
      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Safety Violation Record Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Site *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Site" /></SelectTrigger></FormControl>
                      <SelectContent>{sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="violationDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="severity" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Severity</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel>Kya Hua (Description) *</FormLabel>
                  <FormControl><Input placeholder="e.g. Helmet nahi pehna tha" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="recipientType" render={({ field }) => (
                <FormItem>
                  <FormLabel>Kisne Kiya</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="labour">Labour</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              {recipientType === "labour" ? (
                <FormField control={form.control} name="labourerId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labour chuniye</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Labour" /></SelectTrigger></FormControl>
                      <SelectContent>{labourers?.map(l => <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              ) : (
                <FormField control={form.control} name="contractorId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contractor chuniye</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Contractor" /></SelectTrigger></FormControl>
                      <SelectContent>{contractors?.map(c => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              )}
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="penaltyAmount" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Penalty (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="500" {...field} /></FormControl>
                  </FormItem>
                )} />
                <FormField control={form.control} name="penaltyStatus" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">No Penalty</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="actionTaken" render={({ field }) => (
                <FormItem>
                  <FormLabel>Action Liya Gaya</FormLabel>
                  <FormControl><Input placeholder="e.g. Warning diya, kaam rokaya" {...field} /></FormControl>
                </FormItem>
              )} />
              {/* Photo Upload */}
              <div>
                <p className="text-sm font-medium mb-1">Photos (optional)</p>
                <Input type="file" accept="image/*" multiple
                  onChange={e => setPhotos(Array.from(e.target.files ?? []).slice(0, 5))}
                  className="cursor-pointer" />
                {photos.length > 0 && <p className="text-xs text-muted-foreground mt-1">{photos.length} photo(s) selected</p>}
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =================== TOOLS & MACHINES TAB ===================
function ToolsTab() {
  const sites = useQuery(api.sites.list, {});
  const tools = useQuery(api.safety.tools.list, {});
  const addTool = useMutation(api.safety.tools.add);
  const updateTool = useMutation(api.safety.tools.update);
  const removeTool = useMutation(api.safety.tools.remove);

  const [filterSite, setFilterSite] = useState("all");
  const [dialog, setDialog] = useState(false);

  const form = useForm<ToolForm>({
    resolver: zodResolver(toolSchema),
    defaultValues: { condition: "good", quantity: 1, unit: "nos" },
  });

  const siteMap = Object.fromEntries((sites ?? []).map(s => [s._id, s.name]));
  const filtered = (tools ?? []).filter(t => filterSite === "all" || t.siteId === filterSite);
  const selectedType = form.watch("type");

  async function onSubmit(data: ToolForm) {
    try {
      await addTool({ ...data, siteId: data.siteId as Id<"sites"> });
      toast.success("Tool/Machine add ho gaya");
      setDialog(false);
      form.reset({ condition: "good", quantity: 1, unit: "nos" });
    } catch { toast.error("Kuch galat hua"); }
  }

  // Cable total per site
  const cableTotal = filtered.filter(t => t.type === "cable").reduce((a, b) => a + b.quantity, 0);

  return (
    <div className="space-y-4">
      {tools && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total Items", value: filtered.length },
            { label: "Good Condition", value: filtered.filter(t => t.condition === "good").length },
            { label: "Needs Repair", value: filtered.filter(t => t.condition === "repair").length },
            { label: "Cable (meters)", value: cableTotal },
          ].map(s => (
            <Card key={s.label} className="py-3">
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-2xl font-bold">{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="flex gap-2 items-center justify-between flex-wrap">
        <Select value={filterSite} onValueChange={setFilterSite}>
          <SelectTrigger className="w-44 cursor-pointer"><SelectValue placeholder="All Sites" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={() => setDialog(true)} className="cursor-pointer" size="sm">
          <Plus className="w-4 h-4 mr-1" /> Add Tool/Machine
        </Button>
      </div>

      {!tools ? <Skeleton className="h-40 w-full" /> :
      filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Wrench /></EmptyMedia>
            <EmptyTitle>Koi tool/machine nahi</EmptyTitle>
            <EmptyDescription>CM4 Cutter, Grinder, Drill, Cable add karo</EmptyDescription>
          </EmptyHeader>
          <EmptyContent><Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer">Add Tool</Button></EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Item</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Qty / Unit</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Condition</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Cost</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(t => (
                  <tr key={t._id} className="hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <p className="font-medium">{t.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{TOOL_TYPES.find(x => x.value === t.type)?.label ?? t.type}</p>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground text-xs hidden sm:table-cell">{siteMap[t.siteId] ?? "—"}</td>
                    <td className="px-4 py-3 font-medium">{t.quantity} <span className="text-xs text-muted-foreground">{t.unit}</span></td>
                    <td className="px-4 py-3">
                      <span className={`text-sm font-medium capitalize ${conditionColor(t.condition)}`}>{t.condition}</span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-muted-foreground text-xs">{t.costPerUnit ? `₹${t.costPerUnit}` : "—"}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        {t.condition !== "damaged" && (
                          <Button size="sm" variant="ghost" className="cursor-pointer text-orange-500 h-7 px-2 text-xs"
                            onClick={async () => {
                              const next = t.condition === "good" ? "repair" : "damaged";
                              await updateTool({ id: t._id, condition: next });
                              toast.success("Condition updated");
                            }}>
                            {t.condition === "good" ? "Repair" : "Damaged"}
                          </Button>
                        )}
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                          onClick={async () => { await removeTool({ id: t._id }); toast.success("Removed"); }}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Tool Dialog */}
      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Tool / Machine Add Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField control={form.control} name="siteId" render={({ field }) => (
                <FormItem>
                  <FormLabel>Site *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Site chuniye" /></SelectTrigger></FormControl>
                    <SelectContent>{sites?.map(s => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="type" render={({ field }) => (
                <FormItem>
                  <FormLabel>Type *</FormLabel>
                  <Select onValueChange={(v) => {
                    field.onChange(v);
                    if (v === "cable") form.setValue("unit", "meter");
                    else form.setValue("unit", "nos");
                  }} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Type" /></SelectTrigger></FormControl>
                    <SelectContent>{TOOL_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Name *</FormLabel>
                  <FormControl><Input placeholder="e.g. Bosch Grinder GWS 600" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="quantity" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{selectedType === "cable" ? "Length (meters)" : "Quantity"} *</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="unit" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit *</FormLabel>
                    <FormControl><Input placeholder="nos / meter" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="condition" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Condition</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="repair">Needs Repair</SelectItem>
                        <SelectItem value="damaged">Damaged</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
                <FormField control={form.control} name="costPerUnit" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cost (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="5000" {...field} /></FormControl>
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="purchaseDate" render={({ field }) => (
                <FormItem>
                  <FormLabel>Kharid Date</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                </FormItem>
              )} />
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl><Input placeholder="Optional" {...field} /></FormControl>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Add</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =================== MAIN PAGE ===================
export default function SafetyPage() {
  const sites = useQuery(api.sites.list, {});
  const labourers = useQuery(api.labourers.list, {});
  const navigate = useNavigate();

  // Group safety supervisors by site
  const supervisors = (labourers ?? []).filter(l => l.isSafetySupervisor);
  const siteMap = Object.fromEntries((sites ?? []).map(s => [s._id, s.name]));

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-orange-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Safety Supervisor</h1>
            <p className="text-muted-foreground text-sm">PPE Stock, Violations, Tools & Machines</p>
          </div>
        </div>
        <Button variant="secondary" className="cursor-pointer" onClick={() => navigate("/dashboard")}>
          <Home className="w-4 h-4 mr-1" /> Dashboard
        </Button>
      </div>

      {/* Safety Supervisors per site */}
      {supervisors.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-orange-500" /> Safety Supervisors — Site wise
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex flex-wrap gap-2">
              {supervisors.map(s => (
                <div key={s._id} className="flex items-center gap-2 bg-orange-500/5 border border-orange-500/20 rounded-lg px-3 py-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-orange-500 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{s.name}</p>
                    <p className="text-xs text-muted-foreground">{siteMap[s.siteId] ?? "—"}{s.mobile ? ` · ${s.mobile}` : ""}</p>
                    {s.workerCode && (
                      <p className="text-xs font-bold text-orange-600 mt-0.5">Worker ID: {s.workerCode}</p>
                    )}
                  </div>
                  {s.portalToken && (
                    <button
                      title="Portal link copy karo"
                      className="cursor-pointer p-1.5 rounded hover:bg-orange-500/10 text-orange-500"
                      onClick={() => {
                        const url = `${window.location.origin}/portal/safety-supervisor?token=${s.portalToken}`;
                        void navigator.clipboard.writeText(url);
                        toast.success(`${s.name} ka portal link copy hua!`);
                      }}
                    >
                      <Link className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="ppe">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="ppe" className="cursor-pointer flex gap-1.5 items-center">
            <HardHat className="w-3.5 h-3.5" /> PPE Stock
          </TabsTrigger>
          <TabsTrigger value="violations" className="cursor-pointer flex gap-1.5 items-center">
            <AlertTriangle className="w-3.5 h-3.5" /> Violations
          </TabsTrigger>
          <TabsTrigger value="tools" className="cursor-pointer flex gap-1.5 items-center">
            <Wrench className="w-3.5 h-3.5" /> Tools & Machines
          </TabsTrigger>
        </TabsList>
        <div className="mt-4">
          <TabsContent value="ppe"><PpeStockTab /></TabsContent>
          <TabsContent value="violations"><ViolationsTab /></TabsContent>
          <TabsContent value="tools"><ToolsTab /></TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
