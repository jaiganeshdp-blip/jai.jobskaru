import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Copy, Database, ExternalLink } from "lucide-react";

type PortalLinks = {
  labourer1: string;
  labourer2: string;
  supplier1: string;
  supplier2: string;
  contractor1: string;
  contractor2: string;
};

export default function SeedData() {
  const seedMutation = useMutation(api.seed.seedTestData);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PortalLinks | null>(null);

  const handleSeed = async () => {
    setLoading(true);
    try {
      const res = await seedMutation({});
      setResult(res.portalLinks);
      toast.success("Test data seeded successfully!");
    } catch (e) {
      toast.error("Failed to seed: " + (e instanceof Error ? e.message : "Unknown error"));
    } finally {
      setLoading(false);
    }
  };

  const base = window.location.origin;

  const copyLink = (url: string) => {
    void navigator.clipboard.writeText(url);
    toast.success("Copied to clipboard!");
  };

  const portalRows: Array<{ label: string; key: keyof PortalLinks; path: string }> = [
    { label: "Labour 1 (Mohan Singh)", key: "labourer1", path: "/portal/labour" },
    { label: "Labour 2 (Ramesh Yadav)", key: "labourer2", path: "/portal/labour" },
    { label: "Supplier 1 (Steel & Iron)", key: "supplier1", path: "/portal/supplier" },
    { label: "Supplier 2 (Cement World)", key: "supplier2", path: "/portal/supplier" },
    { label: "Contractor 1 (Ram Labour)", key: "contractor1", path: "/portal/contractor" },
    { label: "Contractor 2 (Shiv Contractors)", key: "contractor2", path: "/portal/contractor" },
  ];

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Test Data Seed</h1>
        <p className="text-muted-foreground mt-1">
          Creates 2 companies, 2 sites, 2 clients, 2 suppliers, 2 contractors, 2 labourers, 2 work orders, material entries, attendance, and a salary sheet for testing.
        </p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Button onClick={() => { void handleSeed(); }} disabled={loading} className="w-full" size="lg">
            <Database size={16} className="mr-2" />
            {loading ? "Seeding data..." : "Seed Test Data"}
          </Button>
          <p className="text-xs text-muted-foreground mt-3 text-center">
            This can be run multiple times. It always creates new records.
          </p>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Portal Access Links</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {portalRows.map((row) => {
              const url = `${base}${row.path}?token=${result[row.key]}`;
              return (
                <div key={row.key} className="border rounded-lg p-3">
                  <p className="font-medium text-sm mb-1">{row.label}</p>
                  <div className="flex gap-2 items-center">
                    <code className="text-xs bg-muted px-2 py-1 rounded flex-1 truncate">{url}</code>
                    <Button size="icon" variant="ghost" onClick={() => copyLink(url)}>
                      <Copy size={14} />
                    </Button>
                    <a href={url} target="_blank" rel="noreferrer">
                      <Button size="icon" variant="ghost">
                        <ExternalLink size={14} />
                      </Button>
                    </a>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
