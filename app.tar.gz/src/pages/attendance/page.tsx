import { useState, useCallback } from "react";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { CalendarCheck, Save, Download, Users, Clock } from "lucide-react";
import { format, getDaysInMonth, startOfMonth, getDay } from "date-fns";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type AttendanceStatus = "present" | "absent" | "half_day" | "holiday";

const STATUS_OPTIONS: { value: AttendanceStatus; label: string; color: string; short: string }[] = [
  { value: "present", label: "Present", short: "P", color: "bg-green-500 text-white" },
  { value: "half_day", label: "Half Day", short: "H", color: "bg-yellow-500 text-white" },
  { value: "absent", label: "Absent", short: "A", color: "bg-red-500 text-white" },
  { value: "holiday", label: "Holiday", short: "Ho", color: "bg-blue-500 text-white" },
];

const GRID_COLORS: Record<AttendanceStatus, string> = {
  present: "bg-green-500 text-white",
  half_day: "bg-yellow-400 text-white",
  absent: "bg-red-400 text-white",
  holiday: "bg-blue-400 text-white",
};

// ─── Daily Entry Tab ────────────────────────────────────────────────────────

function DailyEntryTab({
  siteId,
  selectedDate,
  onDateChange,
}: {
  siteId: string;
  selectedDate: string;
  onDateChange: (d: string) => void;
}) {
  const today = format(new Date(), "yyyy-MM-dd");
  const labourers = useQuery(
    api.labourers.list,
    siteId && siteId !== "none" ? { siteId: siteId as Id<"sites"> } : "skip"
  );
  const attendance = useQuery(
    api.labourers.getAttendance,
    siteId && siteId !== "none"
      ? { siteId: siteId as Id<"sites">, month: selectedDate.slice(0, 7) }
      : "skip"
  );
  const bulkMarkAttendance = useMutation(api.labourers.bulkMarkAttendance);
  const [overrides, setOverrides] = useState<Record<string, AttendanceStatus>>({});
  const [overtimes, setOvertimes] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const savedMap: Record<string, AttendanceStatus> = {};
  const savedOT: Record<string, number> = {};
  const savedSource: Record<string, { source: string; name?: string }> = {};
  (attendance ?? [])
    .filter((a) => a.date === selectedDate)
    .forEach((a) => {
      savedMap[a.labourerId] = a.status as AttendanceStatus;
      if (a.overtimeHours) savedOT[a.labourerId] = a.overtimeHours;
      if (a.markedBySource) savedSource[a.labourerId] = { source: a.markedBySource, name: a.markedByName };
    });

  function getStatus(id: string): AttendanceStatus | undefined {
    return overrides[id] ?? savedMap[id];
  }

  function setStatus(id: string, s: AttendanceStatus) {
    setOverrides((p) => ({ ...p, [id]: s }));
  }

  function markAll(s: AttendanceStatus) {
    if (!labourers) return;
    const next: Record<string, AttendanceStatus> = {};
    labourers.filter((l) => l.isActive).forEach((l) => { next[l._id] = s; });
    setOverrides(next);
  }

  async function saveAttendance() {
    if (!siteId || siteId === "none" || !labourers) return;
    const entries = labourers
      .filter((l) => l.isActive)
      .flatMap((l) => {
        const status = getStatus(l._id);
        if (!status) return [];
        const ot = parseFloat(overtimes[l._id] ?? String(savedOT[l._id] ?? ""));
        return [{ labourerId: l._id as Id<"labourers">, status, overtimeHours: isNaN(ot) ? undefined : ot }];
      });

    if (entries.length === 0) { toast.error("No attendance marked"); return; }
    setSaving(true);
    try {
      await bulkMarkAttendance({ siteId: siteId as Id<"sites">, date: selectedDate, entries });
      setOverrides({});
      setOvertimes({});
      toast.success(`Saved attendance for ${entries.length} labourers`);
    } catch {
      toast.error("Failed to save attendance");
    } finally {
      setSaving(false);
    }
  }

  const active = (labourers ?? []).filter((l) => l.isActive);
  const presentCount = active.filter((l) => getStatus(l._id) === "present").length;
  const halfCount = active.filter((l) => getStatus(l._id) === "half_day").length;
  const absentCount = active.filter((l) => getStatus(l._id) === "absent").length;
  const unmarked = active.filter((l) => !getStatus(l._id)).length;

  return (
    <div className="space-y-4">
      {/* Date selector + save */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => { onDateChange(e.target.value); setOverrides({}); setOvertimes({}); }}
          max={today}
          className="border border-border rounded-md px-3 py-2 text-sm bg-background cursor-pointer"
        />
        <Button onClick={() => void saveAttendance()} disabled={saving || !siteId || siteId === "none"} className="cursor-pointer">
          <Save className="w-4 h-4 mr-1" />
          {saving ? "Saving..." : "Save Attendance"}
        </Button>
      </div>

      {!labourers ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
      ) : active.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-muted-foreground">No active labourers on this site</CardContent></Card>
      ) : (
        <>
          {/* Summary pills */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Present", value: presentCount, color: "text-green-500" },
              { label: "Half Day", value: halfCount, color: "text-yellow-500" },
              { label: "Absent", value: absentCount, color: "text-red-500" },
              { label: "Unmarked", value: unmarked, color: "text-muted-foreground" },
            ].map((s) => (
              <Card key={s.label} className="py-3">
                <CardContent className="px-4 py-0">
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Mark all buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-muted-foreground">Mark all:</span>
            {STATUS_OPTIONS.map((opt) => (
              <Button key={opt.value} size="sm" variant="secondary" className="cursor-pointer text-xs" onClick={() => markAll(opt.value)}>
                All {opt.label}
              </Button>
            ))}
          </div>

          {/* Labourer rows */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{active.length} Active Labourers — {selectedDate}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {active.map((l) => {
                  const status = getStatus(l._id);
                  const otVal = overtimes[l._id] ?? (savedOT[l._id] !== undefined ? String(savedOT[l._id]) : "");
                  return (
                    <div key={l._id} className="px-3 py-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3">
                      {/* Name row */}
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                          <span className="text-orange-500 font-bold text-sm">{l.name[0]?.toUpperCase()}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm">{l.name}</p>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <p className="text-xs text-muted-foreground">{l.designation ?? "Labour"} · ₹{l.dailyRate}/day</p>
                            {savedSource[l._id] && !overrides[l._id] && (
                              <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                                savedSource[l._id].source === "supervisor"
                                  ? "bg-green-500/15 text-green-500"
                                  : "bg-blue-500/15 text-blue-400"
                              }`}>
                                {savedSource[l._id].source === "supervisor"
                                  ? `✓ Supervisor ne bhara (${savedSource[l._id].name ?? "Supervisor"})`
                                  : `✓ Admin ne bhara`}
                              </span>
                            )}
                          </div>
                        </div>
                        {/* Status badge on mobile (right of name) */}
                        {status && (
                          <Badge className={`${STATUS_OPTIONS.find((o) => o.value === status)?.color ?? ""} text-xs sm:hidden border-0 flex-shrink-0`}>
                            {status.replace("_", " ")}
                          </Badge>
                        )}
                      </div>
                      {/* Controls row — larger tap targets on mobile */}
                      <div className="flex items-center gap-2 sm:gap-1 ml-13 sm:ml-0">
                        {/* Status buttons */}
                        <div className="flex items-center gap-1.5 sm:gap-1">
                          {STATUS_OPTIONS.map((opt) => (
                            <button
                              key={opt.value}
                              onClick={() => setStatus(l._id, opt.value)}
                              title={opt.label}
                              className={`w-11 h-11 sm:w-9 sm:h-9 rounded-lg sm:rounded-md text-xs font-bold cursor-pointer transition-all border-2 ${
                                status === opt.value
                                  ? `${opt.color} border-transparent scale-105`
                                  : "bg-muted/40 text-muted-foreground border-transparent hover:border-border"
                              }`}
                            >
                              {opt.short}
                            </button>
                          ))}
                        </div>
                        {/* Overtime input */}
                        <div className="flex items-center gap-1 ml-1">
                          <Clock className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                          <Input
                            type="number"
                            min="0"
                            max="12"
                            step="0.5"
                            placeholder="OT"
                            value={otVal}
                            onChange={(e) => setOvertimes((p) => ({ ...p, [l._id]: e.target.value }))}
                            className="h-9 sm:h-7 w-16 text-xs"
                          />
                        </div>
                        {/* Status badge desktop */}
                        {status && (
                          <Badge className={`${STATUS_OPTIONS.find((o) => o.value === status)?.color ?? ""} text-xs hidden sm:flex border-0`}>
                            {status.replace("_", " ")}
                          </Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

// ─── Monthly Grid Tab ────────────────────────────────────────────────────────

function MonthlyGridTab({ siteId, month }: { siteId: string; month: string }) {
  const labourers = useQuery(
    api.labourers.list,
    siteId && siteId !== "none" ? { siteId: siteId as Id<"sites"> } : "skip"
  );
  const attendance = useQuery(
    api.labourers.getAttendance,
    siteId && siteId !== "none" ? { siteId: siteId as Id<"sites">, month } : "skip"
  );

  const daysInMonth = getDaysInMonth(new Date(`${month}-01`));
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  // Build lookup: labourerId + date -> status
  const lookup: Record<string, Record<string, AttendanceStatus>> = {};
  (attendance ?? []).forEach((a) => {
    const day = parseInt(a.date.slice(8, 10));
    if (!lookup[a.labourerId]) lookup[a.labourerId] = {};
    lookup[a.labourerId][String(day)] = a.status as AttendanceStatus;
  });

  const active = (labourers ?? []).filter((l) => l.isActive);

  if (!labourers) return <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>;
  if (active.length === 0) return <Card><CardContent className="py-12 text-center text-muted-foreground">No active labourers</CardContent></Card>;

  return (
    <div>
      {/* Scroll hint on mobile */}
      <p className="text-xs text-muted-foreground mb-2 md:hidden flex items-center gap-1">
        <span>←</span> Swipe to see all days <span>→</span>
      </p>
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="min-w-full text-xs border-collapse">
        <thead>
          <tr className="bg-muted/50">
            <th className="sticky left-0 bg-muted/80 px-3 py-2 text-left font-semibold min-w-[140px] border-b border-border">Labourer</th>
            {days.map((d) => {
              const dateObj = new Date(`${month}-${String(d).padStart(2, "0")}`);
              const dow = getDay(dateObj);
              const isSun = dow === 0;
              return (
                <th key={d} className={`px-1 py-2 text-center font-medium border-b border-border min-w-[28px] ${isSun ? "text-red-500" : ""}`}>
                  {d}
                </th>
              );
            })}
            <th className="px-2 py-2 text-center font-semibold border-b border-border bg-muted/80">P</th>
            <th className="px-2 py-2 text-center font-semibold border-b border-border bg-muted/80">H</th>
            <th className="px-2 py-2 text-center font-semibold border-b border-border bg-muted/80">A</th>
          </tr>
        </thead>
        <tbody>
          {active.map((l) => {
            const myMap = lookup[l._id] ?? {};
            const pCount = Object.values(myMap).filter((s) => s === "present").length;
            const hCount = Object.values(myMap).filter((s) => s === "half_day").length;
            const aCount = Object.values(myMap).filter((s) => s === "absent").length;
            return (
              <tr key={l._id} className="border-b border-border hover:bg-muted/20">
                <td className="sticky left-0 bg-background px-3 py-1.5 font-medium whitespace-nowrap border-r border-border">
                  {l.name}
                </td>
                {days.map((d) => {
                  const s = myMap[String(d)];
                  return (
                    <td key={d} className="px-0.5 py-1 text-center">
                      {s ? (
                        <span className={`inline-block w-6 h-6 rounded text-[10px] font-bold leading-6 ${GRID_COLORS[s]}`}>
                          {s === "present" ? "P" : s === "half_day" ? "H" : s === "absent" ? "A" : "Ho"}
                        </span>
                      ) : (
                        <span className="inline-block w-6 h-6 text-muted-foreground/30 text-center leading-6">·</span>
                      )}
                    </td>
                  );
                })}
                <td className="px-2 py-1 text-center font-bold text-green-600">{pCount}</td>
                <td className="px-2 py-1 text-center font-bold text-yellow-600">{hCount}</td>
                <td className="px-2 py-1 text-center font-bold text-red-600">{aCount}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      </div>
      {/* Legend */}
      <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
        {STATUS_OPTIONS.map((o) => (
          <span key={o.value} className="flex items-center gap-1">
            <span className={`inline-block w-4 h-4 rounded text-[9px] font-bold leading-4 text-center ${GRID_COLORS[o.value]}`}>{o.short}</span>
            {o.label}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Monthly Summary Tab ─────────────────────────────────────────────────────

function MonthlySummaryTab({ siteId, month }: { siteId: string; month: string }) {
  const summary = useQuery(
    api.labourers.monthlySummary,
    siteId && siteId !== "none" ? { siteId: siteId as Id<"sites">, month } : "skip"
  );

  const daysInMonth = getDaysInMonth(new Date(`${month}-01`));

  const exportCSV = useCallback(() => {
    if (!summary || summary.length === 0) return;
    const headers = ["Name", "Designation", "Daily Rate", "Present", "Half Day", "Absent", "Holiday", "Effective Days", "OT Hours", "Est. Wage"];
    const rows = summary.map((r) => [
      r.name, r.designation ?? "", r.dailyRate, r.present, r.halfDay, r.absent, r.holiday,
      r.effectiveDays.toFixed(1), r.overtimeHours.toFixed(1), r.estimatedWage.toFixed(0),
    ]);
    const csv = [headers, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance-${month}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  }, [summary, month]);

  if (!summary) return <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>;
  if (summary.length === 0) return <Card><CardContent className="py-12 text-center text-muted-foreground">No data for this month</CardContent></Card>;

  const totals = summary.reduce(
    (acc, r) => ({
      present: acc.present + r.present,
      halfDay: acc.halfDay + r.halfDay,
      absent: acc.absent + r.absent,
      overtimeHours: acc.overtimeHours + r.overtimeHours,
      estimatedWage: acc.estimatedWage + r.estimatedWage,
      totalAdvance: acc.totalAdvance + (r.totalAdvance ?? 0),
    }),
    { present: 0, halfDay: 0, absent: 0, overtimeHours: 0, estimatedWage: 0, totalAdvance: 0 }
  );

  return (
    <div className="space-y-4">
      {/* Top KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Total Present Days", value: totals.present, color: "text-green-600" },
          { label: "Total Half Days", value: totals.halfDay, color: "text-yellow-600" },
          { label: "Total OT Hours", value: `${totals.overtimeHours.toFixed(1)}h`, color: "text-blue-600" },
          { label: "Est. Total Wages", value: `₹${totals.estimatedWage.toLocaleString("en-IN")}`, color: "text-purple-600" },
          { label: "Total Advance", value: `₹${totals.totalAdvance.toLocaleString("en-IN")}`, color: "text-red-500" },
        ].map((k) => (
          <Card key={k.label} className="py-3">
            <CardContent className="px-4 py-0">
              <p className="text-xs text-muted-foreground">{k.label}</p>
              <p className={`text-xl font-bold ${k.color}`}>{k.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Export button */}
      <div className="flex justify-end">
        <Button size="sm" variant="secondary" onClick={exportCSV} className="cursor-pointer">
          <Download className="w-4 h-4 mr-1" /> Export CSV
        </Button>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="px-4 py-2 text-left font-semibold">Labourer</th>
                <th className="px-3 py-2 text-center font-semibold text-green-600">P</th>
                <th className="px-3 py-2 text-center font-semibold text-yellow-600">H</th>
                <th className="px-3 py-2 text-center font-semibold text-red-600">A</th>
                <th className="px-3 py-2 text-center font-semibold">Eff. Days</th>
                <th className="px-3 py-2 text-center font-semibold text-blue-600">OT hrs</th>
                <th className="px-3 py-2 text-right font-semibold">Daily Rate</th>
                <th className="px-3 py-2 text-right font-semibold">Est. Wage</th>
                <th className="px-3 py-2 text-right font-semibold text-red-500">Advance</th>
                <th className="px-3 py-2 text-right font-semibold text-green-600">Net</th>
                <th className="px-3 py-2 text-center font-semibold text-muted-foreground">Attd %</th>
              </tr>
            </thead>
            <tbody>
              {summary.map((r) => {
                const pct = daysInMonth > 0 ? ((r.effectiveDays / daysInMonth) * 100).toFixed(0) : "0";
                return (
                  <tr key={r.labourerId} className="border-t border-border hover:bg-muted/20">
                    <td className="px-4 py-2">
                      <p className="font-medium">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.designation ?? "Labour"}</p>
                    </td>
                    <td className="px-3 py-2 text-center font-bold text-green-600">{r.present}</td>
                    <td className="px-3 py-2 text-center font-bold text-yellow-600">{r.halfDay}</td>
                    <td className="px-3 py-2 text-center font-bold text-red-600">{r.absent}</td>
                    <td className="px-3 py-2 text-center">{r.effectiveDays.toFixed(1)}</td>
                    <td className="px-3 py-2 text-center text-blue-600">{r.overtimeHours > 0 ? r.overtimeHours.toFixed(1) : "—"}</td>
                    <td className="px-3 py-2 text-right">₹{r.dailyRate}</td>
                    <td className="px-3 py-2 text-right font-semibold">₹{r.estimatedWage.toLocaleString("en-IN")}</td>
                    <td className="px-3 py-2 text-right text-red-500">{(r.totalAdvance ?? 0) > 0 ? `- ₹${(r.totalAdvance ?? 0).toLocaleString("en-IN")}` : "—"}</td>
                    <td className="px-3 py-2 text-right font-bold text-green-600">₹{(r.netEstimate ?? r.estimatedWage).toLocaleString("en-IN")}</td>
                    <td className="px-3 py-2 text-center">
                      <span className={`text-xs font-medium ${Number(pct) >= 80 ? "text-green-600" : Number(pct) >= 50 ? "text-yellow-600" : "text-red-600"}`}>
                        {pct}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function AttendancePage() {
  const sites = useQuery(api.sites.list, {});
  const [selectedSiteId, setSelectedSiteId] = useState<string>("none");
  const today = format(new Date(), "yyyy-MM-dd");
  const [selectedDate, setSelectedDate] = useState(today);
  const [activeTab, setActiveTab] = useState("daily");

  const currentMonth = selectedDate.slice(0, 7);

  return (
    <div className="p-4 md:p-6 space-y-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <CalendarCheck className="w-6 h-6 text-primary" />
            Attendance
          </h1>
          <p className="text-muted-foreground text-sm">Mark daily attendance, view monthly grid & export</p>
        </div>
      </div>

      {/* Site selector */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Select value={selectedSiteId} onValueChange={(v) => setSelectedSiteId(v)}>
          <SelectTrigger className="w-full sm:w-64 cursor-pointer">
            <SelectValue placeholder="Select a site..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">— Select a site —</SelectItem>
            {sites?.map((s) => (
              <SelectItem key={s._id} value={s._id}>{s.name} ({s.city})</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedSiteId === "none" ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground flex flex-col items-center gap-3">
            <Users className="w-12 h-12 opacity-20" />
            <p>Select a site to view attendance</p>
          </CardContent>
        </Card>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="daily" className="cursor-pointer">Daily Entry</TabsTrigger>
            <TabsTrigger value="grid" className="cursor-pointer">Monthly Grid</TabsTrigger>
            <TabsTrigger value="summary" className="cursor-pointer">Summary & Export</TabsTrigger>
          </TabsList>

          <TabsContent value="daily">
            <DailyEntryTab siteId={selectedSiteId} selectedDate={selectedDate} onDateChange={setSelectedDate} />
          </TabsContent>

          <TabsContent value="grid">
            <MonthlyGridTab siteId={selectedSiteId} month={currentMonth} />
          </TabsContent>

          <TabsContent value="summary">
            <MonthlySummaryTab siteId={selectedSiteId} month={currentMonth} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
