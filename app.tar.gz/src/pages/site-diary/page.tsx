import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { toast } from "sonner";
import { DiaryEntryDialog } from "./_components/diary-entry-dialog.tsx";
import { Card, CardContent, CardHeader } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import {
  BookOpen, Users, AlertTriangle, CheckCircle2, Clock, Eye,
  Hammer, Package, UserCheck,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const WEATHER_ICONS: Record<string, string> = {
  sunny: "☀️", cloudy: "☁️", rainy: "🌧️", stormy: "⛈️", foggy: "🌫️",
};

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-gray-500/15 text-gray-600",
  submitted: "bg-blue-500/15 text-blue-600",
  reviewed: "bg-green-500/15 text-green-600",
};

function SiteDiaryInner() {
  const sites = useQuery(api.sites.list, {});
  const currentUser = useQuery(api.users.getCurrentUserQuery, {});

  const [selectedSiteId, setSelectedSiteId] = useState<string>("none");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const review = useMutation(api.siteDiary.review);
  const remove = useMutation(api.siteDiary.remove);

  const entries = useQuery(
    api.siteDiary.list,
    selectedSiteId && selectedSiteId !== "none"
      ? { siteId: selectedSiteId as Id<"sites"> }
      : "skip"
  );

  const isAdmin = currentUser?.role === "super_admin";

  const handleReview = async (id: Id<"siteDiary">) => {
    try {
      await review({ id });
      toast.success("Entry marked as reviewed");
    } catch {
      toast.error("Failed to review entry");
    }
  };

  const handleDelete = async (id: Id<"siteDiary">) => {
    try {
      await remove({ id });
      toast.success("Entry deleted");
    } catch {
      toast.error("Failed to delete entry");
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-primary" />
            Site Diary
          </h1>
          <p className="text-sm text-muted-foreground">Daily progress log for each site</p>
        </div>
        {selectedSiteId !== "none" && (
          <DiaryEntryDialog siteId={selectedSiteId as Id<"sites">} />
        )}
      </div>

      {/* Site selector */}
      <Select value={selectedSiteId} onValueChange={setSelectedSiteId}>
        <SelectTrigger className="w-full sm:w-72 cursor-pointer">
          <SelectValue placeholder="Select a site..." />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">— Select a site —</SelectItem>
          {(sites ?? []).map((s) => (
            <SelectItem key={s._id} value={s._id}>{s.name} ({s.city})</SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Content */}
      {selectedSiteId === "none" ? (
        <Card>
          <CardContent className="py-16 flex flex-col items-center text-center text-muted-foreground gap-3">
            <BookOpen className="w-12 h-12 opacity-20" />
            <p>Select a site to view its diary</p>
          </CardContent>
        </Card>
      ) : entries === undefined ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}
        </div>
      ) : entries.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><BookOpen /></EmptyMedia>
            <EmptyTitle>No diary entries yet</EmptyTitle>
            <EmptyDescription>Start logging daily progress for this site</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <DiaryEntryDialog siteId={selectedSiteId as Id<"sites">} />
          </EmptyContent>
        </Empty>
      ) : (
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border hidden md:block" />

          <div className="space-y-4">
            {entries.map((entry) => {
              const isExpanded = expandedId === entry._id;
              return (
                <div key={entry._id} className="md:pl-12 relative">
                  {/* Timeline dot */}
                  <div className={`absolute left-2.5 top-4 w-3 h-3 rounded-full border-2 border-background hidden md:block ${
                    entry.status === "reviewed" ? "bg-green-500" :
                    entry.status === "submitted" ? "bg-blue-500" : "bg-gray-400"
                  }`} />

                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-base">{entry.date}</span>
                          {entry.weather && (
                            <span className="text-lg" title={entry.weather}>
                              {WEATHER_ICONS[entry.weather]}
                            </span>
                          )}
                          <Badge className={`${STATUS_COLORS[entry.status]} border-0 text-xs capitalize`}>
                            {entry.status}
                          </Badge>
                          {entry.manpowerCount !== undefined && (
                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Users className="w-3 h-3" /> {entry.manpowerCount} workers
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1.5 items-center">
                          <span className="text-xs text-muted-foreground mr-1">
                            By {entry.submittedByName ?? "—"}
                          </span>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 text-xs cursor-pointer"
                            onClick={() => setExpandedId(isExpanded ? null : entry._id)}
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            {isExpanded ? "Collapse" : "View"}
                          </Button>
                          <DiaryEntryDialog
                            siteId={selectedSiteId as Id<"sites">}
                            existing={entry}
                            triggerLabel="Edit"
                          />
                          {isAdmin && entry.status === "submitted" && (
                            <Button
                              size="sm"
                              className="h-8 text-xs cursor-pointer bg-green-600 hover:bg-green-700"
                              onClick={() => handleReview(entry._id)}
                            >
                              <CheckCircle2 className="w-3 h-3 mr-1" /> Review
                            </Button>
                          )}
                          {isAdmin && (
                            <Button
                              size="sm"
                              variant="destructive"
                              className="h-8 text-xs cursor-pointer"
                              onClick={() => handleDelete(entry._id)}
                            >
                              Delete
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="pt-0">
                      {/* Always visible: progress notes summary */}
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {entry.progressNotes}
                      </p>

                      {/* Expanded view */}
                      {isExpanded && (
                        <div className="mt-4 space-y-3 border-t border-border pt-4">
                          <Section icon={<Clock className="w-4 h-4 text-blue-500" />} label="Progress Notes">
                            {entry.progressNotes}
                          </Section>
                          {entry.workDone && (
                            <Section icon={<Hammer className="w-4 h-4 text-orange-500" />} label="Work Done">
                              {entry.workDone}
                            </Section>
                          )}
                          {entry.issues && (
                            <Section icon={<AlertTriangle className="w-4 h-4 text-red-500" />} label="Issues">
                              {entry.issues}
                            </Section>
                          )}
                          {entry.materialsUsed && (
                            <Section icon={<Package className="w-4 h-4 text-purple-500" />} label="Materials Used">
                              {entry.materialsUsed}
                            </Section>
                          )}
                          {entry.visitorsOnSite && (
                            <Section icon={<UserCheck className="w-4 h-4 text-teal-500" />} label="Visitors">
                              {entry.visitorsOnSite}
                            </Section>
                          )}
                          {entry.status === "reviewed" && entry.reviewedByName && (
                            <div className="rounded-md bg-green-500/10 px-3 py-2 text-sm text-green-700">
                              <CheckCircle2 className="w-4 h-4 inline mr-1" />
                              Reviewed by {entry.reviewedByName}
                              {entry.reviewNotes && <p className="mt-1 text-xs">{entry.reviewNotes}</p>}
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-2">
      <div className="mt-0.5 flex-shrink-0">{icon}</div>
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{label}</p>
        <p className="text-sm">{children as string}</p>
      </div>
    </div>
  );
}

export default function SiteDiaryPage() {
  return (
    <Authenticated>
      <SiteDiaryInner />
    </Authenticated>
  );
}
