import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Plus } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { format } from "date-fns";

const WEATHER_OPTIONS = [
  { value: "sunny", label: "☀️ Sunny" },
  { value: "cloudy", label: "☁️ Cloudy" },
  { value: "rainy", label: "🌧️ Rainy" },
  { value: "stormy", label: "⛈️ Stormy" },
  { value: "foggy", label: "🌫️ Foggy" },
];

const schema = z.object({
  date: z.string().min(1, "Date required"),
  weather: z.enum(["sunny", "cloudy", "rainy", "stormy", "foggy"]).optional(),
  manpowerCount: z.coerce.number().min(0).optional(),
  progressNotes: z.string().min(1, "Progress notes required"),
  issues: z.string().optional(),
  workDone: z.string().optional(),
  materialsUsed: z.string().optional(),
  visitorsOnSite: z.string().optional(),
  status: z.enum(["draft", "submitted"]),
});

type FormValues = z.infer<typeof schema>;

type Props = {
  siteId: Id<"sites">;
  existing?: Doc<"siteDiary">;
  onClose?: () => void;
  triggerLabel?: string;
};

export function DiaryEntryDialog({ siteId, existing, onClose, triggerLabel }: Props) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.siteDiary.create);
  const update = useMutation(api.siteDiary.update);

  const { register, handleSubmit, setValue, reset, formState: { errors, isSubmitting } } =
    useForm<FormValues>({
      resolver: zodResolver(schema),
      defaultValues: existing
        ? {
            date: existing.date,
            weather: existing.weather,
            manpowerCount: existing.manpowerCount,
            progressNotes: existing.progressNotes,
            issues: existing.issues ?? "",
            workDone: existing.workDone ?? "",
            materialsUsed: existing.materialsUsed ?? "",
            visitorsOnSite: existing.visitorsOnSite ?? "",
            status: existing.status === "reviewed" ? "submitted" : existing.status,
          }
        : {
            date: format(new Date(), "yyyy-MM-dd"),
            status: "draft",
          },
    });

  const handleClose = () => {
    setOpen(false);
    onClose?.();
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (existing) {
        await update({
          id: existing._id,
          weather: data.weather,
          manpowerCount: data.manpowerCount,
          progressNotes: data.progressNotes,
          issues: data.issues || undefined,
          workDone: data.workDone || undefined,
          materialsUsed: data.materialsUsed || undefined,
          visitorsOnSite: data.visitorsOnSite || undefined,
          status: data.status,
        });
        toast.success("Diary entry updated");
      } else {
        await create({
          siteId,
          date: data.date,
          weather: data.weather,
          manpowerCount: data.manpowerCount,
          progressNotes: data.progressNotes,
          issues: data.issues || undefined,
          workDone: data.workDone || undefined,
          materialsUsed: data.materialsUsed || undefined,
          visitorsOnSite: data.visitorsOnSite || undefined,
          status: data.status,
        });
        toast.success("Diary entry created");
      }
      reset();
      handleClose();
    } catch (err) {
      if (err instanceof Error) {
        toast.error(err.message);
      } else {
        toast.error("Failed to save diary entry");
      }
    }
  };

  const content = (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>{existing ? "Edit Diary Entry" : "New Site Diary Entry"}</DialogTitle>
      </DialogHeader>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <Label>Date *</Label>
            <Input type="date" {...register("date")} disabled={!!existing} />
            {errors.date && <p className="text-xs text-destructive">{errors.date.message}</p>}
          </div>
          <div className="space-y-1">
            <Label>Weather</Label>
            <Select defaultValue={existing?.weather} onValueChange={(v) => setValue("weather", v as "sunny" | "cloudy" | "rainy" | "stormy" | "foggy")}>
              <SelectTrigger><SelectValue placeholder="Select weather" /></SelectTrigger>
              <SelectContent>
                {WEATHER_OPTIONS.map((w) => (
                  <SelectItem key={w.value} value={w.value}>{w.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1">
          <Label>Manpower Count</Label>
          <Input type="number" min="0" {...register("manpowerCount")} placeholder="Number of workers on site" />
        </div>

        <div className="space-y-1">
          <Label>Progress Notes *</Label>
          <Textarea {...register("progressNotes")} placeholder="What was the overall progress today?" rows={3} />
          {errors.progressNotes && <p className="text-xs text-destructive">{errors.progressNotes.message}</p>}
        </div>

        <div className="space-y-1">
          <Label>Work Done</Label>
          <Textarea {...register("workDone")} placeholder="Specific tasks completed today..." rows={2} />
        </div>

        <div className="space-y-1">
          <Label>Issues / Problems</Label>
          <Textarea {...register("issues")} placeholder="Any blockers, delays, or issues encountered..." rows={2} />
        </div>

        <div className="space-y-1">
          <Label>Materials Used</Label>
          <Input {...register("materialsUsed")} placeholder="e.g. 50 bags cement, 2 tons steel..." />
        </div>

        <div className="space-y-1">
          <Label>Visitors on Site</Label>
          <Input {...register("visitorsOnSite")} placeholder="e.g. Client, Inspector..." />
        </div>

        <div className="space-y-1">
          <Label>Status</Label>
          <Select
            defaultValue={existing?.status === "reviewed" ? "submitted" : (existing?.status ?? "draft")}
            onValueChange={(v) => setValue("status", v as "draft" | "submitted")}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="draft">Save as Draft</SelectItem>
              <SelectItem value="submitted">Submit for Review</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={handleClose}>Cancel</Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : existing ? "Update Entry" : "Create Entry"}
          </Button>
        </div>
      </form>
    </DialogContent>
  );

  if (existing) {
    return (
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) onClose?.(); }}>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline" className="cursor-pointer">{triggerLabel ?? "Edit"}</Button>
        </DialogTrigger>
        {content}
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Entry
        </Button>
      </DialogTrigger>
      {content}
    </Dialog>
  );
}
