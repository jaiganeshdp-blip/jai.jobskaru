import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  CheckCircle, XCircle, Clock, User, Phone, Building2,
  ShieldCheck, HardHat, UserCheck, Briefcase, Filter, UserPlus, Truck,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";

type RequestedRole = "contractor" | "supplier" | "site_supervisor" | "safety_supervisor" | "labour" | "other";
type AssignedRole = "contractor" | "supplier" | "site_incharge" | "safety_supervisor" | "site_supervisor" | "labour" | "billing_manager" | "accounts_manager" | "viewer" | "super_admin";

const ROLE_LABELS: Record<RequestedRole, string> = {
  contractor: "Contractor",
  supplier: "Supplier",
  site_supervisor: "Site Supervisor",
  safety_supervisor: "Safety Supervisor",
  labour: "Labour",
  other: "Other / Staff",
};

const ASSIGN_ROLES: { value: AssignedRole; label: string }[] = [
  { value: "contractor", label: "Contractor" },
  { value: "supplier", label: "Supplier" },
  { value: "site_incharge", label: "Site Incharge" },
  { value: "site_supervisor", label: "Site Supervisor" },
  { value: "safety_supervisor", label: "Safety Supervisor" },
  { value: "billing_manager", label: "Billing Manager" },
  { value: "accounts_manager", label: "Accounts Manager" },
  { value: "labour", label: "Labour" },
  { value: "viewer", label: "Viewer (Read Only)" },
  { value: "super_admin", label: "Super Admin" },
];

const ROLE_ICONS: Record<RequestedRole, React.ComponentType<{ className?: string }>> = {
  contractor: Briefcase,
  supplier: Truck,
  site_supervisor: UserCheck,
  safety_supervisor: ShieldCheck,
  labour: HardHat,
  other: User,
};

const STATUS_COLORS = {
  pending: "bg-amber-100 text-amber-700 border-amber-200",
  approved: "bg-green-100 text-green-700 border-green-200",
  rejected: "bg-red-100 text-red-700 border-red-200",
};

type RegRequest = {
  _id: Id<"registrationRequests">;
  _creationTime: number;
  userId: Id<"users">;
  name: string;
  email?: string;
  mobile: string;
  requestedRole: RequestedRole;
  companyName?: string;
  siteId?: Id<"sites">;
  note?: string;
  status: "pending" | "approved" | "rejected";
  adminNote?: string;
  reviewedAt?: string;
};

// ---- Approve Dialog ----
function ApproveDialog({
  req,
  open,
  onClose,
}: {
  req: RegRequest;
  open: boolean;
  onClose: () => void;
}) {
  const approve = useMutation(api.registration.approveRequest);
  const labourers = useQuery(api.labourers.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const suppliers = useQuery(api.suppliers.list, {});
  const sites = useQuery(api.sites.list, {});

  const defaultRole: AssignedRole =
    req.requestedRole === "contractor" ? "contractor"
    : req.requestedRole === "supplier" ? "supplier"
    : req.requestedRole === "site_supervisor" ? "site_supervisor"
    : req.requestedRole === "safety_supervisor" ? "safety_supervisor"
    : req.requestedRole === "labour" ? "labour"
    : "viewer";

  const [assignedRole, setAssignedRole] = useState<AssignedRole>(defaultRole);
  const [assignedSiteId, setAssignedSiteId] = useState<string>("");
  const [contractorRef, setContractorRef] = useState<string>("new"); // "new" = auto-create
  const [supplierRef, setSupplierRef] = useState<string>("new");
  const [labourerRef, setLabourerRef] = useState<string>("new");
  const [adminNote, setAdminNote] = useState("");
  const [loading, setLoading] = useState(false);

  const isContractor = assignedRole === "contractor";
  const isSupplier = assignedRole === "supplier";
  const isLabour = assignedRole === "labour";
  const needsSite = ["site_incharge", "site_supervisor", "labour"].includes(assignedRole);

  const handleApprove = async () => {
    setLoading(true);
    try {
      await approve({
        requestId: req._id,
        assignedRole,
        assignedSiteId: assignedSiteId ? (assignedSiteId as Id<"sites">) : undefined,
        contractorRef: (isContractor && contractorRef && contractorRef !== "new" && contractorRef !== "none")
          ? (contractorRef as Id<"contractors">) : undefined,
        supplierRef: (isSupplier && supplierRef && supplierRef !== "new" && supplierRef !== "none")
          ? (supplierRef as Id<"suppliers">) : undefined,
        labourerRef: (isLabour && labourerRef && labourerRef !== "new" && labourerRef !== "none")
          ? (labourerRef as Id<"labourers">) : undefined,
        createNewRecord: isContractor ? contractorRef === "new"
          : isSupplier ? supplierRef === "new"
          : isLabour ? labourerRef === "new"
          : undefined,
        adminNote: adminNote || undefined,
      });
      toast.success(`${req.name} ko approve kar diya! ${
        isContractor && contractorRef === "new" ? "Contractor record bhi ban gaya." :
        isSupplier && supplierRef === "new" ? "Supplier record bhi ban gaya." :
        isLabour && labourerRef === "new" ? "Labour record bhi ban gaya." : ""
      }`);
      onClose();
    } catch {
      toast.error("Kuch gadbad hua, dobara try karein.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-green-700 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" /> Approve Karein: {req.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* User info summary */}
          <div className="bg-muted rounded-lg p-3 text-sm space-y-1">
            <div className="flex gap-2"><span className="text-muted-foreground w-28">Email:</span><span className="font-medium">{req.email ?? "—"}</span></div>
            <div className="flex gap-2"><span className="text-muted-foreground w-28">Mobile:</span><span className="font-medium">{req.mobile}</span></div>
            <div className="flex gap-2"><span className="text-muted-foreground w-28">Maanga role:</span><span className="font-medium">{ROLE_LABELS[req.requestedRole]}</span></div>
            {req.companyName && <div className="flex gap-2"><span className="text-muted-foreground w-28">Company:</span><span className="font-medium">{req.companyName}</span></div>}
            {req.note && <div className="flex gap-2"><span className="text-muted-foreground w-28">Note:</span><span className="font-medium">{req.note}</span></div>}
          </div>

          {/* Assign role */}
          <div className="space-y-1">
            <Label className="font-semibold">Role Assign Karein *</Label>
            <Select value={assignedRole} onValueChange={(v) => setAssignedRole(v as AssignedRole)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {ASSIGN_ROLES.map(r => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Site assignment */}
          {needsSite && (
            <div className="space-y-1">
              <Label className="font-semibold">Site Assign Karein{isLabour ? " *" : ""}</Label>
              <Select value={assignedSiteId} onValueChange={setAssignedSiteId}>
                <SelectTrigger><SelectValue placeholder="Site choose karein..." /></SelectTrigger>
                <SelectContent>
                  {(sites ?? []).map(s => (
                    <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Contractor record */}
          {isContractor && (
            <div className="space-y-2">
              <Label className="font-semibold">Contractor Record</Label>
              <div className="rounded-lg border border-border p-3 space-y-2">
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={contractorRef === "new"}
                      onChange={() => setContractorRef("new")}
                      className="accent-primary"
                    />
                    <span className="text-sm font-medium text-green-700">✓ Naya contractor record automatically banao</span>
                  </label>
                </div>
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={contractorRef !== "new"}
                      onChange={() => setContractorRef("none")}
                      className="accent-primary"
                    />
                    <span className="text-sm">Existing record se link karo</span>
                  </label>
                </div>
                {contractorRef !== "new" && (
                  <Select value={contractorRef} onValueChange={setContractorRef}>
                    <SelectTrigger><SelectValue placeholder="Contractor choose karein..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— Link mat karo —</SelectItem>
                      {(contractors ?? []).map(c => (
                        <SelectItem key={c._id} value={c._id}>{c.name}{c.mobile ? ` · ${c.mobile}` : ""}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
          )}

          {/* Supplier record */}
          {isSupplier && (
            <div className="space-y-2">
              <Label className="font-semibold">Supplier Record</Label>
              <div className="rounded-lg border border-border p-3 space-y-2">
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={supplierRef === "new"}
                      onChange={() => setSupplierRef("new")}
                      className="accent-primary"
                    />
                    <span className="text-sm font-medium text-green-700">✓ Naya supplier record automatically banao</span>
                  </label>
                </div>
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={supplierRef !== "new"}
                      onChange={() => setSupplierRef("none")}
                      className="accent-primary"
                    />
                    <span className="text-sm">Existing record se link karo</span>
                  </label>
                </div>
                {supplierRef !== "new" && (
                  <Select value={supplierRef} onValueChange={setSupplierRef}>
                    <SelectTrigger><SelectValue placeholder="Supplier choose karein..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— Link mat karo —</SelectItem>
                      {(suppliers ?? []).map(s => (
                        <SelectItem key={s._id} value={s._id}>{s.name}{s.mobile ? ` · ${s.mobile}` : ""}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
          )}

          {/* Labour record */}
          {isLabour && (
            <div className="space-y-2">
              <Label className="font-semibold">Labour Record</Label>
              <div className="rounded-lg border border-border p-3 space-y-2">
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={labourerRef === "new"}
                      onChange={() => setLabourerRef("new")}
                      className="accent-primary"
                    />
                    <span className="text-sm font-medium text-green-700">✓ Naya labour record automatically banao</span>
                  </label>
                </div>
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={labourerRef !== "new"}
                      onChange={() => setLabourerRef("none")}
                      className="accent-primary"
                    />
                    <span className="text-sm">Existing record se link karo</span>
                  </label>
                </div>
                {labourerRef !== "new" && (
                  <Select value={labourerRef} onValueChange={setLabourerRef}>
                    <SelectTrigger><SelectValue placeholder="Labour choose karein..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— Link mat karo —</SelectItem>
                      {(labourers ?? []).map(l => (
                        <SelectItem key={l._id} value={l._id}>
                          {l.name}{l.workerCode ? ` (${l.workerCode})` : ""}{l.mobile ? ` · ${l.mobile}` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
          )}

          {/* Admin note */}
          <div className="space-y-1">
            <Label>Admin Note (Optional)</Label>
            <Input
              placeholder="Koi baat likhni hai toh..."
              value={adminNote}
              onChange={e => setAdminNote(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleApprove} disabled={loading} className="cursor-pointer bg-green-600 hover:bg-green-700 gap-2">
            <CheckCircle className="w-4 h-4" />
            {loading ? "Ho raha hai..." : "Approve Karein"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Reject Dialog ----
function RejectDialog({
  req,
  open,
  onClose,
}: {
  req: RegRequest;
  open: boolean;
  onClose: () => void;
}) {
  const reject = useMutation(api.registration.rejectRequest);
  const [adminNote, setAdminNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleReject = async () => {
    setLoading(true);
    try {
      await reject({ requestId: req._id, adminNote: adminNote || undefined });
      toast.success(`${req.name} ka request reject kar diya.`);
      onClose();
    } catch {
      toast.error("Kuch gadbad hua.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-red-600 flex items-center gap-2">
            <XCircle className="w-5 h-5" /> Reject Karein: {req.name}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <p className="text-sm text-muted-foreground">Reject karne ka reason batao (optional, user ko dikhega):</p>
          <Input
            placeholder="Jaise: Aapka record hamare system mein nahi hai..."
            value={adminNote}
            onChange={e => setAdminNote(e.target.value)}
          />
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleReject} disabled={loading} variant="destructive" className="cursor-pointer gap-2">
            <XCircle className="w-4 h-4" />
            {loading ? "Ho raha hai..." : "Reject Karein"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Request Card ----
function RequestCard({ req }: { req: RegRequest }) {
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const RoleIcon = ROLE_ICONS[req.requestedRole] ?? User;

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <RoleIcon className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-foreground">{req.name}</span>
                <Badge className={`text-xs border ${STATUS_COLORS[req.status]}`}>
                  {req.status === "pending" ? "Pending" : req.status === "approved" ? "Approved" : "Rejected"}
                </Badge>
                <Badge variant="outline" className="text-xs">{ROLE_LABELS[req.requestedRole]}</Badge>
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1 text-sm text-muted-foreground">
                {req.email && <span>{req.email}</span>}
                <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{req.mobile}</span>
                {req.companyName && <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{req.companyName}</span>}
              </div>
              {req.note && <p className="text-xs text-muted-foreground mt-1 italic">"{req.note}"</p>}
              {req.adminNote && req.status !== "pending" && (
                <p className="text-xs mt-1 text-amber-700 bg-amber-50 dark:bg-amber-950 dark:text-amber-300 rounded px-2 py-0.5">Admin: {req.adminNote}</p>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {format(new Date(req._creationTime), "dd MMM yyyy, hh:mm a")}
              </p>
            </div>

            {req.status === "pending" && (
              <div className="flex gap-2 shrink-0">
                <Button
                  size="sm"
                  className="cursor-pointer bg-green-600 hover:bg-green-700 gap-1"
                  onClick={() => setApproveOpen(true)}
                >
                  <CheckCircle className="w-3.5 h-3.5" /> Approve
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  className="cursor-pointer gap-1"
                  onClick={() => setRejectOpen(true)}
                >
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </Button>
              </div>
            )}
            {req.status === "approved" && (
              <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
            )}
            {req.status === "rejected" && (
              <XCircle className="w-5 h-5 text-red-400 shrink-0" />
            )}
          </div>
        </CardContent>
      </Card>

      {approveOpen && <ApproveDialog req={req} open={approveOpen} onClose={() => setApproveOpen(false)} />}
      {rejectOpen && <RejectDialog req={req} open={rejectOpen} onClose={() => setRejectOpen(false)} />}
    </>
  );
}

// ---- Labour Registration Card (for admin approval) ----
type LabourReg = {
  _id: Id<"labourRegistrations">;
  _creationTime: number;
  name: string;
  mobile: string;
  fatherName?: string;
  aadhaarNumber?: string;
  age?: number;
  address?: string;
  designation: string;
  companyName: string;
  siteName: string;
  siteId: Id<"sites">;
  companyId: Id<"companies">;
  dailyRateExpected?: number;
  experience?: string;
  previousWork?: string;
  status: string;
  supervisorNote?: string;
  photoUrl?: string;
  aadhaarUrl?: string;
};

function LabourRegCard({ reg }: { reg: LabourReg }) {
  const adminApprove = useMutation(api.labourRegistration.adminApprove);
  const adminReject = useMutation(api.labourRegistration.adminReject);
  const contractors = useQuery(api.contractors.list, {});
  const [showApprove, setShowApprove] = useState(false);
  const [showReject, setShowReject] = useState(false);
  const [dailyRate, setDailyRate] = useState(reg.dailyRateExpected?.toString() ?? "");
  const [labourType, setLabourType] = useState<"contractor" | "departmental">("departmental");
  const [contractorId, setContractorId] = useState("");
  const [adminNote, setAdminNote] = useState("");
  const [rejectNote, setRejectNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    if (!dailyRate || isNaN(Number(dailyRate))) {
      toast.error("Daily rate daalo");
      return;
    }
    setLoading(true);
    try {
      await adminApprove({
        registrationId: reg._id,
        dailyRate: Number(dailyRate),
        labourType,
        contractorId: contractorId ? (contractorId as Id<"contractors">) : undefined,
        adminNote: adminNote || undefined,
      });
      toast.success(`${reg.name} site pe add ho gaya!`);
      setShowApprove(false);
    } catch { toast.error("Error hua, dobara try karo"); }
    setLoading(false);
  };

  const handleReject = async () => {
    setLoading(true);
    try {
      await adminReject({
        registrationId: reg._id,
        adminNote: rejectNote || undefined,
      });
      toast.success(`${reg.name} ka request reject ho gaya.`);
      setShowReject(false);
    } catch { toast.error("Error hua"); }
    setLoading(false);
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {reg.photoUrl ? (
              <img src={reg.photoUrl} alt={reg.name} className="w-12 h-12 rounded-full object-cover border shrink-0" />
            ) : (
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <HardHat className="w-5 h-5 text-primary" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-foreground">{reg.name}</span>
                <Badge className="text-xs bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800">Supervisor Approved</Badge>
                <Badge variant="secondary" className="text-xs">{reg.designation}</Badge>
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{reg.mobile}</span>
                <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{reg.companyName}</span>
                <span className="flex items-center gap-1"><HardHat className="w-3 h-3" />{reg.siteName}</span>
              </div>
              {reg.dailyRateExpected && (
                <p className="text-xs text-muted-foreground mt-0.5">Expected rate: ₹{reg.dailyRateExpected}/day</p>
              )}
              {reg.supervisorNote && (
                <p className="text-xs mt-1 bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 rounded px-2 py-0.5 inline-block">
                  Supervisor: {reg.supervisorNote}
                </p>
              )}

              {/* Expandable details */}
              <details className="mt-2">
                <summary className="text-xs text-primary cursor-pointer font-medium select-none">Details dekho</summary>
                <div className="mt-1 text-xs text-muted-foreground space-y-0.5 bg-muted rounded p-2">
                  {reg.fatherName && <p>Pita: {reg.fatherName}</p>}
                  {reg.aadhaarNumber && <p>Aadhaar: {reg.aadhaarNumber}</p>}
                  {reg.age && <p>Age: {reg.age}</p>}
                  {reg.address && <p>Address: {reg.address}</p>}
                  {reg.experience && <p>Experience: {reg.experience}</p>}
                  {reg.previousWork && <p>Previous: {reg.previousWork}</p>}
                  {reg.aadhaarUrl && <a href={reg.aadhaarUrl} target="_blank" rel="noopener noreferrer" className="text-primary underline">Aadhaar Photo</a>}
                </div>
              </details>

              <p className="text-xs text-muted-foreground mt-1">
                {format(new Date(reg._creationTime), "dd MMM yyyy, hh:mm a")}
              </p>
            </div>

            <div className="flex gap-2 shrink-0">
              <Button
                size="sm"
                className="cursor-pointer bg-green-600 hover:bg-green-700 gap-1"
                onClick={() => setShowApprove(true)}
              >
                <CheckCircle className="w-3.5 h-3.5" /> Add
              </Button>
              <Button
                size="sm"
                variant="destructive"
                className="cursor-pointer gap-1"
                onClick={() => setShowReject(true)}
              >
                <XCircle className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Approve Dialog */}
      <Dialog open={showApprove} onOpenChange={setShowApprove}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-green-700 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" /> {reg.name} Ko Site Pe Add Karo
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-muted rounded-lg p-3 text-sm">
              <p><strong>Site:</strong> {reg.siteName}</p>
              <p><strong>Kaam:</strong> {reg.designation}</p>
              <p><strong>Expected Rate:</strong> ₹{reg.dailyRateExpected ?? "—"}/day</p>
            </div>

            <div className="space-y-1">
              <Label className="font-semibold">Daily Rate (₹) *</Label>
              <Input
                type="number"
                placeholder="Jaise: 600"
                value={dailyRate}
                onChange={e => setDailyRate(e.target.value)}
              />
            </div>

            <div className="space-y-1">
              <Label className="font-semibold">Labour Type</Label>
              <Select value={labourType} onValueChange={(v) => setLabourType(v as "contractor" | "departmental")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="departmental">Departmental (Company ka)</SelectItem>
                  <SelectItem value="contractor">Contractor ka</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {labourType === "contractor" && (
              <div className="space-y-1">
                <Label className="font-semibold">Contractor</Label>
                <Select value={contractorId} onValueChange={setContractorId}>
                  <SelectTrigger><SelectValue placeholder="Contractor choose karo..." /></SelectTrigger>
                  <SelectContent>
                    {(contractors ?? []).map(c => (
                      <SelectItem key={c._id} value={c._id}>{c.name}{c.mobile ? ` • ${c.mobile}` : ""}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-1">
              <Label>Admin Note (Optional)</Label>
              <Input placeholder="Koi note..." value={adminNote} onChange={e => setAdminNote(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowApprove(false)} className="cursor-pointer">Cancel</Button>
            <Button onClick={handleApprove} disabled={loading} className="cursor-pointer bg-green-600 hover:bg-green-700 gap-2">
              <CheckCircle className="w-4 h-4" />
              {loading ? "Adding..." : "Add to Site"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showReject} onOpenChange={setShowReject}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <XCircle className="w-5 h-5" /> Reject: {reg.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-muted-foreground">Reject karne ka reason batao (optional):</p>
            <Input
              placeholder="Reason..."
              value={rejectNote}
              onChange={e => setRejectNote(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowReject(false)} className="cursor-pointer">Cancel</Button>
            <Button onClick={handleReject} disabled={loading} variant="destructive" className="cursor-pointer gap-2">
              <XCircle className="w-4 h-4" />
              {loading ? "Rejecting..." : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ---- Main Page ----
export default function UserApprovalsPage() {
  const pending = useQuery(api.registration.listRequests, { status: "pending" });
  const approved = useQuery(api.registration.listRequests, { status: "approved" });
  const rejected = useQuery(api.registration.listRequests, { status: "rejected" });
  const labourPending = useQuery(api.labourRegistration.listForAdmin, { status: "supervisor_approved" });
  const labourApproved = useQuery(api.labourRegistration.listForAdmin, { status: "admin_approved" });

  const pendingCount = pending?.length ?? 0;
  const labourPendingCount = labourPending?.length ?? 0;
  const totalPending = pendingCount + labourPendingCount;

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-primary" />
            User Approvals
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Naye users ki registration requests yahan approve ya reject karein
          </p>
        </div>
        {totalPending > 0 && (
          <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg px-4 py-2">
            <Clock className="w-4 h-4 text-amber-600" />
            <span className="text-amber-700 font-semibold">{totalPending} pending</span>
          </div>
        )}
      </div>

      <Tabs defaultValue={labourPendingCount > 0 ? "labour" : "pending"}>
        <TabsList>
          <TabsTrigger value="labour" className="cursor-pointer gap-1.5">
            <UserPlus className="w-3.5 h-3.5" />
            Naye Labour
            {labourPendingCount > 0 && (
              <span className="bg-primary text-white rounded-full text-xs px-1.5 py-0.5 ml-1 font-bold">
                {labourPendingCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="pending" className="cursor-pointer gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            Pending
            {pendingCount > 0 && (
              <span className="bg-amber-500 text-white rounded-full text-xs px-1.5 py-0.5 ml-1 font-bold">
                {pendingCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="approved" className="cursor-pointer gap-1.5">
            <CheckCircle className="w-3.5 h-3.5" />
            Approved ({(approved?.length ?? 0) + (labourApproved?.length ?? 0)})
          </TabsTrigger>
          <TabsTrigger value="rejected" className="cursor-pointer gap-1.5">
            <XCircle className="w-3.5 h-3.5" />
            Rejected ({rejected?.length ?? 0})
          </TabsTrigger>
        </TabsList>

        {/* Labour Registrations (supervisor-approved, pending admin) */}
        <TabsContent value="labour" className="mt-4">
          {!labourPending ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}</div>
          ) : labourPending.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><UserPlus /></EmptyMedia>
                <EmptyTitle>Koi naya labour registration pending nahi</EmptyTitle>
                <EmptyDescription>Jab supervisor kisi labour ko approve karega, yahan dikhega.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-3">
              {labourPending.map(reg => <LabourRegCard key={reg._id} reg={reg} />)}
            </div>
          )}
        </TabsContent>

        {/* Pending (authenticated users) */}
        <TabsContent value="pending" className="mt-4">
          {!pending ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
          ) : pending.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><Filter /></EmptyMedia>
                <EmptyTitle>Koi pending request nahi</EmptyTitle>
                <EmptyDescription>Jab naye users register karenge, yahan dikhenge.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-3">
              {pending.map(req => <RequestCard key={req._id} req={req as RegRequest} />)}
            </div>
          )}
        </TabsContent>

        {/* Approved */}
        <TabsContent value="approved" className="mt-4">
          {!approved ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
          ) : approved.length === 0 && (labourApproved?.length ?? 0) === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><CheckCircle /></EmptyMedia>
                <EmptyTitle>Koi approved user nahi abhi tak</EmptyTitle>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-3">
              {labourApproved?.map(reg => (
                <Card key={reg._id} className="border-green-200 dark:border-green-800 bg-green-50/30 dark:bg-green-950/30">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center shrink-0">
                        <HardHat className="w-5 h-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-foreground">{reg.name}</span>
                          <Badge className="text-xs bg-green-100 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800">Labour Added</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{reg.designation} • {reg.siteName} • {reg.companyName}</p>
                      </div>
                      <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
              {approved?.map(req => <RequestCard key={req._id} req={req as RegRequest} />)}
            </div>
          )}
        </TabsContent>

        {/* Rejected */}
        <TabsContent value="rejected" className="mt-4">
          {!rejected ? (
            <div className="space-y-3">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
          ) : rejected.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><XCircle /></EmptyMedia>
                <EmptyTitle>Koi rejected request nahi</EmptyTitle>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-3">
              {rejected.map(req => <RequestCard key={req._id} req={req as RegRequest} />)}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
