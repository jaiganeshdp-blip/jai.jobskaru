import { useState } from "react";
import { useQuery } from "convex/react";
import { Authenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import {
  TrendingUp, TrendingDown, IndianRupee, BarChart3, Activity,
  Building2, MapPin, Users, ArrowUpRight, Layers, Receipt,
  CheckCircle, Clock, AlertCircle, XCircle,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend,
} from "recharts";

const COLORS = ["#f97316", "#3b82f6", "#8b5cf6", "#10b981", "#f59e0b", "#14b8a6", "#ec4899", "#6b7280", "#a3e635"];
const CATEGORY_LABELS: Record<string, string> = {
  food: "Food", water: "Water", transport: "Transport", diesel: "Diesel",
  tools: "Tools", safety: "Safety", electricity: "Electricity", rent: "Rent", miscellaneous: "Misc",
};

function fmt(n: number) {
  if (n >= 10_00_000) return "₹" + (n / 10_00_000).toFixed(1) + "L";
  if (n >= 1000) return "₹" + (n / 1000).toFixed(0) + "K";
  return "₹" + n.toLocaleString("en-IN");
}

function fmtFull(n: number) {
  return "₹" + n.toLocaleString("en-IN");
}

function KpiCard({
  label, value, sub, icon: Icon, trend, color = "primary",
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ComponentType<{ className?: string }>;
  trend?: "up" | "down" | "neutral";
  color?: "primary" | "green" | "red" | "amber";
}) {
  const colorMap = {
    primary: "text-primary",
    green: "text-emerald-500",
    red: "text-red-500",
    amber: "text-amber-500",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between">
          <div className="space-y-1 min-w-0">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</p>
            <p className={cn("text-2xl font-bold", colorMap[color])}>{value}</p>
            {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className={cn("p-2 rounded-lg bg-muted", colorMap[color])}>
              <Icon className="w-4 h-4" />
            </div>
            {trend === "up" && <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />}
            {trend === "down" && <TrendingDown className="w-3.5 h-3.5 text-red-500" />}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

type TabId = "overview" | "trends" | "sites" | "companies" | "bills";

function AnalyticsInner() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [trendMonths, setTrendMonths] = useState<6 | 12>(12);
  const [billVendorType, setBillVendorType] = useState<"all" | "contractor" | "supplier">("all");
  const [billStatus, setBillStatus] = useState<"all" | "received" | "approved" | "paid" | "rejected">("all");

  const pnl = useQuery(api.analytics.companyPnL, {});
  const trends = useQuery(api.analytics.monthlyTrends, { months: trendMonths });
  const expCat = useQuery(api.analytics.expenseCategoryBreakdown, {});
  const companyKPIs = useQuery(api.analytics.companyKPIs, {});
  const allBills = useQuery(api.vendorBills.list, {});

  const loading = !pnl || !trends || !expCat || !companyKPIs;

  const tabs: { id: TabId; label: string }[] = [
    { id: "overview", label: "Overview" },
    { id: "trends", label: "Monthly Trends" },
    { id: "sites", label: "Site Comparison" },
    { id: "companies", label: "Companies" },
    { id: "bills", label: "All Bills" },
  ];

  const pieData = Object.entries(expCat?.byCategory ?? {})
    .filter(([, v]) => v > 0)
    .map(([key, val], i) => ({
      name: CATEGORY_LABELS[key] ?? key,
      value: val,
      color: COLORS[i % COLORS.length],
    }));

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Analytics & Dashboards</h1>
            <p className="text-muted-foreground text-sm">Company-wide P&L, site performance & financial trends</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "px-4 py-2 text-sm font-medium border-b-2 transition-colors cursor-pointer -mb-px",
              activeTab === tab.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
      ) : (
        <>
          {/* OVERVIEW TAB */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              {/* KPI Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <KpiCard
                  label="Total WO Value"
                  value={fmt(pnl.totals.woValue)}
                  sub={fmtFull(pnl.totals.woValue)}
                  icon={IndianRupee}
                  color="primary"
                />
                <KpiCard
                  label="Gross Profit"
                  value={fmt(pnl.totals.grossProfit)}
                  sub={`Margin ${pnl.totals.margin}%`}
                  icon={TrendingUp}
                  color={pnl.totals.grossProfit >= 0 ? "green" : "red"}
                  trend={pnl.totals.grossProfit >= 0 ? "up" : "down"}
                />
                <KpiCard
                  label="Total Received"
                  value={fmt(pnl.totals.received)}
                  sub={`Outstanding: ${fmt(pnl.totals.outstanding)}`}
                  icon={BarChart3}
                  color="amber"
                />
                <KpiCard
                  label="Total Costs"
                  value={fmt(pnl.totals.cost)}
                  sub="Bills + Expenses + Salary"
                  icon={TrendingDown}
                  color="red"
                />
              </div>

              {/* Expense Category Pie + Top Sites */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-semibold">Expense Category Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pieData.length === 0 ? (
                      <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">
                        No expense data available
                      </div>
                    ) : (
                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        <ResponsiveContainer width={200} height={200}>
                          <PieChart>
                            <Pie
                              data={pieData}
                              cx="50%"
                              cy="50%"
                              innerRadius={55}
                              outerRadius={90}
                              paddingAngle={2}
                              dataKey="value"
                            >
                              {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                            </Pie>
                            <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 12 }} />
                          </PieChart>
                        </ResponsiveContainer>
                        <div className="flex-1 space-y-1.5">
                          {pieData.map((entry, i) => (
                            <div key={i} className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-2">
                                <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ backgroundColor: entry.color }} />
                                <span className="text-muted-foreground text-xs">{entry.name}</span>
                              </div>
                              <span className="font-semibold text-xs">{fmtFull(entry.value)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-semibold">Top Sites by WO Value</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pnl.topSites.length === 0 ? (
                      <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">
                        No sites found
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {pnl.topSites.map((site, i) => (
                          <div key={site.siteId} className="space-y-1">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-2 min-w-0">
                                <span className="text-xs text-muted-foreground w-4">{i + 1}.</span>
                                <MapPin className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                                <span className="font-medium truncate">{site.siteName}</span>
                                <span
                                  className={cn(
                                    "text-xs px-1.5 py-0.5 rounded-full flex-shrink-0",
                                    site.status === "active" ? "bg-emerald-500/15 text-emerald-600" :
                                    site.status === "completed" ? "bg-blue-500/15 text-blue-600" :
                                    "bg-muted text-muted-foreground"
                                  )}
                                >
                                  {site.status}
                                </span>
                              </div>
                              <span className="font-bold text-xs ml-2">{fmt(site.woValue)}</span>
                            </div>
                            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full bg-primary rounded-full transition-all"
                                style={{
                                  width: pnl.topSites[0].woValue > 0
                                    ? `${(site.woValue / pnl.topSites[0].woValue) * 100}%`
                                    : "0%"
                                }}
                              />
                            </div>
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>Cost: {fmt(site.totalCost)}</span>
                              <span className={site.grossProfit >= 0 ? "text-emerald-600" : "text-red-500"}>
                                {site.margin}% margin
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* TRENDS TAB */}
          {activeTab === "trends" && (
            <div className="space-y-5">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Show:</span>
                {([6, 12] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setTrendMonths(m)}
                    className={cn(
                      "px-3 py-1 text-xs rounded-full font-medium transition-colors cursor-pointer",
                      trendMonths === m
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-accent"
                    )}
                  >
                    {m} Months
                  </button>
                ))}
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold">Revenue vs Cost vs Collection</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={trends} margin={{ left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => fmt(v)} width={60} />
                      <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 12 }} />
                      <Legend iconType="square" wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="revenue" name="WO Value" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                      <Bar dataKey="totalCost" name="Total Cost" fill="#f97316" radius={[3, 3, 0, 0]} />
                      <Bar dataKey="received" name="Collected" fill="#10b981" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold">Monthly Profit Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <LineChart data={trends} margin={{ left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => fmt(v)} width={60} />
                      <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 12 }} />
                      <Line
                        type="monotone"
                        dataKey="profit"
                        name="Gross Profit"
                        stroke="#8b5cf6"
                        strokeWidth={2.5}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-1">
                    <CardTitle className="text-xs text-muted-foreground uppercase tracking-wider">Cost Breakdown by Type</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={trends} margin={{ left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                        <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} tickFormatter={(v: number) => fmt(v)} width={55} />
                        <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 11 }} />
                        <Legend iconType="square" wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="expenses" name="Expenses" fill="#f97316" stackId="cost" />
                        <Bar dataKey="bills" name="Vendor Bills" fill="#ec4899" stackId="cost" />
                        <Bar dataKey="salaries" name="Salaries" fill="#8b5cf6" stackId="cost" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="md:col-span-2">
                  <CardHeader className="pb-1">
                    <CardTitle className="text-xs text-muted-foreground uppercase tracking-wider">Monthly Summary Table</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-border">
                            <th className="text-left py-1.5 pr-2 font-medium text-muted-foreground">Month</th>
                            <th className="text-right py-1.5 pr-2 font-medium text-muted-foreground">Revenue</th>
                            <th className="text-right py-1.5 pr-2 font-medium text-muted-foreground">Cost</th>
                            <th className="text-right py-1.5 pr-2 font-medium text-muted-foreground">Collected</th>
                            <th className="text-right py-1.5 font-medium text-muted-foreground">Profit</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                          {[...trends].reverse().slice(0, 8).map((row) => (
                            <tr key={row.month} className="hover:bg-muted/30">
                              <td className="py-1.5 pr-2 text-muted-foreground">{row.label}</td>
                              <td className="py-1.5 pr-2 text-right">{fmt(row.revenue)}</td>
                              <td className="py-1.5 pr-2 text-right text-red-500">{fmt(row.totalCost)}</td>
                              <td className="py-1.5 pr-2 text-right text-emerald-600">{fmt(row.received)}</td>
                              <td className={cn("py-1.5 text-right font-semibold", row.profit >= 0 ? "text-emerald-600" : "text-red-500")}>
                                {fmt(row.profit)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* SITE COMPARISON TAB */}
          {activeTab === "sites" && (
            <div className="space-y-5">
              {/* Summary bar chart */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold">Site Revenue vs Cost Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  {pnl.siteSummaries.length === 0 ? (
                    <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No sites found</div>
                  ) : (
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart
                        data={pnl.siteSummaries.slice(0, 10).map((s) => ({
                          name: s.siteName.length > 14 ? s.siteName.slice(0, 14) + "…" : s.siteName,
                          Revenue: s.woValue,
                          Cost: s.totalCost,
                          Collected: s.received,
                        }))}
                        margin={{ left: 10 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} tickFormatter={(v: number) => fmt(v)} width={60} />
                        <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 12 }} />
                        <Legend iconType="square" wrapperStyle={{ fontSize: 12 }} />
                        <Bar dataKey="Revenue" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="Cost" fill="#f97316" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="Collected" fill="#10b981" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>

              {/* Site comparison table */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Layers className="w-4 h-4 text-primary" />
                    All Sites — Revenue, Cost & Margin
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50 border-b border-border">
                        <tr>
                          <th className="text-left px-4 py-3 font-medium text-muted-foreground">Site</th>
                          <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Company</th>
                          <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Status</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">WO Value</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Total Cost</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">Profit</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">Margin</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden xl:table-cell">Collected</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden xl:table-cell">Outstanding</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {pnl.siteSummaries
                          .slice()
                          .sort((a, b) => b.woValue - a.woValue)
                          .map((site) => (
                            <tr key={site.siteId} className="hover:bg-muted/20">
                              <td className="px-4 py-3 font-medium">
                                <div className="flex items-center gap-1.5">
                                  <MapPin className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                                  {site.siteName}
                                </div>
                              </td>
                              <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell text-xs">{site.companyName}</td>
                              <td className="px-4 py-3 hidden md:table-cell">
                                <span className={cn(
                                  "text-xs px-2 py-0.5 rounded-full",
                                  site.status === "active" ? "bg-emerald-500/15 text-emerald-600" :
                                  site.status === "completed" ? "bg-blue-500/15 text-blue-600" :
                                  site.status === "on_hold" ? "bg-amber-500/15 text-amber-600" :
                                  "bg-muted text-muted-foreground"
                                )}>
                                  {site.status}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-right font-semibold">{fmtFull(site.woValue)}</td>
                              <td className="px-4 py-3 text-right text-red-500 hidden lg:table-cell">{fmtFull(site.totalCost)}</td>
                              <td className={cn("px-4 py-3 text-right font-semibold", site.grossProfit >= 0 ? "text-emerald-600" : "text-red-500")}>
                                {fmtFull(site.grossProfit)}
                              </td>
                              <td className="px-4 py-3 text-right">
                                <span className={cn(
                                  "text-xs font-bold px-2 py-0.5 rounded",
                                  site.margin >= 20 ? "bg-emerald-500/15 text-emerald-700" :
                                  site.margin >= 0 ? "bg-amber-500/15 text-amber-700" :
                                  "bg-red-500/15 text-red-700"
                                )}>
                                  {site.margin}%
                                </span>
                              </td>
                              <td className="px-4 py-3 text-right text-emerald-600 hidden xl:table-cell">{fmtFull(site.received)}</td>
                              <td className="px-4 py-3 text-right text-amber-600 hidden xl:table-cell">{fmtFull(site.outstanding)}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* COMPANIES TAB */}
          {activeTab === "companies" && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {companyKPIs.map((co) => (
                  <Card key={co.companyId}>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-semibold flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-primary" />
                        {co.companyName}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="p-2 bg-muted/40 rounded-lg">
                          <div className="text-lg font-bold text-primary">{co.totalSites}</div>
                          <div className="text-xs text-muted-foreground">Sites</div>
                        </div>
                        <div className="p-2 bg-muted/40 rounded-lg">
                          <div className="text-lg font-bold text-emerald-600">{co.activeSites}</div>
                          <div className="text-xs text-muted-foreground">Active</div>
                        </div>
                        <div className="p-2 bg-muted/40 rounded-lg">
                          <div className="text-lg font-bold">{co.labourCount}</div>
                          <div className="text-xs text-muted-foreground">Labour</div>
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground flex items-center gap-1">
                            <IndianRupee className="w-3 h-3" /> WO Value
                          </span>
                          <span className="font-semibold">{fmtFull(co.woValue)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground flex items-center gap-1">
                            <ArrowUpRight className="w-3 h-3 text-emerald-500" /> Received
                          </span>
                          <span className="font-semibold text-emerald-600">{fmtFull(co.totalReceived)}</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                          <div
                            className="h-full bg-emerald-500 rounded-full"
                            style={{
                              width: co.woValue > 0
                                ? `${Math.min((co.totalReceived / co.woValue) * 100, 100)}%`
                                : "0%"
                            }}
                          />
                        </div>
                        <div className="text-xs text-muted-foreground text-right">
                          {co.woValue > 0 ? Math.round((co.totalReceived / co.woValue) * 100) : 0}% collected
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Company WO value bar */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Users className="w-4 h-4 text-primary" /> Company-wise Collection Rate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart
                      data={companyKPIs.map((c) => ({
                        name: c.companyName.length > 16 ? c.companyName.slice(0, 16) + "…" : c.companyName,
                        "WO Value": c.woValue,
                        "Collected": c.totalReceived,
                      }))}
                      margin={{ left: 10 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => fmt(v)} width={60} />
                      <Tooltip formatter={(v: number) => fmtFull(v)} contentStyle={{ fontSize: 12 }} />
                      <Legend iconType="square" wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="WO Value" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                      <Bar dataKey="Collected" fill="#10b981" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          )}
          {/* BILLS TAB */}
          {activeTab === "bills" && (
            <div className="space-y-5">
              {/* Summary KPIs */}
              {allBills && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {(() => {
                    const total = allBills.length;
                    const totalAmt = allBills.reduce((s, b) => s + b.totalAmount, 0);
                    const paid = allBills.filter(b => b.status === "paid").reduce((s, b) => s + b.paidAmount, 0);
                    const outstanding = allBills.reduce((s, b) => s + (b.totalAmount - b.paidAmount), 0);
                    return (
                      <>
                        <Card><CardContent className="pt-4 pb-3">
                          <p className="text-xs text-muted-foreground font-semibold uppercase mb-1">Total Bills</p>
                          <p className="text-2xl font-bold text-primary">{total}</p>
                          <p className="text-xs text-muted-foreground">All vendors</p>
                        </CardContent></Card>
                        <Card><CardContent className="pt-4 pb-3">
                          <p className="text-xs text-muted-foreground font-semibold uppercase mb-1">Total Amount</p>
                          <p className="text-2xl font-bold text-blue-600">{fmt(totalAmt)}</p>
                          <p className="text-xs text-muted-foreground">{fmtFull(totalAmt)}</p>
                        </CardContent></Card>
                        <Card><CardContent className="pt-4 pb-3">
                          <p className="text-xs text-muted-foreground font-semibold uppercase mb-1">Total Paid</p>
                          <p className="text-2xl font-bold text-emerald-600">{fmt(paid)}</p>
                          <p className="text-xs text-muted-foreground">{fmtFull(paid)}</p>
                        </CardContent></Card>
                        <Card><CardContent className="pt-4 pb-3">
                          <p className="text-xs text-muted-foreground font-semibold uppercase mb-1">Outstanding</p>
                          <p className="text-2xl font-bold text-orange-600">{fmt(outstanding)}</p>
                          <p className="text-xs text-muted-foreground">{fmtFull(outstanding)}</p>
                        </CardContent></Card>
                      </>
                    );
                  })()}
                </div>
              )}

              {/* Filters */}
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm font-semibold text-muted-foreground">Vendor:</span>
                {(["all", "contractor", "supplier"] as const).map(v => (
                  <button key={v} onClick={() => setBillVendorType(v)}
                    className={cn("px-3 py-1 text-xs rounded-full font-semibold transition-colors cursor-pointer",
                      billVendorType === v ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
                    )}>
                    {v === "all" ? "All" : v === "contractor" ? "Contractor" : "Supplier"}
                  </button>
                ))}
                <span className="text-sm font-semibold text-muted-foreground ml-3">Status:</span>
                {(["all", "received", "approved", "paid", "rejected"] as const).map(s => (
                  <button key={s} onClick={() => setBillStatus(s)}
                    className={cn("px-3 py-1 text-xs rounded-full font-semibold transition-colors cursor-pointer",
                      billStatus === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
                    )}>
                    {s === "all" ? "All Status" : s.charAt(0).toUpperCase() + s.slice(1)}
                  </button>
                ))}
              </div>

              {/* Bills Table */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-orange-500" />
                    {billVendorType === "all" ? "All Vendor Bills" : billVendorType === "contractor" ? "Contractor Bills" : "Supplier Bills"}
                    {allBills && (
                      <span className="ml-auto text-xs font-normal text-muted-foreground">
                        {(() => {
                          const filtered = (allBills ?? []).filter(b => {
                            const vtOk = billVendorType === "all" || (billVendorType === "contractor" ? !!b.contractorId : !!b.supplierId);
                            const stOk = billStatus === "all" || b.status === billStatus;
                            return vtOk && stOk;
                          });
                          return `${filtered.length} bills`;
                        })()}
                      </span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {!allBills ? (
                    <div className="p-4 space-y-2">{Array.from({length: 5}).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-slate-700 text-white">
                          <tr>
                            <th className="text-left px-4 py-3 font-semibold">Bill No.</th>
                            <th className="text-left px-4 py-3 font-semibold">Vendor</th>
                            <th className="text-left px-4 py-3 font-semibold hidden sm:table-cell">Type</th>
                            <th className="text-left px-4 py-3 font-semibold hidden md:table-cell">Site</th>
                            <th className="text-left px-4 py-3 font-semibold hidden lg:table-cell">Date</th>
                            <th className="text-right px-4 py-3 font-semibold">Amount</th>
                            <th className="text-right px-4 py-3 font-semibold hidden md:table-cell">Paid</th>
                            <th className="text-right px-4 py-3 font-semibold hidden md:table-cell">Outstanding</th>
                            <th className="text-center px-4 py-3 font-semibold">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                          {(allBills ?? [])
                            .filter(b => {
                              const vtOk = billVendorType === "all" || (billVendorType === "contractor" ? !!b.contractorId : !!b.supplierId);
                              const stOk = billStatus === "all" || b.status === billStatus;
                              return vtOk && stOk;
                            })
                            .slice(0, 200)
                            .map(b => {
                              const outstanding = b.totalAmount - b.paidAmount;
                              const vendorName = b.contractorName ?? b.supplierName ?? "—";
                              const isContractor = !!b.contractorId;
                              const statusConfig: Record<string, { bg: string; text: string; icon: React.ComponentType<{ className?: string }> }> = {
                                received: { bg: "bg-blue-100 text-blue-800", text: "Received", icon: Clock },
                                approved: { bg: "bg-emerald-100 text-emerald-800", text: "Approved", icon: CheckCircle },
                                paid: { bg: "bg-green-100 text-green-800", text: "Paid ✓", icon: CheckCircle },
                                rejected: { bg: "bg-red-100 text-red-800", text: "Rejected", icon: XCircle },
                                disputed: { bg: "bg-yellow-100 text-yellow-800", text: "Disputed", icon: AlertCircle },
                              };
                              const sc = statusConfig[b.status] ?? { bg: "bg-gray-100 text-gray-700", text: b.status, icon: Clock };
                              const StatusIcon = sc.icon;
                              return (
                                <tr key={b._id} className="hover:bg-muted/20">
                                  <td className="px-4 py-3 font-bold text-gray-900">{b.billNumber}</td>
                                  <td className="px-4 py-3">
                                    <div>
                                      <p className="font-semibold text-gray-900">{vendorName}</p>
                                      <span className={cn("text-[10px] px-1.5 py-0.5 rounded font-bold",
                                        isContractor ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                                      )}>
                                        {isContractor ? "Contractor" : "Supplier"}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-4 py-3 hidden sm:table-cell">
                                    <span className={cn("text-xs font-semibold px-2 py-0.5 rounded",
                                      b.billType === "final" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                                    )}>
                                      {b.billType === "final" ? "Final Bill" : `RA-${b.raNumber ?? ""}`}
                                    </span>
                                  </td>
                                  <td className="px-4 py-3 text-muted-foreground text-xs hidden md:table-cell">{b.siteName ?? "—"}</td>
                                  <td className="px-4 py-3 text-muted-foreground text-xs hidden lg:table-cell">{b.billDate}</td>
                                  <td className="px-4 py-3 text-right font-bold text-gray-900">{fmtFull(b.totalAmount)}</td>
                                  <td className="px-4 py-3 text-right text-emerald-700 font-semibold hidden md:table-cell">{fmtFull(b.paidAmount)}</td>
                                  <td className={cn("px-4 py-3 text-right font-semibold hidden md:table-cell", outstanding > 0 ? "text-orange-600" : "text-gray-400")}>
                                    {outstanding > 0 ? fmtFull(outstanding) : "—"}
                                  </td>
                                  <td className="px-4 py-3 text-center">
                                    <span className={cn("text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 justify-center w-fit mx-auto", sc.bg)}>
                                      <StatusIcon className="w-3 h-3" />{sc.text}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                      {(allBills ?? []).filter(b => {
                        const vtOk = billVendorType === "all" || (billVendorType === "contractor" ? !!b.contractorId : !!b.supplierId);
                        const stOk = billStatus === "all" || b.status === billStatus;
                        return vtOk && stOk;
                      }).length === 0 && (
                        <div className="text-center py-12 text-muted-foreground">
                          <Receipt className="w-10 h-10 mx-auto mb-2 opacity-30" />
                          <p className="text-sm">Is filter ke liye koi bill nahi mila</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default function AnalyticsPage() {
  return (
    <Authenticated>
      <AnalyticsInner />
    </Authenticated>
  );
}
