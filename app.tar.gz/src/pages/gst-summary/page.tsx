import { useState } from "react";
import { useQuery } from "convex/react";
import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs.tsx";
import { FileSpreadsheet, TrendingDown, TrendingUp, BookMarked, Download, FileText } from "lucide-react";
import { cn } from "@/lib/utils.ts";
import jsPDF from "jspdf";
import autoTablePlugin from "jspdf-autotable";

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];
const OUR_COMPANIES = ["JAI AAINATH INTERIOR", "JAI GANESH INTERIOR"];
const BRAND = "JAI SITE MANAGER ERP";
const PRIMARY: [number, number, number] = [30, 64, 175];

function fmt(n: number) {
  return "₹" + n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

function pct(n: number) {
  return n.toFixed(1) + "%";
}

// ─── Shared rate-bucket table component ──────────────────────────────────────
type RateBucket = { gstPercent: number; taxableValue: number; gstAmount: number; count: number };

function RateTable({
  buckets,
  totalTaxable,
  totalGst,
  accentClass,
}: {
  buckets: RateBucket[];
  totalTaxable: number;
  totalGst: number;
  accentClass: string;
}) {
  if (buckets.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground text-sm">
        Koi data nahi mila is selection ke liye.
      </div>
    );
  }
  return (
    <div className="rounded-lg border overflow-x-auto">
      <table className="w-full text-xs border-collapse min-w-[520px]">
        <thead>
          <tr className={cn("text-white", accentClass)}>
            <th className="px-3 py-2 text-center w-20">GST %</th>
            <th className="px-3 py-2 text-right">Taxable Value</th>
            <th className="px-3 py-2 text-right">CGST (50%)</th>
            <th className="px-3 py-2 text-right">SGST (50%)</th>
            <th className="px-3 py-2 text-right">Total GST</th>
            <th className="px-3 py-2 text-right">Total (with GST)</th>
            <th className="px-3 py-2 text-center w-20">Invoices</th>
          </tr>
        </thead>
        <tbody>
          {buckets.map((b, idx) => {
            const half = b.gstAmount / 2;
            return (
              <tr key={b.gstPercent} className={cn(
                "text-gray-900",
                idx % 2 === 0 ? "bg-white" : "bg-muted/20"
              )}>
                <td className="border border-border px-3 py-1.5 text-center font-bold">{b.gstPercent}%</td>
                <td className="border border-border px-3 py-1.5 text-right">{fmt(b.taxableValue)}</td>
                <td className="border border-border px-3 py-1.5 text-right">{fmt(half)}</td>
                <td className="border border-border px-3 py-1.5 text-right">{fmt(half)}</td>
                <td className="border border-border px-3 py-1.5 text-right font-semibold">{fmt(b.gstAmount)}</td>
                <td className="border border-border px-3 py-1.5 text-right font-bold">{fmt(b.taxableValue + b.gstAmount)}</td>
                <td className="border border-border px-3 py-1.5 text-center text-muted-foreground">{b.count}</td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr className="font-bold border-t-2 border-border bg-muted/40 text-gray-900">
            <td className="px-3 py-2 text-right">TOTAL</td>
            <td className="px-3 py-2 text-right">{fmt(totalTaxable)}</td>
            <td className="px-3 py-2 text-right">{fmt(totalGst / 2)}</td>
            <td className="px-3 py-2 text-right">{fmt(totalGst / 2)}</td>
            <td className="px-3 py-2 text-right">{fmt(totalGst)}</td>
            <td className="px-3 py-2 text-right">{fmt(totalTaxable + totalGst)}</td>
            <td className="px-3 py-2 text-center text-muted-foreground">
              {buckets.reduce((s, b) => s + b.count, 0)}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

// ─── Summary KPI cards ────────────────────────────────────────────────────────
function KpiCards({ taxable, gst, invoices, label, colorClass }: {
  taxable: number; gst: number; invoices: number; label: string; colorClass: string;
}) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {[
        { title: "Taxable Value", val: fmt(taxable) },
        { title: "Total GST", val: fmt(gst) },
        { title: "Grand Total", val: fmt(taxable + gst) },
        { title: `${label} Invoices`, val: String(invoices) },
      ].map((k) => (
        <div key={k.title} className={cn("rounded-lg border p-3", colorClass)}>
          <div className="text-xs text-muted-foreground mb-1">{k.title}</div>
          <div className="font-bold text-base">{k.val}</div>
        </div>
      ))}
    </div>
  );
}

// ─── PDF generator ────────────────────────────────────────────────────────────
function exportGstPdf(
  title: string,
  subtitle: string,
  buckets: RateBucket[],
  totalTaxable: number,
  totalGst: number,
  extraRows?: { label: string; value: string }[]
) {
  const doc = new jsPDF();
  // brand bar
  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, 210, 16, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8); doc.setFont("helvetica", "bold");
  doc.text(BRAND, 14, 10);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, 196, 10, { align: "right" });

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(15); doc.setFont("helvetica", "bold");
  doc.text(title, 14, 28);
  doc.setFontSize(9); doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(subtitle, 14, 35);

  autoTablePlugin(doc, {
    startY: 42,
    head: [["GST %", "Taxable Value", "CGST (50%)", "SGST (50%)", "Total GST", "Total (with GST)", "Invoices"]],
    body: buckets.map((b) => [
      `${b.gstPercent}%`,
      `Rs.${b.taxableValue.toLocaleString("en-IN")}`,
      `Rs.${(b.gstAmount / 2).toLocaleString("en-IN")}`,
      `Rs.${(b.gstAmount / 2).toLocaleString("en-IN")}`,
      `Rs.${b.gstAmount.toLocaleString("en-IN")}`,
      `Rs.${(b.taxableValue + b.gstAmount).toLocaleString("en-IN")}`,
      String(b.count),
    ]),
    foot: [[
      "TOTAL",
      `Rs.${totalTaxable.toLocaleString("en-IN")}`,
      `Rs.${(totalGst / 2).toLocaleString("en-IN")}`,
      `Rs.${(totalGst / 2).toLocaleString("en-IN")}`,
      `Rs.${totalGst.toLocaleString("en-IN")}`,
      `Rs.${(totalTaxable + totalGst).toLocaleString("en-IN")}`,
      String(buckets.reduce((s, b) => s + b.count, 0)),
    ]],
    headStyles: { fillColor: PRIMARY, textColor: 255, fontSize: 8, fontStyle: "bold" },
    footStyles: { fillColor: [240, 249, 255], textColor: [30, 64, 175], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { halign: "center", cellWidth: 18 },
      1: { halign: "right" },
      2: { halign: "right" },
      3: { halign: "right" },
      4: { halign: "right" },
      5: { halign: "right" },
      6: { halign: "center", cellWidth: 18 },
    },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  if (extraRows && extraRows.length > 0) {
    const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
    doc.setFontSize(9); doc.setTextColor(100, 116, 139);
    doc.text("Additional Deductions / Details", 14, finalY);
    let y = finalY + 7;
    for (const row of extraRows) {
      doc.setFontSize(8);
      doc.setTextColor(30, 41, 59);
      doc.text(row.label + ":", 14, y);
      doc.setFont("helvetica", "bold");
      doc.text(row.value, 80, y);
      doc.setFont("helvetica", "normal");
      y += 6;
    }
  }

  // page numbers
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7); doc.setTextColor(150, 150, 150);
    doc.text(`Page ${i} of ${pageCount}`, 196, 290, { align: "right" });
    doc.text(BRAND, 14, 290);
  }

  doc.save(`gst-summary-${title.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().split("T")[0]}.pdf`);
}

// ─── CSV export ────────────────────────────────────────────────────────────────
function exportGstCsv(title: string, buckets: RateBucket[], totalTaxable: number, totalGst: number) {
  const header = ["GST %", "Taxable Value", "CGST (50%)", "SGST (50%)", "Total GST", "Total (with GST)", "Invoices"];
  const rows = buckets.map((b) => [
    `${b.gstPercent}%`,
    b.taxableValue,
    b.gstAmount / 2,
    b.gstAmount / 2,
    b.gstAmount,
    b.taxableValue + b.gstAmount,
    b.count,
  ]);
  rows.push(["TOTAL", totalTaxable, totalGst / 2, totalGst / 2, totalGst, totalTaxable + totalGst,
    buckets.reduce((s, b) => s + b.count, 0)]);
  const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `gst-${title.toLowerCase().replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.csv`;
  document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
}

// ─── Purchase (Input Tax) Tab ──────────────────────────────────────────────────
function PurchaseGstTab() {
  const [fy, setFy] = useState("2026-27");
  const [company, setCompany] = useState("JAI AAINATH INTERIOR");

  const data = useQuery(api.gstSummary.purchaseGstSummary, { financialYear: fy, ourCompanyName: company });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={company} onValueChange={setCompany}>
          <SelectTrigger className="w-56 h-9 text-sm font-semibold"><SelectValue /></SelectTrigger>
          <SelectContent>
            {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fy} onValueChange={setFy}>
          <SelectTrigger className="w-28 h-9 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-1.5 ml-auto">
          <Button size="sm" variant="secondary" className="gap-1.5 cursor-pointer"
            disabled={!data || data.byRate.length === 0}
            onClick={() => data && exportGstCsv(`Purchase-${company}-${fy}`, data.byRate, data.totalTaxableValue, data.totalGstAmount)}>
            <Download className="w-3.5 h-3.5" /> CSV
          </Button>
          <Button size="sm" variant="secondary" className="gap-1.5 cursor-pointer"
            disabled={!data || data.byRate.length === 0}
            onClick={() => data && exportGstPdf(
              "PURCHASE (INPUT) GST SUMMARY",
              `${company}  ·  FY ${fy}`,
              data.byRate, data.totalTaxableValue, data.totalGstAmount
            )}>
            <FileText className="w-3.5 h-3.5" /> PDF
          </Button>
        </div>
      </div>

      {data === undefined ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
      ) : (
        <div className="space-y-4">
          <KpiCards
            taxable={data.totalTaxableValue}
            gst={data.totalGstAmount}
            invoices={data.totalInvoices}
            label="Purchase"
            colorClass="bg-orange-50/50 border-orange-200"
          />
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              Input Tax Credit (ITC) Breakup by GST Rate
            </div>
            <RateTable
              buckets={data.byRate}
              totalTaxable={data.totalTaxableValue}
              totalGst={data.totalGstAmount}
              accentClass="bg-orange-600"
            />
          </div>
          {data.totalTaxableValue > 0 && (
            <div className="text-xs text-muted-foreground bg-orange-50 border border-orange-200 rounded-lg p-3">
              <span className="font-semibold">Effective GST Rate:</span>{" "}
              {pct((data.totalGstAmount / data.totalTaxableValue) * 100)} on total taxable value of {fmt(data.totalTaxableValue)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Sale (Output Tax) Tab — from gstInvoiceTracking ─────────────────────────
function SaleGstTab() {
  const [fy, setFy] = useState("2026-27");
  const [company, setCompany] = useState("JAI AAINATH INTERIOR");

  const data = useQuery(api.gstSummary.gstTrackingOutputSummary, { financialYear: fy, ourCompanyName: company });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={company} onValueChange={setCompany}>
          <SelectTrigger className="w-56 h-9 text-sm font-semibold"><SelectValue /></SelectTrigger>
          <SelectContent>
            {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fy} onValueChange={setFy}>
          <SelectTrigger className="w-28 h-9 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-1.5 ml-auto">
          <Button size="sm" variant="secondary" className="gap-1.5 cursor-pointer"
            disabled={!data || data.byRate.length === 0}
            onClick={() => data && exportGstCsv(`Sale-${company}-${fy}`, data.byRate, data.totalTaxableValue, data.totalGstAmount)}>
            <Download className="w-3.5 h-3.5" /> CSV
          </Button>
          <Button size="sm" variant="secondary" className="gap-1.5 cursor-pointer"
            disabled={!data || data.byRate.length === 0}
            onClick={() => data && exportGstPdf(
              "SALE (OUTPUT) GST SUMMARY",
              `${company}  ·  FY ${fy}`,
              data.byRate, data.totalTaxableValue, data.totalGstAmount,
              [
                { label: "Total Retention", value: fmt(data.totalRetention) },
                { label: "Total TDS", value: fmt(data.totalTds) },
                { label: "Total Net Payable", value: fmt(data.totalNetPayable) },
              ]
            )}>
            <FileText className="w-3.5 h-3.5" /> PDF
          </Button>
        </div>
      </div>

      {data === undefined ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { title: "Taxable Value", val: fmt(data.totalTaxableValue) },
              { title: "Output GST", val: fmt(data.totalGstAmount) },
              { title: "Retention", val: fmt(data.totalRetention) },
              { title: "Net Payable", val: fmt(data.totalNetPayable) },
            ].map((k) => (
              <div key={k.title} className="rounded-lg border bg-emerald-50/50 border-emerald-200 p-3">
                <div className="text-xs text-muted-foreground mb-1">{k.title}</div>
                <div className="font-bold text-base">{k.val}</div>
              </div>
            ))}
          </div>

          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              Output Tax Liability Breakup by GST Rate
            </div>
            <RateTable
              buckets={data.byRate}
              totalTaxable={data.totalTaxableValue}
              totalGst={data.totalGstAmount}
              accentClass="bg-emerald-600"
            />
          </div>

          {/* ITC vs Output Summary */}
          {data.totalTaxableValue > 0 && (
            <div className="text-xs text-muted-foreground bg-emerald-50 border border-emerald-200 rounded-lg p-3">
              <span className="font-semibold">TDS Deducted:</span> {fmt(data.totalTds)}
              {"  ·  "}
              <span className="font-semibold">Retention Held:</span> {fmt(data.totalRetention)}
              {"  ·  "}
              <span className="font-semibold">Grand Total (incl. GST):</span> {fmt(data.totalTaxableValue + data.totalGstAmount)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Net GST Liability Tab ────────────────────────────────────────────────────
function NetLiabilityTab() {
  const [fy, setFy] = useState("2026-27");
  const [company, setCompany] = useState("JAI AAINATH INTERIOR");

  const purchaseData = useQuery(api.gstSummary.purchaseGstSummary, { financialYear: fy, ourCompanyName: company });
  const saleData = useQuery(api.gstSummary.gstTrackingOutputSummary, { financialYear: fy, ourCompanyName: company });

  const loading = purchaseData === undefined || saleData === undefined;

  const outputGst = saleData?.totalGstAmount ?? 0;
  const inputGst = purchaseData?.totalGstAmount ?? 0;
  const netLiability = outputGst - inputGst;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={company} onValueChange={setCompany}>
          <SelectTrigger className="w-56 h-9 text-sm font-semibold"><SelectValue /></SelectTrigger>
          <SelectContent>
            {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fy} onValueChange={setFy}>
          <SelectTrigger className="w-28 h-9 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
      ) : (
        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-xl border bg-emerald-50 border-emerald-200 p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-semibold text-emerald-700 uppercase">Output Tax (Sale)</span>
              </div>
              <div className="text-2xl font-bold text-emerald-700">{fmt(outputGst)}</div>
              <div className="text-xs text-muted-foreground mt-1">
                On taxable value of {fmt(saleData.totalTaxableValue)}
              </div>
            </div>
            <div className="rounded-xl border bg-orange-50 border-orange-200 p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-4 h-4 text-orange-600" />
                <span className="text-xs font-semibold text-orange-700 uppercase">Input Tax Credit (Purchase)</span>
              </div>
              <div className="text-2xl font-bold text-orange-700">{fmt(inputGst)}</div>
              <div className="text-xs text-muted-foreground mt-1">
                On taxable value of {fmt(purchaseData.totalTaxableValue)}
              </div>
            </div>
            <div className={cn(
              "rounded-xl border p-4",
              netLiability > 0 ? "bg-red-50 border-red-200" : "bg-blue-50 border-blue-200"
            )}>
              <div className="flex items-center gap-2 mb-2">
                <BookMarked className={cn("w-4 h-4", netLiability > 0 ? "text-red-600" : "text-blue-600")} />
                <span className={cn("text-xs font-semibold uppercase",
                  netLiability > 0 ? "text-red-700" : "text-blue-700")}>
                  {netLiability > 0 ? "Net GST Payable" : "Excess ITC (Credit)"}
                </span>
              </div>
              <div className={cn("text-2xl font-bold", netLiability > 0 ? "text-red-700" : "text-blue-700")}>
                {fmt(Math.abs(netLiability))}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {netLiability > 0
                  ? "Output exceeds Input — GST payable to govt"
                  : "Input exceeds Output — ITC carry forward"}
              </div>
            </div>
          </div>

          {/* Breakdown table */}
          <div className="rounded-lg border overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 border-b">
                  <th className="px-4 py-2.5 text-left font-semibold">Particulars</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="px-4 py-2 text-emerald-700 font-medium">Output GST (on Sales)</td>
                  <td className="px-4 py-2 text-right font-bold">{fmt(outputGst)}</td>
                </tr>
                <tr className="border-b bg-muted/10">
                  <td className="px-4 py-2 text-orange-700 font-medium">Less: Input Tax Credit (on Purchases)</td>
                  <td className="px-4 py-2 text-right font-bold text-orange-700">({fmt(inputGst)})</td>
                </tr>
                <tr className={cn("border-t-2", netLiability > 0 ? "border-red-400 bg-red-50" : "border-blue-400 bg-blue-50")}>
                  <td className={cn("px-4 py-3 font-bold text-base",
                    netLiability > 0 ? "text-red-700" : "text-blue-700")}>
                    {netLiability > 0 ? "Net GST Payable to Govt" : "Net ITC Excess (Carry Forward)"}
                  </td>
                  <td className={cn("px-4 py-3 text-right font-bold text-base",
                    netLiability > 0 ? "text-red-700" : "text-blue-700")}>
                    {fmt(Math.abs(netLiability))}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="text-xs text-muted-foreground">
            * This is a simplified overview for internal reference. CGST and SGST are each assumed to be 50% of the total GST. Consult your CA for official GSTR filing.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Page ──────────────────────────────────────────────────────────────────────
function GstSummaryInner() {
  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center gap-3">
        <FileSpreadsheet className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold tracking-tight">GST Summary Report</h1>
          <p className="text-muted-foreground text-sm">Input/Output tax breakup for GST filing overview</p>
        </div>
      </div>

      <Tabs defaultValue="net" className="w-full">
        <TabsList>
          <TabsTrigger value="net" className="cursor-pointer gap-1.5">
            <BookMarked className="w-4 h-4" /> Net Liability
          </TabsTrigger>
          <TabsTrigger value="sale" className="cursor-pointer gap-1.5">
            <TrendingUp className="w-4 h-4" /> Output Tax (Sale)
          </TabsTrigger>
          <TabsTrigger value="purchase" className="cursor-pointer gap-1.5">
            <TrendingDown className="w-4 h-4" /> Input Tax (Purchase)
          </TabsTrigger>
        </TabsList>
        <TabsContent value="net" className="mt-4"><NetLiabilityTab /></TabsContent>
        <TabsContent value="sale" className="mt-4"><SaleGstTab /></TabsContent>
        <TabsContent value="purchase" className="mt-4"><PurchaseGstTab /></TabsContent>
      </Tabs>
    </div>
  );
}

export default function GstSummaryPage() {
  return (
    <>
      <Unauthenticated><div className="flex items-center justify-center h-64"><SignInButton /></div></Unauthenticated>
      <Authenticated><GstSummaryInner /></Authenticated>
    </>
  );
}
