import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Authenticated, AuthLoading } from "convex/react";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Building2, CreditCard, CheckCircle, FileText } from "lucide-react";
import { toast } from "sonner";

function Form2Inner() {
  const navigate = useNavigate();
  const profileStatus = useQuery(api.profileForm2.getProfileStatus, {});
  const submitContractorForm2 = useMutation(api.profileForm2.submitContractorForm2);
  const submitSupplierForm2 = useMutation(api.profileForm2.submitSupplierForm2);

  const [gstNumber, setGstNumber] = useState("");
  const [panNumber, setPanNumber] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  const [address, setAddress] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  // Prefill from existing data
  useEffect(() => {
    if (profileStatus?.record) {
      setGstNumber(profileStatus.record.gstNumber ?? "");
      setPanNumber(profileStatus.record.panNumber ?? "");
      setBankName(profileStatus.record.bankName ?? "");
      setAccountNumber(profileStatus.record.accountNumber ?? "");
      setIfscCode(profileStatus.record.ifscCode ?? "");
      setAddress(profileStatus.record.address ?? "");
    }
  }, [profileStatus]);

  if (!profileStatus) {
    return (
      <div className="space-y-4 max-w-lg mx-auto p-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  // If already complete, show success
  if (profileStatus.isForm2Complete || isComplete) {
    return (
      <div className="max-w-lg mx-auto p-4">
        <Card className="text-center">
          <CardContent className="py-10 space-y-4">
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <h2 className="text-xl font-bold text-foreground">Profile Complete!</h2>
            <p className="text-muted-foreground">
              Aapki GST aur bank details save ho chuki hain.
            </p>
            <Button className="cursor-pointer" onClick={() => navigate("/dashboard")}>
              Dashboard pe Jaao
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If not contractor or supplier, redirect
  if (profileStatus.role !== "contractor" && profileStatus.role !== "supplier") {
    return (
      <div className="max-w-lg mx-auto p-4">
        <Card className="text-center">
          <CardContent className="py-10 space-y-4">
            <p className="text-muted-foreground">
              Yeh form sirf Contractors aur Suppliers ke liye hai.
            </p>
            <Button className="cursor-pointer" onClick={() => navigate("/dashboard")}>
              Dashboard pe Jaao
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const roleLabel = profileStatus.role === "contractor" ? "Contractor" : "Supplier";

  const handleSubmit = async () => {
    if (!gstNumber.trim()) {
      toast.error("GST Number daalo");
      return;
    }
    if (!bankName.trim()) {
      toast.error("Bank ka naam daalo");
      return;
    }
    if (!accountNumber.trim()) {
      toast.error("Account number daalo");
      return;
    }
    if (!ifscCode.trim()) {
      toast.error("IFSC code daalo");
      return;
    }

    setIsSubmitting(true);
    try {
      const mutationArgs = {
        gstNumber: gstNumber.trim().toUpperCase(),
        panNumber: panNumber.trim().toUpperCase() || undefined,
        bankName: bankName.trim(),
        accountNumber: accountNumber.trim(),
        ifscCode: ifscCode.trim().toUpperCase(),
        address: address.trim() || undefined,
      };

      if (profileStatus.role === "contractor") {
        await submitContractorForm2(mutationArgs);
      } else {
        await submitSupplierForm2(mutationArgs);
      }
      toast.success("Form 2 submit ho gaya!");
      setIsComplete(true);
    } catch (error) {
      toast.error("Error: Form submit nahi ho paya. Dobara try karo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto p-4">
      <div className="text-center mb-6">
        <div className="w-14 h-14 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
          <FileText className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">Form 2 - {roleLabel} Details</h1>
        <p className="text-sm text-muted-foreground mt-1">
          GST number aur bank details bharein
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-600" />
            {roleLabel} Jaankari
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* GST Details */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">GST / PAN</h3>

            <div>
              <Label>GST Number <span className="text-red-500">*</span></Label>
              <Input
                placeholder="22AAAAA0000A1Z5"
                value={gstNumber}
                onChange={(e) => setGstNumber(e.target.value.toUpperCase())}
                maxLength={15}
              />
            </div>

            <div>
              <Label>PAN Number</Label>
              <Input
                placeholder="ABCDE1234F"
                value={panNumber}
                onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                maxLength={10}
              />
            </div>

            <div>
              <Label>Address</Label>
              <Input
                placeholder="Office/Shop address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
          </div>

          {/* Bank Details */}
          <div className="space-y-3 pt-2 border-t">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Bank Details
            </h3>

            <div>
              <Label>Bank ka Naam <span className="text-red-500">*</span></Label>
              <Input
                placeholder="SBI, HDFC, ICICI etc."
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
              />
            </div>

            <div>
              <Label>Account Number <span className="text-red-500">*</span></Label>
              <Input
                placeholder="Account Number"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
              />
            </div>

            <div>
              <Label>IFSC Code <span className="text-red-500">*</span></Label>
              <Input
                placeholder="SBIN0001234"
                value={ifscCode}
                onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                maxLength={11}
              />
            </div>
          </div>

          <Button
            className="w-full cursor-pointer mt-4"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? "Submit ho raha hai..." : "Submit Karo"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

export default function ProfileForm2Page() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 py-8 px-4">
      <AuthLoading>
        <div className="max-w-lg mx-auto space-y-4">
          <Skeleton className="h-8 w-48 mx-auto" />
          <Skeleton className="h-96 w-full" />
        </div>
      </AuthLoading>
      <Authenticated>
        <Form2Inner />
      </Authenticated>
    </div>
  );
}
