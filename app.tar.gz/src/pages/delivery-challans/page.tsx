import { useState, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import {
  Truck, Plus, CheckCircle2, XCircle, Clock, Camera, Trash2,
  ChevronDown, ChevronUp, Image,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const STATUS_CONFIG = {
  pending: { label: "Pending", class: "bg-yellow-500/10 text-yellow-600", icon: Clock },
  approved: { label: "Approved", class: "bg-green-500/10 text-green-600", icon: CheckCircle2 },
  rejected: { label: "Rejected", class: "bg-red-500/10 text-red-600", icon: XCircle },
} as const;

const UNITS = ["bags", "tons", "kg", "cubic ft", "cubic m", "litre", "nos", "rft", "sqft", "loads", "trips"];

type FormState = {
  siteId: string;
  vehicleNumber: string;
  driverName: string;
  supplierId: string;
  deliveryDate: string;
  materialType: string;
  quantity: string;
  unit: string;
  notes: string;
};

const EMPTY_FORM: FormState = {
  siteId: "",
  vehicleNumber: "",
  driverName: "",
  supplierId: "",
  deliveryDate: new Date().toISOString().split("T")[0],
  materialType: "",
  quantity: "",
  unit: "bags",
  notes: "",
};

function DeliveryChallansInner() {
  const sites = useQuery(api.sites.list, {});
  const suppliers = useQuery(api.suppliers.list, {});
  const currentUser = useQuery(api.users.getCurrentUserQuery, {});
  const challans = useQuery(api.deliveryChallans.list, {});

  const createChallan = useMutation(api.deliveryChallans.create);
  const approveChallan = useMutation(api.deliveryChallans.approve);
  const rejectChallan = useMutation(api.deliveryChallans.reject);
  const removeChallan = useMutation(api.deliveryChallans.remove);
  const generateUploadUrl = useMutation(api.deliveryChallans.generateUploadUrl);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [photos, setPhotos] = useState<File[]>([]);
  const [photoPreviews, setPhotoPreviews] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [rejectDialogId, setRejectDialogId] = useState<string | null>(null);
  const [rejectNote, setRejectNote] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isAdmin = currentUser?.role === "super_admin";

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (photos.length + files.length > 5) {
      toast.error("Maximum 5 photos allowed");
      return;
    }
    const newPhotos = [...photos, ...files].slice(0, 5);
    setPhotos(newPhotos);
    const previews = newPhotos.map((f) => URL.createObjectURL(f));
    setPhotoPreviews(previews);
  }

  function removePhoto(index: number) {
    const newPhotos = photos.filter((_, i) => i !== index);
    const newPreviews = photoPreviews.filter((_, i) => i !== index);
    setPhotos(newPhotos);
    setPhotoPreviews(newPreviews);
  }

  async function handleSubmit() {
    if (!form.siteId || !form.vehicleNumber.trim() || !form.materialType.trim() || !form.quantity.trim() || !form.deliveryDate) {
      toast.error("Please fill in all required fields");
      return;
    }
    setSubmitting(true);
    try {
      // Upload photos
      const storageIds: string[] = [];
      for (const photo of photos) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": photo.type },
          body: photo,
        });
        const { storageId } = await result.json() as { storageId: string };
        storageIds.push(storageId);
      }

      await createChallan({
        siteId: form.siteId as Id<"sites">,
        vehicleNumber: form.vehicleNumber.trim(),
        driverName: form.driverName.trim() || undefined,
        supplierId: form.supplierId ? (form.supplierId as Id<"suppliers">) : undefined,
        deliveryDate: form.deliveryDate,
        materialType: form.materialType.trim(),
        quantity: form.quantity.trim(),
        unit: form.unit,
        notes: form.notes.trim() || undefined,
        photoStorageIds: storageIds.length > 0 ? storageIds : undefined,
      });

      toast.success("Delivery challan submitted for approval");
      setDialogOpen(false);
      setForm(EMPTY_FORM);
      setPhotos([]);
      setPhotoPreviews([]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to submit");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleApprove(id: string) {
    try {
      await approveChallan({ id: id as Id<"deliveryChallans"> });
      toast.success("Challan approved");
    } catch {
      toast.error("Failed to approve");
    }
  }

  async function handleReject() {
    if (!rejectDialogId) return;
    try {
      await rejectChallan({ id: rejectDialogId as Id<"deliveryChallans">, rejectionNote: rejectNote || undefined });
      toast.success("Challan rejected");
      setRejectDialogId(null);
      setRejectNote("");
    } catch {
      toast.error("Failed to reject");
    }
  }

  async function handleDelete(id: string) {
    try {
      await removeChallan({ id: id as Id<"deliveryChallans"> });
      toast.success("Challan deleted");
    } catch {
      toast.error("Failed to delete");
    }
  }

  const filtered = (challans ?? []).filter((c) =>
    filterStatus === "all" ? true : c.status === filterStatus
  );

  const pendingCount = (challans ?? []).filter((c) => c.status === "pending").length;

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Truck className="w-6 h-6 text-primary" />
            Delivery Challans
          </h1>
          <p className="text-sm text-muted-foreground">Submit vehicle/material deliveries for admin approval</p>
        </div>
        <Button className="cursor-pointer" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> New Challan
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {(["pending", "approved", "rejected"] as const).map((s) => {
          const cfg = STATUS_CONFIG[s];
          const count = (challans ?? []).filter((c) => c.status === s).length;
          return (
            <Card key={s} className="py-3 cursor-pointer" onClick={() => setFilterStatus(filterStatus === s ? "all" : s)}>
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground capitalize">{cfg.label}</p>
                <p className={`text-2xl font-bold ${cfg.class.split(" ")[1]}`}>{count}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {["all", "pending", "approved", "rejected"].map((s) => (
          <button
            key={s}
            onClick={() => setFilterStatus(s)}
            className={`px-3 py-1 rounded-full text-sm font-medium cursor-pointer transition-colors ${
              filterStatus === s
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {s === "all" ? "All" : STATUS_CONFIG[s as keyof typeof STATUS_CONFIG].label}
            {s === "pending" && pendingCount > 0 && (
              <span className="ml-1.5 bg-yellow-500 text-white text-xs rounded-full px-1.5 py-0.5">{pendingCount}</span>
            )}
          </button>
        ))}
      </div>

      {/* List */}
      {challans === undefined ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Truck /></EmptyMedia>
            <EmptyTitle>No challans found</EmptyTitle>
            <EmptyDescription>Submit a delivery challan to log vehicle and material arrivals</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="w-4 h-4 mr-1" /> New Challan</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-3">
          {filtered.map((c) => {
            const cfg = STATUS_CONFIG[c.status];
            const StatusIcon = cfg.icon;
            const isExpanded = expandedId === c._id;
            return (
              <Card key={c._id} className="overflow-hidden">
                <CardContent className="p-0">
                  {/* Main row */}
                  <div className="px-4 py-3 flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Truck className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm">{c.vehicleNumber}</span>
                        <Badge className={`${cfg.class} border-0 text-xs`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {cfg.label}
                        </Badge>
                        {c.photoUrls.length > 0 && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Image className="w-3 h-3" /> {c.photoUrls.length}
                          </span>
                        )}
                      </div>
                      <p className="text-sm mt-0.5">
                        <span className="font-medium">{c.materialType}</span>
                        {" — "}{c.quantity} {c.unit}
                      </p>
                      <div className="flex flex-wrap gap-2 mt-1 text-xs text-muted-foreground">
                        <span>{c.siteName}</span>
                        <span>·</span>
                        <span>{c.deliveryDate}</span>
                        <span>·</span>
                        <span>By {c.submittedByName}</span>
                        {c.supplierName && <><span>·</span><span>{c.supplierName}</span></>}
                      </div>
                    </div>
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : c._id)}
                      className="cursor-pointer text-muted-foreground hover:text-foreground flex-shrink-0 mt-1"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Expanded */}
                  {isExpanded && (
                    <div className="border-t border-border px-4 py-3 space-y-3 bg-muted/20">
                      {c.driverName && (
                        <p className="text-sm"><span className="text-muted-foreground">Driver:</span> {c.driverName}</p>
                      )}
                      {c.notes && (
                        <p className="text-sm"><span className="text-muted-foreground">Notes:</span> {c.notes}</p>
                      )}
                      {c.rejectionNote && (
                        <p className="text-sm text-red-600"><span className="font-medium">Rejection reason:</span> {c.rejectionNote}</p>
                      )}

                      {/* Photos grid */}
                      {c.photoUrls.length > 0 && (
                        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                          {c.photoUrls.map((url, i) => url && (
                            <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                              <img
                                src={url}
                                alt={`Photo ${i + 1}`}
                                className="w-full aspect-square object-cover rounded-lg border border-border cursor-pointer hover:opacity-80 transition-opacity"
                              />
                            </a>
                          ))}
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2 flex-wrap pt-1">
                        {isAdmin && c.status === "pending" && (
                          <>
                            <Button size="sm" className="cursor-pointer bg-green-600 hover:bg-green-700 h-8" onClick={() => handleApprove(c._id)}>
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approve
                            </Button>
                            <Button size="sm" variant="destructive" className="cursor-pointer h-8" onClick={() => { setRejectDialogId(c._id); setRejectNote(""); }}>
                              <XCircle className="w-3.5 h-3.5 mr-1" /> Reject
                            </Button>
                          </>
                        )}
                        {(isAdmin || c.status === "pending") && (
                          <Button size="sm" variant="ghost" className="cursor-pointer h-8 text-destructive hover:text-destructive" onClick={() => handleDelete(c._id)}>
                            <Trash2 className="w-3.5 h-3.5 mr-1" /> Delete
                          </Button>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Mobile FAB */}
      <button
        onClick={() => setDialogOpen(true)}
        className="fixed bottom-20 right-5 z-20 sm:hidden w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        aria-label="New Challan"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Submit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(v) => { setDialogOpen(v); if (!v) { setPhotos([]); setPhotoPreviews([]); } }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Delivery Challan</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Site */}
            <div className="space-y-1.5">
              <Label>Site *</Label>
              <Select value={form.siteId} onValueChange={(v) => setForm({ ...form, siteId: v })}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger>
                <SelectContent>
                  {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name} ({s.city})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Vehicle + Driver */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Vehicle No. *</Label>
                <Input
                  placeholder="MH12AB1234"
                  value={form.vehicleNumber}
                  onChange={(e) => setForm({ ...form, vehicleNumber: e.target.value.toUpperCase() })}
                  className="uppercase"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Driver Name</Label>
                <Input
                  placeholder="Ramesh Kumar"
                  value={form.driverName}
                  onChange={(e) => setForm({ ...form, driverName: e.target.value })}
                />
              </div>
            </div>

            {/* Material + Qty */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Material Type *</Label>
                <Input
                  placeholder="Sand, Cement, Steel..."
                  value={form.materialType}
                  onChange={(e) => setForm({ ...form, materialType: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Delivery Date *</Label>
                <Input
                  type="date"
                  value={form.deliveryDate}
                  onChange={(e) => setForm({ ...form, deliveryDate: e.target.value })}
                />
              </div>
            </div>

            {/* Quantity + Unit */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Quantity *</Label>
                <Input
                  placeholder="50"
                  value={form.quantity}
                  onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Unit *</Label>
                <Select value={form.unit} onValueChange={(v) => setForm({ ...form, unit: v })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Supplier */}
            <div className="space-y-1.5">
              <Label>Supplier (optional)</Label>
              <Select value={form.supplierId || "none"} onValueChange={(v) => setForm({ ...form, supplierId: v === "none" ? "" : v })}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— No supplier —</SelectItem>
                  {(suppliers ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea
                placeholder="Any additional details about this delivery..."
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </div>

            {/* Photo Upload */}
            <div className="space-y-2">
              <Label>Photos (max 5)</Label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                capture="environment"
                className="hidden"
                onChange={handlePhotoChange}
              />
              {photoPreviews.length < 5 && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-border rounded-lg text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors cursor-pointer w-full justify-center"
                >
                  <Camera className="w-4 h-4" />
                  Tap to take photo or upload ({photoPreviews.length}/5)
                </button>
              )}
              {photoPreviews.length > 0 && (
                <div className="grid grid-cols-4 gap-2">
                  {photoPreviews.map((url, i) => (
                    <div key={i} className="relative group">
                      <img src={url} alt={`Preview ${i + 1}`} className="w-full aspect-square object-cover rounded-lg border border-border" />
                      <button
                        onClick={() => removePhoto(i)}
                        className="absolute top-1 right-1 w-5 h-5 bg-black/60 text-white rounded-full flex items-center justify-center cursor-pointer opacity-80 hover:opacity-100"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={submitting} onClick={() => void handleSubmit()}>
              {submitting ? "Submitting..." : "Submit Challan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject dialog */}
      <Dialog open={!!rejectDialogId} onOpenChange={() => setRejectDialogId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Reject Challan</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Optionally provide a reason for rejection:</p>
            <Textarea
              placeholder="e.g. Wrong material quantity, vehicle not verified..."
              rows={3}
              value={rejectNote}
              onChange={(e) => setRejectNote(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setRejectDialogId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={() => void handleReject()}>Reject</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function DeliveryChallansPage() {
  return (
    <Authenticated>
      <DeliveryChallansInner />
    </Authenticated>
  );
}
