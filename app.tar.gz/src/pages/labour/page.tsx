import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Plus, Search, Pencil, Trash2, Users, Link, Eye, CalendarCheck, ShieldCheck, ArrowRightLeft, IndianRupee, CheckCircle2 } from "lucide-react";
import { WhatsAppButton, WhatsAppPortalButton } from "@/components/whatsapp-button.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  mobile: z.string().optional(),
  aadhaarNumber: z.string().optional(),
  siteId: z.string().min(1, "Site is required"),
  labourType: z.enum(["contractor", "departmental"]).optional(),
  contractorId: z.string().optional(),
  designation: z.string().optional(),
  dailyRate: z.coerce.number().min(1, "Daily rate required"),
  joinDate: z.string().optional(),
  isSafetySupervisor: z.boolean().optional(),
  isSiteSupervisor: z.boolean().optional(),
  isSiteIncharge: z.boolean().optional(),
  workerCode: z.string().optional(),
});
type LabourForm = z.infer<typeof schema>;

function copyPortalLink(token: string) {
  const url = `${window.location.origin}/portal/labour?token=${token}`;
  void navigator.clipboard.writeText(url);
  toast.success("Labour portal link copied!");
}

export default function Labour() {
  const navigate = useNavigate();
  const labourers = useQuery(api.labourers.list, {});
  const sites = useQuery(api.sites.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const pendingRates = useQuery(api.labourers.listPendingRates, {});
  const createLabourer = useMutation(api.labourers.create);
  const updateLabourer = useMutation(api.labourers.update);
  const removeLabourer = useMutation(api.labourers.remove);
  const bulkTransferMut = useMutation(api.labourers.bulkTransfer);
  const approveRateMut = useMutation(api.labourers.approveRate);

  const [search, setSearch] = useState("");
  const [filterSiteId, setFilterSiteId] = useState("all");
  const [filterContractorId, setFilterContractorId] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [transferOpen, setTransferOpen] = useState(false);
  const [transferSiteId, setTransferSiteId] = useState("");
  const [transferContractorId, setTransferContractorId] = useState("none");
  const [transferLabourType, setTransferLabourType] = useState("none");
  const [transferDate, setTransferDate] = useState(new Date().toISOString().slice(0, 10));
  const [rateApprovalId, setRateApprovalId] = useState<Id<"labourers"> | null>(null);
  const [finalRate, setFinalRate] = useState("");

  const form = useForm<LabourForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", dailyRate: 0, siteId: "" },
  });

  const siteMap = Object.fromEntries((sites ?? []).map((s) => [s._id, s.name]));
  const contractorMap = Object.fromEntries((contractors ?? []).map((c) => [c._id, c.name]));

  const filtered = (labourers ?? []).filter((l) => {
    const matchSearch = l.name.toLowerCase().includes(search.toLowerCase()) ||
      (l.mobile ?? "").includes(search) ||
      (l.designation ?? "").toLowerCase().includes(search.toLowerCase());
    const matchSite = filterSiteId === "all" || l.siteId === filterSiteId;
    const matchContractor = filterContractorId === "all" || l.contractorId === filterContractorId;
    const matchStatus =
      filterStatus === "all" ||
      (filterStatus === "active" && l.isActive) ||
      (filterStatus === "inactive" && !l.isActive);
    return matchSearch && matchSite && matchContractor && matchStatus;
  });

  const activeCount = (labourers ?? []).filter((l) => l.isActive).length;

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleAll() {
    const allIds = filtered.map((l) => l._id);
    const allSelected = allIds.every((id) => selectedIds.has(id));
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(allIds));
    }
  }

  function clearSelection() {
    setSelectedIds(new Set());
  }

  function openCreate() {
    setEditId(null);
    form.reset({ name: "", dailyRate: 0, siteId: "" });
    setDialogOpen(true);
  }
  function openEdit(l: (typeof filtered)[number]) {
    setEditId(l._id);
    form.reset({
      name: l.name,
      mobile: l.mobile ?? "",
      aadhaarNumber: l.aadhaarNumber ?? "",
      siteId: l.siteId,
      labourType: (l.labourType as "contractor" | "departmental" | undefined) ?? undefined,
      contractorId: l.contractorId ?? "",
      designation: l.designation ?? "",
      dailyRate: l.dailyRate,
      joinDate: l.joinDate ?? "",
      isSafetySupervisor: l.isSafetySupervisor ?? false,
      isSiteSupervisor: l.isSiteSupervisor ?? false,
      isSiteIncharge: l.isSiteIncharge ?? false,
      workerCode: l.workerCode ?? "",
    });
    setDialogOpen(true);
  }

  async function onSubmit(data: LabourForm) {
    try {
      const payload = {
        ...data,
        siteId: data.siteId as Id<"sites">,
        contractorId: (data.labourType === "contractor" && data.contractorId) ? data.contractorId as Id<"contractors"> : undefined,
        labourType: data.labourType ?? undefined,
        mobile: data.mobile || undefined,
        designation: data.designation || undefined,
        joinDate: data.joinDate || undefined,
      };
      if (editId) {
        await updateLabourer({ id: editId as Id<"labourers">, ...payload });
        toast.success("Labour updated");
      } else {
        await createLabourer(payload);
        toast.success("Labour added — portal link generated!");
      }
      setDialogOpen(false);
    } catch { toast.error("Something went wrong"); }
  }

  async function handleBulkTransfer() {
    if (!transferSiteId) { toast.error("Site select karo"); return; }
    try {
      const result = await bulkTransferMut({
        labourerIds: Array.from(selectedIds) as Id<"labourers">[],
        toSiteId: transferSiteId as Id<"sites">,
        toContractorId: (transferLabourType === "contractor" && transferContractorId !== "none") ? transferContractorId as Id<"contractors"> : undefined,
        clearContractor: transferLabourType === "departmental" ? true : transferContractorId === "none" ? undefined : undefined,
        labourType: (transferLabourType === "contractor" || transferLabourType === "departmental") ? transferLabourType : undefined,
        transferDate: transferDate || undefined,
      });
      toast.success(`${result.transferred} labourers transferred successfully!`);
      setTransferOpen(false);
      setSelectedIds(new Set());
    } catch { toast.error("Transfer failed"); }
  }

  async function handleApproveRate() {
    if (!rateApprovalId) return;
    const rate = parseFloat(finalRate);
    if (isNaN(rate) || rate <= 0) { toast.error("Sahi rate daalo"); return; }
    try {
      await approveRateMut({ id: rateApprovalId, finalRate: rate });
      toast.success("Rate finalize ho gaya!");
      setRateApprovalId(null);
      setFinalRate("");
    } catch { toast.error("Rate approve nahi hua"); }
  }

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Labour Management</h1>
          <p className="text-muted-foreground text-sm">
            {labourers ? `${labourers.length} total · ${activeCount} active` : "Loading..."}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" className="cursor-pointer hidden sm:flex" onClick={() => navigate("/attendance")}>
            <CalendarCheck className="w-4 h-4 mr-1" /> Attendance
          </Button>
          {selectedIds.size > 0 && (
            <Button variant="secondary" className="cursor-pointer" onClick={() => setTransferOpen(true)}>
              <ArrowRightLeft className="w-4 h-4 mr-1" /> Transfer ({selectedIds.size})
            </Button>
          )}
          <Button onClick={openCreate} className="cursor-pointer">
            <Plus className="w-4 h-4 mr-1" /> Add Labour
          </Button>
        </div>
      </div>

      {/* Rate Approval Pending Banner */}
      {pendingRates && pendingRates.length > 0 && (
        <Card className="border-amber-300 bg-amber-50 py-3">
          <CardContent className="px-4 py-0">
            <div className="flex items-center gap-2 mb-3">
              <IndianRupee className="w-5 h-5 text-amber-600" />
              <h3 className="font-semibold text-amber-800">Rate Approval Pending ({pendingRates.length})</h3>
              <Badge className="bg-amber-200 text-amber-700 border-amber-300">Admin Action Required</Badge>
            </div>
            <div className="space-y-2">
              {pendingRates.map((lab) => (
                <div key={lab._id} className="flex items-center justify-between bg-white rounded-lg px-3 py-2 border border-amber-200">
                  <div>
                    <p className="font-medium text-sm text-gray-900">{lab.name}</p>
                    <p className="text-xs text-gray-500">{lab.siteName} · {lab.designation ?? "Labour"}</p>
                    {lab.suggestedRate && lab.suggestedRate > 0 && (
                      <p className="text-xs text-amber-600 font-medium">Supervisor ne suggest kiya: ₹{lab.suggestedRate}/day</p>
                    )}
                  </div>
                  <Button
                    size="sm"
                    className="cursor-pointer bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => {
                      setRateApprovalId(lab._id);
                      setFinalRate(lab.suggestedRate ? String(lab.suggestedRate) : "");
                    }}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Rate Set Karo
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary cards */}
      {labourers && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total Labour", value: labourers.length, color: "text-foreground" },
            { label: "Active", value: activeCount, color: "text-green-500" },
            { label: "Sites", value: new Set(labourers.map((l) => l.siteId)).size, color: "text-blue-500" },
            { label: "Contractors", value: new Set(labourers.filter((l) => l.contractorId).map((l) => l.contractorId)).size, color: "text-orange-500" },
          ].map((stat) => (
            <Card key={stat.label} className="py-3">
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search name, mobile, designation..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterSiteId} onValueChange={setFilterSiteId}>
          <SelectTrigger className="w-full sm:w-44 cursor-pointer">
            <SelectValue placeholder="All Sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterContractorId} onValueChange={setFilterContractorId}>
          <SelectTrigger className="w-full sm:w-44 cursor-pointer">
            <SelectValue placeholder="All Contractors" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Contractors</SelectItem>
            {contractors?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-36 cursor-pointer">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bulk Delete Bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        onDelete={async () => {
          for (const id of selectedIds) {
            await removeLabourer({ id: id as Id<"labourers"> });
          }
          clearSelection();
        }}
        onClear={clearSelection}
        itemLabel="labourer"
      />

      {/* Table */}
      {!labourers ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Users /></EmptyMedia>
            <EmptyTitle>No labourers found</EmptyTitle>
            <EmptyDescription>Add labourers to sites to track attendance and salary</EmptyDescription>
          </EmptyHeader>
          <EmptyContent><Button onClick={openCreate} size="sm" className="cursor-pointer">Add Labour</Button></EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox
                      checked={filtered.length > 0 && filtered.every((l) => selectedIds.has(l._id))}
                      indeterminate={filtered.some((l) => selectedIds.has(l._id)) && !filtered.every((l) => selectedIds.has(l._id))}
                      onCheckedChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Designation</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Contractor</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Daily Rate</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden xl:table-cell">Join Date</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((l) => (
                  <tr key={l._id} className="hover:bg-muted/30 cursor-pointer" onClick={() => navigate(`/labour/${l._id}`)}>
                    <td className="px-4 py-3 w-10" onClick={(e) => e.stopPropagation()}>
                      <BulkCheckbox
                        checked={selectedIds.has(l._id)}
                        onCheckedChange={() => toggleSelect(l._id)}
                      />
                    </td>
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                          <span className="text-orange-500 font-bold text-xs">{l.name[0]?.toUpperCase()}</span>
                        </div>
                        <div>
                          <p className="font-medium">{l.name}</p>
                          {l.mobile && <p className="text-xs text-muted-foreground">{l.mobile}</p>}
                          {l.isSafetySupervisor && (
                            <span className="inline-flex items-center gap-0.5 text-xs text-orange-500 font-medium mt-0.5">
                              <ShieldCheck className="w-3 h-3" /> Safety Sup.
                            </span>
                          )}
                          {l.isSiteSupervisor && (
                            <span className="inline-flex items-center gap-0.5 text-xs text-blue-500 font-medium mt-0.5 ml-1">
                              <Users className="w-3 h-3" /> Site Sup.
                              {l.workerCode && <span className="font-mono ml-1">({l.workerCode})</span>}
                            </span>
                          )}
                          {(l as typeof l & { isSiteIncharge?: boolean }).isSiteIncharge && (
                            <span className="inline-flex items-center gap-0.5 text-xs text-purple-500 font-medium mt-0.5 ml-1">
                              <ShieldCheck className="w-3 h-3" /> Site Incharge
                              {l.workerCode && <span className="font-mono ml-1">({l.workerCode})</span>}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{l.designation ?? "—"}</td>
                    <td className="px-4 py-3 hidden sm:table-cell text-muted-foreground text-xs">{siteMap[l.siteId] ?? "—"}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground text-xs">{l.contractorId ? contractorMap[l.contractorId] ?? "—" : <span className="text-xs italic">Direct</span>}</td>
                    <td className="px-4 py-3 hidden lg:table-cell font-medium">₹{l.dailyRate.toLocaleString("en-IN")}/day</td>
                    <td className="px-4 py-3 hidden xl:table-cell text-muted-foreground text-xs">{l.joinDate ?? "—"}</td>
                    <td className="px-4 py-3">
                      <Badge variant={l.isActive ? "default" : "secondary"} className="text-xs">
                        {l.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </td>
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        {l.mobile && <WhatsAppButton mobile={l.mobile} />}
                        {l.portalToken && (
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" title="Copy portal link"
                            onClick={() => copyPortalLink(l.portalToken!)}>
                            <Link className="w-3.5 h-3.5 text-orange-500" />
                          </Button>
                        )}
                        {l.portalToken && l.mobile && (
                          <WhatsAppPortalButton mobile={l.mobile} portalToken={l.portalToken} labourName={l.name} />
                        )}
                        {l.workerCode && (l.isSiteSupervisor || l.isSafetySupervisor) && (
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" title="Copy Supervisor Portal link"
                            onClick={() => {
                              const url = `${window.location.origin}/portal/supervisor`;
                              void navigator.clipboard.writeText(url + "\nWorker ID: " + l.workerCode);
                              toast.success(`Supervisor portal link copied! Worker ID: ${l.workerCode}`);
                            }}>
                            <Users className="w-3.5 h-3.5 text-blue-500" />
                          </Button>
                        )}
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                          onClick={() => navigate(`/labour/${l._id}`)}>
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                          onClick={() => openEdit(l)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                          onClick={() => setDeleteId(l._id)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editId ? "Edit Labour" : "Add Labour"}</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Full Name *</FormLabel>
                    <FormControl><Input placeholder="Mohan Singh" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Site *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger></FormControl>
                      <SelectContent>{sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                {/* Labour Type */}
                <FormField control={form.control} name="labourType" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Labour Type *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select type" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="contractor">Contractor Labour</SelectItem>
                        <SelectItem value="departmental">Departmental Labour</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                {/* Contractor — only shown when labour type is "contractor" */}
                {form.watch("labourType") === "contractor" && (
                  <FormField control={form.control} name="contractorId" render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Contractor</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ?? ""}>
                        <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select contractor" /></SelectTrigger></FormControl>
                        <SelectContent>
                          {contractors?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}
                <FormField control={form.control} name="designation" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Designation</FormLabel>
                    <FormControl><Input placeholder="Mason / Helper / Welder" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="dailyRate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Daily Rate (₹) *</FormLabel>
                    <FormControl><Input type="number" placeholder="500" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile</FormLabel>
                    <FormControl><Input placeholder="9876543210" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="aadhaarNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aadhaar Number</FormLabel>
                    <FormControl><Input placeholder="XXXX XXXX XXXX" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="joinDate" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Join Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              {/* Safety Supervisor Checkbox */}
              <FormField control={form.control} name="isSafetySupervisor" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-orange-500/30 bg-orange-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={e => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-orange-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <ShieldCheck className="w-4 h-4 text-orange-500" /> Safety Supervisor hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Is labour ko Safety Supervisor mark karo</p>
                  </div>
                </FormItem>
              )} />
              {/* Site Supervisor Checkbox */}
              <FormField control={form.control} name="isSiteSupervisor" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-blue-500/30 bg-blue-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={e => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-blue-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <Users className="w-4 h-4 text-blue-500" /> Site Supervisor hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Hajri, Advance, Report karne ka portal access milega</p>
                  </div>
                </FormItem>
              )} />
              {/* Site Incharge Checkbox */}
              <FormField control={form.control} name="isSiteIncharge" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-purple-500/30 bg-purple-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={e => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-purple-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <ShieldCheck className="w-4 h-4 text-purple-500" /> Site Incharge hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Poori site ka management, workers, materials, reports sab handle karega</p>
                  </div>
                </FormItem>
              )} />
              {/* Worker Code */}
              <FormField control={form.control} name="workerCode" render={({ field }) => (
                <FormItem>
                  <FormLabel>Worker ID (Portal Login Code)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. S1234 (auto-generate hoga agar blank chodo)"
                      {...field}
                      onChange={e => field.onChange(e.target.value.toUpperCase())}
                    />
                  </FormControl>
                  <p className="text-xs text-muted-foreground">Supervisor is code se portal mein login karega</p>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Add Labour"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Labour Record</DialogTitle></DialogHeader>
          <p className="text-muted-foreground text-sm">
            This will permanently delete the labourer and all associated records. This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteId) return;
              try {
                await removeLabourer({ id: deleteId as Id<"labourers"> });
                toast.success("Labour deleted");
              } catch { toast.error("Failed to delete"); }
              setDeleteId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Transfer Dialog */}
      <Dialog open={transferOpen} onOpenChange={setTransferOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-orange-500" />
              Bulk Transfer — {selectedIds.size} Labourer{selectedIds.size !== 1 ? "s" : ""}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Target Site *</label>
              <Select value={transferSiteId} onValueChange={setTransferSiteId}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Site select karo" /></SelectTrigger>
                <SelectContent>
                  {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Labour Type (optional)</label>
              <Select value={transferLabourType} onValueChange={setTransferLabourType}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Type change karo (optional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Change Mat Karo</SelectItem>
                  <SelectItem value="contractor">Contractor Labour</SelectItem>
                  <SelectItem value="departmental">Departmental Labour</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {transferLabourType === "contractor" && (
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Contractor (optional)</label>
                <Select value={transferContractorId} onValueChange={setTransferContractorId}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Contractor select karo" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Koi Nahi</SelectItem>
                    {contractors?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Transfer Date</label>
              <Input type="date" value={transferDate} onChange={(e) => setTransferDate(e.target.value)} />
            </div>
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-sm text-orange-800">
              Selected labourers: <span className="font-bold">{selectedIds.size}</span> ko <span className="font-bold">{sites?.find(s => s._id === transferSiteId)?.name ?? "—"}</span> pe transfer kiya jayega.
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setTransferOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" onClick={handleBulkTransfer} disabled={!transferSiteId}>
              <ArrowRightLeft className="w-4 h-4 mr-1" /> Transfer Karo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rate Approval Dialog */}
      <Dialog open={!!rateApprovalId} onOpenChange={() => { setRateApprovalId(null); setFinalRate(""); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <IndianRupee className="w-5 h-5 text-green-600" />
              Labour Rate Finalize Karo
            </DialogTitle>
          </DialogHeader>
          {rateApprovalId && (() => {
            const lab = pendingRates?.find((l) => l._id === rateApprovalId);
            return lab ? (
              <div className="space-y-4 py-2">
                <div className="bg-gray-50 rounded-lg p-3 space-y-1">
                  <p className="font-semibold text-gray-900">{lab.name}</p>
                  <p className="text-sm text-gray-500">{lab.siteName} · {lab.designation ?? "Labour"}</p>
                  {lab.suggestedRate && lab.suggestedRate > 0 && (
                    <p className="text-sm text-amber-600">Supervisor ka suggested rate: <span className="font-bold">₹{lab.suggestedRate}/day</span></p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-gray-700">Final Daily Rate (₹) *</label>
                  <Input
                    type="number"
                    placeholder="e.g. 650"
                    value={finalRate}
                    onChange={(e) => setFinalRate(e.target.value)}
                    className="text-gray-900 bg-white"
                  />
                  <p className="text-xs text-muted-foreground">Yeh rate final hoga. Baad mein bhi change kar sakte hain.</p>
                </div>
              </div>
            ) : null;
          })()}
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => { setRateApprovalId(null); setFinalRate(""); }}>Cancel</Button>
            <Button className="cursor-pointer bg-green-600 hover:bg-green-700 text-white" onClick={handleApproveRate} disabled={!finalRate}>
              <CheckCircle2 className="w-4 h-4 mr-1" /> Rate Approve Karo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
