import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { ArrowLeft, Phone, MapPin, Building2, Users2, IndianRupee, CalendarCheck, Link, CalendarDays } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { format, getDaysInMonth, startOfMonth } from "date-fns";

const STATUS_CONFIG = {
  present: { label: "P", color: "bg-green-500 text-white", full: "Present" },
  absent: { label: "A", color: "bg-red-500 text-white", full: "Absent" },
  half_day: { label: "H", color: "bg-yellow-500 text-white", full: "Half Day" },
  holiday: { label: "Ho", color: "bg-blue-500 text-white", full: "Holiday" },
} as const;

type AttendanceStatus = keyof typeof STATUS_CONFIG;

function AttendanceGrid({
  labourerId,
  siteId,
  month,
}: {
  labourerId: Id<"labourers">;
  siteId: Id<"sites">;
  month: string;
}) {
  const attendance = useQuery(api.labourers.getLabourerAttendance, { labourerId, month });
  const markAttendance = useMutation(api.labourers.markAttendance);

  const attendanceMap = Object.fromEntries(
    (attendance ?? []).map((a) => [a.date, a.status])
  );

  const [year, mon] = month.split("-").map(Number);
  const daysInMonth = getDaysInMonth(startOfMonth(new Date(year, mon - 1)));
  const days = Array.from({ length: daysInMonth }, (_, i) => {
    const d = i + 1;
    return `${month}-${String(d).padStart(2, "0")}`;
  });

  const presentCount = Object.values(attendanceMap).filter((s) => s === "present").length;
  const halfCount = Object.values(attendanceMap).filter((s) => s === "half_day").length;
  const absentCount = Object.values(attendanceMap).filter((s) => s === "absent").length;

  async function cycle(date: string) {
    const current = attendanceMap[date] as AttendanceStatus | undefined;
    const order: AttendanceStatus[] = ["present", "half_day", "absent", "holiday"];
    const idx = current ? order.indexOf(current) : -1;
    const next = order[(idx + 1) % order.length];
    try {
      await markAttendance({ siteId, labourerId, date, status: next });
    } catch {
      toast.error("Failed to mark attendance");
    }
  }

  if (!attendance) return <div className="space-y-1">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>;

  return (
    <div className="space-y-4">
      <div className="flex gap-4 text-sm flex-wrap">
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-green-500 inline-block" /><span className="text-muted-foreground">Present: <strong className="text-foreground">{presentCount}</strong></span></span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-yellow-500 inline-block" /><span className="text-muted-foreground">Half Day: <strong className="text-foreground">{halfCount}</strong></span></span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-red-500 inline-block" /><span className="text-muted-foreground">Absent: <strong className="text-foreground">{absentCount}</strong></span></span>
        <span className="text-muted-foreground">Effective days: <strong className="text-foreground">{presentCount + halfCount * 0.5}</strong></span>
      </div>
      <div className="grid grid-cols-7 gap-1.5">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="text-center text-xs font-medium text-muted-foreground py-1">{d}</div>
        ))}
        {/* Empty cells for day offset */}
        {Array.from({ length: new Date(days[0]).getDay() }).map((_, i) => (
          <div key={`empty-${i}`} />
        ))}
        {days.map((date) => {
          const status = attendanceMap[date] as AttendanceStatus | undefined;
          const cfg = status ? STATUS_CONFIG[status] : null;
          const dayNum = parseInt(date.split("-")[2]);
          return (
            <button
              key={date}
              onClick={() => void cycle(date)}
              title={`${date} — ${cfg?.full ?? "Not marked"}`}
              className={`rounded-md text-xs font-bold py-1.5 text-center cursor-pointer transition-colors border border-border ${cfg ? cfg.color : "bg-muted/40 text-muted-foreground hover:bg-muted"}`}
            >
              {dayNum}
              {cfg && <div className="text-[9px] font-normal leading-tight">{cfg.label}</div>}
            </button>
          );
        })}
      </div>
      <p className="text-xs text-muted-foreground">Click a date to cycle: Not marked → Present → Half Day → Absent → Holiday</p>
    </div>
  );
}

export default function LabourDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const detail = useQuery(
    api.labourers.getDetail,
    id ? { id: id as Id<"labourers"> } : "skip"
  );

  const today = new Date();
  const [selectedMonth, setSelectedMonth] = useState(format(today, "yyyy-MM"));

  // Generate last 12 months
  const months = Array.from({ length: 12 }, (_, i) => {
    const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
    return { value: format(d, "yyyy-MM"), label: format(d, "MMMM yyyy") };
  });

  function copyPortalLink(token: string) {
    const url = `${window.location.origin}/portal/labour?token=${token}`;
    void navigator.clipboard.writeText(url);
    toast.success("Labour portal link copied!");
  }

  if (!detail) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const { labourer, site, contractor, stats, salaryEntries, advances } = detail;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" className="cursor-pointer mt-1" onClick={() => navigate("/labour")}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
              <span className="text-orange-500 font-bold text-xl">{labourer.name[0]?.toUpperCase()}</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold">{labourer.name}</h1>
              <div className="flex items-center gap-2 flex-wrap mt-0.5">
                {labourer.designation && <Badge variant="secondary">{labourer.designation}</Badge>}
                <Badge variant={labourer.isActive ? "default" : "secondary"}>
                  {labourer.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
            </div>
          </div>
        </div>
        {labourer.portalToken && (
          <Button variant="secondary" className="cursor-pointer" onClick={() => copyPortalLink(labourer.portalToken!)}>
            <Link className="w-4 h-4 mr-1" /> Portal Link
          </Button>
        )}
      </div>

      {/* Info cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <IndianRupee className="w-8 h-8 text-green-500 bg-green-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Total Earned</p>
              <p className="font-bold text-lg">₹{stats.totalEarned.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <CalendarCheck className="w-8 h-8 text-blue-500 bg-blue-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Days Present</p>
              <p className="font-bold text-lg">{stats.presentDays} days</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <CalendarDays className="w-8 h-8 text-yellow-500 bg-yellow-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Half Days</p>
              <p className="font-bold text-lg">{stats.halfDays} days</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <IndianRupee className="w-8 h-8 text-orange-500 bg-orange-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Daily Rate</p>
              <p className="font-bold text-lg">₹{labourer.dailyRate.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <IndianRupee className="w-8 h-8 text-red-500 bg-red-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Total Advance</p>
              <p className="font-bold text-lg text-red-500">₹{(stats.totalAdvance ?? 0).toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column — details */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Labour Info</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {labourer.mobile && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{labourer.mobile}</span>
                </div>
              )}
              {labourer.aadhaarNumber && (
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground text-xs">Aadhaar:</span>
                  <span className="font-mono">{labourer.aadhaarNumber}</span>
                </div>
              )}
              {site && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{site.name} — {site.city}</span>
                </div>
              )}
              {contractor && (
                <div className="flex items-center gap-2">
                  <Users2 className="w-4 h-4 text-muted-foreground" />
                  <span>{contractor.name}</span>
                </div>
              )}
              {!contractor && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground italic">Direct (no contractor)</span>
                </div>
              )}
              {labourer.joinDate && (
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-muted-foreground" />
                  <span>Joined: {labourer.joinDate}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Salary history */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Salary History</CardTitle></CardHeader>
            <CardContent className="p-0">
              {salaryEntries.length === 0 ? (
                <p className="text-muted-foreground text-sm px-4 pb-4">No salary records yet</p>
              ) : (
                <div className="divide-y divide-border">
                  {salaryEntries.slice(0, 8).map((e) => (
                    <div key={e._id} className="px-4 py-3 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-medium">{e.month}</p>
                        <p className="text-xs text-muted-foreground">{e.daysWorked}d worked · ₹{e.dailyRate}/day</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">₹{e.netAmount.toLocaleString("en-IN")}</p>
                        {e.deductions > 0 && <p className="text-xs text-red-500">-₹{e.deductions.toLocaleString("en-IN")}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          {/* Advances history */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Advance History</CardTitle></CardHeader>
            <CardContent className="p-0">
              {advances.length === 0 ? (
                <p className="text-muted-foreground text-sm px-4 pb-4">Koi advance nahi diya abhi tak</p>
              ) : (
                <div className="divide-y divide-border">
                  {advances.map((adv) => (
                    <div key={adv._id} className="px-4 py-3 flex items-center justify-between text-sm">
                      <div>
                        <p className="font-medium">{adv.date}</p>
                        {adv.reason && <p className="text-xs text-muted-foreground">{adv.reason}</p>}
                      </div>
                      <p className="font-bold text-red-500">₹{adv.amount.toLocaleString("en-IN")}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between gap-4">
              <CardTitle className="text-base">Attendance</CardTitle>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-44 cursor-pointer">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              {site && (
                <AttendanceGrid
                  labourerId={labourer._id as Id<"labourers">}
                  siteId={site._id as Id<"sites">}
                  month={selectedMonth}
                />
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
