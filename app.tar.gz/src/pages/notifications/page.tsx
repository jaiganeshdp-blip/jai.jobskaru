import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { toast } from "sonner";
import { Bell, Mail, Settings2 } from "lucide-react";

const EVENT_LABELS: Record<string, { label: string; description: string }> = {
  payment_received:   { label: "Payment Received",       description: "When a client payment is recorded on an invoice" },
  payment_made:       { label: "Payment Made",           description: "When an outgoing payment is recorded to a supplier or contractor" },
  work_order_issued:  { label: "Work Order Issued",      description: "When a new work order is created" },
  work_order_amended: { label: "Work Order Amended",     description: "When a work order is updated or amended" },
  salary_processed:   { label: "Salary Submitted",       description: "When a salary sheet is submitted for approval" },
  salary_approved:    { label: "Salary Approved",        description: "When a salary sheet is approved" },
  material_approved:  { label: "Material Approved",      description: "When a material delivery is approved" },
  material_rejected:  { label: "Material Rejected",      description: "When a material delivery is rejected" },
  invoice_sent:       { label: "Invoice Sent",           description: "When an invoice is marked as sent to a client" },
  invoice_overdue:    { label: "Invoice Overdue",        description: "When an invoice is marked as overdue" },
};

type EventsObj = {
  payment_received: boolean;
  payment_made: boolean;
  work_order_issued: boolean;
  work_order_amended: boolean;
  salary_processed: boolean;
  salary_approved: boolean;
  material_approved: boolean;
  material_rejected: boolean;
  invoice_sent: boolean;
  invoice_overdue: boolean;
};

type EventKey = keyof EventsObj;

type EventsState = Record<EventKey, boolean>;

function NotificationsPageInner() {
  const prefs = useQuery(api.notifications.getPreferences, {});
  const savePreferences = useMutation(api.notifications.savePreferences);
  const notifications = useQuery(api.notifications.list, { limit: 50 });
  const markAllRead = useMutation(api.notifications.markAllRead);
  const markRead = useMutation(api.notifications.markRead);

  const [emailEnabled, setEmailEnabled] = useState(true);
  const [inAppEnabled, setInAppEnabled] = useState(true);
  const [emailAddress, setEmailAddress] = useState("");
  const [events, setEvents] = useState<EventsState>({
    payment_received: true,
    payment_made: true,
    work_order_issued: true,
    work_order_amended: true,
    salary_processed: true,
    salary_approved: true,
    material_approved: true,
    material_rejected: true,
    invoice_sent: true,
    invoice_overdue: true,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (prefs) {
      setEmailEnabled(prefs.emailEnabled);
      setInAppEnabled(prefs.inAppEnabled);
      setEmailAddress(prefs.emailAddress ?? "");
      setEvents({ ...prefs.events } as EventsState);
    }
  }, [prefs]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await savePreferences({
        emailEnabled,
        inAppEnabled,
        events,
        emailAddress: emailAddress || undefined,
      });
      toast.success("Notification preferences saved");
    } catch {
      toast.error("Failed to save preferences");
    } finally {
      setSaving(false);
    }
  };

  const toggleEvent = (key: EventKey) =>
    setEvents((prev) => ({ ...prev, [key]: !prev[key] }));

  if (!prefs) return (
    <div className="p-6 space-y-4">
      {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
    </div>
  );

  const TYPE_ICONS: Record<string, string> = {
    payment_received: "💰", payment_made: "💳", work_order_issued: "📋",
    work_order_amended: "📝", salary_processed: "📊", salary_approved: "✅",
    material_approved: "✅", material_rejected: "❌", invoice_sent: "📄", invoice_overdue: "⚠️",
  };

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold">Notifications</h1>
        <p className="text-muted-foreground text-sm mt-1">Manage your notification preferences and view recent activity</p>
      </div>

      {/* Channels */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Settings2 className="h-4 w-4" /> Notification Channels
          </CardTitle>
          <CardDescription>Choose how you want to be notified</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Bell className="h-4 w-4 text-blue-400" />
              </div>
              <div>
                <p className="font-medium text-sm">In-App Notifications</p>
                <p className="text-xs text-muted-foreground">Bell icon in the top navigation</p>
              </div>
            </div>
            <Switch checked={inAppEnabled} onCheckedChange={setInAppEnabled} />
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <Mail className="h-4 w-4 text-green-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">Email Notifications</p>
                  <p className="text-xs text-muted-foreground">Requires a verified sender in Hercules Emails tab</p>
                </div>
              </div>
              <Switch checked={emailEnabled} onCheckedChange={setEmailEnabled} />
            </div>
            {emailEnabled && (
              <div className="ml-11 space-y-1">
                <Label className="text-xs">Email Address</Label>
                <Input
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  placeholder="you@example.com"
                  type="email"
                  className="h-8 text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  Also set <code className="bg-muted px-1 rounded text-[11px]">CONSTRUCTPRO_SENDER_EMAIL</code> in Secrets to a verified email.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Events */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Event Subscriptions</CardTitle>
          <CardDescription>Choose which events trigger notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-1">
          {Object.entries(EVENT_LABELS).map(([key, { label, description }]) => (
            <div key={key} className="flex items-center justify-between py-3 border-b border-border/50 last:border-0">
              <div className="flex items-center gap-3">
                <span className="text-base">{TYPE_ICONS[key] ?? "🔔"}</span>
                <div>
                  <p className="text-sm font-medium">{label}</p>
                  <p className="text-xs text-muted-foreground">{description}</p>
                </div>
              </div>
              <Switch
                checked={events[key as EventKey] ?? true}
                onCheckedChange={() => toggleEvent(key as EventKey)}
                disabled={!inAppEnabled && !emailEnabled}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Button onClick={handleSave} disabled={saving}>
        {saving ? "Saving..." : "Save Preferences"}
      </Button>

      {/* Recent Notifications */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Recent Notifications</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => markAllRead()}>
              Mark all read
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {!notifications || notifications.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground text-sm">No notifications yet.</div>
          ) : (
            <div className="divide-y divide-border">
              {notifications.map((n) => (
                <div
                  key={n._id}
                  className={`flex items-start gap-3 px-4 py-3 cursor-pointer hover:bg-muted/30 transition-colors ${!n.isRead ? "bg-primary/5" : ""}`}
                  onClick={() => markRead({ id: n._id })}
                >
                  <span className="text-lg mt-0.5">{TYPE_ICONS[n.type] ?? "🔔"}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{n.title}</p>
                      {!n.isRead && <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />}
                    </div>
                    <p className="text-xs text-muted-foreground">{n.message}</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-0.5">
                      {new Date(n._creationTime).toLocaleString("en-IN")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function NotificationsPage() {
  return (
    <Authenticated>
      <NotificationsPageInner />
    </Authenticated>
  );
}
