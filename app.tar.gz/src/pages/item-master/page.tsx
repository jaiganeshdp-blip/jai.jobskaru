import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import { ConvexError } from "convex/values";
import { Plus, Search, Pencil, Trash2, Package, PackageX } from "lucide-react";

const UNIT_OPTIONS = ["nos", "sqft", "sqm", "rmt", "cum", "kg", "ton", "bag", "ltr", "job", "lumpsum"];

type CatalogItem = {
  _id: Id<"catalogItems">;
  name: string;
  defaultUnit: string;
  defaultRate: number;
  category?: string;
  hsnCode?: string;
  isActive: boolean;
};

function ItemMasterInner() {
  const meQuery = useQuery(api.users.getCurrentUserQuery, {});
  const isSuperAdmin = meQuery?.role === "super_admin";

  const items = useQuery(api.catalogItems.list, {});
  const createItem = useMutation(api.catalogItems.create);
  const updateItem = useMutation(api.catalogItems.update);
  const removeItem = useMutation(api.catalogItems.remove);

  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<Id<"catalogItems"> | null>(null);
  const [deleteId, setDeleteId] = useState<Id<"catalogItems"> | null>(null);

  const [name, setName] = useState("");
  const [unit, setUnit] = useState("nos");
  const [rate, setRate] = useState("");
  const [category, setCategory] = useState("");
  const [hsnCode, setHsnCode] = useState("");
  const [saving, setSaving] = useState(false);

  const filtered = (items ?? []).filter((it) =>
    it.name.toLowerCase().includes(search.toLowerCase()) ||
    (it.category ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setName(""); setUnit("nos"); setRate(""); setCategory(""); setHsnCode("");
    setDialogOpen(true);
  };

  const openEdit = (it: CatalogItem) => {
    setEditId(it._id);
    setName(it.name);
    setUnit(it.defaultUnit);
    setRate(String(it.defaultRate));
    setCategory(it.category ?? "");
    setHsnCode(it.hsnCode ?? "");
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!name.trim()) { toast.error("Item ka naam daalein"); return; }
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        defaultUnit: unit,
        defaultRate: Number(rate) || 0,
        category: category.trim() || undefined,
        hsnCode: hsnCode.trim() || undefined,
      };
      if (editId) {
        await updateItem({ id: editId, ...payload });
        toast.success("Item update ho gaya");
      } else {
        await createItem(payload);
        toast.success("Item add ho gaya");
      }
      setDialogOpen(false);
    } catch (e) {
      if (e instanceof ConvexError) {
        const { message } = e.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Kuch galat ho gaya");
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await removeItem({ id: deleteId });
      toast.success("Item delete ho gaya");
      setDeleteId(null);
    } catch {
      toast.error("Delete nahi hua");
    }
  };

  const toggleActive = async (it: CatalogItem) => {
    try {
      await updateItem({ id: it._id, isActive: !it.isActive });
    } catch {
      toast.error("Update nahi hua");
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Package className="w-6 h-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Item Master</h1>
            <p className="text-muted-foreground text-sm">Reusable items — bill/invoice me item add karte samay yahan se pick karein</p>
          </div>
        </div>
        {isSuperAdmin && (
          <Button onClick={openCreate} className="cursor-pointer">
            <Plus className="w-4 h-4 mr-1" /> Item Add Karein
          </Button>
        )}
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Item ya category dhundein..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {!items ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><PackageX /></EmptyMedia>
            <EmptyTitle>Koi item nahi</EmptyTitle>
            <EmptyDescription>{search ? "Search badalkar dekhein" : "Apna pehla item add karein"}</EmptyDescription>
          </EmptyHeader>
          {isSuperAdmin && (
            <EmptyContent>
              <Button onClick={openCreate} size="sm" className="cursor-pointer">Item Add Karein</Button>
            </EmptyContent>
          )}
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Item Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Category</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground">Unit</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Default Rate ₹</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">HSN</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground">Status</th>
                  {isSuperAdmin && <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((it) => (
                  <tr key={it._id} className="hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Package className="w-4 h-4 text-primary" />
                        </div>
                        <span className="truncate max-w-[220px]">{it.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{it.category ?? "—"}</td>
                    <td className="px-4 py-3 text-center">{it.defaultUnit}</td>
                    <td className="px-4 py-3 text-right font-semibold">{it.defaultRate.toLocaleString("en-IN")}</td>
                    <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{it.hsnCode ?? "—"}</td>
                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => isSuperAdmin && toggleActive(it)}
                        className={isSuperAdmin ? "cursor-pointer" : "cursor-default"}
                      >
                        <Badge className={it.isActive
                          ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                          : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"}>
                          {it.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </button>
                    </td>
                    {isSuperAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(it)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            size="icon" variant="ghost"
                            className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(it._id)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editId ? "Item Edit Karein" : "Naya Item Add Karein"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Item Name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Gypsum Board 12mm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Default Unit</Label>
                <select
                  className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm cursor-pointer"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                >
                  {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Default Rate (₹)</Label>
                <Input type="number" min="0" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="0" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="e.g. Ceiling" />
              </div>
              <div className="space-y-1.5">
                <Label>HSN Code</Label>
                <Input value={hsnCode} onChange={(e) => setHsnCode(e.target.value)} placeholder="Optional" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving} className="cursor-pointer">
              {saving ? "Saving..." : editId ? "Update" : "Add Item"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Item Delete Karein?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Yeh item permanently delete ho jaayega. Pehle se bane bills par koi asar nahi padega.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteId(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" onClick={handleDelete} className="cursor-pointer">Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function ItemMasterPage() {
  return (
    <>
      <Unauthenticated><div className="flex items-center justify-center h-64"><SignInButton /></div></Unauthenticated>
      <Authenticated><ItemMasterInner /></Authenticated>
    </>
  );
}
