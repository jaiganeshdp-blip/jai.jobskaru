import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, CheckCircle, XCircle, Clock, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type StatusFilter = "all" | "pending" | "resolved" | "rejected";

const typeLabels: Record<string, string> = {
  attendance: "Hajri Galat",
  advance: "Advance Galat",
  salary: "Salary Galat",
  other: "Kuch Aur",
};

function StatusBadge({ status }: { status: string }) {
  if (status === "pending") return <Badge variant="secondary" className="gap-1 text-xs"><Clock className="w-3 h-3" />Pending</Badge>;
  if (status === "resolved") return <Badge className="bg-green-600 gap-1 text-xs"><CheckCircle className="w-3 h-3" />Resolved</Badge>;
  return <Badge variant="destructive" className="gap-1 text-xs"><XCircle className="w-3 h-3" />Rejected</Badge>;
}

type CorrectionRequest = {
  _id: Id<"labourCorrectionRequests">;
  labourerName: string;
  labourerMobile?: string;
  requestType: string;
  month: string;
  description: string;
  status: "pending" | "resolved" | "rejected";
  adminNote?: string;
  photoUrls: string[];
  _creationTime: number;
};

export default function LabourCorrectionRequests() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("pending");
  const [reviewItem, setReviewItem] = useState<CorrectionRequest | null>(null);
  const [action, setAction] = useState<"resolved" | "rejected">("resolved");
  const [adminNote, setAdminNote] = useState("");
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  const requests = useQuery(api.labourCorrectionRequests.list, 
    statusFilter === "all" ? {} : { status: statusFilter }
  );
  const updateStatus = useMutation(api.labourCorrectionRequests.updateStatus);

  async function handleResolve() {
    if (!reviewItem) return;
    try {
      await updateStatus({
        id: reviewItem._id,
        status: action,
        adminNote: adminNote.trim() || undefined,
      });
      toast.success(action === "resolved" ? "Request resolved!" : "Request rejected");
      setReviewItem(null);
      setAdminNote("");
    } catch {
      toast.error("Failed to update");
    }
  }

  const pendingCount = useQuery(api.labourCorrectionRequests.list, { status: "pending" })?.length ?? 0;

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <AlertCircle className="text-orange-500" size={22} />
            Labour Correction Requests
          </h1>
          <p className="text-muted-foreground text-sm">
            Labour portal se aaye correction requests — hajri, advance, salary me sudhaar ke liye
          </p>
        </div>
        {pendingCount > 0 && (
          <Badge variant="secondary" className="text-sm px-3 py-1">
            {pendingCount} Pending
          </Badge>
        )}
      </div>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {(["all", "pending", "resolved", "rejected"] as StatusFilter[]).map((s) => (
          <Button
            key={s}
            size="sm"
            variant={statusFilter === s ? "default" : "secondary"}
            className="cursor-pointer capitalize text-xs h-8"
            onClick={() => setStatusFilter(s)}
          >
            {s === "all" ? "Sab" : s === "pending" ? "Pending" : s === "resolved" ? "Resolved" : "Rejected"}
          </Button>
        ))}
      </div>

      {/* List */}
      {!requests ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
      ) : requests.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><AlertCircle /></EmptyMedia>
            <EmptyTitle>Koi request nahi</EmptyTitle>
            <EmptyDescription>
              {statusFilter === "pending" ? "Abhi koi pending request nahi hai." : "Is category mein koi request nahi."}
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="space-y-3">
          {(requests as CorrectionRequest[]).map((req) => (
            <Card key={req._id} className="border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-sm">{req.labourerName}</p>
                      {req.labourerMobile && <span className="text-xs text-muted-foreground">{req.labourerMobile}</span>}
                      <StatusBadge status={req.status} />
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">{typeLabels[req.requestType] ?? req.requestType}</Badge>
                      <span className="text-xs text-muted-foreground">{req.month}</span>
                    </div>
                    <p className="text-sm mt-2 text-muted-foreground line-clamp-2">{req.description}</p>

                    {/* Photos */}
                    {req.photoUrls.length > 0 && (
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {req.photoUrls.map((url, i) => (
                          <button key={i} onClick={() => setLightboxUrl(url)} className="cursor-pointer">
                            <img src={url} alt="proof" className="w-16 h-16 object-cover rounded border hover:opacity-80" />
                          </button>
                        ))}
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <ImageIcon className="w-3 h-3" />
                          {req.photoUrls.length} photo
                        </div>
                      </div>
                    )}

                    {req.adminNote && (
                      <div className="bg-muted/50 rounded p-2 mt-2 text-xs">
                        <span className="font-medium">Admin Note: </span>{req.adminNote}
                      </div>
                    )}
                  </div>

                  {req.status === "pending" && (
                    <Button
                      size="sm"
                      className="cursor-pointer shrink-0 bg-orange-600 hover:bg-orange-700 text-xs h-8"
                      onClick={() => { setReviewItem(req); setAction("resolved"); setAdminNote(""); }}
                    >
                      Review
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Review Dialog */}
      <Dialog open={!!reviewItem} onOpenChange={() => setReviewItem(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Request Review — {reviewItem?.labourerName}</DialogTitle>
          </DialogHeader>
          {reviewItem && (
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-3 space-y-1 text-sm">
                <div className="flex gap-2">
                  <Badge variant="outline" className="text-xs">{typeLabels[reviewItem.requestType] ?? reviewItem.requestType}</Badge>
                  <span className="text-muted-foreground text-xs">{reviewItem.month}</span>
                </div>
                <p className="mt-2">{reviewItem.description}</p>
              </div>

              {reviewItem.photoUrls.length > 0 && (
                <div>
                  <p className="text-xs font-medium mb-2">Uploaded Photos / Proofs:</p>
                  <div className="flex gap-2 flex-wrap">
                    {reviewItem.photoUrls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noreferrer">
                        <img src={url} alt="proof" className="w-24 h-24 object-cover rounded-md border cursor-pointer hover:opacity-80" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-sm font-medium">Action</p>
                <Select value={action} onValueChange={(v) => setAction(v as "resolved" | "rejected")}>
                  <SelectTrigger className="cursor-pointer">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="resolved">✅ Sahi Kar Diya (Resolve)</SelectItem>
                    <SelectItem value="rejected">❌ Request Reject Karo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Labour Ko Jawab Bhejo (Optional)</p>
                <Textarea
                  placeholder="Jaise: Hajri sahi kar di, 5 June ka present add ho gaya..."
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  rows={2}
                  className="text-sm resize-none"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setReviewItem(null)}>Cancel</Button>
            <Button
              className={`cursor-pointer ${action === "resolved" ? "bg-green-600 hover:bg-green-700" : "bg-destructive hover:bg-destructive/80"}`}
              onClick={handleResolve}
            >
              {action === "resolved" ? "Resolve Karo" : "Reject Karo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Lightbox */}
      {lightboxUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center cursor-pointer p-4"
          onClick={() => setLightboxUrl(null)}
        >
          <img src={lightboxUrl} alt="proof" className="max-w-full max-h-full rounded-lg object-contain" />
        </div>
      )}
    </div>
  );
}
