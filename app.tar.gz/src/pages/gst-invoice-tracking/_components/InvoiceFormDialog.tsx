import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { XIcon } from "lucide-react";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Trash2 } from "lucide-react";

const OUR_COMPANIES = ["JAI AAINATH INTERIOR", "JAI GANESH INTERIOR"];

const schema = z.object({
  ourCompanyName: z.string().optional(),
  serialNo: z.coerce.number().optional(),
  billNo: z.string().optional(),
  location: z.string().optional(),
  billJai: z.string().optional(),
  siteCode: z.string().optional(),
  poNo: z.string().optional(),
  companyName: z.string().min(1, "Company name required"),
  billType: z.enum(["FINAL", "RA BILL", "DRAFT"]),
  draftInvoiceNo: z.string().optional(),
  draftInvoiceDate: z.string().optional(),
  invoiceStatus: z.enum(["DRAFT", "FINAL", "SUBMITTED"]),
  sesDone: z.string().optional(),
  caseId: z.string().optional(),
  taxInvoiceNo: z.string().optional(),
  taxInvoiceDate: z.string().optional(),
  amount: z.coerce.number().min(0),
  gstPercent: z.coerce.number().min(0).max(100),
  billAmount: z.coerce.number().optional(),
  retention: z.coerce.number().optional(),
  tds: z.coerce.number().optional(),
  utrNo: z.string().optional(),
  utrDate: z.string().optional(),
  termsDays: z.coerce.number().optional(),
  dueDate: z.string().optional(),
  // Payment Advice fields
  advanceDeducted: z.coerce.number().optional(),
  vendorDocDeducted: z.coerce.number().optional(),
  netPayable: z.coerce.number().optional(),
  paymentAdviceRef: z.string().optional(),
  bankName: z.string().optional(),
  remark: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editId: Id<"gstInvoiceTracking"> | null;
  financialYear: string;
  defaultCompanyName?: string; // "our company" — JAI AAINATH or JAI GANESH
};

export default function InvoiceFormDialog({ open, onOpenChange, editId, financialYear, defaultCompanyName }: Props) {
  const existing = useQuery(
    api.gstInvoiceTracking.get,
    editId ? { id: editId } : "skip"
  );

  const create = useMutation(api.gstInvoiceTracking.create);
  const update = useMutation(api.gstInvoiceTracking.update);
  const remove = useMutation(api.gstInvoiceTracking.remove);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      ourCompanyName: defaultCompanyName ?? OUR_COMPANIES[0],
      companyName: "",
      billType: "DRAFT",
      invoiceStatus: "DRAFT",
      amount: 0,
      gstPercent: 18,
    },
  });

  const watchAmount = form.watch("amount");
  const watchGst = form.watch("gstPercent");
  const computedGst = (Number(watchAmount) * Number(watchGst)) / 100;
  const computedBill = Number(watchAmount) + computedGst;

  useEffect(() => {
    if (existing && editId) {
      form.reset({
        ourCompanyName: existing.ourCompanyName ?? defaultCompanyName ?? OUR_COMPANIES[0],
        serialNo: existing.serialNo,
        billNo: existing.billNo ?? "",
        location: existing.location ?? "",
        billJai: existing.billJai ?? "",
        siteCode: existing.siteCode ?? "",
        poNo: existing.poNo ?? "",
        companyName: existing.companyName,
        billType: existing.billType,
        draftInvoiceNo: existing.draftInvoiceNo ?? "",
        draftInvoiceDate: existing.draftInvoiceDate ?? "",
        invoiceStatus: existing.invoiceStatus,
        sesDone: existing.sesDone ?? "",
        caseId: existing.caseId ?? "",
        taxInvoiceNo: existing.taxInvoiceNo ?? "",
        taxInvoiceDate: existing.taxInvoiceDate ?? "",
        amount: existing.amount,
        gstPercent: existing.gstPercent,
        billAmount: existing.billAmount,
        retention: existing.retention,
        tds: existing.tds,
        utrNo: existing.utrNo ?? "",
        utrDate: existing.utrDate ?? "",
        termsDays: existing.termsDays,
        dueDate: existing.dueDate ?? "",
        advanceDeducted: existing.advanceDeducted,
        vendorDocDeducted: existing.vendorDocDeducted,
        netPayable: existing.netPayable,
        paymentAdviceRef: existing.paymentAdviceRef ?? "",
        bankName: existing.bankName ?? "",
        remark: existing.remark ?? "",
      });
    } else if (!editId) {
      form.reset({
        ourCompanyName: defaultCompanyName ?? OUR_COMPANIES[0],
        companyName: "",
        billType: "DRAFT",
        invoiceStatus: "DRAFT",
        amount: 0,
        gstPercent: 18,
      });
    }
  }, [existing, editId, defaultCompanyName]);

  const onSubmit = async (values: FormValues) => {
    try {
      if (editId) {
        await update({ id: editId, ...values });
        toast.success("Invoice updated");
      } else {
        await create({ ...values, financialYear, companyName: values.companyName, amount: values.amount, gstPercent: values.gstPercent });
        toast.success("Invoice added");
      }
      onOpenChange(false);
    } catch {
      toast.error("Error saving invoice");
    }
  };

  const handleDelete = async () => {
    if (!editId) return;
    if (!confirm("Yeh invoice delete karein?")) return;
    try {
      await remove({ id: editId });
      toast.success("Invoice deleted");
      onOpenChange(false);
    } catch {
      toast.error("Delete failed");
    }
  };

  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/50" />
        <DialogPrimitive.Content className="fixed inset-0 z-50 flex flex-col bg-white text-gray-900 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b bg-white shrink-0">
            <h2 className="text-xl font-bold text-gray-900">{editId ? "Invoice Edit Karein" : "Naya Invoice Add Karein"}</h2>
            <DialogPrimitive.Close className="p-1 rounded hover:bg-gray-100 cursor-pointer">
              <XIcon className="w-5 h-5 text-gray-700" />
            </DialogPrimitive.Close>
          </div>

          {/* Scrollable body */}
          <div className="flex-1 overflow-y-auto px-6 py-5 bg-white">
        <Form {...form}>
          <form id="invoice-form" onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 max-w-5xl mx-auto [&_label]:text-gray-800 [&_input]:text-gray-900 [&_input]:bg-white [&_textarea]:text-gray-900 [&_textarea]:bg-white [&_p]:text-gray-700">

            {/* Section 0: Our Company */}
            <div className="bg-primary/10 rounded-lg p-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Hamari Company</p>
              <FormField control={form.control} name="ourCompanyName" render={({ field }) => (
                <FormItem className="max-w-sm">
                  <FormLabel className="text-sm font-semibold">Yeh invoice kis company ka hai? *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl>
                      <SelectTrigger className="h-10 font-semibold text-primary border-primary/50">
                        <SelectValue placeholder="Select company..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {OUR_COMPANIES.map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            {/* Section 1: Basic Info */}
            <div className="bg-muted/40 rounded-lg p-4 space-y-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Basic Information</p>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="serialNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">S.No</FormLabel>
                    <FormControl><Input type="number" placeholder="1" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="billJai" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">BILL-JAI</FormLabel>
                    <FormControl><Input placeholder="JAI" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="siteCode" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Site Code</FormLabel>
                    <FormControl><Input placeholder="T07" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="poNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">PO No</FormLabel>
                    <FormControl><Input placeholder="4800172998" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="billNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Bill No</FormLabel>
                    <FormControl><Input placeholder="Common Area Tiling Work..." className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="location" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Location</FormLabel>
                    <FormControl><Input placeholder="Bldg No.107, Phase-IV, Raheja Vistas..." className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <FormField control={form.control} name="companyName" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel className="text-sm">Client Company Name *</FormLabel>
                    <FormControl><Input placeholder="CAVALCADE PROPERTIES PVT LTD" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="billType" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Final / RA Bill</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="FINAL">FINAL</SelectItem>
                        <SelectItem value="RA BILL">RA BILL</SelectItem>
                        <SelectItem value="DRAFT">DRAFT</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </div>

            {/* Section 2: Invoice Details */}
            <div className="bg-muted/40 rounded-lg p-4 space-y-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Invoice Details</p>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="draftInvoiceNo" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel className="text-sm">Draft Invoice No</FormLabel>
                    <FormControl><Input placeholder="DRAFT JAI/023 / 25-26" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="draftInvoiceDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Invoice Date</FormLabel>
                    <FormControl><Input type="date" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="invoiceStatus" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="DRAFT">DRAFT</SelectItem>
                        <SelectItem value="FINAL">FINAL</SelectItem>
                        <SelectItem value="SUBMITTED">SUBMITTED</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="sesDone" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">SES Done</FormLabel>
                    <FormControl><Input placeholder="yes / date" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="caseId" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Case ID</FormLabel>
                    <FormControl><Input placeholder="PA155002050570039" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="taxInvoiceNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Tax Invoice No</FormLabel>
                    <FormControl><Input placeholder="JAI/2025-26/001" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="taxInvoiceDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Tax Invoice Date</FormLabel>
                    <FormControl><Input type="date" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </div>

            {/* Section 3: Amounts */}
            <div className="bg-muted/40 rounded-lg p-4 space-y-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Amount & GST</p>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="amount" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Amount (₹) *</FormLabel>
                    <FormControl><Input type="number" placeholder="610507" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="gstPercent" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">GST %</FormLabel>
                    <FormControl><Input type="number" placeholder="18" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="space-y-2">
                  <label className="text-sm font-medium">GST Amount (auto)</label>
                  <div className="h-10 flex items-center px-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-md text-base font-bold text-blue-600 dark:text-blue-400">
                    ₹{computedGst.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                  </div>
                </div>
                <FormField control={form.control} name="billAmount" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Bill Amount (₹)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder={String(Math.round(computedBill))}
                        className="h-10"
                        {...field}
                        value={field.value ?? ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="retention" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Retention (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="0" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="tds" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">TDS (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="0" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </div>

            {/* Section 4: Payment Advice (from K Raheja / Client payment advice doc) */}
            <div className="bg-orange-50 dark:bg-orange-950/20 rounded-lg p-4 space-y-4 border border-orange-200 dark:border-orange-800">
              <div>
                <p className="text-xs font-semibold text-orange-700 dark:text-orange-400 uppercase tracking-wide">Payment Advice Details</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Payment Advice milne par yahan entry karein — advance deduction, vendor document, net payable</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <FormField control={form.control} name="paymentAdviceRef" render={({ field }) => (
                  <FormItem className="col-span-3">
                    <FormLabel className="text-sm">Payment Advice Ref No <span className="text-muted-foreground font-normal">(e.g. 1500003600)</span></FormLabel>
                    <FormControl><Input placeholder="1500003600" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <FormField control={form.control} name="advanceDeducted" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Advance Deducted (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="4000000" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <p className="text-[10px] text-muted-foreground">Pehle liya hua advance jab kata</p>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="vendorDocDeducted" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Vendor Doc Deducted (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="370743" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <p className="text-[10px] text-muted-foreground">Retention — 1 saal baad milega</p>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="netPayable" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Net Payable (₹)</FormLabel>
                    <FormControl><Input type="number" placeholder="4344658" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <p className="text-[10px] text-muted-foreground">Jo actually mila payment mein</p>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </div>

            {/* Section 5: Payment */}
            <div className="bg-muted/40 rounded-lg p-4 space-y-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Payment & Due Date</p>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="utrNo" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel className="text-sm">UTR No</FormLabel>
                    <FormControl><Input placeholder="KKBKR22025080618262054" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="utrDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">UTR Date</FormLabel>
                    <FormControl><Input type="date" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid grid-cols-4 gap-4">
                <FormField control={form.control} name="termsDays" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Terms (Days)</FormLabel>
                    <FormControl><Input type="number" placeholder="45" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="dueDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm">Due Date</FormLabel>
                    <FormControl><Input type="date" className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="bankName" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel className="text-sm">Bank Name</FormLabel>
                    <FormControl><Input placeholder="HDFC Bank / SBI / ICICI..." className="h-10" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </div>

            {/* Remark */}
            <FormField control={form.control} name="remark" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm">Remark</FormLabel>
                <FormControl><Textarea placeholder="koi bhi note likhein..." rows={2} className="resize-none" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

          </form>
        </Form>
          </div>

          {/* Footer */}
          <div className="border-t px-6 py-4 bg-white flex gap-2 justify-between shrink-0">
          {editId && (
            <Button type="button" variant="destructive" size="sm" onClick={handleDelete} className="cursor-pointer gap-1">
              <Trash2 className="w-3.5 h-3.5" />
              Delete
            </Button>
          )}
          <div className="flex gap-2 ml-auto">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="cursor-pointer">
              Cancel
            </Button>
            <Button type="submit" form="invoice-form" className="cursor-pointer px-8">
              {editId ? "Update Invoice" : "Save Invoice"}
            </Button>
          </div>
        </div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}
