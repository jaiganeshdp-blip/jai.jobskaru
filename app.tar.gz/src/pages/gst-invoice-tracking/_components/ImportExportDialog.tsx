import { useRef, useState } from "react";
import * as XLSX from "xlsx";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Upload, Download, FileSpreadsheet, CheckCircle, AlertTriangle, Loader2 } from "lucide-react";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  financialYear: string;
  ourCompanyName?: string;
};

// Normalize a header string for matching
function norm(s: unknown): string {
  return String(s ?? "").toLowerCase().replace(/[\s_\-&./]/g, "").trim();
}

// Parse an Excel date serial or string to YYYY-MM-DD
function parseDate(val: unknown): string | undefined {
  if (!val) return undefined;
  if (typeof val === "number") {
    // Excel date serial
    const d = XLSX.SSF.parse_date_code(val);
    if (d) {
      const mm = String(d.m).padStart(2, "0");
      const dd = String(d.d).padStart(2, "0");
      return `${d.y}-${mm}-${dd}`;
    }
  }
  const s = String(val).trim();
  // dd-mm-yyyy
  const m1 = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  if (m1) return `${m1[3]}-${m1[2].padStart(2, "0")}-${m1[1].padStart(2, "0")}`;
  // yyyy-mm-dd
  const m2 = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if (m2) return `${m2[1]}-${m2[2].padStart(2, "0")}-${m2[3].padStart(2, "0")}`;
  return undefined;
}

function parseNum(val: unknown): number {
  const n = parseFloat(String(val ?? "0").replace(/,/g, ""));
  return isNaN(n) ? 0 : n;
}

type PreviewRow = {
  serialNo?: number;
  billNo?: string;
  location?: string;
  billJai?: string;
  siteCode?: string;
  poNo?: string;
  companyName: string;
  billType: "FINAL" | "RA BILL" | "DRAFT";
  draftInvoiceNo?: string;
  draftInvoiceDate?: string;
  invoiceStatus: "DRAFT" | "FINAL" | "SUBMITTED";
  sesDone?: string;
  caseId?: string;
  taxInvoiceNo?: string;
  taxInvoiceDate?: string;
  amount: number;
  gstPercent: number;
  gstAmount: number;
  billAmount?: number;
  retention?: number;
  tds?: number;
  utrNo?: string;
  utrDate?: string;
  termsDays?: number;
  dueDate?: string;
  remark?: string;
};

export default function ImportExportDialog({ open, onOpenChange, financialYear, ourCompanyName }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<PreviewRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [step, setStep] = useState<"idle" | "preview" | "done">("idle");

  const create = useMutation(api.gstInvoiceTracking.create);
  const rows = useQuery(api.gstInvoiceTracking.list, { financialYear });

  // ── IMPORT ──────────────────────────────────────────────────────────
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array", cellDates: false });

        // Try "GST BILL SUMMARY" sheet first, else first sheet
        const sheetName =
          wb.SheetNames.find((n) => n.toLowerCase().includes("gst bill")) ??
          wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];

        const raw = XLSX.utils.sheet_to_json<unknown[]>(ws, {
          header: 1,
          defval: "",
          raw: true,
        }) as unknown[][];

        // Find header row (row that has "Bill No" or "BILL NO" or "S.R NO")
        let headerRowIdx = -1;
        let headerRow: string[] = [];
        for (let i = 0; i < Math.min(10, raw.length); i++) {
          const row = raw[i] as unknown[];
          const joined = row.map((c) => norm(c)).join("|");
          if (joined.includes("billno") || joined.includes("billno&location") || joined.includes("srno") || joined.includes("sno")) {
            headerRowIdx = i;
            headerRow = row.map((c) => String(c ?? ""));
            break;
          }
        }

        if (headerRowIdx === -1) {
          toast.error("Header row nahi mili — column names check karein");
          return;
        }

        // Map column indexes by normalized name
        const idx: Record<string, number> = {};
        headerRow.forEach((h, i) => {
          idx[norm(h)] = i;
        });

        const getCol = (keys: string[], row: unknown[]): unknown => {
          for (const k of keys) {
            if (idx[k] !== undefined && row[idx[k]] !== "" && row[idx[k]] !== undefined) {
              return row[idx[k]];
            }
          }
          return undefined;
        };

        const parsed: PreviewRow[] = [];
        for (let i = headerRowIdx + 1; i < raw.length; i++) {
          const row = raw[i] as unknown[];
          const company = String(getCol(["nameofcompany", "companyname", "company"], row) ?? "").trim();
          if (!company || company.toLowerCase().includes("total")) continue;

          const amtRaw = parseNum(getCol(["amt", "amount"], row));
          const gstRaw = parseNum(getCol(["gst18%", "gst18", "gst%", "gst"], row));
          const gstPct = amtRaw > 0 && gstRaw > 0 ? Math.round((gstRaw / amtRaw) * 100) : 18;

          // billType
          const billTypeRaw = String(getCol(["finalandrabill", "finalrabill", "finalbill", "rabill", "billtype"], row) ?? "").toUpperCase();
          let billType: "FINAL" | "RA BILL" | "DRAFT" = "DRAFT";
          if (billTypeRaw.includes("FINAL")) billType = "FINAL";
          else if (billTypeRaw.includes("RA")) billType = "RA BILL";

          // invoice status from draft invoice no — if it says FINAL it's final
          const draftInvNo = String(getCol(["draftinvoiceno", "draftinvoice", "invoiceno"], row) ?? "").trim();
          let invoiceStatus: "DRAFT" | "FINAL" | "SUBMITTED" = "DRAFT";
          if (draftInvNo.toUpperCase().includes("FINAL")) invoiceStatus = "FINAL";
          else if (billType === "FINAL") invoiceStatus = "FINAL";

          // UTR — may be combined "UTR no. & DATE" column
          const utrCombined = String(getCol(["utrno&date", "utrno.&date", "utrnodate", "utr"], row) ?? "").trim();
          let utrNo: string | undefined;
          let utrDate: string | undefined;
          if (utrCombined) {
            const parts = utrCombined.split(/\s+/);
            utrNo = parts[0];
            if (parts[1]) utrDate = parseDate(parts[1]);
          } else {
            utrNo = String(getCol(["utrno", "utrnumber"], row) ?? "").trim() || undefined;
            utrDate = parseDate(getCol(["utrdate", "utrdt"], row));
          }

          parsed.push({
            serialNo: parseNum(getCol(["srno", "sno", "s.rno", "sno"], row)) || i - headerRowIdx,
            billNo: String(getCol(["billno&location", "billno", "billnolocation"], row) ?? "").trim() || undefined,
            location: String(getCol(["location"], row) ?? "").trim() || undefined,
            billJai: String(getCol(["billjai", "bill-jai", "billjai"], row) ?? "").trim() || undefined,
            siteCode: String(getCol(["site", "sitecode"], row) ?? "").trim() || undefined,
            poNo: String(getCol(["pono", "po no", "pono."], row) ?? "").trim() || undefined,
            companyName: company,
            billType,
            draftInvoiceNo: draftInvNo || undefined,
            draftInvoiceDate: parseDate(getCol(["draftinvoicedate", "invoicedate", "draftdate"], row)),
            invoiceStatus,
            sesDone: String(getCol(["sesdone", "ses"], row) ?? "").trim() || undefined,
            caseId: String(getCol(["caseid", "case id"], row) ?? "").trim() || undefined,
            taxInvoiceNo: String(getCol(["taxinvoiceno", "taxinvoice"], row) ?? "").trim() || undefined,
            taxInvoiceDate: parseDate(getCol(["taxinvoicedate", "taxdate"], row)),
            amount: amtRaw,
            gstPercent: gstPct,
            gstAmount: gstRaw || Math.round((amtRaw * gstPct) / 100),
            billAmount: parseNum(getCol(["bill", "billamount", "blamount"], row)) || undefined,
            retention: parseNum(getCol(["retention", "retentionamount"], row)) || undefined,
            tds: parseNum(getCol(["tds"], row)) || undefined,
            utrNo,
            utrDate,
            termsDays: parseNum(getCol(["termsofdays", "termsdays", "terms", "termsofdaysfordraft", "daysdraft"], row)) || undefined,
            dueDate: parseDate(getCol(["duedate", "due date"], row)),
            remark: String(getCol(["overdue", "remark", "remarks"], row) ?? "").trim() || undefined,
          });
        }

        if (parsed.length === 0) {
          toast.error("Koi valid row nahi mili Excel mein");
          return;
        }

        setPreview(parsed);
        setStep("preview");
      } catch (err) {
        console.error(err);
        toast.error("Excel parse nahi hua — sahi format mein file upload karein");
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  const handleImport = async () => {
    setImporting(true);
    let success = 0;
    let failed = 0;
    for (const row of preview) {
      try {
        // gstAmount is NOT in create args — backend calculates it from amount * gstPercent
        const { gstAmount: _gstAmount, ...rest } = row;
        await create({ ...rest, financialYear, ourCompanyName });
        success++;
      } catch (err) {
        console.error("Import row failed:", err);
        failed++;
      }
    }
    setImporting(false);
    setStep("done");
    if (failed === 0) toast.success(`${success} invoices import ho gaye!`);
    else toast.warning(`${success} import hue, ${failed} fail hue`);
  };

  // ── EXPORT ──────────────────────────────────────────────────────────
  const handleExport = () => {
    if (!rows || rows.length === 0) {
      toast.error("Export karne ke liye pehle kuch invoices add karein");
      return;
    }

    const today = new Date();
    const fmtDate = (d: string | undefined) => {
      if (!d) return "";
      const [y, m, day] = d.split("-");
      return `${day}-${m}-${y}`;
    };
    const daysOs = (due: string | undefined) => {
      if (!due) return "";
      const diff = Math.floor((today.getTime() - new Date(due).getTime()) / (1000 * 60 * 60 * 24));
      return diff;
    };

    const wsData: unknown[][] = [
      // Title row
      [`GST BILL    JAI AAINATH INTERIOR  INVOICE TRACKING    ${financialYear}`, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Invoice Terms And Conditions"],
      // Header
      ["S.R NO", "Bill No & Location", "BILL JAI", "SITE", "PO NO", "Name of company", "FINAL AND RA BILL", "DRAFT INVOICE NO", "DRAFT INVOICE DATE", "SES DONE", "Case ID", "TAX INVOICE NO", "TAX INVOICE DATE", "AMT", "GST 18%", "BILL", "RETENTION", "TDS", "UTR no. & DATE", "BL BILL", "Terms Of Days for draft", "Due date", "Days outstanding", "Overdue"],
    ];

    let totalAmt = 0, totalGst = 0, totalBill = 0, totalRet = 0, totalTds = 0;

    rows.forEach((r, i) => {
      const days = daysOs(r.dueDate);
      const overdue = typeof days === "number" && days > 0 ? "yes" : "no";
      totalAmt += r.amount;
      totalGst += r.gstAmount;
      totalBill += r.billAmount ?? 0;
      totalRet += r.retention ?? 0;
      totalTds += r.tds ?? 0;

      wsData.push([
        r.serialNo ?? i + 1,
        [r.billNo, r.location].filter(Boolean).join("\n"),
        r.billJai ?? "",
        r.siteCode ?? "",
        r.poNo ?? "",
        r.companyName,
        r.billType,
        r.draftInvoiceNo ?? "",
        fmtDate(r.draftInvoiceDate),
        r.sesDone ?? "",
        r.caseId ?? "",
        r.taxInvoiceNo ?? "",
        fmtDate(r.taxInvoiceDate),
        r.amount,
        r.gstAmount,
        r.billAmount ?? "",
        r.retention ?? 0,
        r.tds ?? 0,
        [r.utrNo, fmtDate(r.utrDate)].filter(Boolean).join(" "),
        "",
        r.termsDays ?? 45,
        fmtDate(r.dueDate),
        days,
        overdue,
      ]);
    });

    // Total row
    wsData.push([
      "", "TOTAL BILLING", "", "", "", "", "", "", "", "", "", "", "",
      totalAmt, totalGst, totalBill, totalRet, totalTds,
      "", "", "", "", "", ""
    ]);

    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Column widths
    ws["!cols"] = [
      { wch: 6 }, { wch: 35 }, { wch: 10 }, { wch: 8 }, { wch: 14 },
      { wch: 30 }, { wch: 12 }, { wch: 25 }, { wch: 14 }, { wch: 10 },
      { wch: 20 }, { wch: 20 }, { wch: 14 }, { wch: 12 }, { wch: 10 },
      { wch: 12 }, { wch: 10 }, { wch: 10 }, { wch: 20 }, { wch: 8 },
      { wch: 10 }, { wch: 12 }, { wch: 14 }, { wch: 8 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `GST BILL SUMMARY ${financialYear}`);
    XLSX.writeFile(wb, `GST_Bill_Invoice_Tracking_${financialYear}.xlsx`);
    toast.success("Excel download ho raha hai!");
  };

  const handleClose = () => {
    setPreview([]);
    setStep("idle");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl w-[95vw] max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-5 pb-4 border-b">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <FileSpreadsheet className="w-5 h-5 text-primary" />
            Excel Import / Export
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Export section */}
          <div className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold">Export to Excel</p>
                <p className="text-sm text-muted-foreground">Saare {financialYear} invoices ko Excel mein download karein</p>
              </div>
              <Button onClick={handleExport} className="cursor-pointer gap-2">
                <Download className="w-4 h-4" />
                Download Excel
              </Button>
            </div>
          </div>

          {/* Import section */}
          <div className="border rounded-lg p-4 space-y-3">
            <div>
              <p className="font-semibold">Import from Excel</p>
              <p className="text-sm text-muted-foreground">
                Apna GST Bill Excel file upload karein — same company name se match hoga
              </p>
            </div>

            {step === "idle" && (
              <div
                className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
                <p className="font-medium">Excel file yahan drop karein ya click karein</p>
                <p className="text-sm text-muted-foreground mt-1">.xlsx, .xls supported</p>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".xlsx,.xls"
                  className="hidden"
                  onChange={handleFile}
                />
              </div>
            )}

            {step === "preview" && preview.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-green-600 dark:text-green-400 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" />
                    {preview.length} rows mili hain — preview dekh ke import karein
                  </p>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={() => { setPreview([]); setStep("idle"); }} className="cursor-pointer">
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleImport} disabled={importing} className="cursor-pointer gap-1.5">
                      {importing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      {importing ? "Import ho raha hai..." : `Import Karein (${preview.length})`}
                    </Button>
                  </div>
                </div>

                {/* Preview table */}
                <div className="overflow-auto max-h-64 border rounded-lg">
                  <table className="w-full text-xs border-collapse min-w-[900px]">
                    <thead className="sticky top-0 bg-muted">
                      <tr>
                        {["S.No", "Company Name", "Bill Type", "Draft Invoice No", "Inv Date", "Amount", "GST", "Bill Amt", "Retention", "TDS", "Due Date", "Status"].map(h => (
                          <th key={h} className="border border-border px-2 py-1.5 text-left font-medium whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {preview.map((r, i) => (
                        <tr key={i} className={i % 2 === 0 ? "bg-background" : "bg-muted/30"}>
                          <td className="border border-border px-2 py-1">{r.serialNo ?? i + 1}</td>
                          <td className="border border-border px-2 py-1 font-medium max-w-[180px] truncate">{r.companyName}</td>
                          <td className="border border-border px-2 py-1">{r.billType}</td>
                          <td className="border border-border px-2 py-1 max-w-[140px] truncate">{r.draftInvoiceNo ?? "-"}</td>
                          <td className="border border-border px-2 py-1 whitespace-nowrap">{r.draftInvoiceDate ?? "-"}</td>
                          <td className="border border-border px-2 py-1 text-right">{r.amount.toLocaleString("en-IN")}</td>
                          <td className="border border-border px-2 py-1 text-right text-blue-600">{r.gstAmount.toLocaleString("en-IN")}</td>
                          <td className="border border-border px-2 py-1 text-right">{r.billAmount?.toLocaleString("en-IN") ?? "-"}</td>
                          <td className="border border-border px-2 py-1 text-right">{r.retention ?? 0}</td>
                          <td className="border border-border px-2 py-1 text-right">{r.tds ?? 0}</td>
                          <td className="border border-border px-2 py-1 whitespace-nowrap">{r.dueDate ?? "-"}</td>
                          <td className="border border-border px-2 py-1">{r.invoiceStatus}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {step === "done" && (
              <div className="flex flex-col items-center py-6 gap-3">
                <CheckCircle className="w-12 h-12 text-green-500" />
                <p className="font-semibold text-green-600 dark:text-green-400">{preview.length} invoices import ho gaye!</p>
                <Button onClick={handleClose} className="cursor-pointer">Done</Button>
              </div>
            )}
          </div>

          {/* Format guide */}
          <div className="bg-muted/40 rounded-lg p-4 space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" /> Excel Format Guide
            </p>
            <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
              <li>Column headers ki row automatically dhundhi jayegi (row 1-10 mein)</li>
              <li><strong>Company Name</strong> column required hai — iske bina row skip hogi</li>
              <li>Supported columns: Bill No, BILL JAI, SITE, PO NO, FINAL AND RA BILL, Draft Invoice No, Draft Invoice Date, SES DONE, Case ID, Tax Invoice No, Tax Invoice Date, AMT, GST 18%, BILL, RETENTION, TDS, UTR, Terms, Due date</li>
              <li>Dates format: dd-mm-yyyy ya Excel date serial dono chalega</li>
              <li>"TOTAL BILLING" wali row automatically skip hogi</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
