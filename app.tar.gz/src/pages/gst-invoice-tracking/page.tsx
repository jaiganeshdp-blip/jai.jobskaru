import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated, Unauthenticated } from "convex/react";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { PlusCircle, FileSpreadsheet, AlertTriangle, CheckCircle, Upload, Trash2, CheckSquare, Square } from "lucide-react";
import { cn } from "@/lib/utils.ts";
import InvoiceFormDialog from "./_components/InvoiceFormDialog.tsx";
import ImportExportDialog from "./_components/ImportExportDialog.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];

const OUR_COMPANIES = [
  "JAI AAINATH INTERIOR",
  "JAI GANESH INTERIOR",
];

function fmt(n: number | undefined) {
  if (n === undefined || n === null) return "-";
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

function fmtDate(d: string | undefined) {
  if (!d) return "-";
  const [y, m, day] = d.split("-");
  return `${day}-${m}-${y}`;
}

function daysOutstanding(dueDate: string | undefined): number | null {
  if (!dueDate) return null;
  const due = new Date(dueDate);
  const today = new Date();
  return Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
}

function GstTrackingInner() {
  const [fy, setFy] = useState("2026-27");
  const [ourCompany, setOurCompany] = useState<string>("JAI AAINATH INTERIOR");
  const [filterCompany, setFilterCompany] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<Id<"gstInvoiceTracking"> | null>(null);
  const [importExportOpen, setImportExportOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<Id<"gstInvoiceTracking"> | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const removeInvoice = useMutation(api.gstInvoiceTracking.remove);

  const rows = useQuery(api.gstInvoiceTracking.list, {
    financialYear: fy,
    ourCompanyName: ourCompany,
    companyName: filterCompany !== "all" ? filterCompany : undefined,
    invoiceStatus: filterStatus !== "all" ? (filterStatus as "DRAFT" | "FINAL" | "SUBMITTED") : undefined,
  });

  // All rows for this ourCompany (no client-company filter) — used for breakdown
  const allRows = useQuery(api.gstInvoiceTracking.list, { financialYear: fy, ourCompanyName: ourCompany });

  const companies = useQuery(api.gstInvoiceTracking.distinctCompanies, { financialYear: fy, ourCompanyName: ourCompany });
  const summary = useQuery(api.gstInvoiceTracking.summary, {
    financialYear: fy,
    ourCompanyName: ourCompany,
    companyName: filterCompany !== "all" ? filterCompany : undefined,
  });

  const handleEdit = (id: Id<"gstInvoiceTracking">) => {
    setEditId(id);
    setDialogOpen(true);
  };

  const handleAdd = () => {
    setEditId(null);
    setDialogOpen(true);
  };

  const isLoading = rows === undefined;

  const allRowIds = rows?.map((r) => r._id as string) ?? [];
  const allSelected = allRowIds.length > 0 && allRowIds.every((id) => selectedIds.has(id));
  const someSelected = selectedIds.size > 0;

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(allRowIds));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleBulkDelete = async () => {
    let failed = 0;
    for (const id of Array.from(selectedIds)) {
      try {
        await removeInvoice({ id: id as Id<"gstInvoiceTracking"> });
      } catch {
        failed++;
      }
    }
    if (failed === 0) toast.success(`${selectedIds.size} invoice(s) delete ho gaye`);
    else toast.error(`${failed} invoice delete nahi ho sake`);
    setSelectedIds(new Set());
    setBulkDeleteOpen(false);
  };

  // Company-wise breakdown from allRows
  type CompanyBreakdown = {
    companyName: string;
    billCount: number;
    totalAmount: number;
    totalGst: number;
    totalBill: number;
    draftCount: number;
    finalCount: number;
    submittedCount: number;
  };
  const companyBreakdown: CompanyBreakdown[] = [];
  if (allRows) {
    const map = new Map<string, CompanyBreakdown>();
    for (const r of allRows) {
      const existing = map.get(r.companyName) ?? {
        companyName: r.companyName, billCount: 0,
        totalAmount: 0, totalGst: 0, totalBill: 0,
        draftCount: 0, finalCount: 0, submittedCount: 0,
      };
      existing.billCount++;
      existing.totalAmount += r.amount;
      existing.totalGst += r.gstAmount;
      existing.totalBill += r.billAmount ?? 0;
      if (r.invoiceStatus === "DRAFT") existing.draftCount++;
      else if (r.invoiceStatus === "FINAL") existing.finalCount++;
      else if (r.invoiceStatus === "SUBMITTED") existing.submittedCount++;
      map.set(r.companyName, existing);
    }
    companyBreakdown.push(...Array.from(map.values()).sort((a, b) => b.totalAmount - a.totalAmount));
  }

  return (
    <div className="flex flex-col h-full min-h-screen bg-background">
      {/* Header */}
      <div className="border-b px-4 py-3 bg-card">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-primary" />
            <div>
              <h1 className="font-bold text-base leading-tight">GST BILL — {ourCompany}</h1>
              <p className="text-xs text-muted-foreground">Invoice Tracking</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {/* Our Company selector */}
            <Select value={ourCompany} onValueChange={(v) => { setOurCompany(v); setFilterCompany("all"); }}>
              <SelectTrigger className="w-52 h-8 text-xs font-semibold border-primary/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {OUR_COMPANIES.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={fy} onValueChange={setFy}>
              <SelectTrigger className="w-28 h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FINANCIAL_YEARS.map((y) => (
                  <SelectItem key={y} value={y}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Company filter */}
            <Select value={filterCompany} onValueChange={setFilterCompany}>
              <SelectTrigger className="w-44 h-8 text-xs">
                <SelectValue placeholder="All Companies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies?.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Status filter */}
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-28 h-8 text-xs">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="DRAFT">Draft</SelectItem>
                <SelectItem value="FINAL">Final</SelectItem>
                <SelectItem value="SUBMITTED">Submitted</SelectItem>
              </SelectContent>
            </Select>

            <Button size="sm" variant="secondary" onClick={() => setImportExportOpen(true)} className="h-8 text-xs cursor-pointer gap-1">
              <Upload className="w-3.5 h-3.5" />
              Import/Export
            </Button>
            <Button size="sm" onClick={handleAdd} className="h-8 text-xs cursor-pointer gap-1">
              <PlusCircle className="w-3.5 h-3.5" />
              Add Invoice
            </Button>
            {someSelected && (
              <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)} className="h-8 text-xs cursor-pointer gap-1">
                <Trash2 className="w-3.5 h-3.5" />
                Delete ({selectedIds.size})
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Summary bar */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-px bg-border border-b">
          {[
            { label: "Total Amount", value: fmt(summary.totalAmount) },
            { label: "GST 18%", value: fmt(summary.totalGst) },
            { label: "Total Billing", value: fmt(summary.totalBilling) },
            { label: "Retention", value: fmt(summary.totalRetention) },
            { label: "TDS", value: fmt(summary.totalTds) },
            { label: "Overdue", value: String(summary.overdueCount), highlight: summary.overdueCount > 0 },
          ].map((s) => (
            <div key={s.label} className="bg-card px-3 py-2 text-center">
              <div className={cn("text-sm font-bold", s.highlight ? "text-destructive" : "text-foreground")}>
                {s.value}
              </div>
              <div className="text-[10px] text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Company-wise breakdown cards — shown when All Companies selected */}
      {filterCompany === "all" && companyBreakdown.length > 0 && (
        <div className="px-4 py-3 border-b bg-muted/30">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            {ourCompany} — Company-wise Bill Breakdown ({fy})
          </p>
          <div className="flex flex-wrap gap-3">
            {companyBreakdown.map((cb) => (
              <button
                key={cb.companyName}
                onClick={() => setFilterCompany(cb.companyName)}
                className="cursor-pointer text-left border rounded-lg px-3 py-2 bg-card hover:bg-muted transition-colors min-w-[200px]"
              >
                <div className="font-semibold text-[11px] text-foreground truncate max-w-[220px]">{cb.companyName}</div>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] text-muted-foreground">{cb.billCount} bills</span>
                  <span className="text-[10px] font-bold text-foreground">₹{fmt(cb.totalAmount)}</span>
                </div>
                <div className="flex gap-1.5 mt-1 flex-wrap">
                  {cb.draftCount > 0 && (
                    <span className="text-[9px] bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300 px-1.5 py-0.5 rounded font-medium">
                      DRAFT: {cb.draftCount}
                    </span>
                  )}
                  {cb.finalCount > 0 && (
                    <span className="text-[9px] bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300 px-1.5 py-0.5 rounded font-medium">
                      FINAL: {cb.finalCount}
                    </span>
                  )}
                  {cb.submittedCount > 0 && (
                    <span className="text-[9px] bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 px-1.5 py-0.5 rounded font-medium">
                      SUBMITTED: {cb.submittedCount}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-[11px] border-collapse min-w-[1400px] bg-white text-gray-900">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary text-primary-foreground">
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-8">
                <button
                  onClick={toggleSelectAll}
                  className="cursor-pointer flex items-center justify-center w-full"
                  title={allSelected ? "Deselect All" : "Select All"}
                >
                  {allSelected ? (
                    <CheckSquare className="w-3.5 h-3.5" />
                  ) : (
                    <Square className="w-3.5 h-3.5 opacity-70" />
                  )}
                </button>
              </th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-8">S.No</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-left min-w-[180px]">Bill No & Location</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-16">BILL-JAI</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-16">Site</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-24">PO No</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-left min-w-[160px]">Company Name</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-20">Final/RA Bill</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center min-w-[130px]">Draft Invoice No</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-20">Invoice Date</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-16">Status</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-20">SES Done</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-28">Case ID</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-28">Tax Invoice No</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-22">Tax Inv Date</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-right w-24">Amount</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-right w-20">GST 18%</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-right w-24">Bill</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-right w-20">Retention</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-right w-20">TDS</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-28">UTR No & Date</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-16">Terms Days</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-22">Due Date</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-20">Days O/S</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-16">Overdue</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-left min-w-[100px]">Remark</th>
              <th className="border border-primary/20 px-1.5 py-1.5 text-center w-10"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading &&
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  {Array.from({ length: 27 }).map((__, j) => (
                    <td key={j} className="border border-border px-1.5 py-1">
                      <Skeleton className="h-3 w-full" />
                    </td>
                  ))}
                </tr>
              ))}

            {!isLoading && rows?.length === 0 && (
              <tr>
                <td colSpan={27} className="text-center py-12 text-muted-foreground">
                  <FileSpreadsheet className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>Koi invoice nahi mila. "Add Invoice" button dabayein.</p>
                </td>
              </tr>
            )}

            {!isLoading &&
              rows?.map((row, idx) => {
                const days = daysOutstanding(row.dueDate);
                const overdue = days !== null && days > 0;
                const rowClass = overdue
                  ? "bg-red-50 hover:bg-red-100"
                  : idx % 2 === 0
                    ? "bg-white hover:bg-orange-50"
                    : "bg-orange-50/50 hover:bg-orange-100/60";

                return (
                  <tr
                    key={row._id}
                    className={cn(
                      "cursor-pointer transition-colors",
                      selectedIds.has(row._id) ? "bg-primary/10 hover:bg-primary/15" : rowClass
                    )}
                    onClick={() => handleEdit(row._id)}
                  >
                    <td className="border border-gray-300 px-1 py-1 text-center" onClick={(e) => e.stopPropagation()}>
                      <button
                        className="cursor-pointer flex items-center justify-center w-full"
                        onClick={() => toggleSelect(row._id)}
                      >
                        {selectedIds.has(row._id) ? (
                          <CheckSquare className="w-3.5 h-3.5 text-primary" />
                        ) : (
                          <Square className="w-3.5 h-3.5 text-gray-400" />
                        )}
                      </button>
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-600">
                      {row.serialNo ?? idx + 1}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 font-medium text-gray-900">
                      {row.billNo ?? "-"}
                      {row.location && <span className="block text-[10px] text-gray-500">{row.location}</span>}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{row.billJai ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{row.siteCode ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center font-mono text-[10px] text-gray-900">{row.poNo ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 font-semibold text-[10px] text-gray-900">{row.companyName}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center">
                      <Badge
                        variant={row.billType === "FINAL" ? "default" : "secondary"}
                        className="text-[9px] px-1 py-0"
                      >
                        {row.billType}
                      </Badge>
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center font-mono text-[10px] text-gray-900">
                      {row.draftInvoiceNo ?? "-"}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{fmtDate(row.draftInvoiceDate)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center">
                      <Badge
                        className={cn(
                          "text-[9px] px-1 py-0",
                          row.invoiceStatus === "FINAL"
                            ? "bg-green-100 text-green-800"
                            : row.invoiceStatus === "SUBMITTED"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-yellow-100 text-yellow-800"
                        )}
                        variant="outline"
                      >
                        {row.invoiceStatus}
                      </Badge>
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{row.sesDone ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center font-mono text-[10px] text-gray-900">{row.caseId ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center font-mono text-[10px] text-gray-900">{row.taxInvoiceNo ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{fmtDate(row.taxInvoiceDate)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-right font-bold text-gray-900">{fmt(row.amount)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-right text-blue-700 font-semibold">{fmt(row.gstAmount)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-right font-bold text-gray-900">{fmt(row.billAmount)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-right text-orange-700">{fmt(row.retention)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-right text-purple-700">{fmt(row.tds)}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-[10px] text-gray-900">
                      {row.utrNo ? (
                        <>
                          <div className="font-mono">{row.utrNo}</div>
                          {row.utrDate && <div className="text-gray-500">{fmtDate(row.utrDate)}</div>}
                        </>
                      ) : "-"}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{row.termsDays ?? "-"}</td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center text-gray-900">{fmtDate(row.dueDate)}</td>
                    <td className={cn(
                      "border border-gray-300 px-1.5 py-1 text-center font-semibold",
                      days !== null && days > 0 ? "text-red-600" : days !== null && days <= 0 ? "text-green-700" : "text-gray-900"
                    )}>
                      {days !== null ? (days > 0 ? `+${days}` : days === 0 ? "Today" : `${days}`) : "-"}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-center">
                      {overdue ? (
                        <AlertTriangle className="w-3.5 h-3.5 text-red-600 mx-auto" />
                      ) : days !== null ? (
                        <CheckCircle className="w-3.5 h-3.5 text-green-600 mx-auto" />
                      ) : "-"}
                    </td>
                    <td className="border border-gray-300 px-1.5 py-1 text-[10px] text-gray-600">{row.remark ?? "-"}</td>
                    <td className="border border-gray-300 px-1 py-1 text-center" onClick={(e) => e.stopPropagation()}>
                      <button
                        className="p-1 rounded hover:bg-red-100 text-red-500 hover:text-red-700 transition-colors cursor-pointer"
                        onClick={() => setDeleteId(row._id)}
                        title="Delete invoice"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
          </tbody>

          {/* Total row */}
          {summary && !isLoading && rows && rows.length > 0 && (
            <tfoot>
              <tr className="bg-primary/10 font-bold border-t-2 border-primary">
                <td colSpan={16} className="border border-gray-300 px-2 py-1.5 text-right text-xs text-gray-900">
                  TOTAL BILLING →
                </td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-gray-900">{fmt(summary.totalAmount)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-blue-700">{fmt(summary.totalGst)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-gray-900">{fmt(summary.totalBilling)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-orange-700">{fmt(summary.totalRetention)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-purple-700">{fmt(summary.totalTds)}</td>
                <td colSpan={7} className="border border-gray-300" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      <InvoiceFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editId={editId}
        financialYear={fy}
        defaultCompanyName={ourCompany}
      />
      <ImportExportDialog
        open={importExportOpen}
        onOpenChange={setImportExportOpen}
        financialYear={fy}
        ourCompanyName={ourCompany}
      />

      {/* Bulk Delete Confirm Dialog */}
      <Dialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{selectedIds.size} Invoice(s) Delete Karen?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Yeh <strong>{selectedIds.size}</strong> invoice permanently delete ho jaayenge. Yeh action undo nahi hoga.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setBulkDeleteOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={handleBulkDelete}>
              Delete {selectedIds.size} Invoice(s)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Single Delete Confirm Dialog */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Invoice Delete Karen?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">Yeh invoice permanently delete ho jaayega. Yeh action undo nahi hoga.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteId(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteId) return;
              try {
                await removeInvoice({ id: deleteId });
                toast.success("Invoice deleted");
              } catch {
                toast.error("Delete failed");
              }
              setDeleteId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function GstInvoiceTrackingPage() {
  return (
    <>
      <Unauthenticated>
        <div className="flex items-center justify-center h-64">
          <SignInButton />
        </div>
      </Unauthenticated>
      <Authenticated>
        <GstTrackingInner />
      </Authenticated>
    </>
  );
}
