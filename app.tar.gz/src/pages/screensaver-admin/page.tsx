import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { toast } from "sonner";
import { Monitor, Plus, Trash2, Pencil, Eye, EyeOff } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const slideSchema = z.object({
  title: z.string().min(1, "Title required"),
  subtitle: z.string().optional(),
  imageUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  siteId: z.string().optional(),
  order: z.number(),
});
type SlideForm = z.infer<typeof slideSchema>;

const settingsSchema = z.object({
  idleMinutes: z.number().min(1).max(60),
  transitionSeconds: z.number().min(3).max(30),
  showStats: z.boolean(),
  theme: z.enum(["dark", "light", "blur"]),
});
type SettingsForm = z.infer<typeof settingsSchema>;

export default function ScreensaverAdmin() {
  const slides = useQuery(api.screensaver.getAllSlides, {});
  const settings = useQuery(api.screensaver.getSettings, {});
  const sites = useQuery(api.sites.list, {});
  const addSlide = useMutation(api.screensaver.addSlide);
  const updateSlide = useMutation(api.screensaver.updateSlide);
  const removeSlide = useMutation(api.screensaver.removeSlide);
  const saveSettings = useMutation(api.screensaver.saveSettings);

  const [slideDialog, setSlideDialog] = useState(false);
  const [editSlideId, setEditSlideId] = useState<string | null>(null);
  const [previewActive, setPreviewActive] = useState(false);

  const slideForm = useForm<SlideForm>({
    resolver: zodResolver(slideSchema),
    defaultValues: { title: "", order: 0 },
  });

  const settingsForm = useForm<SettingsForm>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      idleMinutes: settings?.idleMinutes ?? 5,
      transitionSeconds: settings?.transitionSeconds ?? 6,
      showStats: settings?.showStats ?? true,
      theme: (settings?.theme ?? "dark") as "dark" | "light" | "blur",
    },
    values: settings
      ? {
          idleMinutes: settings.idleMinutes,
          transitionSeconds: settings.transitionSeconds,
          showStats: settings.showStats,
          theme: settings.theme,
        }
      : undefined,
  });

  function openAddSlide() {
    setEditSlideId(null);
    slideForm.reset({ title: "", order: (slides?.length ?? 0) + 1 });
    setSlideDialog(true);
  }

  function openEditSlide(s: NonNullable<typeof slides>[number]) {
    setEditSlideId(s._id);
    slideForm.reset({
      title: s.title,
      subtitle: s.subtitle ?? "",
      imageUrl: s.imageUrl ?? "",
      siteId: s.siteId ?? "",
      order: s.order,
    });
    setSlideDialog(true);
  }

  async function onSlideSubmit(data: SlideForm) {
    try {
      const payload = {
        title: data.title,
        subtitle: data.subtitle || undefined,
        imageUrl: data.imageUrl || undefined,
        siteId: (data.siteId || undefined) as Id<"sites"> | undefined,
        order: data.order,
      };
      if (editSlideId) {
        await updateSlide({ id: editSlideId as Id<"screensaverSlides">, ...payload });
        toast.success("Slide updated");
      } else {
        await addSlide(payload);
        toast.success("Slide added");
      }
      setSlideDialog(false);
    } catch {
      toast.error("Failed to save slide");
    }
  }

  async function onSettingsSubmit(data: SettingsForm) {
    try {
      await saveSettings(data);
      toast.success("Settings saved");
    } catch {
      toast.error("Failed to save settings");
    }
  }

  async function toggleActive(id: string, current: boolean) {
    try {
      await updateSlide({ id: id as Id<"screensaverSlides">, isActive: !current });
    } catch {
      toast.error("Failed to update");
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Monitor className="w-6 h-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Screensaver Gallery</h1>
            <p className="text-muted-foreground text-sm">
              Auto-activates after {settingsForm.watch("idleMinutes")} min of inactivity on all PCs
            </p>
          </div>
        </div>
        <Button onClick={openAddSlide} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Slide
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Slides list */}
        <div className="lg:col-span-2 space-y-3">
          <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Slides ({slides?.length ?? 0})</h2>
          {!slides ? (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
          ) : slides.length === 0 ? (
            <div className="border border-dashed border-border rounded-xl p-10 text-center text-muted-foreground">
              <Monitor className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No slides yet. Add a slide to show in the screensaver.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {slides.map((slide) => (
                <div
                  key={slide._id}
                  className="flex items-center gap-4 p-3 rounded-xl border border-border bg-card hover:shadow-sm transition-shadow"
                >
                  {/* Thumbnail */}
                  <div className="w-20 h-14 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                    {slide.imageUrl ? (
                      <img src={slide.imageUrl} alt={slide.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[oklch(0.14_0.025_250)]">
                        <Monitor className="w-5 h-5 text-primary/40" />
                      </div>
                    )}
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{slide.title}</div>
                    {slide.subtitle && <div className="text-xs text-muted-foreground truncate">{slide.subtitle}</div>}
                    <div className="text-xs text-muted-foreground">Order: {slide.order}</div>
                  </div>
                  {/* Actions */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => toggleActive(slide._id, slide.isActive)}
                      className={`p-1.5 rounded-md cursor-pointer transition-colors ${slide.isActive ? "text-green-500 hover:bg-green-50" : "text-muted-foreground hover:bg-muted"}`}
                      title={slide.isActive ? "Active (click to hide)" : "Hidden (click to show)"}
                    >
                      {slide.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                    <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEditSlide(slide)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      size="icon" variant="ghost"
                      className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                      onClick={async () => {
                        try { await removeSlide({ id: slide._id as Id<"screensaverSlides"> }); toast.success("Deleted"); }
                        catch { toast.error("Failed"); }
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Settings panel */}
        <div className="space-y-4">
          <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Settings</h2>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Screensaver Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-4">
                  <FormField
                    control={settingsForm.control}
                    name="idleMinutes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Idle time (minutes)</FormLabel>
                        <FormControl>
                          <Input
                            type="number" min={1} max={60}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 5)}
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">Screensaver starts after this many minutes of no activity</p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={settingsForm.control}
                    name="transitionSeconds"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Slide duration (seconds)</FormLabel>
                        <FormControl>
                          <Input
                            type="number" min={3} max={30}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 6)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={settingsForm.control}
                    name="theme"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Theme</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="dark">Dark</SelectItem>
                            <SelectItem value="light">Light</SelectItem>
                            <SelectItem value="blur">Blur</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={settingsForm.control}
                    name="showStats"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-3">
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <Label>Show site stats on slides</Label>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full cursor-pointer">Save Settings</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card className="border-dashed">
            <CardContent className="pt-4">
              <p className="text-xs text-muted-foreground mb-3">
                The screensaver will activate automatically after the set idle time on any PC where this app is open. Click anywhere or press any key to dismiss it.
              </p>
              <p className="text-xs text-muted-foreground">
                If no slides are added, the screensaver will automatically show all your active sites.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Slide dialog */}
      <Dialog open={slideDialog} onOpenChange={setSlideDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editSlideId ? "Edit Slide" : "Add Slide"}</DialogTitle>
          </DialogHeader>
          <Form {...slideForm}>
            <form onSubmit={slideForm.handleSubmit(onSlideSubmit)} className="space-y-4">
              <FormField control={slideForm.control} name="title" render={({ field }) => (
                <FormItem>
                  <FormLabel>Title *</FormLabel>
                  <FormControl><Input placeholder="Skyline Tower, Mumbai" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={slideForm.control} name="subtitle" render={({ field }) => (
                <FormItem>
                  <FormLabel>Subtitle</FormLabel>
                  <FormControl><Input placeholder="Commercial project · ABC Builders" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={slideForm.control} name="imageUrl" render={({ field }) => (
                <FormItem>
                  <FormLabel>Image URL</FormLabel>
                  <FormControl><Input placeholder="https://example.com/site-photo.jpg" {...field} /></FormControl>
                  <p className="text-xs text-muted-foreground">Paste a direct image URL. Use the Files tab to upload images first.</p>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={slideForm.control} name="siteId" render={({ field }) => (
                <FormItem>
                  <FormLabel>Link to Site (optional)</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl>
                      <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {(sites ?? []).map((s) => (
                        <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={slideForm.control} name="order" render={({ field }) => (
                <FormItem>
                  <FormLabel>Order</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} onChange={(e) => field.onChange(parseInt(e.target.value) || 0)} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setSlideDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editSlideId ? "Update" : "Add Slide"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
