import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import {
  AlertCircle, CheckCheck, MapPin, FileText, IndianRupee,
  ArrowRight, Building2, Layers, RefreshCw,
} from "lucide-react";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const OUR_COMPANIES = [
  "JAI AAINATH INTERIOR",
  "JAI GANESH INTERIOR",
  "JAI VISHWA INTERIOR",
];

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];

export default function BillingDashboard() {
  const navigate = useNavigate();
  const pendingMilestones = useQuery(api.workOrderMilestones.listPendingBilling, {});
  const markBilled = useMutation(api.workOrderMilestones.markBilled);
  const createInvoice = useMutation(api.gstInvoiceTracking.create);

  const [invoiceDialogId, setInvoiceDialogId] = useState<Id<"workOrderMilestones"> | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Invoice form state
  const [fy, setFy] = useState("2026-27");
  const [ourCompany, setOurCompany] = useState(OUR_COMPANIES[0]);
  const [billNo, setBillNo] = useState("");
  const [draftInvoiceNo, setDraftInvoiceNo] = useState("");
  const [poNo, setPoNo] = useState("");
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split("T")[0]);
  const [termsDays, setTermsDays] = useState("45");

  const selectedMilestone = pendingMilestones?.find((m) => m._id === invoiceDialogId);

  function openInvoiceDialog(milestoneId: Id<"workOrderMilestones">) {
    setInvoiceDialogId(milestoneId);
    setBillNo("");
    setDraftInvoiceNo("");
    setPoNo("");
    setInvoiceDate(new Date().toISOString().split("T")[0]);
  }

  async function handleCreateInvoice() {
    if (!selectedMilestone || !invoiceDialogId) return;
    if (!billNo.trim()) { toast.error("Bill No. enter karo"); return; }

    setSubmitting(true);
    try {
      const gstPercent = 18;
      const gstAmount = Math.round(selectedMilestone.amount * 0.18);
      const billAmount = selectedMilestone.amount + gstAmount;

      const dueDate = termsDays
        ? new Date(new Date(invoiceDate).getTime() + parseInt(termsDays) * 86400000).toISOString().split("T")[0]
        : undefined;

      await createInvoice({
        financialYear: fy,
        ourCompanyName: ourCompany,
        companyName: selectedMilestone.clientName ?? "—",
        billNo: billNo.trim(),
        siteCode: selectedMilestone.siteName?.slice(0, 10) ?? "",
        poNo: poNo.trim() || undefined,
        draftInvoiceNo: draftInvoiceNo.trim() || undefined,
        draftInvoiceDate: invoiceDate,
        invoiceStatus: "DRAFT",
        billType: "RA BILL",
        amount: selectedMilestone.amount,
        gstPercent,
        billAmount,
        termsDays: termsDays ? parseInt(termsDays) : undefined,
        dueDate,
        location: `${selectedMilestone.siteName} - ${selectedMilestone.name}`,
        remark: `Progress billing: ${selectedMilestone.name} (WO: ${selectedMilestone.workOrderNumber ?? ""})`,
      });

      // Mark milestone as billed
      await markBilled({ id: invoiceDialogId });

      toast.success("Invoice create ho gaya aur milestone billed mark ho gaya!");
      setInvoiceDialogId(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Invoice create failed");
    } finally {
      setSubmitting(false);
    }
  }

  const totalPendingAmount = (pendingMilestones ?? []).reduce((s, m) => s + m.amount, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <AlertCircle className="w-6 h-6 text-orange-500" />
            Billing Dashboard
          </h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Completed milestones jo abhi tak bill nahi hue — site incharge ne mark kiya hai
          </p>
        </div>
        <Button variant="secondary" className="cursor-pointer gap-1.5" onClick={() => navigate("/work-orders")}>
          <Layers className="w-4 h-4" /> Work Orders
        </Button>
      </div>

      {/* Summary cards */}
      {pendingMilestones && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <Card className="py-3">
            <CardContent className="px-4 py-0">
              <p className="text-xs text-muted-foreground">Pending Bills</p>
              <p className="text-2xl font-bold text-orange-500">{pendingMilestones.length}</p>
            </CardContent>
          </Card>
          <Card className="py-3">
            <CardContent className="px-4 py-0">
              <p className="text-xs text-muted-foreground">Total Pending Amount</p>
              <p className="text-2xl font-bold text-orange-500">
                ₹{(totalPendingAmount / 100000).toFixed(2)}L
              </p>
            </CardContent>
          </Card>
          <Card className="py-3">
            <CardContent className="px-4 py-0">
              <p className="text-xs text-muted-foreground">Unique Sites</p>
              <p className="text-2xl font-bold text-blue-500">
                {new Set(pendingMilestones.map((m) => m.siteId)).size}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Pending billing list */}
      {!pendingMilestones ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      ) : pendingMilestones.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><CheckCheck /></EmptyMedia>
            <EmptyTitle>Sab bills ban gaye!</EmptyTitle>
            <EmptyDescription>
              Koi bhi completed milestone billing ke liye pending nahi hai.
              Jab site incharge koi milestone "Mark Done" karega, yahan dikhega.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="space-y-3">
          {pendingMilestones.map((m) => (
            <div
              key={m._id}
              className="border border-orange-200 dark:border-orange-900/40 rounded-xl bg-orange-50/50 dark:bg-orange-900/10 p-4"
            >
              <div className="flex items-start gap-4 flex-wrap">
                <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-5 h-5 text-orange-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-base">{m.name}</span>
                        <span className="text-xs bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 px-2 py-0.5 rounded-full font-medium">
                          Billing Due
                        </span>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1">
                          <FileText className="w-3.5 h-3.5" />
                          WO: {m.workOrderNumber ?? "—"}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5" />
                          {m.siteName ?? "—"}{m.siteCity ? `, ${m.siteCity}` : ""}
                        </span>
                        {m.clientName && (
                          <span className="flex items-center gap-1">
                            <Building2 className="w-3.5 h-3.5" />
                            {m.clientName}
                          </span>
                        )}
                      </div>
                      {m.completedAt && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Completed: {m.completedAt.split("T")[0]}
                          {m.completedByName && ` by ${m.completedByName}`}
                          {m.completionNote && ` · "${m.completionNote}"`}
                        </p>
                      )}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-2xl font-bold text-orange-600">
                        ₹{m.amount.toLocaleString("en-IN")}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {m.percentage.toFixed(2)}% of WO value
                      </p>
                      <p className="text-xs text-muted-foreground">
                        + GST 18% = ₹{(m.amount * 1.18).toLocaleString("en-IN")}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button
                    size="sm" variant="secondary" className="cursor-pointer gap-1.5 text-xs"
                    onClick={() => navigate(`/work-orders/${m.workOrderId}`)}
                  >
                    View WO <ArrowRight className="w-3 h-3" />
                  </Button>
                  <Button
                    size="sm" className="cursor-pointer gap-1.5 text-xs"
                    onClick={() => openInvoiceDialog(m._id)}
                  >
                    <FileText className="w-3.5 h-3.5" /> Create Invoice
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Invoice Dialog */}
      <Dialog open={!!invoiceDialogId} onOpenChange={() => setInvoiceDialogId(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Invoice Create Karo — {selectedMilestone?.name}</DialogTitle>
          </DialogHeader>
          {selectedMilestone && (
            <div className="space-y-4">
              {/* Summary */}
              <div className="rounded-lg bg-orange-500/10 border border-orange-500/20 p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Site</span>
                  <span className="font-medium">{selectedMilestone.siteName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Work Order</span>
                  <span className="font-medium">{selectedMilestone.workOrderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Client</span>
                  <span className="font-medium">{selectedMilestone.clientName ?? "—"}</span>
                </div>
                <div className="flex justify-between font-bold text-orange-600">
                  <span>Amount (excl. GST)</span>
                  <span>₹{selectedMilestone.amount.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>GST 18%</span>
                  <span>₹{Math.round(selectedMilestone.amount * 0.18).toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-orange-200 dark:border-orange-800 pt-1">
                  <span>Total Bill Amount</span>
                  <span>₹{Math.round(selectedMilestone.amount * 1.18).toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Financial Year *</Label>
                  <Select value={fy} onValueChange={setFy}>
                    <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Our Company *</Label>
                  <Select value={ourCompany} onValueChange={setOurCompany}>
                    <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Bill No. / Location *</Label>
                  <Input placeholder="e.g. Flooring Work - Floor 1" value={billNo} onChange={(e) => setBillNo(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>PO No.</Label>
                  <Input placeholder="e.g. 4800172966" value={poNo} onChange={(e) => setPoNo(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Draft Invoice No.</Label>
                  <Input placeholder="DRAFT JAI/001/26-27" value={draftInvoiceNo} onChange={(e) => setDraftInvoiceNo(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Invoice Date *</Label>
                  <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Terms (Days)</Label>
                  <Input type="number" placeholder="45" value={termsDays} onChange={(e) => setTermsDays(e.target.value)} />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setInvoiceDialogId(null)} className="cursor-pointer">Cancel</Button>
            <Button onClick={() => void handleCreateInvoice()} disabled={submitting} className="cursor-pointer">
              <FileText className="w-4 h-4 mr-1" />
              {submitting ? "Creating..." : "Create Invoice in GST Tracker"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
