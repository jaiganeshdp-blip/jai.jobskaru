import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { Plus, Search, Pencil, Trash2, HardHat, Link as LinkIcon, Eye } from "lucide-react";
import { WhatsAppButton } from "@/components/whatsapp-button.tsx";
import { Link } from "react-router-dom";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  mobile: z.string().min(10, "Valid mobile required"),
  email: z.string().email().optional().or(z.literal("")),
  gstNumber: z.string().optional(),
  panNumber: z.string().optional(),
  address: z.string().optional(),
  specialization: z.string().optional(),
  bankName: z.string().optional(),
  accountNumber: z.string().optional(),
  ifscCode: z.string().optional(),
});
type ContractorForm = z.infer<typeof schema>;

function copyPortalLink(token: string) {
  const url = `${window.location.origin}/portal/contractor?token=${token}`;
  void navigator.clipboard.writeText(url);
  toast.success("Portal link copied!");
}

export default function Contractors() {
  const contractors = useQuery(api.contractors.list, {});
  const createContractor = useMutation(api.contractors.create);
  const updateContractor = useMutation(api.contractors.update);
  const removeContractor = useMutation(api.contractors.remove);

  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const form = useForm<ContractorForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", mobile: "" },
  });

  const filtered = (contractors ?? []).filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.specialization ?? "").toLowerCase().includes(search.toLowerCase())
  );

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }

  function toggleAll() {
    if (selectedIds.size === filtered.length && filtered.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((c) => c._id)));
    }
  }

  function clearSelection() {
    setSelectedIds(new Set());
  }

  function openCreate() {
    setEditId(null);
    form.reset({ name: "", mobile: "" });
    setDialogOpen(true);
  }

  function openEdit(c: (typeof filtered)[number]) {
    setEditId(c._id);
    form.reset({
      name: c.name,
      mobile: c.mobile,
      email: c.email ?? "",
      gstNumber: c.gstNumber ?? "",
      panNumber: c.panNumber ?? "",
      address: c.address ?? "",
      specialization: c.specialization ?? "",
      bankName: c.bankName ?? "",
      accountNumber: c.accountNumber ?? "",
      ifscCode: c.ifscCode ?? "",
    });
    setDialogOpen(true);
  }

  async function onSubmit(data: ContractorForm) {
    try {
      const payload = {
        ...data,
        email: data.email || undefined,
        gstNumber: data.gstNumber || undefined,
        panNumber: data.panNumber || undefined,
        address: data.address || undefined,
        specialization: data.specialization || undefined,
        bankName: data.bankName || undefined,
        accountNumber: data.accountNumber || undefined,
        ifscCode: data.ifscCode || undefined,
      };
      if (editId) {
        await updateContractor({ id: editId as Id<"contractors">, ...payload });
        toast.success("Contractor updated");
      } else {
        await createContractor(payload);
        toast.success("Contractor added — portal link generated!");
      }
      setDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    }
  }

  async function handleDelete(id: string) {
    try {
      await removeContractor({ id: id as Id<"contractors"> });
      toast.success("Contractor deleted");
      setDeleteConfirm(null);
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Contractors</h1>
          <p className="text-muted-foreground text-sm">
            Labour contractors — each gets a private portal link
          </p>
        </div>
        <Button onClick={openCreate} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Contractor
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or specialization..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <BulkDeleteBar
        selectedCount={selectedIds.size}
        onDelete={async () => {
          await Promise.all(
            Array.from(selectedIds).map((id) =>
              removeContractor({ id: id as Id<"contractors"> })
            )
          );
          clearSelection();
          toast.success(`${selectedIds.size} contractor(s) deleted`);
        }}
        onClear={clearSelection}
        itemLabel="contractor"
      />

      {!contractors ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><HardHat /></EmptyMedia>
            <EmptyTitle>No contractors found</EmptyTitle>
            <EmptyDescription>{search ? "Try adjusting your search" : "Add your first labour contractor"}</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={openCreate} size="sm" className="cursor-pointer">Add Contractor</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox
                      checked={selectedIds.size === filtered.length && filtered.length > 0}
                      indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length}
                      onCheckedChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Contractor Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Mobile</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Specialization</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">GST</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((c) => (
                  <tr key={c._id} className="hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <BulkCheckbox
                        checked={selectedIds.has(c._id)}
                        onCheckedChange={() => toggleSelect(c._id)}
                      />
                    </td>
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center flex-shrink-0">
                          <HardHat className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                        </div>
                        <span className="truncate max-w-[150px]">{c.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <div className="flex items-center gap-1">
                        <span>{c.mobile}</span>
                        <WhatsAppButton mobile={c.mobile} />
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{c.specialization ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{c.gstNumber ?? "—"}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${c.isActive ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-gray-100 text-gray-600"}`}>
                        {c.isActive ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link to={`/contractors/${c._id}`}>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" title="View details">
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                        </Link>
                        {c.portalToken && (
                          <Button
                            size="icon" variant="ghost"
                            className="w-8 h-8 cursor-pointer"
                            title="Copy portal link"
                            onClick={() => copyPortalLink(c.portalToken!)}
                          >
                            <LinkIcon className="w-3.5 h-3.5 text-emerald-500" />
                          </Button>
                        )}
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(c)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="icon" variant="ghost"
                          className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                          onClick={() => setDeleteConfirm(c._id)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Contractor" : "Add Contractor"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Contractor Name *</FormLabel>
                    <FormControl><Input placeholder="Ravi Labour Works" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile *</FormLabel>
                    <FormControl><Input placeholder="9876543210" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl><Input placeholder="contractor@example.com" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="specialization" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Specialization</FormLabel>
                    <FormControl><Input placeholder="Civil, Electrical, Plumbing…" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="gstNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>GST Number</FormLabel>
                    <FormControl><Input placeholder="27ABCDE1234F1Z5" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="panNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>PAN Number</FormLabel>
                    <FormControl><Input placeholder="ABCDE1234F" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Address</FormLabel>
                    <FormControl><Input placeholder="Office address" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <div className="col-span-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Bank Details</p>
                </div>
                <FormField control={form.control} name="bankName" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bank Name</FormLabel>
                    <FormControl><Input placeholder="HDFC" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="accountNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Number</FormLabel>
                    <FormControl><Input placeholder="1234567890" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="ifscCode" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>IFSC Code</FormLabel>
                    <FormControl><Input placeholder="HDFC0001234" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Add Contractor"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Contractor?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete the contractor record.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteConfirm(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" onClick={() => deleteConfirm && handleDelete(deleteConfirm)} className="cursor-pointer">Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
