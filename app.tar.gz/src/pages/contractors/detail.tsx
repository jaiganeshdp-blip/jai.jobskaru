import { useParams, Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  ArrowLeft, Phone, Mail, HardHat, Users, CreditCard,
  Link as LinkIcon, AlertCircle, Wrench, ClipboardList,
  Building2, MapPin, Receipt, FileText, IndianRupee, TrendingUp,
} from "lucide-react";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function fmt(amount: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}

function fmtL(amount: number) {
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)}Cr`;
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)}L`;
  return fmt(amount);
}

function copyPortalLink(token: string) {
  const url = `${window.location.origin}/portal/contractor?token=${token}`;
  void navigator.clipboard.writeText(url);
  toast.success("Portal link copied!");
}

const STATUS_COLORS: Record<string, string> = {
  received: "bg-blue-500/15 text-blue-600",
  verified: "bg-yellow-500/15 text-yellow-600",
  approved: "bg-purple-500/15 text-purple-600",
  paid: "bg-green-500/15 text-green-600",
  disputed: "bg-red-500/15 text-red-600",
};

const SITE_STATUS: Record<string, string> = {
  active: "bg-green-500/15 text-green-600",
  planning: "bg-yellow-500/15 text-yellow-600",
  on_hold: "bg-orange-500/15 text-orange-600",
  completed: "bg-gray-500/15 text-gray-500",
};

const PO_STATUS: Record<string, string> = {
  draft: "bg-gray-500/15 text-gray-500",
  issued: "bg-blue-500/15 text-blue-600",
  partially_delivered: "bg-orange-500/15 text-orange-600",
  delivered: "bg-green-500/15 text-green-600",
  cancelled: "bg-red-500/15 text-red-600",
};

export default function ContractorDetail() {
  const { id } = useParams<{ id: string }>();
  const data = useQuery(api.contractors.getDetail, id ? { id: id as Id<"contractors"> } : "skip");

  if (data === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6 text-center space-y-2">
        <AlertCircle className="w-8 h-8 mx-auto text-muted-foreground" />
        <p className="text-muted-foreground">Contractor not found</p>
        <Link to="/contractors"><Button variant="ghost" size="sm">Back to Contractors</Button></Link>
      </div>
    );
  }

  const {
    contractor, labourCount, activeLabourCount, totalPaid, totalBilled, totalOutstanding,
    workOrderCount, sites, bills, purchaseOrders, recentPayments, labourers,
  } = data;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">

      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <Link to="/contractors">
          <Button variant="ghost" size="sm" className="cursor-pointer gap-1 -ml-2">
            <ArrowLeft className="w-4 h-4" /> Contractors
          </Button>
        </Link>
        {contractor.portalToken && (
          <Button variant="secondary" size="sm" className="cursor-pointer gap-2" onClick={() => copyPortalLink(contractor.portalToken!)}>
            <LinkIcon className="w-3.5 h-3.5" /> Copy Portal Link
          </Button>
        )}
      </div>

      {/* Hero */}
      <div className="rounded-xl bg-[oklch(0.14_0.025_250)] text-white p-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <HardHat className="w-5 h-5 text-yellow-400" />
              </div>
              <h1 className="text-2xl md:text-3xl font-bold">{contractor.name}</h1>
            </div>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-white/70">
              {contractor.mobile && <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {contractor.mobile}</span>}
              {contractor.email && <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {contractor.email}</span>}
              {contractor.specialization && <span className="flex items-center gap-1"><Wrench className="w-3.5 h-3.5" /> {contractor.specialization}</span>}
              {contractor.address && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {contractor.address}</span>}
            </div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold self-start ${contractor.isActive ? "bg-green-500/20 text-green-300" : "bg-gray-500/20 text-gray-300"}`}>
            {contractor.isActive ? "Active" : "Inactive"}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <Users className="w-3.5 h-3.5" /> Labour
          </div>
          <div className="text-2xl font-bold">{labourCount}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{activeLabourCount} active</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <ClipboardList className="w-3.5 h-3.5" /> Work Orders
          </div>
          <div className="text-2xl font-bold">{workOrderCount}</div>
          <div className="text-xs text-muted-foreground mt-0.5">assigned sites</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <FileText className="w-3.5 h-3.5" /> POs
          </div>
          <div className="text-2xl font-bold">{purchaseOrders.length}</div>
          <div className="text-xs text-muted-foreground mt-0.5">purchase orders</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <TrendingUp className="w-3.5 h-3.5" /> Total Billed
          </div>
          <div className="text-xl font-bold">{fmtL(totalBilled)}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{bills.length} bills</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <CreditCard className="w-3.5 h-3.5" /> Paid
          </div>
          <div className="text-xl font-bold text-green-600 dark:text-green-400">{fmtL(totalPaid)}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{recentPayments.length} payments</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1">
            <IndianRupee className="w-3.5 h-3.5" /> Outstanding
          </div>
          <div className={`text-xl font-bold ${totalOutstanding > 0 ? "text-orange-600" : "text-green-600 dark:text-green-400"}`}>
            {fmtL(totalOutstanding)}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">balance payable</div>
        </div>
      </div>

      {/* Sites where contractor works */}
      <div className="border border-border rounded-lg p-4 space-y-3">
        <h3 className="font-semibold text-sm flex items-center gap-2">
          <Building2 className="w-4 h-4" /> Sites &amp; Companies ({sites.length})
        </h3>
        {sites.length === 0 ? (
          <p className="text-sm text-muted-foreground">No sites assigned yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-xs text-muted-foreground">
                  <th className="text-left pb-2 font-medium">Site Name</th>
                  <th className="text-left pb-2 font-medium">Company</th>
                  <th className="text-left pb-2 font-medium">City</th>
                  <th className="text-center pb-2 font-medium">Labour</th>
                  <th className="text-right pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {sites.map((s) => (
                  <tr key={s.siteId} className="border-b border-border/50 last:border-0">
                    <td className="py-2 font-medium">{s.siteName}</td>
                    <td className="py-2 text-muted-foreground">{s.companyName}</td>
                    <td className="py-2 text-muted-foreground">{s.city}</td>
                    <td className="py-2 text-center">{s.labourCount}</td>
                    <td className="py-2 text-right">
                      <Badge className={`text-xs border-0 capitalize ${SITE_STATUS[s.status] ?? "bg-muted text-muted-foreground"}`}>
                        {s.status.replace("_", " ")}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* POs + Bills in two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Purchase Orders */}
        <div className="border border-border rounded-lg p-4 space-y-3">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <FileText className="w-4 h-4" /> Purchase Orders ({purchaseOrders.length})
          </h3>
          {purchaseOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground">No purchase orders yet</p>
          ) : (
            <div className="space-y-2">
              {purchaseOrders.map((po) => (
                <div key={po._id} className="flex items-start justify-between py-2 border-b border-border/50 last:border-0">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{po.poNumber}</span>
                      <Badge className={`text-xs border-0 capitalize ${PO_STATUS[po.status] ?? "bg-muted text-muted-foreground"}`}>
                        {po.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{po.siteName} · {po.issueDate}</p>
                    {po.description && <p className="text-xs text-muted-foreground truncate">{po.description}</p>}
                  </div>
                  <div className="text-right ml-3">
                    <div className="font-bold text-sm">{fmtL(po.totalValue)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Vendor Bills */}
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Receipt className="w-4 h-4" /> Bills ({bills.length})
            </h3>
            <Link to="/vendor-bills" className="text-xs text-primary cursor-pointer">View all</Link>
          </div>
          {bills.length === 0 ? (
            <p className="text-sm text-muted-foreground">No bills submitted yet</p>
          ) : (
            <div className="space-y-2">
              {bills.slice(0, 15).map((b) => {
                const paidPct = b.totalAmount > 0 ? (b.paidAmount / b.totalAmount) * 100 : 0;
                return (
                  <div key={b._id} className="py-2 border-b border-border/50 last:border-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-semibold text-sm">{b.billNumber}</span>
                          {b.billType === "ra" && (
                            <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">RA-{b.raNumber}</Badge>
                          )}
                          {b.billType === "final" && (
                            <Badge className="bg-purple-100 text-purple-700 border-0 text-xs">Final</Badge>
                          )}
                          <Badge className={`text-xs border-0 capitalize ${STATUS_COLORS[b.status] ?? ""}`}>
                            {b.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {b.siteName} · {b.billDate}
                          {b.poNumber && ` · PO: ${b.poNumber}`}
                        </p>
                      </div>
                      <div className="text-right ml-3">
                        <div className="font-bold text-sm">{fmtL(b.totalAmount)}</div>
                        {b.outstanding > 0 && (
                          <div className="text-xs text-orange-600">{fmtL(b.outstanding)} due</div>
                        )}
                        {b.outstanding === 0 && b.paidAmount > 0 && (
                          <div className="text-xs text-green-600">Paid</div>
                        )}
                      </div>
                    </div>
                    {/* Payment progress bar */}
                    <div className="mt-1.5 flex items-center gap-2">
                      <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 rounded-full transition-all"
                          style={{ width: `${paidPct}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap">{paidPct.toFixed(0)}%</span>
                    </div>
                  </div>
                );
              })}
              {bills.length > 15 && (
                <p className="text-xs text-muted-foreground text-center">+{bills.length - 15} more bills</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom section: Info + Payments + Labour */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Contractor Info */}
        <div className="space-y-4">
          <div className="border border-border rounded-lg p-4 space-y-3">
            <h3 className="font-semibold text-sm">Contractor Information</h3>
            {[
              { label: "GST Number", value: contractor.gstNumber ?? "—" },
              { label: "PAN Number", value: contractor.panNumber ?? "—" },
              { label: "Address", value: contractor.address ?? "—" },
              { label: "Specialization", value: contractor.specialization ?? "—" },
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{row.label}</span>
                <span className="font-medium text-right max-w-[180px]">{row.value}</span>
              </div>
            ))}
          </div>
          {(contractor.bankName ?? contractor.accountNumber) && (
            <div className="border border-border rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-sm">Bank Details</h3>
              {[
                { label: "Bank", value: contractor.bankName ?? "—" },
                { label: "Account", value: contractor.accountNumber ?? "—" },
                { label: "IFSC", value: contractor.ifscCode ?? "—" },
              ].map((row) => (
                <div key={row.label} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{row.label}</span>
                  <span className="font-medium font-mono">{row.value}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Payments */}
        <div className="border border-border rounded-lg p-4 space-y-3">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <CreditCard className="w-4 h-4" /> Payment History
          </h3>
          {/* Summary */}
          <div className="grid grid-cols-2 gap-2 pb-2 border-b border-border">
            <div className="bg-green-500/10 rounded-lg p-2 text-center">
              <div className="text-xs text-muted-foreground">Total Paid</div>
              <div className="font-bold text-green-600 dark:text-green-400 text-sm">{fmtL(totalPaid)}</div>
            </div>
            <div className="bg-orange-500/10 rounded-lg p-2 text-center">
              <div className="text-xs text-muted-foreground">Outstanding</div>
              <div className={`font-bold text-sm ${totalOutstanding > 0 ? "text-orange-600" : "text-green-600"}`}>
                {fmtL(totalOutstanding)}
              </div>
            </div>
          </div>
          {recentPayments.length === 0 ? (
            <p className="text-sm text-muted-foreground">No payments recorded yet</p>
          ) : (
            <div className="space-y-2 overflow-y-auto max-h-64">
              {recentPayments.map((p) => (
                <div key={p._id} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                  <div>
                    <div className="text-sm font-semibold text-green-600 dark:text-green-400">{fmt(p.amount)}</div>
                    <div className="text-xs text-muted-foreground">
                      {p.date} · {p.mode === "bill_payment" ? "Bill Payment" : p.mode.toUpperCase()}
                    </div>
                    {p.description && (
                      <div className="text-xs text-muted-foreground/70">{p.description}</div>
                    )}
                  </div>
                  {p.referenceNumber && (
                    <span className="text-xs text-muted-foreground font-mono">{p.referenceNumber}</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Labour */}
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Users className="w-4 h-4" /> Labour ({labourCount})
            </h3>
            <Link to="/labour" className="text-xs text-primary cursor-pointer">View all</Link>
          </div>
          {labourers.length === 0 ? (
            <p className="text-sm text-muted-foreground">No labourers assigned yet</p>
          ) : (
            <div className="space-y-1 overflow-y-auto max-h-64">
              {labourers.map((l) => (
                <div key={l._id} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                  <div>
                    <div className="text-sm font-medium flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 rounded-full ${l.isActive ? "bg-green-500" : "bg-gray-400"}`} />
                      {l.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{l.siteName} · {l.designation ?? "General"}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-semibold">{fmt(l.dailyRate)}/day</div>
                  </div>
                </div>
              ))}
              {labourCount > 10 && (
                <p className="text-xs text-muted-foreground text-center pt-1">+{labourCount - 10} more</p>
              )}
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
