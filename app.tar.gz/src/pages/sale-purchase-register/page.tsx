import { useState } from "react";
import { useQuery } from "convex/react";
import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs.tsx";
import { BookOpen, ShoppingCart, Receipt, Search, Download, FileText } from "lucide-react";
import { cn } from "@/lib/utils.ts";
import {
  downloadPurchaseRegisterCSV,
  downloadSaleRegisterCSV,
} from "@/lib/csv-exports.ts";
import {
  downloadPurchaseRegisterPDF,
  downloadSaleRegisterPDF,
} from "@/lib/pdf-exports.ts";

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];
const OUR_COMPANIES = ["JAI AAINATH INTERIOR", "JAI GANESH INTERIOR"];

function fmt(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}
function fmtDate(d: string | undefined) {
  if (!d) return "-";
  const [y, m, day] = d.split("T")[0].split("-");
  return `${day}-${m}-${y}`;
}

// ─── Purchase Register Tab ─────────────────────────────────────────────────────
function PurchaseRegister() {
  const [fy, setFy] = useState("2026-27");
  const [company, setCompany] = useState("JAI AAINATH INTERIOR");
  const [search, setSearch] = useState("");

  const items = useQuery(api.salePurchaseRegister.purchaseItems, {
    financialYear: fy,
    ourCompanyName: company,
  });

  const filtered = (items ?? []).filter((it) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      it.description.toLowerCase().includes(q) ||
      it.vendorName.toLowerCase().includes(q) ||
      it.billNo.toLowerCase().includes(q)
    );
  });

  const totalQty = filtered.reduce((s, i) => s + i.quantity, 0);
  const totalAmount = filtered.reduce((s, i) => s + i.amount, 0);

  function handleCsvExport() {
    downloadPurchaseRegisterCSV(filtered, company, fy);
  }

  function handlePdfExport() {
    downloadPurchaseRegisterPDF(filtered, company, fy, totalQty, totalAmount);
  }

  return (
    <div className="space-y-3">
      {/* Filters + Export */}
      <div className="flex flex-wrap items-center gap-2">
        <Select value={company} onValueChange={setCompany}>
          <SelectTrigger className="w-56 h-9 text-sm font-semibold"><SelectValue /></SelectTrigger>
          <SelectContent>
            {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fy} onValueChange={setFy}>
          <SelectTrigger className="w-28 h-9 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Item / vendor / bill no dhundein..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-9"
          />
        </div>
        <div className="flex items-center gap-1.5 ml-auto">
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            disabled={filtered.length === 0}
            onClick={handleCsvExport}
          >
            <Download className="w-3.5 h-3.5" /> CSV
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            disabled={filtered.length === 0}
            onClick={handlePdfExport}
          >
            <FileText className="w-3.5 h-3.5" /> PDF
          </Button>
        </div>
      </div>

      {items === undefined ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-9 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p>Koi purchase item nahi mila.</p>
        </div>
      ) : (
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-xs border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-orange-600 text-white">
                <th className="border border-orange-500/30 px-2 py-1.5 text-center w-10">S.No</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-center w-24">Bill Date</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-left min-w-[150px]">Vendor</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-left w-28">Bill No</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-left min-w-[180px]">Item / Description</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-center w-16">Unit</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-right w-16">Qty</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-right w-24">Rate ₹</th>
                <th className="border border-orange-500/30 px-2 py-1.5 text-right w-28">Amount ₹</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((it, idx) => (
                <tr key={it.key} className={cn(idx % 2 === 0 ? "bg-white" : "bg-orange-50/30", "text-gray-900")}>
                  <td className="border border-gray-200 px-2 py-1 text-center text-gray-500">{idx + 1}</td>
                  <td className="border border-gray-200 px-2 py-1 text-center">{fmtDate(it.billDate)}</td>
                  <td className="border border-gray-200 px-2 py-1 font-semibold">
                    {it.vendorName}
                    <span className={cn("ml-1 text-[9px] px-1 py-0.5 rounded",
                      it.vendorType === "supplier" ? "bg-blue-100 text-blue-800" : "bg-orange-100 text-orange-800")}>
                      {it.vendorType === "supplier" ? "SUP" : "CON"}
                    </span>
                  </td>
                  <td className="border border-gray-200 px-2 py-1 font-mono text-[10px]">{it.billNo}</td>
                  <td className={cn("border border-gray-200 px-2 py-1", !it.hasItems && "text-gray-400 italic")}>{it.description}</td>
                  <td className="border border-gray-200 px-2 py-1 text-center">{it.unit}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right">{it.quantity}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right">{fmt(it.ratePerUnit)}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right font-bold">{fmt(it.amount)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-orange-50 font-bold border-t-2 border-orange-400 text-gray-900">
                <td colSpan={6} className="border border-gray-300 px-2 py-1.5 text-right">TOTAL →</td>
                <td className="border border-gray-300 px-2 py-1.5 text-right">{fmt(totalQty)}</td>
                <td className="border border-gray-300" />
                <td className="border border-gray-300 px-2 py-1.5 text-right">{fmt(totalAmount)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Sale Register Tab ─────────────────────────────────────────────────────────
function SaleRegister() {
  const [search, setSearch] = useState("");
  const items = useQuery(api.salePurchaseRegister.saleItems, {});

  const filtered = (items ?? []).filter((it) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      it.description.toLowerCase().includes(q) ||
      it.clientName.toLowerCase().includes(q) ||
      it.invoiceNumber.toLowerCase().includes(q)
    );
  });

  const totalQty = filtered.reduce((s, i) => s + i.quantity, 0);
  const totalAmount = filtered.reduce((s, i) => s + i.amount, 0);

  function handleCsvExport() {
    downloadSaleRegisterCSV(filtered, "all");
  }

  function handlePdfExport() {
    downloadSaleRegisterPDF(filtered, "All Clients", totalQty, totalAmount);
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Item / client / invoice no dhundein..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-9"
          />
        </div>
        <div className="flex items-center gap-1.5 ml-auto">
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            disabled={filtered.length === 0}
            onClick={handleCsvExport}
          >
            <Download className="w-3.5 h-3.5" /> CSV
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            disabled={filtered.length === 0}
            onClick={handlePdfExport}
          >
            <FileText className="w-3.5 h-3.5" /> PDF
          </Button>
        </div>
      </div>

      {items === undefined ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-9 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Receipt className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p>Koi sale item nahi mila.</p>
        </div>
      ) : (
        <div className="rounded-lg border overflow-x-auto">
          <table className="w-full text-xs border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-emerald-600 text-white">
                <th className="border border-emerald-500/30 px-2 py-1.5 text-center w-10">S.No</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-center w-24">Date</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-left min-w-[150px]">Client</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-left w-28">Invoice No</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-left min-w-[180px]">Item / Description</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-center w-16">Unit</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-right w-16">Qty</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-right w-24">Rate ₹</th>
                <th className="border border-emerald-500/30 px-2 py-1.5 text-right w-28">Amount ₹</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((it, idx) => (
                <tr key={it.key} className={cn(idx % 2 === 0 ? "bg-white" : "bg-emerald-50/30", "text-gray-900")}>
                  <td className="border border-gray-200 px-2 py-1 text-center text-gray-500">{idx + 1}</td>
                  <td className="border border-gray-200 px-2 py-1 text-center">{fmtDate(it.issueDate)}</td>
                  <td className="border border-gray-200 px-2 py-1 font-semibold">{it.clientName}</td>
                  <td className="border border-gray-200 px-2 py-1 font-mono text-[10px]">{it.invoiceNumber}</td>
                  <td className="border border-gray-200 px-2 py-1">{it.description}</td>
                  <td className="border border-gray-200 px-2 py-1 text-center">{it.unit}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right">{it.quantity}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right">{fmt(it.rate)}</td>
                  <td className="border border-gray-200 px-2 py-1 text-right font-bold">{fmt(it.amount)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-emerald-50 font-bold border-t-2 border-emerald-400 text-gray-900">
                <td colSpan={6} className="border border-gray-300 px-2 py-1.5 text-right">TOTAL →</td>
                <td className="border border-gray-300 px-2 py-1.5 text-right">{fmt(totalQty)}</td>
                <td className="border border-gray-300" />
                <td className="border border-gray-300 px-2 py-1.5 text-right">{fmt(totalAmount)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}

function SalePurchaseRegisterInner() {
  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center gap-3">
        <BookOpen className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Sale &amp; Purchase Register</h1>
          <p className="text-muted-foreground text-sm">Item-wise sale aur purchase entries ek jagah</p>
        </div>
      </div>

      <Tabs defaultValue="purchase" className="w-full">
        <TabsList>
          <TabsTrigger value="purchase" className="cursor-pointer gap-1.5">
            <ShoppingCart className="w-4 h-4" /> Purchase Register
          </TabsTrigger>
          <TabsTrigger value="sale" className="cursor-pointer gap-1.5">
            <Receipt className="w-4 h-4" /> Sale Register
          </TabsTrigger>
        </TabsList>
        <TabsContent value="purchase" className="mt-4">
          <PurchaseRegister />
        </TabsContent>
        <TabsContent value="sale" className="mt-4">
          <SaleRegister />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function SalePurchaseRegisterPage() {
  return (
    <>
      <Unauthenticated><div className="flex items-center justify-center h-64"><SignInButton /></div></Unauthenticated>
      <Authenticated><SalePurchaseRegisterInner /></Authenticated>
    </>
  );
}
