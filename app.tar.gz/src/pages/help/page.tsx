import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import {
  BookOpen,
  ChevronDown,
  ChevronRight,
  Users,
  Package,
  HardHat,
  ClipboardList,
  CheckCircle2,
  ArrowRight,
  Building2,
  MapPin,
  ShieldCheck,
  Truck,
  ExternalLink,
  Search,
  UserPlus,
  Key,
  Send,
  Eye,
  BadgeCheck,
  FileSpreadsheet,
  Upload,
  BarChart3,
  TrendingDown,
} from "lucide-react";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";

// ─── Types ─────────────────────────────────────────────────────────────────

type Step = {
  icon?: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  link?: { label: string; to: string };
  tip?: string;
};

type Section = {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badge: string;
  title: string;
  subtitle: string;
  steps: Step[];
};

// ─── Guide Content ─────────────────────────────────────────────────────────

const SECTIONS: Section[] = [
  {
    id: "labour-register",
    icon: UserPlus,
    color: "text-blue-600",
    badge: "bg-blue-500/10 text-blue-600",
    title: "Labour Register Karna",
    subtitle: "Kisi bhi labourer ko system mein kaise add karein, supervisor kaise banayein",
    steps: [
      {
        icon: Building2,
        title: "Pehle Company & Site Set Karo",
        desc: "Labour add karne se pehle ensure karo ki company aur site already bani hui hai. Agar nahi bani, pehle Companies → Sites mein jao aur banao.",
        link: { label: "Sites page pe jao", to: "/sites" },
      },
      {
        icon: UserPlus,
        title: "Labour → New Labour",
        desc: "Labour page pe jao aur 'New Labour' button dabao. Name, mobile, daily rate, aur site select karo. Aadhaar optional hai.",
        link: { label: "Labour page", to: "/labour" },
      },
      {
        icon: Key,
        title: "Worker Code set karo (Supervisor ke liye)",
        desc: "Agar ye labourer Site Supervisor ya Safety Supervisor hai — toh 'Worker Code' field bharein (jaise S001, SUP01) aur checkbox tick karo. Yahi code supervisor portal login ke liye use hoga.",
        tip: "Worker Code chhota aur yaad rakhne layak rakho. Supervisor isko daily use karega.",
      },
      {
        icon: BadgeCheck,
        title: "Supervisor flags tick karo",
        desc: "'Is Site Supervisor' ya 'Is Safety Supervisor' checkbox ON karo. Sirf in logon ko Supervisor Portal ka access milega.",
      },
      {
        icon: CheckCircle2,
        title: "Save karo — ho gaya!",
        desc: "Labour ab system mein register ho gaya. Supervisor ka Worker Code portal login ke liye ready hai.",
      },
    ],
  },
  {
    id: "supervisor-portal",
    icon: HardHat,
    color: "text-orange-600",
    badge: "bg-orange-500/10 text-orange-600",
    title: "Supervisor Portal Use Karna",
    subtitle: "Supervisor portal kya hai, kaise login karein aur kya kya kar sakte hain",
    steps: [
      {
        icon: ExternalLink,
        title: "Portal ka URL",
        desc: "Supervisor portal alag page hai — koi admin login nahi chahiye. Browser mein kholo: [your-app-url]/portal/supervisor",
        tip: "Supervisor ko ye link share karo. Mobile ya PC dono pe kaam karta hai.",
      },
      {
        icon: Key,
        title: "Login — Worker ID dalein",
        desc: "Portal khulne pe 'Worker ID' box aayega. Supervisor apna Worker Code type kare (jaise S001) aur 'Login Karo' dabaye. Koi password nahi chahiye.",
        link: { label: "Supervisor Portal", to: "/portal/supervisor" },
      },
      {
        icon: ClipboardList,
        title: "Hajri Tab — Attendance mark karo",
        desc: "Login ke baad 'Hajri' tab dikhega. Date select karo aur har labourer ke liye Present/Absent/Half Day/Holiday dabao. 'Save Attendance' se save hota hai.",
      },
      {
        icon: CheckCircle2,
        title: "Advance Tab — Advance entry karo",
        desc: "'Advance' tab mein jakar 'New Advance Entry' se kisi labourer ko advance dene ki entry karo — amount aur date ke saath.",
      },
      {
        icon: Package,
        title: "Material Tab — Material request bhejo",
        desc: "'Material' tab mein 'Material Request Karo' button dabao. Item ka naam, quantity, unit, urgency (Low/Medium/High) aur optional photo attach karo, phir bhejo.",
        tip: "High urgency = Aaj chahiye, Medium = 2-3 din, Low = koi jaldi nahi.",
      },
      {
        icon: Eye,
        title: "Request ka status dekhna",
        desc: "Material tab mein request list mein status dikhega: Requested → PO Issued → Delivered. Jab admin supplier assign kare, supplier ka naam aur mobile bhi dikhega.",
      },
    ],
  },
  {
    id: "material-request-flow",
    icon: Package,
    color: "text-purple-600",
    badge: "bg-purple-500/10 text-purple-600",
    title: "Material Request Flow",
    subtitle: "Supervisor request se lekar delivery tak — poora process",
    steps: [
      {
        icon: Send,
        title: "Step 1 — Supervisor Request Bhejta Hai",
        desc: "Supervisor /portal/supervisor pe login kare → Material tab → 'Material Request Karo'. Item naam, qty, unit, urgency aur notes bhare. Photo optional hai (item ki photo ya specification).",
        link: { label: "Supervisor Portal", to: "/portal/supervisor" },
      },
      {
        icon: Eye,
        title: "Step 2 — Admin Requests Dekhta Hai",
        desc: "Admin 'Material Requests' page pe jata hai. Yahan sab sites ke requests dikhte hain — urgency color ke saath (Red=High, Orange=Medium, Green=Low). Filter by site ya status bhi kar sakte ho.",
        link: { label: "Material Requests", to: "/material-requests" },
      },
      {
        icon: Truck,
        title: "Step 3 — Admin Supplier Assign Karta Hai (PO Issue)",
        desc: "'Review' button dabao → Supplier dropdown se supplier chunein → 'Issue PO' dabao. Status 'PO Issued' ho jaati hai. Supervisor ko portal mein supplier ka naam aur mobile number dikhne lagta hai.",
        tip: "Pehle Suppliers page pe suppliers add karo taki dropdown mein aayein.",
        link: { label: "Suppliers Page", to: "/suppliers" },
      },
      {
        icon: CheckCircle2,
        title: "Step 4 — Delivery Confirm Karo",
        desc: "Jab material site pe aa jaye, admin Material Requests page pe jao → PO Issued request dhundho → 'Review' → 'Mark Delivered'. Status 'Delivered' ho jaati hai.",
      },
      {
        icon: ShieldCheck,
        title: "Reject karna (agar zarurat ho)",
        desc: "Agar request sahi nahi lagi — 'Review' → admin note dalein → 'Reject' dabao. Supervisor portal mein status 'Rejected' dikhega note ke saath.",
      },
    ],
  },
  {
    id: "boq-system",
    icon: FileSpreadsheet,
    color: "text-amber-600",
    badge: "bg-amber-500/10 text-amber-600",
    title: "BOQ Rate System (L1/L2/L3)",
    subtitle: "Admin BOQ upload karta hai, vendors rate bharte hain, L1/L2/L3 se best rate final hota hai",
    steps: [
      {
        icon: Upload,
        title: "Step 1 — Admin BOQ Excel Upload Karta Hai",
        desc: "Admin 'BOQ Management' page pe jata hai → 'New BOQ Upload' → Excel file choose karta hai (columns: Description, Unit, Quantity) → Title aur Company fill karta hai → Create karta hai.",
        link: { label: "BOQ Management", to: "/boq" },
      },
      {
        icon: Users,
        title: "Step 2 — Vendors / Suppliers Ko Invite Karo",
        desc: "'Vendors Invite' button se suppliers aur contractors ko select karo. Phir 'WhatsApp' ya 'Email' button se unhe link bhejo. Har invited vendor ka naam list mein aata hai.",
      },
      {
        icon: FileSpreadsheet,
        title: "Step 3 — Vendor Rate Bharta Hai",
        desc: "Vendor apna link kholta hai → Apna naam select karta hai → Template Excel download karta hai → 'Rate Per Unit' column bharta hai → Upload karta hai ya directly table mein rates type karta hai → Submit karta hai.",
        tip: "Vendor bina kisi login ke yah kaam kar sakta hai. Sirf link chahiye.",
      },
      {
        icon: BarChart3,
        title: "Step 4 — Admin L1/L2/L3 Compare Karta Hai",
        desc: "'Compare & Issue PO' button se comparison page khulta hai. Yahan sab vendors ki rates side-by-side dikhti hain. Lowest bid ko L1, doosre ko L2, teesre ko L3 kaha jata hai. Admin 'Vendors Ko L1/L2/L3 Dikhayein' button dabata hai.",
        link: { label: "Compare Page", to: "/boq" },
      },
      {
        icon: TrendingDown,
        title: "Step 5 — Vendors Apni Rank Dekhte Hain Aur Rate Revise Karte Hain",
        desc: "L1/L2/L3 publish hone ke baad vendor apne portal mein apni rank dekhta hai. Usse apna rate aur L1 se fark dikhta hai. Agar chahein toh 'Rate Revise Karein' se apna rate kam kar sakta hai.",
        tip: "Sirf L2, L3 vendors revise karte hain. L1 ko revision ki zarurat nahi — woh already sabse kam hai.",
      },
      {
        icon: CheckCircle2,
        title: "Step 6 — Admin Final Rate Select Karke PO Issue Karta Hai",
        desc: "Final round ke baad admin L1 vendor ko 'Select' karta hai → 'Purchase Order Issue Karein' dialog mein site aur supplier fill karta hai → PO issue hota hai. Iske baad hi kaam shuru hota hai ya supply milti hai.",
        tip: "PO issue hone ke baad status 'Ordered' ho jaata hai. Sirf tab supply ya kaam start hona chahiye.",
      },
    ],
  },
  {
    id: "safety-supervisor",
    icon: ShieldCheck,
    color: "text-green-600",
    badge: "bg-green-500/10 text-green-600",
    title: "Safety Supervisor Portal",
    subtitle: "Safety supervisor ka alag portal — violations, PPE, reports",
    steps: [
      {
        icon: UserPlus,
        title: "Safety Supervisor Register Karo",
        desc: "Labour page pe jao → Safety Supervisor ko add karo → 'Is Safety Supervisor' checkbox ON karo → Worker Code set karo (jaise SS001).",
        link: { label: "Labour Page", to: "/labour" },
      },
      {
        icon: ExternalLink,
        title: "Safety Portal URL",
        desc: "Safety supervisor ka portal alag hai: /portal/safety-supervisor. Iska link safety supervisor ko share karo.",
        link: { label: "Safety Supervisor Portal", to: "/portal/safety-supervisor" },
      },
      {
        icon: ClipboardList,
        title: "Portal Features",
        desc: "Safety supervisor portal mein: Safety violations report karna, PPE distribution dekhna, daily safety reports submit karna — sab kuch unhi ke site ka.",
      },
    ],
  },
  {
    id: "quick-tips",
    icon: BookOpen,
    color: "text-teal-600",
    badge: "bg-teal-500/10 text-teal-600",
    title: "Quick Tips & FAQ",
    subtitle: "Common sawaal aur zaroori baatein",
    steps: [
      {
        title: "Supervisor portal mein login nahi ho raha?",
        desc: "Check karo: 1) Labour page pe us labourer ka Worker Code set hai ki nahi. 2) 'Is Site Supervisor' ya 'Is Safety Supervisor' checkbox ON hai ki nahi. 3) Worker Code bilkul wahi type karo jo set kiya tha (uppercase).",
        icon: Key,
      },
      {
        title: "Supplier dropdown mein supplier nahi aa raha?",
        desc: "Suppliers page pe supplier add karo aur 'Is Active' ON rakho. Inactive suppliers dropdown mein nahi aate.",
        link: { label: "Suppliers Page", to: "/suppliers" },
        icon: Truck,
      },
      {
        title: "Ek labourer site supervisor bhi hai aur safety supervisor bhi?",
        desc: "Dono checkboxes ON kar sakte ho — Site Supervisor aur Safety Supervisor. Wo dono portals use kar sakta hai.",
        icon: BadgeCheck,
      },
      {
        title: "Material request photo kaise attach karein?",
        desc: "Supervisor portal ke Material tab mein 'Material Request Karo' form mein neeche 'Photo Add Karo' button hai. Camera se kheench sakte ho ya gallery se choose kar sakte ho.",
        icon: Package,
      },
      {
        title: "Admin kahan sab kuch manage karta hai?",
        desc: "Admin dashboard se: Labour, Sites, Materials, Purchase Orders, Salary, Invoices, Payments — sab ek jagah pe. Supervisor portal sirf field supervisors ke liye hai.",
        link: { label: "Dashboard", to: "/dashboard" },
        icon: Building2,
      },
    ],
  },
];

// ─── Accordion Section ─────────────────────────────────────────────────────

function GuideSection({ section }: { section: Section }) {
  const [open, setOpen] = useState(false);
  const Icon = section.icon;

  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-muted/40 transition-colors cursor-pointer"
      >
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0", section.badge)}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold">{section.title}</p>
            <Badge variant="outline" className={cn("text-xs", section.badge)}>{section.steps.length} steps</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">{section.subtitle}</p>
        </div>
        {open ? <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" /> : <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" as const }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-0">
              {section.steps.map((step, i) => {
                const StepIcon = step.icon;
                return (
                  <div key={i} className="flex gap-4 py-4 border-b border-border last:border-0">
                    {/* Step number + connector */}
                    <div className="flex flex-col items-center gap-1 flex-shrink-0">
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2",
                        "bg-background border-primary/30 text-primary"
                      )}>
                        {i + 1}
                      </div>
                      {i < section.steps.length - 1 && (
                        <div className="w-0.5 flex-1 bg-border min-h-4" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-1.5">
                      <div className="flex items-center gap-2">
                        {StepIcon && <StepIcon className={cn("w-4 h-4 flex-shrink-0", section.color)} />}
                        <p className="font-medium text-sm">{step.title}</p>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
                      {step.tip && (
                        <div className="bg-amber-500/10 border border-amber-500/20 rounded-md px-3 py-2">
                          <p className="text-xs text-amber-700 dark:text-amber-400">
                            Tip: {step.tip}
                          </p>
                        </div>
                      )}
                      {step.link && (
                        <Link
                          to={step.link.to}
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline font-medium mt-1"
                        >
                          <ArrowRight className="w-3 h-3" />
                          {step.link.label}
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Main Page ──────────────────────────────────────────────────────────────

export default function HelpPage() {
  const [search, setSearch] = useState("");

  const filtered = SECTIONS.filter((s) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      s.title.toLowerCase().includes(q) ||
      s.subtitle.toLowerCase().includes(q) ||
      s.steps.some((st) => st.title.toLowerCase().includes(q) || st.desc.toLowerCase().includes(q))
    );
  });

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-1">
          <div className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Help & Guide</h1>
        </div>
        <p className="text-muted-foreground text-sm">
          Labour register karna, supervisor portal use karna, material requests — sab kuch step by step.
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Guide mein search karo..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Quick links */}
      {!search && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { icon: Users, label: "Labour Register", to: "/labour", color: "text-blue-600", bg: "bg-blue-500/10" },
            { icon: HardHat, label: "Supervisor Portal", to: "/portal/supervisor", color: "text-orange-600", bg: "bg-orange-500/10" },
            { icon: Package, label: "Material Requests", to: "/material-requests", color: "text-purple-600", bg: "bg-purple-500/10" },
            { icon: Truck, label: "Suppliers", to: "/suppliers", color: "text-teal-600", bg: "bg-teal-500/10" },
            { icon: MapPin, label: "Sites", to: "/sites", color: "text-green-600", bg: "bg-green-500/10" },
            { icon: ShieldCheck, label: "Safety Portal", to: "/portal/safety-supervisor", color: "text-red-600", bg: "bg-red-500/10" },
            { icon: FileSpreadsheet, label: "BOQ Management", to: "/boq", color: "text-amber-600", bg: "bg-amber-500/10" },
          ].map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex items-center gap-3 p-3 rounded-xl border border-border hover:bg-muted/50 transition-colors cursor-pointer group"
            >
              <div className={cn("w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0", item.bg)}>
                <item.icon className={cn("w-4 h-4", item.color)} />
              </div>
              <span className="text-sm font-medium group-hover:text-primary transition-colors">{item.label}</span>
              <ExternalLink className="w-3 h-3 text-muted-foreground ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
          ))}
        </div>
      )}

      {/* Guide sections */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <p className="text-center text-muted-foreground py-10">Koi result nahi mila "{search}" ke liye</p>
        ) : (
          filtered.map((section) => (
            <GuideSection key={section.id} section={section} />
          ))
        )}
      </div>

      {/* Footer note */}
      {!search && (
        <div className="bg-muted/40 rounded-xl p-4 text-sm text-muted-foreground text-center">
          Aur koi sawaal hai? Admin se sampark karein ya supervisor portal ka link share karein:
          {" "}
          <Link to="/portal/supervisor" className="text-primary font-medium hover:underline inline-flex items-center gap-1">
            /portal/supervisor <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
      )}
    </div>
  );
}
