import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Building2, Package, IndianRupee, Receipt, FileSpreadsheet, TrendingUp, Clock, CheckCircle2, ShoppingCart } from "lucide-react";
import { format } from "date-fns";
import { PortalRABillForm } from "../_components/portal-ra-bill-form.tsx";
import { PortalBillAttachments } from "../_components/portal-bill-attachments.tsx";
import { ChallanAttachments } from "../_components/challan-attachments.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const fmt = (n: number) =>
  n >= 100000
    ? `₹${(n / 100000).toFixed(1)}L`
    : n >= 1000
    ? `₹${(n / 1000).toFixed(0)}K`
    : `₹${n.toLocaleString("en-IN")}`;

export default function SupplierPortal() {
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [activeTab, setActiveTab] = useState<"pos" | "bills" | "deliveries" | "payments">("pos");

  const data = useQuery(api.portal.supplier.getByToken, token ? { token } : "skip");
  const materials = useQuery(api.portal.supplier.getMaterialsByToken, token ? { token } : "skip");
  const payments = useQuery(api.portal.supplier.getPaymentsByToken, token ? { token } : "skip");
  const bills = useQuery(api.portal.supplier.getBillsByToken, token ? { token } : "skip") ?? [];
  const pos = useQuery(api.portal.supplier.getPOsByToken, token ? { token } : "skip") ?? [];

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center p-8">
          <Building2 className="mx-auto mb-4 text-slate-500" size={48} />
          <h2 className="text-xl font-bold text-white mb-2">Invalid Link</h2>
          <p className="text-slate-400">Please use the link provided to you.</p>
        </div>
      </div>
    );
  }

  if (data === undefined) {
    return (
      <div className="min-h-screen bg-slate-900 p-4 space-y-4">
        <Skeleton className="h-40 w-full bg-slate-800" />
        <Skeleton className="h-32 w-full bg-slate-800" />
        <Skeleton className="h-64 w-full bg-slate-800" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="text-red-400 font-semibold">Supplier record not found.</p>
      </div>
    );
  }

  const { supplier } = data;
  const totalSupplied = materials?.reduce((sum, m) => sum + m.totalAmount, 0) ?? 0;
  const totalPaid = payments?.reduce((sum, p) => sum + p.amount, 0) ?? 0;
  const balance = totalSupplied - totalPaid;

  const pendingBills = bills.filter((b) => b.status === "received" || b.status === "verified").length;
  const paidBills = bills.filter((b) => b.status === "paid").length;

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 px-4 pt-6 pb-10">
        <div className="max-w-2xl mx-auto">
          <p className="text-blue-200 text-xs font-semibold uppercase tracking-widest mb-1">
            JAI SITE MANAGER ERP — SUPPLIER PORTAL
          </p>
          <h1 className="text-3xl font-extrabold text-white">{supplier.name}</h1>
          <p className="text-blue-200 mt-1 text-sm">{supplier.city ?? ""} · {supplier.mobile}</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 -mt-6 space-y-5 pb-10">
        {/* KPI Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-slate-800 border border-blue-700/50 rounded-xl p-4 text-center">
            <TrendingUp className="mx-auto mb-1 text-blue-400" size={20} />
            <p className="text-xl font-extrabold text-blue-300">{fmt(totalSupplied)}</p>
            <p className="text-xs text-slate-400 mt-0.5">Total Supplied</p>
          </div>
          <div className="bg-slate-800 border border-green-700/50 rounded-xl p-4 text-center">
            <CheckCircle2 className="mx-auto mb-1 text-green-400" size={20} />
            <p className="text-xl font-extrabold text-green-300">{fmt(totalPaid)}</p>
            <p className="text-xs text-slate-400 mt-0.5">Total Paid</p>
          </div>
          <div className="bg-slate-800 border border-red-700/50 rounded-xl p-4 text-center">
            <Clock className="mx-auto mb-1 text-red-400" size={20} />
            <p className="text-xl font-extrabold text-red-300">{fmt(balance)}</p>
            <p className="text-xs text-slate-400 mt-0.5">Balance Due</p>
          </div>
        </div>

        {/* Bill Submit Section */}
        <div className="bg-slate-800 border border-emerald-700/50 rounded-xl overflow-hidden">
          <div className="bg-emerald-700 px-4 py-3 flex items-center gap-2">
            <FileSpreadsheet size={18} className="text-white" />
            <span className="text-white font-bold text-base">Naya Bill Submit Karein</span>
            {pendingBills > 0 && (
              <span className="ml-auto bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-0.5 rounded-full">
                {pendingBills} Pending
              </span>
            )}
          </div>
          <div className="p-4">
            <PortalRABillForm token={token} vendorType="supplier" />
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex bg-slate-800 rounded-xl p-1 gap-1 flex-wrap">
          {(["pos", "bills", "deliveries", "payments"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-colors ${
                activeTab === tab
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {tab === "pos" ? `PO (${pos.length})` : tab === "bills" ? `Bills (${bills.length})` : tab === "deliveries" ? `Delivery (${materials?.length ?? 0})` : `Payment (${payments?.length ?? 0})`}
            </button>
          ))}
        </div>

        {/* Purchase Orders Tab */}
        {activeTab === "pos" && (
          <div className="space-y-3">
            {pos.length === 0 && (
              <div className="bg-slate-800 rounded-xl p-8 text-center text-slate-400">
                <ShoppingCart className="mx-auto mb-3 text-slate-600" size={40} />
                <p className="font-semibold text-white mb-1">Koi Purchase Order nahi hai</p>
                <p className="text-sm">Jab admin aapko PO dega, yahan dikhega</p>
              </div>
            )}
            {pos.map((po) => {
              const statusColor =
                po.status === "closed" ? "bg-green-800 text-green-200" :
                po.status === "cancelled" ? "bg-red-800 text-red-200" :
                po.status === "sent" ? "bg-blue-800 text-blue-200" :
                po.status === "partially_received" ? "bg-yellow-800 text-yellow-200" :
                "bg-slate-700 text-slate-300";
              const statusLabel =
                po.status === "sent" ? "BHEJA GAYA" :
                po.status === "closed" ? "COMPLETE" :
                po.status === "cancelled" ? "CANCEL" :
                po.status === "partially_received" ? "PART RECEIVED" :
                po.status?.toUpperCase() ?? "PENDING";
              return (
                <div key={po._id} className="bg-slate-800 border border-blue-700/40 rounded-xl p-4">
                  {po.companyName && po.companyName !== "—" && (
                    <div className="flex items-center gap-1.5 mb-2">
                      <Building2 size={12} className="text-yellow-400 shrink-0" />
                      <span className="text-yellow-300 text-xs font-bold uppercase tracking-wide">{po.companyName}</span>
                    </div>
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <ShoppingCart size={14} className="text-blue-400 shrink-0" />
                        <span className="font-bold text-white">{po.poNumber}</span>
                        <span className={`text-xs px-2 py-0.5 rounded font-bold ${statusColor}`}>{statusLabel}</span>
                      </div>
                      <p className="text-slate-400 text-xs mt-1">{po.siteName}</p>
                      {po.issueDate && (
                        <p className="text-slate-500 text-xs">Issued: {format(new Date(po.issueDate + "T00:00:00"), "dd MMM yyyy")}</p>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-white font-extrabold text-lg">₹{po.totalValue.toLocaleString("en-IN")}</p>
                      <p className="text-slate-400 text-xs">{po.items?.length ?? 0} items</p>
                    </div>
                  </div>
                  {/* Show PO items */}
                  {po.items && po.items.length > 0 && (
                    <div className="mt-3 space-y-1.5 border-t border-slate-700 pt-3">
                      {po.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-start text-xs">
                          <span className="text-slate-300 flex-1 pr-2">{item.name}</span>
                          <span className="text-slate-400 shrink-0">{item.quantity} {item.unit} × ₹{item.ratePerUnit} = <span className="text-white font-semibold">₹{item.totalAmount.toLocaleString("en-IN")}</span></span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Bills Tab */}
        {activeTab === "bills" && (
          <div className="space-y-3">
            {bills.length === 0 && (
              <div className="bg-slate-800 rounded-xl p-8 text-center text-slate-400">
                <Receipt className="mx-auto mb-3 text-slate-600" size={40} />
                <p>Abhi koi bill submit nahi hua</p>
              </div>
            )}
            {bills.map((b) => {
              const outstanding = b.totalAmount - b.paidAmount;
              const statusColor =
                b.status === "paid" ? "bg-green-800 text-green-200" :
                b.status === "approved" ? "bg-blue-800 text-blue-200" :
                b.status === "verified" ? "bg-yellow-800 text-yellow-200" :
                "bg-slate-700 text-slate-300";
              return (
                <div key={b._id} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  {/* Company name */}
                  {b.companyName && b.companyName !== "—" && (
                    <div className="flex items-center gap-1.5 mb-2">
                      <Building2 size={12} className="text-yellow-400 shrink-0" />
                      <span className="text-yellow-300 text-xs font-bold uppercase tracking-wide">{b.companyName}</span>
                    </div>
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white text-base">{b.billNumber}</span>
                        {b.billType === "ra" && (
                          <span className="bg-blue-700 text-blue-100 text-xs px-2 py-0.5 rounded font-bold">RA-{b.raNumber}</span>
                        )}
                        {b.billType === "final" && (
                          <span className="bg-purple-700 text-purple-100 text-xs px-2 py-0.5 rounded font-bold">Final</span>
                        )}
                        <span className={`text-xs px-2 py-0.5 rounded font-bold ${statusColor}`}>{b.status.toUpperCase()}</span>
                      </div>
                      <p className="text-slate-400 text-xs mt-1">{b.siteName} · {b.billDate}</p>
                      {b.poNumber && <p className="text-slate-500 text-xs">PO: {b.poNumber}</p>}
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-white font-extrabold text-lg">₹{b.totalAmount.toLocaleString("en-IN")}</p>
                      {outstanding > 0 && b.status !== "paid" ? (
                        <p className="text-orange-400 text-xs font-semibold">₹{outstanding.toLocaleString("en-IN")} baki</p>
                      ) : (
                        <p className="text-green-400 text-xs font-semibold">Paid ✓</p>
                      )}
                    </div>
                  </div>
                  {/* Attachment upload section */}
                  <PortalBillAttachments token={token} billId={b._id as Id<"vendorBills">} vendorType="supplier" />
                </div>
              );
            })}
          </div>
        )}

        {/* Deliveries Tab */}
        {activeTab === "deliveries" && (
          <div className="space-y-3">
            {materials?.length === 0 && (
              <div className="bg-slate-800 rounded-xl p-8 text-center text-slate-400">
                <Package className="mx-auto mb-3 text-slate-600" size={40} />
                <p>Koi delivery record nahi hai</p>
              </div>
            )}
            {materials?.map((mat) => (
              <div key={mat._id} className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-white">{mat.invoiceNumber ?? "Invoice #—"}</p>
                    <p className="text-slate-400 text-xs mt-0.5">
                      {mat.siteName} · {format(new Date(mat.deliveryDate + "T00:00:00"), "dd MMM yyyy")}
                    </p>
                    <p className="text-slate-500 text-xs mt-1 truncate">
                      {mat.items.map((item, i) => `${item.name} (${item.quantity} ${item.unit})`).join(", ")}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-extrabold text-white text-base">₹{mat.totalAmount.toLocaleString("en-IN")}</p>
                    <Badge
                      className={
                        mat.status === "approved" ? "bg-green-800 text-green-200 text-xs" :
                        mat.status === "rejected" ? "bg-red-800 text-red-200 text-xs" :
                        "bg-slate-700 text-slate-300 text-xs"
                      }
                    >
                      {mat.status}
                    </Badge>
                  </div>
                </div>
                {/* Challan / photo upload for this delivery */}
                <ChallanAttachments token={token} materialId={mat._id as Id<"materials">} />
              </div>
            ))}
          </div>
        )}

        {/* Payments Tab */}
        {activeTab === "payments" && (
          <div className="space-y-3">
            {payments?.length === 0 && (
              <div className="bg-slate-800 rounded-xl p-8 text-center text-slate-400">
                <IndianRupee className="mx-auto mb-3 text-slate-600" size={40} />
                <p>Koi payment record nahi hai</p>
              </div>
            )}
            {payments?.map((p) => (
              <div key={p._id} className="bg-slate-800 border border-green-700/40 rounded-xl p-4 flex justify-between items-center">
                <div>
                  <p className="font-bold text-green-300 text-lg">₹{p.amount.toLocaleString("en-IN")}</p>
                  <p className="text-slate-400 text-xs mt-0.5">
                    {(() => { try { return format(new Date(typeof p.date === "number" ? p.date : p.date + "T00:00:00"), "dd MMM yyyy"); } catch { return String(p.date); } })()} {(p as { mode?: string }).mode ? `· ${(p as { mode?: string }).mode!.toUpperCase()}` : ""}
                  </p>
                </div>
                {p.referenceNumber && (
                  <p className="text-slate-400 text-xs font-mono">{p.referenceNumber}</p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Stats summary at bottom */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center justify-between text-xs text-slate-400">
          <span>{bills.length} total bills · {paidBills} paid · {pendingBills} pending</span>
          <span className="text-slate-500">Portal — read only</span>
        </div>
      </div>
    </div>
  );
}
