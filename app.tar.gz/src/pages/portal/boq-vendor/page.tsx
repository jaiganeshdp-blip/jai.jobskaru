import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  FileSpreadsheet, Upload, CheckCircle, Download,
  AlertTriangle, Clock, ChevronRight, RotateCcw, TrendingDown
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function useUrlParam(key: string): string {
  return new URLSearchParams(window.location.search).get(key) ?? "";
}

// Generate a BOQ template Excel for vendor to fill rates
function generateBOQTemplate(
  title: string,
  items: { srNo: number; description: string; unit: string; quantity: number }[]
): void {
  const ws_data: (string | number)[][] = [
    ["Sr No", "Description", "Unit", "Quantity", "Rate Per Unit (₹)", "Total Amount (₹)", "Remarks"],
    ...items.map((item) => [item.srNo, item.description, item.unit, item.quantity, "", "", ""]),
  ];
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(ws_data);
  // Column widths
  ws["!cols"] = [{ wch: 6 }, { wch: 40 }, { wch: 10 }, { wch: 10 }, { wch: 18 }, { wch: 18 }, { wch: 20 }];
  XLSX.utils.book_append_sheet(wb, ws, "BOQ");
  XLSX.writeFile(wb, `BOQ_Rate_Template_${title.replace(/\s+/g, "_")}.xlsx`);
}

export default function BOQVendorPortal() {
  const token = useUrlParam("token");
  const vendorToken = useUrlParam("vendorToken");

  // New flow: vendorToken identifies the specific vendor directly
  const invByVendorToken = useQuery(
    api.boq.invitations.getByVendorToken,
    vendorToken ? { vendorToken } : "skip"
  );
  const boqByInv = useQuery(
    api.boq.projects.get,
    invByVendorToken ? { id: invByVendorToken.boqId } : "skip"
  );

  // Legacy flow: token is the BOQ token (shows vendor selection)
  const boqByToken = useQuery(api.boq.projects.getByToken, token ? { token } : "skip");

  if (!token && !vendorToken) return <ErrorPage msg="Invalid link. Admin se sahi link maangein." />;

  // New vendor-specific link flow
  if (vendorToken) {
    if (invByVendorToken === undefined || boqByInv === undefined) return <LoadingPage />;
    if (invByVendorToken === null) return <ErrorPage msg="Aapka link invalid hai. Admin se naya link maangein." />;
    if (boqByInv === null) return <ErrorPage msg="BOQ nahi mila." />;
    const isExpired = boqByInv.deadlineDate
      ? new Date(boqByInv.deadlineDate) < new Date(new Date().toDateString())
      : false;
    return <BOQPortalMain boq={boqByInv} isExpired={isExpired} preselectedInvitation={invByVendorToken} />;
  }

  // Legacy BOQ token flow
  if (boqByToken === undefined) return <LoadingPage />;
  if (boqByToken === null) return <ErrorPage msg="BOQ nahi mila. Link expire ho gayi ho sakti hai." />;
  const isExpiredLegacy = boqByToken.deadlineDate
    ? new Date(boqByToken.deadlineDate) < new Date(new Date().toDateString())
    : false;
  return <BOQPortalMain boq={boqByToken} isExpired={isExpiredLegacy} />;
}

type BOQDoc = NonNullable<ReturnType<typeof useQuery<typeof api.boq.projects.getByToken>>>;
type InvDoc = NonNullable<Awaited<ReturnType<typeof useQuery<typeof api.boq.invitations.getByVendorToken>>>>;

function BOQPortalMain({ boq, isExpired, preselectedInvitation }: { boq: BOQDoc; isExpired: boolean; preselectedInvitation?: InvDoc }) {
  const invitations = useQuery(api.boq.invitations.listByBoq, { boqId: boq._id }) ?? [];
  const existingSubmissions = useQuery(api.boq.submissions.listByBoq, { boqId: boq._id }) ?? [];
  const markViewed = useMutation(api.boq.invitations.markViewed);

  // Auto-select vendor when preselected invitation is provided
  const [step, setStep] = useState<1 | 2 | 3>(preselectedInvitation ? 2 : 1);
  const [selectedInvId, setSelectedInvId] = useState<Id<"boqInvitations"> | "">(preselectedInvitation?._id ?? "");
  const [vendorName, setVendorName] = useState(preselectedInvitation?.vendorName ?? "");
  const [vendorMobile, setVendorMobile] = useState(preselectedInvitation?.vendorMobile ?? "");
  const [notes, setNotes] = useState("");
  const [rates, setRates] = useState<Record<number, string>>({});
  const [remarks, setRemarks] = useState<Record<number, string>>({});
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [reviseMode, setReviseMode] = useState(false);
  const [reviseRates, setReviseRates] = useState<Record<number, string>>({});
  const [revising, setRevising] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const submitMutation = useMutation(api.boq.submissions.submit);
  const reviseMutation = useMutation(api.boq.submissions.revise);
  const generateUploadUrl = useMutation(api.boq.submissions.generateUploadUrl);

  // Check if selected vendor already submitted
  const mySubmission = existingSubmissions.find((s) => s.invitationId === selectedInvId);

  // Auto mark viewed when vendor opens their direct link
  const hasMarkedViewed = preselectedInvitation != null;
  if (hasMarkedViewed && preselectedInvitation && preselectedInvitation.status === "invited") {
    void markViewed({ id: preselectedInvitation._id });
  }

  async function handleSelectInv(id: Id<"boqInvitations">) {
    setSelectedInvId(id);
    const inv = invitations.find((i) => i._id === id);
    if (inv) {
      if (!vendorName) setVendorName(inv.vendorName);
      if (inv.vendorMobile && !vendorMobile) setVendorMobile(inv.vendorMobile);
    }
    try { await markViewed({ id }); } catch { /* silent */ }
  }

  async function handleExcelParse(file: File) {
    setExcelFile(file);
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
      const newRates: Record<number, string> = {};
      const newRemarks: Record<number, string> = {};
      rows.forEach((row, i) => {
        const srNo = Number(row["Sr No"] ?? row["Sr"] ?? row["SrNo"] ?? i + 1);
        const rate = String(
          row["Rate Per Unit (₹)"] ?? row["Rate Per Unit"] ?? row["Rate"] ?? row["rate"] ?? ""
        ).trim();
        const rem = String(row["Remarks"] ?? row["remarks"] ?? "").trim();
        if (rate && !isNaN(Number(rate))) newRates[srNo] = rate;
        if (rem) newRemarks[srNo] = rem;
      });
      if (Object.keys(newRates).length > 0) {
        setRates((prev) => ({ ...prev, ...newRates }));
        setRemarks((prev) => ({ ...prev, ...newRemarks }));
        toast.success(`${Object.keys(newRates).length} items ki rates fill ho gayi!`);
      } else {
        toast.warning("Excel mein rates nahi mile. Manually bharo ya sahi column names use karo.");
      }
    } catch {
      toast.error("Excel read karne mein error. Sahi format use karein.");
    }
  }

  async function handleSubmit() {
    if (!selectedInvId) { toast.error("Pehle apna naam select karein"); return; }
    if (!vendorName.trim()) { toast.error("Naam bharein"); return; }
    const missingRates = boq.items.filter(
      (item) => !rates[item.srNo] || isNaN(Number(rates[item.srNo])) || Number(rates[item.srNo]) <= 0
    );
    if (missingRates.length > 0) {
      toast.error(`${missingRates.length} items ki rate missing ya zero hai`);
      return;
    }

    setSubmitting(true);
    try {
      let storageId: string | undefined;
      let fileName: string | undefined;
      if (excelFile) {
        const uploadUrl = await generateUploadUrl();
        const res = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": excelFile.type },
          body: excelFile,
        });
        const json = (await res.json()) as { storageId: string };
        storageId = json.storageId;
        fileName = excelFile.name;
      }

      const items = boq.items.map((item) => {
        const rate = Number(rates[item.srNo] ?? 0);
        return {
          srNo: item.srNo,
          description: item.description,
          unit: item.unit,
          quantity: item.quantity,
          ratePerUnit: rate,
          totalAmount: rate * item.quantity,
          remarks: remarks[item.srNo] ?? undefined,
        };
      });
      const totalAmount = items.reduce((s, i) => s + i.totalAmount, 0);

      await submitMutation({
        boqId: boq._id,
        invitationId: selectedInvId,
        vendorName,
        vendorMobile: vendorMobile || undefined,
        items,
        totalAmount,
        excelStorageId: storageId,
        excelFileName: fileName,
        notes: notes || undefined,
      });

      setSubmitted(true);
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setSubmitting(false);
    }
  }

  const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;
  const grandTotal = boq.items.reduce(
    (s, item) => s + Number(rates[item.srNo] ?? 0) * item.quantity,
    0
  );
  const filledCount = boq.items.filter(
    (item) => rates[item.srNo] && Number(rates[item.srNo]) > 0
  ).length;

  // ---- Rankings Published view ----
  if (boq.comparisonPublished && mySubmission && !submitted) {
    const sortedByTotal = [...existingSubmissions].sort((a, b) => a.totalAmount - b.totalAmount);
    const myRankIndex = sortedByTotal.findIndex((s) => s._id === mySubmission._id);
    const rankLabel = myRankIndex === 0 ? "L1" : myRankIndex === 1 ? "L2" : myRankIndex === 2 ? "L3" : `L${myRankIndex + 1}`;
    const l1Sub = sortedByTotal[0];
    const isRevisionExpired = boq.revisionDeadline
      ? new Date(boq.revisionDeadline) < new Date()
      : false;

    const rankBadgeClass =
      rankLabel === "L1" ? "bg-green-100 text-green-800 border border-green-300" :
      rankLabel === "L2" ? "bg-blue-100 text-blue-800 border border-blue-300" :
      "bg-orange-100 text-orange-800 border border-orange-300";

    function handleStartRevise() {
      const initialRates: Record<number, string> = {};
      mySubmission!.items.forEach((item) => { initialRates[item.srNo] = String(item.ratePerUnit); });
      setReviseRates(initialRates);
      setReviseMode(true);
    }

    async function handleReviseSubmit() {
      if (!selectedInvId) return;
      const missingRates = boq.items.filter(
        (item) => !reviseRates[item.srNo] || isNaN(Number(reviseRates[item.srNo])) || Number(reviseRates[item.srNo]) <= 0
      );
      if (missingRates.length > 0) { toast.error(`${missingRates.length} items ki rate missing ya zero hai`); return; }
      setRevising(true);
      try {
        const items = boq.items.map((item) => {
          const rate = Number(reviseRates[item.srNo] ?? 0);
          return {
            srNo: item.srNo, description: item.description, unit: item.unit,
            quantity: item.quantity, ratePerUnit: rate, totalAmount: rate * item.quantity,
          };
        });
        const totalAmount = items.reduce((s, i) => s + i.totalAmount, 0);
        await reviseMutation({
          boqId: boq._id,
          invitationId: selectedInvId,
          vendorName: mySubmission!.vendorName,
          vendorMobile: mySubmission!.vendorMobile,
          items,
          totalAmount,
        });
        setReviseMode(false);
        setSubmitted(true);
      } catch (e) {
        toast.error("Error: " + String(e));
      } finally {
        setRevising(false);
      }
    }

    // Revise form
    if (reviseMode) {
      const reviseGrandTotal = boq.items.reduce(
        (s, item) => s + Number(reviseRates[item.srNo] ?? 0) * item.quantity, 0
      );
      return (
        <PortalShell boq={boq}>
          <Card className="max-w-4xl mx-auto">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingDown size={18} className="text-primary" />
                Revised Rates Bharen
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700">
                Apna rate kam kar sakte hain. L1 ka total: <strong>{fmt(l1Sub?.totalAmount ?? 0)}</strong>
              </div>
              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm min-w-[640px]">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-semibold w-10">Sr</th>
                      <th className="px-3 py-2 text-left text-xs font-semibold">Description</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-16">Unit</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-16">Qty</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-28">Purana Rate</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-32">Naya Rate (₹) *</th>
                      <th className="px-3 py-2 text-right text-xs font-semibold w-28">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {boq.items.map((item) => {
                      const oldRate = mySubmission!.items.find((i) => i.srNo === item.srNo)?.ratePerUnit ?? 0;
                      const newRate = Number(reviseRates[item.srNo] ?? 0);
                      const total = newRate * item.quantity;
                      return (
                        <tr key={item.srNo} className="border-t">
                          <td className="px-3 py-1.5 text-xs">{item.srNo}</td>
                          <td className="px-3 py-1.5 text-xs">{item.description}</td>
                          <td className="px-3 py-1.5 text-xs text-center">{item.unit}</td>
                          <td className="px-3 py-1.5 text-xs text-center">{item.quantity}</td>
                          <td className="px-3 py-1.5 text-xs text-center text-muted-foreground">{fmt(oldRate)}/{item.unit}</td>
                          <td className="px-2 py-1">
                            <Input
                              type="number" min="0"
                              className="h-7 text-xs text-center"
                              value={reviseRates[item.srNo] ?? ""}
                              onChange={(e) => setReviseRates((prev) => ({ ...prev, [item.srNo]: e.target.value }))}
                            />
                          </td>
                          <td className="px-3 py-1.5 text-xs text-right font-medium">
                            {newRate > 0 ? fmt(total) : <span className="text-muted-foreground">—</span>}
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted font-semibold">
                      <td colSpan={6} className="px-3 py-2 text-sm text-right">Grand Total</td>
                      <td className="px-3 py-2 text-sm text-right text-primary">
                        {reviseGrandTotal > 0 ? fmt(reviseGrandTotal) : "—"}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="flex gap-3">
                <Button onClick={handleReviseSubmit} disabled={revising} className="flex-1">
                  {revising ? "Submit ho raha hai..." : "Revised Rates Submit Karein"}
                </Button>
                <Button variant="ghost" onClick={() => setReviseMode(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        </PortalShell>
      );
    }

    // Rankings display
    return (
      <PortalShell boq={boq}>
        <div className="max-w-2xl mx-auto space-y-4">
          {/* My rank card */}
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-sm text-muted-foreground mb-3 font-medium uppercase tracking-wide">Rankings Published</p>
              <div className={`inline-flex items-center gap-2 px-8 py-3 rounded-full text-2xl font-bold ${rankBadgeClass}`}>
                {rankLabel} — {mySubmission.vendorName}
              </div>
              <p className="text-muted-foreground text-sm mt-4">
                Aapka total: <span className="font-semibold text-foreground">{fmt(mySubmission.totalAmount)}</span>
              </p>
              {rankLabel !== "L1" && l1Sub && (
                <p className="text-xs text-red-600 mt-1">
                  L1 se {fmt(mySubmission.totalAmount - l1Sub.totalAmount)} zyada
                </p>
              )}
              {boq.revisionDeadline && (
                <p className={`text-xs mt-2 font-medium ${isRevisionExpired ? "text-red-600" : "text-orange-600"}`}>
                  {isRevisionExpired
                    ? "Revision deadline nikal gayi hai."
                    : `Revision deadline: ${boq.revisionDeadline}`}
                </p>
              )}
            </CardContent>
          </Card>

          {/* All vendors ranked */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Sab Vendors Ki Ranking</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {sortedByTotal.map((sub, idx) => {
                  const lbl = idx === 0 ? "L1" : idx === 1 ? "L2" : idx === 2 ? "L3" : `L${idx + 1}`;
                  const isMe = sub._id === mySubmission._id;
                  const lblBadge =
                    idx === 0 ? "bg-green-100 text-green-700" :
                    idx === 1 ? "bg-blue-100 text-blue-700" :
                    "bg-orange-100 text-orange-700";
                  return (
                    <div key={sub._id} className={`flex items-center gap-3 px-4 py-3 ${isMe ? "bg-primary/5" : ""}`}>
                      <Badge className={lblBadge}>{lbl}</Badge>
                      <span className="text-sm flex-1">{isMe ? sub.vendorName : `${lbl} Vendor`}</span>
                      <span className={`text-sm font-semibold ${isMe ? "text-primary" : ""}`}>{fmt(sub.totalAmount)}</span>
                      {isMe && <Badge variant="outline" className="text-xs border-primary text-primary">Aap</Badge>}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Per-item comparison vs L1 (only if not L1) */}
          {rankLabel !== "L1" && l1Sub && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Aapka Rate vs L1 Rate (Item-wise)</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-muted">
                      <tr>
                        <th className="px-3 py-2 text-left">Description</th>
                        <th className="px-3 py-2 text-center">Aapka Rate</th>
                        <th className="px-3 py-2 text-center text-green-700">L1 Rate</th>
                        <th className="px-3 py-2 text-center">Fark</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mySubmission.items.map((item) => {
                        const l1Item = l1Sub.items.find((i) => i.srNo === item.srNo);
                        const diff = item.ratePerUnit - (l1Item?.ratePerUnit ?? 0);
                        return (
                          <tr key={item.srNo} className="border-t">
                            <td className="px-3 py-2">{item.description}</td>
                            <td className="px-3 py-2 text-center">{fmt(item.ratePerUnit)}</td>
                            <td className="px-3 py-2 text-center text-green-600 font-medium">{fmt(l1Item?.ratePerUnit ?? 0)}</td>
                            <td className={`px-3 py-2 text-center font-medium ${diff > 0 ? "text-red-600" : diff < 0 ? "text-green-600" : "text-muted-foreground"}`}>
                              {diff > 0 ? `+${fmt(diff)}` : diff === 0 ? "—" : fmt(diff)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Revise button */}
          {rankLabel !== "L1" && (
            <Button
              className="w-full py-5 text-base font-semibold gap-2"
              onClick={handleStartRevise}
              disabled={isRevisionExpired}
            >
              <TrendingDown size={18} />
              {isRevisionExpired ? "Revision Band Hai (Deadline Nikal Gayi)" : "Rate Revise Karein"}
            </Button>
          )}

          <Button
            variant="ghost" size="sm"
            className="w-full gap-1 text-muted-foreground"
            onClick={() => setSelectedInvId("")}
          >
            <RotateCcw size={12} /> Kisi aur vendor ke liye dekhna hai?
          </Button>
        </div>
      </PortalShell>
    );
  }

  // ---- Already submitted view ----
  if (!boq.comparisonPublished && mySubmission && !submitted) {
    return (
      <PortalShell boq={boq}>
        <Card className="max-w-2xl mx-auto">
          <CardContent className="py-10 text-center">
            <CheckCircle size={52} className="mx-auto text-green-500 mb-4" />
            <h2 className="text-xl font-bold text-green-700 mb-1">Rates Submit Ho Chuke Hain</h2>
            <p className="text-muted-foreground text-sm mb-4">
              {vendorName || mySubmission.vendorName} ke rates {new Date(mySubmission.submittedAt).toLocaleDateString("hi-IN")} ko submit ho gaye.
            </p>
            <div className="border rounded-lg overflow-hidden text-left mb-4">
              <div className="bg-muted px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Submitted Rates Summary</div>
              <div className="divide-y max-h-64 overflow-y-auto">
                {mySubmission.items.map((item) => (
                  <div key={item.srNo} className="px-4 py-2 flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.srNo}. {item.description}</span>
                    <span className="font-medium">{fmt(item.ratePerUnit)}/{item.unit}</span>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2 bg-muted flex justify-between font-semibold text-sm">
                <span>Grand Total</span>
                <span>{fmt(mySubmission.totalAmount)}</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Admin review karenge aur aapko inform karenge.</p>
            <Button
              variant="ghost"
              size="sm"
              className="mt-3 gap-1 text-muted-foreground"
              onClick={() => { setSubmitted(false); setSelectedInvId(""); }}
            >
              <RotateCcw size={12} /> Kisi aur vendor ke liye submit karna hai?
            </Button>
          </CardContent>
        </Card>
      </PortalShell>
    );
  }

  // ---- Submitted success view ----
  if (submitted) {
    return (
      <PortalShell boq={boq}>
        <Card className="max-w-md mx-auto text-center">
          <CardContent className="py-12">
            <CheckCircle size={64} className="mx-auto text-green-500 mb-4" />
            <h2 className="text-2xl font-bold text-green-700 mb-2">Shukriya!</h2>
            <p className="font-medium mb-1">{vendorName}</p>
            <p className="text-muted-foreground text-sm">
              Aapke rates successfully submit ho gaye. Admin compare karenge aur decision lenge.
            </p>
            <div className="mt-4 bg-green-50 rounded-lg p-3 text-sm text-green-700">
              <p className="font-semibold">Aapka Total: {fmt(grandTotal)}</p>
              <p className="text-xs mt-0.5 text-green-600">{boq.items.length} items submitted</p>
            </div>
          </CardContent>
        </Card>
      </PortalShell>
    );
  }

  // ---- Main portal ----
  return (
    <PortalShell boq={boq}>
      {/* Deadline warning */}
      {isExpired && (
        <div className="max-w-4xl mx-auto mb-4">
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 flex items-center gap-2 text-sm">
            <AlertTriangle size={16} />
            <span>Deadline ({boq.deadlineDate}) nikal gayi hai. Rates accept nahi honge.</span>
          </div>
        </div>
      )}

      <div className="max-w-4xl mx-auto space-y-5">
        {/* Progress steps */}
        <div className="flex items-center gap-2 text-sm overflow-x-auto pb-1">
          {([
            { n: 1, label: "Apna naam chunen" },
            { n: 2, label: "Template download karein" },
            { n: 3, label: "Rates bharen & submit karein" },
          ] as const).map((s, i, arr) => (
            <div key={s.n} className="flex items-center gap-2 flex-shrink-0">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition
                  ${step >= s.n ? "bg-primary text-primary-foreground border-primary" : "border-muted-foreground text-muted-foreground"}`}
              >
                {step > s.n ? "✓" : s.n}
              </div>
              <span className={step >= s.n ? "font-medium" : "text-muted-foreground"}>{s.label}</span>
              {i < arr.length - 1 && <ChevronRight size={14} className="text-muted-foreground" />}
            </div>
          ))}
        </div>

        {/* STEP 1: Choose vendor name */}
        <Card className={step !== 1 && selectedInvId ? "opacity-70" : ""}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold">1</span>
              Apna naam chunen
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {invitations.length === 0 ? (
              <p className="text-sm text-muted-foreground py-2">
                Admin ne abhi invitations nahi bheje. Thodi der baad try karein ya admin se baat karein.
              </p>
            ) : (
              <div className="grid gap-2">
                {invitations.map((inv) => {
                  const alreadySubmitted = existingSubmissions.some((s) => s.invitationId === inv._id);
                  return (
                    <button
                      key={inv._id}
                      type="button"
                      className={`w-full flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition text-left
                        ${selectedInvId === inv._id ? "border-primary bg-primary/5 ring-1 ring-primary" : "hover:bg-accent/30"}
                        ${alreadySubmitted && selectedInvId !== inv._id ? "opacity-50" : ""}`}
                      onClick={() => handleSelectInv(inv._id)}
                    >
                      <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0
                        ${selectedInvId === inv._id ? "border-primary bg-primary" : "border-muted-foreground"}`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm">{inv.vendorName}</p>
                        <p className="text-xs text-muted-foreground capitalize">{inv.vendorMobile} • {inv.vendorType}</p>
                      </div>
                      <Badge className={
                        alreadySubmitted ? "bg-green-100 text-green-700" :
                        inv.status === "viewed" ? "bg-yellow-100 text-yellow-700" :
                        "bg-blue-100 text-blue-700"
                      }>
                        {alreadySubmitted ? "Submitted" : inv.status === "viewed" ? "Dekha" : "Invited"}
                      </Badge>
                    </button>
                  );
                })}
              </div>
            )}

            {selectedInvId && (
              <div className="grid grid-cols-2 gap-3 pt-1 border-t">
                <div className="space-y-1">
                  <Label className="text-xs">Naam confirm karein *</Label>
                  <Input value={vendorName} onChange={(e) => setVendorName(e.target.value)} placeholder="Aapka naam" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Mobile (optional)</Label>
                  <Input value={vendorMobile} onChange={(e) => setVendorMobile(e.target.value)} placeholder="9876543210" />
                </div>
              </div>
            )}

            {selectedInvId && vendorName && (
              <Button size="sm" onClick={() => setStep(2)} className="gap-1">
                Aage Badhen <ChevronRight size={14} />
              </Button>
            )}
          </CardContent>
        </Card>

        {/* STEP 2: Download template */}
        {(step >= 2 || selectedInvId) && (
          <Card className={step !== 2 ? "opacity-70" : ""}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold">2</span>
                BOQ Template Download Karein
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700">
                <p className="font-medium mb-1">Kaise bharen:</p>
                <ol className="space-y-1 text-xs list-decimal list-inside">
                  <li>Niche se template download karein (.xlsx)</li>
                  <li>"Rate Per Unit (₹)" column mein apna rate daalen</li>
                  <li>File save karein aur Step 3 mein upload karein</li>
                  <li>Ya seedha table mein rate type karein</li>
                </ol>
              </div>
              <div className="flex flex-wrap gap-3">
                <Button
                  variant="secondary"
                  className="gap-2"
                  onClick={() => generateBOQTemplate(boq.title, boq.items)}
                >
                  <Download size={15} /> Rate Template Download (.xlsx)
                </Button>
                <Button size="sm" onClick={() => setStep(3)} className="gap-1">
                  Rates Bhar Lete Hain <ChevronRight size={14} />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                {boq.items.length} items hain is BOQ mein
                {boq.deadlineDate && ` • Deadline: ${boq.deadlineDate}`}
              </p>
            </CardContent>
          </Card>
        )}

        {/* STEP 3: Fill rates & submit */}
        {(step >= 3 || selectedInvId) && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-bold">3</span>
                Rates Bharen aur Submit Karein
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Excel upload to auto-fill */}
              <div
                className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:bg-accent/20 transition"
                onClick={() => fileRef.current?.click()}
              >
                <Upload size={22} className="mx-auto text-muted-foreground mb-1" />
                {excelFile ? (
                  <p className="text-sm text-green-600 font-medium">{excelFile.name} — rates auto-fill ho gaye</p>
                ) : (
                  <>
                    <p className="text-sm font-medium">Bhara hua Excel upload karein</p>
                    <p className="text-xs text-muted-foreground">Rates auto fill ho jayenge • ya niche manually type karein</p>
                  </>
                )}
                <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleExcelParse(f); }}
                />
              </div>

              {/* Progress bar */}
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all"
                    style={{ width: `${(filledCount / boq.items.length) * 100}%` }}
                  />
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {filledCount}/{boq.items.length} filled
                </span>
              </div>

              {/* Items table */}
              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm min-w-[600px]">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-semibold w-10">Sr</th>
                      <th className="px-3 py-2 text-left text-xs font-semibold">Description</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-16">Unit</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-16">Qty</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold w-32">Rate/Unit (₹) *</th>
                      <th className="px-3 py-2 text-right text-xs font-semibold w-28">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {boq.items.map((item) => {
                      const rate = Number(rates[item.srNo] ?? 0);
                      const total = rate * item.quantity;
                      const filled = rate > 0;
                      return (
                        <tr key={item.srNo} className={`border-t ${filled ? "" : "bg-red-50/30"}`}>
                          <td className="px-3 py-1.5 text-xs">{item.srNo}</td>
                          <td className="px-3 py-1.5 text-xs">{item.description}</td>
                          <td className="px-3 py-1.5 text-xs text-center">{item.unit}</td>
                          <td className="px-3 py-1.5 text-xs text-center">{item.quantity}</td>
                          <td className="px-2 py-1">
                            <Input
                              type="number"
                              min="0"
                              className={`h-7 text-xs text-center ${filled ? "" : "border-orange-300 focus:ring-orange-400"}`}
                              placeholder="Rate daalen"
                              value={rates[item.srNo] ?? ""}
                              onChange={(e) => setRates((prev) => ({ ...prev, [item.srNo]: e.target.value }))}
                            />
                          </td>
                          <td className="px-3 py-1.5 text-xs text-right font-medium">
                            {filled ? fmt(total) : <span className="text-muted-foreground">—</span>}
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted font-semibold">
                      <td colSpan={5} className="px-3 py-2 text-sm text-right">Grand Total</td>
                      <td className="px-3 py-2 text-sm text-right text-primary">
                        {grandTotal > 0 ? fmt(grandTotal) : "—"}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">Notes / Terms (optional)</Label>
                <Textarea
                  rows={2}
                  placeholder="Koi special note, payment terms, delivery timeline..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              {/* Summary before submit */}
              {filledCount > 0 && (
                <div className="bg-muted/50 rounded-lg p-3 text-sm flex justify-between items-center">
                  <div>
                    <p className="font-medium">{vendorName}</p>
                    <p className="text-xs text-muted-foreground">{filledCount}/{boq.items.length} items filled</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-primary text-lg">{fmt(grandTotal)}</p>
                    <p className="text-xs text-muted-foreground">Grand Total</p>
                  </div>
                </div>
              )}

              <Button
                onClick={handleSubmit}
                disabled={submitting || isExpired || !selectedInvId}
                className="w-full py-5 text-base font-semibold"
              >
                {submitting ? "Submit ho raha hai..." :
                 isExpired ? "Deadline nikal gayi — Submit band hai" :
                 "Rates Submit Karein"}
              </Button>

              {filledCount < boq.items.length && (
                <p className="text-xs text-center text-orange-600">
                  <AlertTriangle size={11} className="inline mr-1" />
                  {boq.items.length - filledCount} items ki rate abhi bhari nahi hai
                </p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </PortalShell>
  );
}

function PortalShell({ boq, children }: { boq: BOQDoc; children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-4 px-4 md:px-8 shadow-sm">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-start gap-3">
            <FileSpreadsheet size={28} className="mt-0.5 opacity-80 flex-shrink-0" />
            <div>
              <h1 className="text-lg font-bold leading-tight">{boq.title}</h1>
              <p className="text-sm opacity-80 mt-0.5">BOQ Rate Portal</p>
              {boq.deadlineDate && (
                <p className="text-xs opacity-70 mt-0.5 flex items-center gap-1">
                  <Clock size={11} /> Deadline: {boq.deadlineDate}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="p-4 md:p-6">{children}</div>
    </div>
  );
}

function LoadingPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <FileSpreadsheet size={48} className="mx-auto text-muted-foreground mb-3 animate-pulse" />
        <p className="text-muted-foreground">BOQ load ho raha hai...</p>
      </div>
    </div>
  );
}

function ErrorPage({ msg }: { msg: string }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="max-w-sm w-full text-center">
        <CardContent className="py-10">
          <AlertTriangle size={40} className="mx-auto text-destructive mb-3" />
          <p className="text-lg font-semibold mb-2">Link Invalid</p>
          <p className="text-muted-foreground text-sm">{msg}</p>
        </CardContent>
      </Card>
    </div>
  );
}
