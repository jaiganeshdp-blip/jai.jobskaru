import { useSearchParams } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarDays, HardHat, IndianRupee, User, AlertCircle, Upload, X, CheckCircle, Clock, XCircle, ImagePlus, Languages } from "lucide-react";
import { format } from "date-fns";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { T, type Lang } from "./translations.ts";

function AttendanceBadge({ status, t }: { status: string; t: typeof T[Lang] }) {
  const map: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    present: { label: t.present, variant: "default" },
    absent: { label: t.absent, variant: "destructive" },
    half_day: { label: t.halfDay, variant: "secondary" },
    holiday: { label: "Holiday", variant: "outline" },
  };
  const info = map[status] ?? { label: status, variant: "outline" as const };
  return <Badge variant={info.variant}>{info.label}</Badge>;
}

function StatusBadge({ status, t }: { status: string; t: typeof T[Lang] }) {
  if (status === "pending") return <Badge variant="secondary" className="gap-1"><Clock className="w-3 h-3" />{t.pending}</Badge>;
  if (status === "resolved") return <Badge className="bg-green-600 gap-1"><CheckCircle className="w-3 h-3" />{t.resolved}</Badge>;
  return <Badge variant="destructive" className="gap-1"><XCircle className="w-3 h-3" />{t.rejected}</Badge>;
}

type RequestType = "attendance" | "advance" | "salary" | "other";

export default function LabourPortal() {
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [lang, setLang] = useState<Lang>("hinglish");
  const t = T[lang];

  const today = new Date();
  const month = format(today, "yyyy-MM");

  const data = useQuery(api.portal.labour.getByToken, token ? { token } : "skip");
  const attendance = useQuery(
    api.portal.labour.getAttendanceByToken,
    token ? { token, month } : "skip"
  );
  const salary = useQuery(api.portal.labour.getSalaryByToken, token ? { token } : "skip");
  const corrections = useQuery(api.labourCorrectionRequests.getByToken, token ? { token } : "skip");
  const checkinData = useQuery(api.geofencing.getCheckinsByToken, token ? { token } : "skip");

  const checkInByToken = useMutation(api.geofencing.checkInByToken);
  const generateUploadUrl = useMutation(api.labourCorrectionRequests.generateUploadUrl);
  const submitRequest = useMutation(api.labourCorrectionRequests.submitRequest);

  const [showForm, setShowForm] = useState(false);
  const [reqType, setReqType] = useState<RequestType>("attendance");
  const [reqMonth, setReqMonth] = useState(month);
  const [description, setDescription] = useState("");
  const [photos, setPhotos] = useState<{ file: File; preview: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [punchLoading, setPunchLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function handlePhotoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (photos.length + files.length > 5) {
      toast.error("Maximum 5 photos allowed");
      return;
    }
    const newPhotos = files.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setPhotos((prev) => [...prev, ...newPhotos]);
    e.target.value = "";
  }

  function removePhoto(index: number) {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit() {
    if (!description.trim()) { toast.error(lang === "hindi" ? "समस्या लिखें" : "Problem zaroor likho"); return; }
    setUploading(true);
    try {
      const storageIds: string[] = [];
      for (const { file } of photos) {
        const uploadUrl = await generateUploadUrl();
        const res = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });
        if (!res.ok) throw new Error("Upload failed");
        const { storageId } = await res.json() as { storageId: string };
        storageIds.push(storageId);
      }
      await submitRequest({
        token,
        requestType: reqType,
        month: reqMonth,
        description: description.trim(),
        photoStorageIds: storageIds.length > 0 ? storageIds : undefined,
      });
      toast.success(lang === "hindi" ? "अनुरोध भेज दिया गया!" : "Request bhej di gai! Admin dekhega.");
      setShowForm(false);
      setDescription("");
      setPhotos([]);
      setReqType("attendance");
      setReqMonth(month);
    } catch {
      toast.error(lang === "hindi" ? "कुछ गलत हुआ। दोबारा कोशिश करें।" : "Kuch gadbad hui. Dobara try karo.");
    } finally {
      setUploading(false);
    }
  }

  const typeOptions: { value: RequestType; label: string }[] = [
    { value: "attendance", label: t.attendance },
    { value: "advance", label: t.advance },
    { value: "salary", label: t.salary },
    { value: "other", label: t.other },
  ];
  const typeLabels = Object.fromEntries(typeOptions.map((o) => [o.value, o.label]));

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <HardHat className="mx-auto mb-4 text-muted-foreground" size={48} />
            <h2 className="text-xl font-bold mb-2">{t.invalidLink}</h2>
            <p className="text-muted-foreground">{t.invalidLinkMsg}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (data === undefined) {
    return (
      <div className="min-h-screen bg-background p-4 space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <p className="text-destructive font-semibold">{t.notFound}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { labourer, site } = data;

  const presentDays = attendance?.filter((a) => a.status === "present").length ?? 0;
  const halfDays = attendance?.filter((a) => a.status === "half_day").length ?? 0;
  const absentDays = attendance?.filter((a) => a.status === "absent").length ?? 0;
  const effectiveDays = presentDays + halfDays * 0.5;
  const estimatedSalary = effectiveDays * labourer.dailyRate;
  const pendingCount = corrections?.filter((c) => c.status === "pending").length ?? 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-background dark:from-orange-950/20">
      {/* Header */}
      <div className="bg-orange-600 text-white p-4 pb-8">
        <div className="max-w-lg mx-auto flex items-start justify-between gap-2">
          <div>
            <p className="text-orange-200 text-xs font-medium uppercase tracking-wide">{t.appTitle}</p>
            <h1 className="text-2xl font-bold mt-1">{labourer.name}</h1>
            <p className="text-orange-100 mt-0.5">{labourer.designation ?? "Labour"} &bull; {site?.name ?? "Site"}</p>
          </div>
          {/* Language Switcher */}
          <div className="shrink-0 mt-1">
            <Select value={lang} onValueChange={(v) => setLang(v as Lang)}>
              <SelectTrigger className="bg-orange-700 border-orange-500 text-white h-8 w-28 text-xs cursor-pointer">
                <Languages className="w-3.5 h-3.5 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hinglish">Hinglish</SelectItem>
                <SelectItem value="hindi">हिंदी</SelectItem>
                <SelectItem value="english">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-4 space-y-4 pb-8">
        {/* IN/OUT Punch Card */}
        <Card className="border-green-200 dark:border-green-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock size={16} className="text-green-600" /> IN / OUT Punch
            </CardTitle>
            {checkinData?.site && (
              <p className="text-xs text-muted-foreground">
                Shift: {checkinData.site.shiftStartTime} - {checkinData.site.shiftEndTime} (Grace: {checkinData.site.graceMinutes} min)
              </p>
            )}
          </CardHeader>
          <CardContent className="space-y-3">
            {/* Punch buttons */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                className="h-16 text-lg font-bold bg-green-600 hover:bg-green-700 cursor-pointer"
                disabled={punchLoading}
                onClick={async () => {
                  setPunchLoading(true);
                  try {
                    if (!("geolocation" in navigator)) {
                      toast.error("GPS not available on this device");
                      return;
                    }
                    const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
                      navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 })
                    );
                    const result = await checkInByToken({
                      token,
                      latitude: pos.coords.latitude,
                      longitude: pos.coords.longitude,
                      type: "in",
                    });
                    if (result.isWithinGeofence) {
                      toast.success(result.timeStatus === "late"
                        ? `IN marked! (${result.minutesDiff} min late)`
                        : "IN marked! On time");
                    } else {
                      toast.error(`IN marked but you are ${result.distanceFromSite}m away from site!`);
                    }
                  } catch (err) {
                    const msg = err instanceof Error ? err.message : "Location detect nahi ho paya";
                    toast.error(msg);
                  } finally {
                    setPunchLoading(false);
                  }
                }}
              >
                IN
              </Button>
              <Button
                className="h-16 text-lg font-bold bg-red-600 hover:bg-red-700 cursor-pointer"
                disabled={punchLoading}
                onClick={async () => {
                  setPunchLoading(true);
                  try {
                    if (!("geolocation" in navigator)) {
                      toast.error("GPS not available on this device");
                      return;
                    }
                    const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
                      navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 })
                    );
                    const result = await checkInByToken({
                      token,
                      latitude: pos.coords.latitude,
                      longitude: pos.coords.longitude,
                      type: "out",
                    });
                    if (result.timeStatus === "early") {
                      toast.warning(`OUT marked! (${result.minutesDiff} min early)`);
                    } else if (result.timeStatus === "overtime") {
                      toast.success(`OUT marked! Overtime: ${result.minutesDiff} min`);
                    } else {
                      toast.success("OUT marked! On time");
                    }
                  } catch (err) {
                    const msg = err instanceof Error ? err.message : "Location detect nahi ho paya";
                    toast.error(msg);
                  } finally {
                    setPunchLoading(false);
                  }
                }}
              >
                OUT
              </Button>
            </div>

            {/* Today's punches */}
            {checkinData && checkinData.checkins.length > 0 && (
              <div className="border rounded-lg p-3 bg-muted/30 space-y-1.5">
                <p className="text-xs font-medium text-muted-foreground uppercase">Today&apos;s Punches</p>
                {checkinData.checkins.map((c) => {
                  const time = new Date(c.checkinTime).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
                  return (
                    <div key={c._id} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant={c.type === "in" ? "default" : "destructive"} className="text-xs w-10 justify-center">
                          {c.type === "in" ? "IN" : "OUT"}
                        </Badge>
                        <span>{time}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {c.isWithinGeofence ? (
                          <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">On Site</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs bg-red-100 text-red-700">{c.distanceFromSite}m away</Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Profile Card */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <User size={16} /> {t.myDetails}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">{t.mobile}</span><span>{labourer.mobile ?? "—"}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">{t.dailyRate}</span><span>₹{labourer.dailyRate}/day</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">{t.joinDate}</span><span>{labourer.joinDate ?? "—"}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">{t.site}</span><span>{site?.name ?? "—"}</span></div>
          </CardContent>
        </Card>

        {/* This Month Attendance */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarDays size={16} /> {t.thisMonth} ({format(today, "MMMM yyyy")})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-green-50 dark:bg-green-950/30 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{presentDays}</p>
                <p className="text-xs text-muted-foreground">{t.present}</p>
              </div>
              <div className="text-center p-2 bg-yellow-50 dark:bg-yellow-950/30 rounded-lg">
                <p className="text-2xl font-bold text-yellow-600">{halfDays}</p>
                <p className="text-xs text-muted-foreground">{t.halfDay}</p>
              </div>
              <div className="text-center p-2 bg-red-50 dark:bg-red-950/30 rounded-lg">
                <p className="text-2xl font-bold text-red-600">{absentDays}</p>
                <p className="text-xs text-muted-foreground">{t.absent}</p>
              </div>
            </div>
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {attendance?.sort((a, b) => a.date.localeCompare(b.date)).map((a) => (
                <div key={a._id} className="flex justify-between items-center text-sm py-0.5">
                  <span className="text-muted-foreground">{format(new Date(a.date + "T00:00:00"), "dd MMM")}</span>
                  <AttendanceBadge status={a.status} t={t} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Estimated Salary */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <IndianRupee size={16} /> {t.estimatedSalary}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-orange-600">₹{estimatedSalary.toLocaleString("en-IN")}</p>
            <p className="text-xs text-muted-foreground mt-1">{effectiveDays} {t.effectiveDays} × ₹{labourer.dailyRate}</p>
          </CardContent>
        </Card>

        {/* Past Salary Sheets */}
        {salary && salary.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{t.salaryHistory}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {salary.map(({ sheet, entry }) => (
                <div key={sheet._id} className="flex justify-between items-center border-b pb-2 last:border-0 last:pb-0">
                  <div>
                    <p className="font-medium text-sm">{sheet.month}</p>
                    <p className="text-xs text-muted-foreground">
                      {entry.daysWorked} {t.days} + {entry.halfDays} {t.half}
                      {entry.nastaAmount ? ` · Nasta: ₹${entry.nastaAmount.toLocaleString("en-IN")}` : ""}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm">₹{entry.netAmount.toLocaleString("en-IN")}</p>
                    <Badge variant={sheet.status === "paid" ? "default" : "secondary"} className="text-xs">
                      {sheet.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* ====== CORRECTION REQUEST SECTION ====== */}
        <Card className="border-orange-200 dark:border-orange-800">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertCircle size={16} className="text-orange-500" />
                {t.correctionTitle}
                {pendingCount > 0 && (
                  <Badge variant="secondary" className="text-xs">{pendingCount} {t.pending}</Badge>
                )}
              </CardTitle>
              {!showForm && (
                <Button size="sm" className="cursor-pointer bg-orange-600 hover:bg-orange-700 text-xs h-7 px-3"
                  onClick={() => setShowForm(true)}>
                  {t.newRequest}
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{t.correctionDesc}</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* New Request Form */}
            {showForm && (
              <div className="border rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/20 space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t.requestType}</Label>
                  <Select value={reqType} onValueChange={(v) => setReqType(v as RequestType)}>
                    <SelectTrigger className="h-9 cursor-pointer text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {typeOptions.map((o) => (
                        <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t.month}</Label>
                  <input
                    type="month"
                    value={reqMonth}
                    max={month}
                    onChange={(e) => setReqMonth(e.target.value)}
                    className="w-full border rounded-md px-3 py-2 text-sm bg-background"
                  />
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t.description}</Label>
                  <Textarea
                    placeholder={t.descPlaceholder}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    className="text-sm resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">{t.photoLabel}</Label>
                  <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoSelect} />
                  {photos.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {photos.map((p, i) => (
                        <div key={i} className="relative w-20 h-20">
                          <img src={p.preview} alt="proof" className="w-20 h-20 object-cover rounded-md border" />
                          <button
                            className="absolute -top-1 -right-1 bg-destructive text-white rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
                            onClick={() => removePhoto(i)}
                          ><X className="w-3 h-3" /></button>
                        </div>
                      ))}
                    </div>
                  )}
                  {photos.length < 5 && (
                    <Button type="button" variant="secondary" size="sm" className="cursor-pointer text-xs h-8 gap-1"
                      onClick={() => fileRef.current?.click()}>
                      <ImagePlus className="w-3.5 h-3.5" />{t.addPhoto}
                    </Button>
                  )}
                </div>

                <div className="flex gap-2 pt-1">
                  <Button size="sm" className="cursor-pointer flex-1 bg-orange-600 hover:bg-orange-700 gap-1"
                    onClick={handleSubmit} disabled={uploading}>
                    {uploading
                      ? <><Upload className="w-3.5 h-3.5 animate-bounce" />{t.sendRequest}</>
                      : <><Upload className="w-3.5 h-3.5" />{t.submitRequest}</>
                    }
                  </Button>
                  <Button size="sm" variant="secondary" className="cursor-pointer"
                    onClick={() => { setShowForm(false); setPhotos([]); setDescription(""); }}>
                    {t.cancel}
                  </Button>
                </div>
              </div>
            )}

            {/* Past Requests */}
            {corrections && corrections.length > 0 ? (
              <div className="space-y-3">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{t.oldRequests}</p>
                {corrections.map((req) => (
                  <div key={req._id} className="border rounded-lg p-3 space-y-2 text-sm">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-medium">{typeLabels[req.requestType] ?? req.requestType}</p>
                        <p className="text-xs text-muted-foreground">{req.month}</p>
                      </div>
                      <StatusBadge status={req.status} t={t} />
                    </div>
                    <p className="text-muted-foreground text-xs">{req.description}</p>
                    {req.photoUrls && req.photoUrls.length > 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {req.photoUrls.map((url, i) => (
                          <a key={i} href={url} target="_blank" rel="noreferrer">
                            <img src={url} alt="proof" className="w-16 h-16 object-cover rounded border cursor-pointer hover:opacity-80" />
                          </a>
                        ))}
                      </div>
                    )}
                    {req.adminNote && (
                      <div className="bg-muted/50 rounded p-2 text-xs">
                        <span className="font-medium">{t.adminReply}</span>{req.adminNote}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : !showForm ? (
              <p className="text-xs text-muted-foreground text-center py-2">{t.noRequests}</p>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
