import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import {
  ShieldCheck, HardHat, AlertTriangle, Wrench, Plus, Package,
  CalendarCheck, IndianRupee, FileText, ChevronLeft, ChevronRight,
  Home, User, Calendar,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const PPE_CATEGORIES = [
  { value: "helmet", label: "Helmet" },
  { value: "safety_shoes", label: "Safety Shoes (Juta)" },
  { value: "goggles", label: "Goggles" },
  { value: "gloves", label: "Gloves (Handgous)" },
  { value: "jacket", label: "Safety Jacket" },
  { value: "harness", label: "Harness" },
  { value: "mask", label: "Mask" },
  { value: "other", label: "Other" },
] as const;

const TOOL_TYPES = [
  { value: "cutter", label: "CM4 Cutter" },
  { value: "grinder", label: "Grinder" },
  { value: "drill", label: "Drill Machine" },
  { value: "cable", label: "Cable (Running Meter)" },
  { value: "welding", label: "Welding Machine" },
  { value: "pump", label: "Water Pump" },
  { value: "generator", label: "Generator" },
  { value: "other", label: "Other" },
] as const;

function severityColor(s: string) {
  if (s === "high") return "bg-red-500/10 text-red-500 border-red-500/20";
  if (s === "medium") return "bg-orange-500/10 text-orange-500 border-orange-500/20";
  return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
}

// ============ PPE TAB ============
function PpeTab({ token, data }: { token: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const addStockMut = useMutation(api.safety.supervisorPortal.addStock);
  const distributeMut = useMutation(api.safety.supervisorPortal.distribute);
  const genUrl = useMutation(api.safety.supervisorPortal.generateUploadUrl);

  const [tab, setTab] = useState<"stock" | "history">("stock");
  const [stockDialog, setStockDialog] = useState(false);
  const [distributeDialog, setDistributeDialog] = useState<string | null>(null);

  const stockSchema = z.object({
    itemName: z.string().min(1),
    category: z.enum(["helmet","safety_shoes","goggles","gloves","jacket","harness","mask","other"]),
    totalQuantity: z.coerce.number().min(1),
    purchaseDate: z.string().optional(),
    costPerUnit: z.coerce.number().optional(),
    notes: z.string().optional(),
  });
  const distSchema = z.object({
    recipientType: z.enum(["labour","contractor"]),
    labourerId: z.string().optional(),
    contractorId: z.string().optional(),
    quantity: z.coerce.number().min(1),
    distributedDate: z.string().min(1),
    condition: z.enum(["new","used","damaged"]).optional(),
    notes: z.string().optional(),
  });

  const stockForm = useForm({ resolver: zodResolver(stockSchema), defaultValues: { totalQuantity: 1, category: "helmet" as const } });
  const distForm = useForm({ resolver: zodResolver(distSchema), defaultValues: { recipientType: "labour" as const, quantity: 1, distributedDate: new Date().toISOString().slice(0,10) } });
  const recipientType = distForm.watch("recipientType");

  const labourMap = Object.fromEntries((data.labourers ?? []).map(l => [l._id, l.name]));

  async function onAddStock(d: z.infer<typeof stockSchema>) {
    try {
      await addStockMut({ token, ...d });
      toast.success("Stock add ho gaya");
      setStockDialog(false); stockForm.reset();
    } catch { toast.error("Kuch galat hua"); }
  }

  async function onDistribute(d: z.infer<typeof distSchema>) {
    if (!distributeDialog) return;
    const stockItem = data.ppeStock.find(s => s._id === distributeDialog);
    if (!stockItem) return;
    try {
      await distributeMut({
        token,
        ppeStockId: distributeDialog as Id<"ppeStock">,
        recipientType: d.recipientType,
        labourerId: d.labourerId ? d.labourerId as Id<"labourers"> : undefined,
        contractorId: d.contractorId ? d.contractorId as Id<"contractors"> : undefined,
        itemName: stockItem.itemName,
        quantity: d.quantity,
        distributedDate: d.distributedDate,
        condition: d.condition,
        notes: d.notes,
      });
      toast.success("Vitran ho gaya");
      setDistributeDialog(null); distForm.reset();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Kuch galat hua");
    }
  }

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-3">
        {PPE_CATEGORIES.slice(0,4).map(cat => {
          const avail = data.ppeStock.filter(s => s.category === cat.value).reduce((a, b) => a + b.availableQuantity, 0);
          const total = data.ppeStock.filter(s => s.category === cat.value).reduce((a, b) => a + b.totalQuantity, 0);
          return (
            <Card key={cat.value} className="py-2">
              <CardContent className="px-3 py-0">
                <p className="text-xs text-muted-foreground">{cat.label}</p>
                <p className={`text-xl font-bold ${avail === 0 ? "text-red-500" : avail < 3 ? "text-orange-500" : ""}`}>{avail}
                  <span className="text-xs text-muted-foreground font-normal"> / {total}</span>
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex gap-2 items-center justify-between">
        <div className="flex gap-1">
          <Button variant="ghost" size="sm" className={`cursor-pointer ${tab === "stock" ? "bg-muted" : ""}`} onClick={() => setTab("stock")}>Stock</Button>
          <Button variant="ghost" size="sm" className={`cursor-pointer ${tab === "history" ? "bg-muted" : ""}`} onClick={() => setTab("history")}>Vitran</Button>
        </div>
        <Button size="sm" onClick={() => setStockDialog(true)} className="cursor-pointer">
          <Plus className="w-3.5 h-3.5 mr-1" /> Add Stock
        </Button>
      </div>

      {tab === "stock" ? (
        data.ppeStock.length === 0 ? (
          <Empty><EmptyHeader><EmptyMedia variant="icon"><HardHat /></EmptyMedia><EmptyTitle>Koi stock nahi</EmptyTitle></EmptyHeader></Empty>
        ) : (
          <div className="space-y-2">
            {data.ppeStock.map(item => (
              <Card key={item._id}>
                <CardContent className="p-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-medium text-sm">{item.itemName}</p>
                    <p className="text-xs text-muted-foreground capitalize">{item.category.replace("_"," ")}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className={`text-lg font-bold ${item.availableQuantity === 0 ? "text-red-500" : item.availableQuantity < 3 ? "text-orange-500" : "text-green-500"}`}>
                        {item.availableQuantity}
                      </p>
                      <p className="text-xs text-muted-foreground">Available / {item.totalQuantity}</p>
                    </div>
                    <Button size="sm" variant="outline" className="cursor-pointer text-xs h-7"
                      onClick={() => { setDistributeDialog(item._id); distForm.reset({ recipientType: "labour", quantity: 1, distributedDate: new Date().toISOString().slice(0,10) }); }}>
                      Vitran
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )
      ) : (
        data.distributions.length === 0 ? (
          <Empty><EmptyHeader><EmptyMedia variant="icon"><Package /></EmptyMedia><EmptyTitle>Koi vitran nahi</EmptyTitle></EmptyHeader></Empty>
        ) : (
          <div className="space-y-2">
            {data.distributions.map(d => (
              <Card key={d._id}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{d.itemName}</p>
                      <p className="text-xs text-muted-foreground">
                        {d.labourerId ? (labourMap[d.labourerId] ?? "Labour") : "Contractor"} · {d.distributedDate}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{d.quantity}</p>
                      {d.condition && <p className="text-xs text-muted-foreground capitalize">{d.condition}</p>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )
      )}

      {/* Add Stock Dialog */}
      <Dialog open={stockDialog} onOpenChange={setStockDialog}>
        <DialogContent className="max-w-sm max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>PPE Stock Add Karo</DialogTitle></DialogHeader>
          <Form {...stockForm}>
            <form onSubmit={stockForm.handleSubmit(onAddStock)} className="space-y-3">
              <FormField control={stockForm.control} name="category" render={({ field }) => (
                <FormItem><FormLabel>Category *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>{PPE_CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={stockForm.control} name="itemName" render={({ field }) => (
                <FormItem><FormLabel>Item Name *</FormLabel>
                  <FormControl><Input placeholder="e.g. ISI Helmet" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-2">
                <FormField control={stockForm.control} name="totalQuantity" render={({ field }) => (
                  <FormItem><FormLabel>Qty *</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={stockForm.control} name="costPerUnit" render={({ field }) => (
                  <FormItem><FormLabel>Cost/Unit ₹</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl>
                  </FormItem>
                )} />
              </div>
              <FormField control={stockForm.control} name="purchaseDate" render={({ field }) => (
                <FormItem><FormLabel>Date</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setStockDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Add</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Distribute Dialog */}
      <Dialog open={!!distributeDialog} onOpenChange={() => setDistributeDialog(null)}>
        <DialogContent className="max-w-sm max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>PPE Vitran Karo</DialogTitle></DialogHeader>
          <Form {...distForm}>
            <form onSubmit={distForm.handleSubmit(onDistribute)} className="space-y-3">
              <FormField control={distForm.control} name="recipientType" render={({ field }) => (
                <FormItem><FormLabel>Kisko</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="labour">Labour</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              {recipientType === "labour" && (
                <FormField control={distForm.control} name="labourerId" render={({ field }) => (
                  <FormItem><FormLabel>Labour</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Labour chuniye" /></SelectTrigger></FormControl>
                      <SelectContent>{data.labourers.map(l => <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              )}
              <div className="grid grid-cols-2 gap-2">
                <FormField control={distForm.control} name="quantity" render={({ field }) => (
                  <FormItem><FormLabel>Qty *</FormLabel>
                    <FormControl><Input type="number" min={1} {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={distForm.control} name="distributedDate" render={({ field }) => (
                  <FormItem><FormLabel>Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={distForm.control} name="condition" render={({ field }) => (
                <FormItem><FormLabel>Condition</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Condition" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="used">Used</SelectItem>
                      <SelectItem value="damaged">Damaged</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDistributeDialog(null)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Vitran Karo</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ VIOLATIONS TAB ============
function ViolationsTab({ token, data }: { token: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const addViolation = useMutation(api.safety.supervisorPortal.addViolation);
  const updateStatus = useMutation(api.safety.supervisorPortal.updateViolationStatus);
  const genUrl = useMutation(api.safety.supervisorPortal.generateUploadUrl);

  const [dialog, setDialog] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);

  const schema = z.object({
    violationDate: z.string().min(1),
    description: z.string().min(1, "Description required"),
    recipientType: z.enum(["labour","contractor"]),
    labourerId: z.string().optional(),
    contractorId: z.string().optional(),
    severity: z.enum(["low","medium","high"]),
    penaltyAmount: z.coerce.number().optional(),
    penaltyStatus: z.enum(["none","pending","paid"]),
    actionTaken: z.string().optional(),
  });

  const form = useForm({ resolver: zodResolver(schema), defaultValues: {
    recipientType: "labour" as const, severity: "medium" as const,
    penaltyStatus: "none" as const, violationDate: new Date().toISOString().slice(0,10),
  }});
  const recipientType = form.watch("recipientType");
  const labourMap = Object.fromEntries((data.labourers ?? []).map(l => [l._id, l.name]));

  async function onSubmit(d: z.infer<typeof schema>) {
    try {
      const photoStorageIds: string[] = [];
      for (const file of photos) {
        const uploadUrl = await genUrl({ token });
        const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
        const { storageId } = await res.json() as { storageId: string };
        photoStorageIds.push(storageId);
      }
      await addViolation({
        token,
        ...d,
        labourerId: d.labourerId ? d.labourerId as Id<"labourers"> : undefined,
        contractorId: d.contractorId ? d.contractorId as Id<"contractors"> : undefined,
        photoStorageIds: photoStorageIds.length > 0 ? photoStorageIds : undefined,
      });
      toast.success("Violation record ho gaya");
      setDialog(false); setPhotos([]); form.reset();
    } catch { toast.error("Kuch galat hua"); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-3">
          <Card className="py-2 px-3">
            <p className="text-xs text-muted-foreground">Total</p>
            <p className="text-xl font-bold">{data.violations.length}</p>
          </Card>
          <Card className="py-2 px-3">
            <p className="text-xs text-muted-foreground">Penalty Pending</p>
            <p className="text-xl font-bold text-orange-500">{data.violations.filter(v => v.penaltyStatus === "pending").length}</p>
          </Card>
        </div>
        <Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer">
          <Plus className="w-3.5 h-3.5 mr-1" /> Add
        </Button>
      </div>

      {data.violations.length === 0 ? (
        <Empty><EmptyHeader><EmptyMedia variant="icon"><AlertTriangle /></EmptyMedia><EmptyTitle>Koi violation nahi</EmptyTitle></EmptyHeader></Empty>
      ) : (
        <div className="space-y-3">
          {data.violations.map(v => (
            <Card key={v._id}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded border font-medium capitalize ${severityColor(v.severity)}`}>{v.severity}</span>
                      <span className="text-xs text-muted-foreground">{v.violationDate}</span>
                    </div>
                    <p className="font-medium text-sm">{v.description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {v.labourerId ? (labourMap[v.labourerId] ?? "Labour") : "Contractor"}
                    </p>
                    {v.penaltyAmount ? (
                      <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                        <span className="text-sm font-medium">Penalty: ₹{v.penaltyAmount.toLocaleString("en-IN")}</span>
                        <Badge variant={v.penaltyStatus === "paid" ? "default" : "secondary"} className="text-xs capitalize">
                          {v.penaltyStatus}
                        </Badge>
                        {v.penaltyStatus === "pending" && (
                          <Button size="sm" variant="ghost" className="cursor-pointer text-green-500 h-6 px-2 text-xs"
                            onClick={async () => { await updateStatus({ token, id: v._id, penaltyStatus: "paid" }); toast.success("Paid marked"); }}>
                            Mark Paid
                          </Button>
                        )}
                      </div>
                    ) : null}
                    {v.actionTaken && <p className="text-xs text-muted-foreground mt-1">Action: {v.actionTaken}</p>}
                  </div>
                </div>
                {v.photoUrls && v.photoUrls.length > 0 && (
                  <div className="flex gap-2 flex-wrap mt-2">
                    {v.photoUrls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                        <img src={url} alt="violation" className="w-16 h-16 object-cover rounded border cursor-pointer hover:opacity-80" />
                      </a>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-sm max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Violation Record Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <FormField control={form.control} name="violationDate" render={({ field }) => (
                  <FormItem><FormLabel>Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="severity" render={({ field }) => (
                  <FormItem><FormLabel>Severity</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem><FormLabel>Kya Hua *</FormLabel>
                  <FormControl><Input placeholder="e.g. Helmet nahi pehna" {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="recipientType" render={({ field }) => (
                <FormItem><FormLabel>Kisne Kiya</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="labour">Labour</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              {recipientType === "labour" && (
                <FormField control={form.control} name="labourerId" render={({ field }) => (
                  <FormItem><FormLabel>Labour</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Labour chuniye" /></SelectTrigger></FormControl>
                      <SelectContent>{data.labourers.map(l => <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormItem>
                )} />
              )}
              <div className="grid grid-cols-2 gap-2">
                <FormField control={form.control} name="penaltyAmount" render={({ field }) => (
                  <FormItem><FormLabel>Penalty ₹</FormLabel>
                    <FormControl><Input type="number" placeholder="500" {...field} /></FormControl>
                  </FormItem>
                )} />
                <FormField control={form.control} name="penaltyStatus" render={({ field }) => (
                  <FormItem><FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">No Penalty</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="actionTaken" render={({ field }) => (
                <FormItem><FormLabel>Action Liya</FormLabel>
                  <FormControl><Input placeholder="Warning, kaam rokaya..." {...field} /></FormControl>
                </FormItem>
              )} />
              <div>
                <p className="text-sm font-medium mb-1">Photos</p>
                <Input type="file" accept="image/*" multiple
                  onChange={e => setPhotos(Array.from(e.target.files ?? []).slice(0,5))}
                  className="cursor-pointer" />
                {photos.length > 0 && <p className="text-xs text-muted-foreground mt-1">{photos.length} photo(s)</p>}
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ TOOLS TAB ============
function ToolsTab({ token, data }: { token: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const addToolMut = useMutation(api.safety.supervisorPortal.addTool);
  const updateCondition = useMutation(api.safety.supervisorPortal.updateToolCondition);
  const [dialog, setDialog] = useState(false);

  const schema = z.object({
    name: z.string().min(1),
    type: z.enum(["cutter","grinder","drill","cable","welding","pump","generator","other"]),
    quantity: z.coerce.number().min(1),
    unit: z.string().min(1),
    condition: z.enum(["good","repair","damaged"]),
    purchaseDate: z.string().optional(),
    costPerUnit: z.coerce.number().optional(),
    notes: z.string().optional(),
  });
  const form = useForm({ resolver: zodResolver(schema), defaultValues: { condition: "good" as const, quantity: 1, unit: "nos" } });
  const selectedType = form.watch("type");

  async function onSubmit(d: z.infer<typeof schema>) {
    try {
      await addToolMut({ token, ...d });
      toast.success("Tool add ho gaya");
      setDialog(false); form.reset({ condition: "good", quantity: 1, unit: "nos" });
    } catch { toast.error("Kuch galat hua"); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="grid grid-cols-3 gap-2">
          <Card className="py-2 px-3"><p className="text-xs text-muted-foreground">Total</p><p className="text-xl font-bold">{data.tools.length}</p></Card>
          <Card className="py-2 px-3"><p className="text-xs text-muted-foreground">Good</p><p className="text-xl font-bold text-green-500">{data.tools.filter(t => t.condition === "good").length}</p></Card>
          <Card className="py-2 px-3"><p className="text-xs text-muted-foreground">Repair</p><p className="text-xl font-bold text-orange-500">{data.tools.filter(t => t.condition === "repair").length}</p></Card>
        </div>
        <Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer">
          <Plus className="w-3.5 h-3.5 mr-1" /> Add
        </Button>
      </div>

      {data.tools.length === 0 ? (
        <Empty><EmptyHeader><EmptyMedia variant="icon"><Wrench /></EmptyMedia><EmptyTitle>Koi tool nahi</EmptyTitle></EmptyHeader></Empty>
      ) : (
        <div className="space-y-2">
          {data.tools.map(t => (
            <Card key={t._id}>
              <CardContent className="p-3 flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium text-sm">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{TOOL_TYPES.find(x => x.value === t.type)?.label ?? t.type} · {t.quantity} {t.unit}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-medium capitalize ${t.condition === "good" ? "text-green-500" : t.condition === "repair" ? "text-orange-500" : "text-red-500"}`}>
                    {t.condition}
                  </span>
                  {t.condition !== "damaged" && (
                    <Button size="sm" variant="ghost" className="cursor-pointer text-xs h-7 px-2"
                      onClick={async () => {
                        const next = t.condition === "good" ? "repair" : "damaged";
                        await updateCondition({ token, id: t._id, condition: next });
                        toast.success("Updated");
                      }}>
                      {t.condition === "good" ? "→ Repair" : "→ Damaged"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-sm max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Tool/Machine Add Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField control={form.control} name="type" render={({ field }) => (
                <FormItem><FormLabel>Type *</FormLabel>
                  <Select onValueChange={(v) => { field.onChange(v); if (v === "cable") form.setValue("unit", "meter"); else form.setValue("unit", "nos"); }} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Type" /></SelectTrigger></FormControl>
                    <SelectContent>{TOOL_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                  </Select><FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem><FormLabel>Name *</FormLabel>
                  <FormControl><Input placeholder="Bosch Grinder..." {...field} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-2">
                <FormField control={form.control} name="quantity" render={({ field }) => (
                  <FormItem><FormLabel>{selectedType === "cable" ? "Meters" : "Qty"} *</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="unit" render={({ field }) => (
                  <FormItem><FormLabel>Unit</FormLabel>
                    <FormControl><Input placeholder="nos/meter" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="condition" render={({ field }) => (
                <FormItem><FormLabel>Condition</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="repair">Needs Repair</SelectItem>
                      <SelectItem value="damaged">Damaged</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Add</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ LABOUR LIST TAB ============
function LabourListTab({ data }: { data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const distByLabour = new Map<string, typeof data.distributions>();
  for (const d of data.distributions) {
    if (d.labourerId) {
      if (!distByLabour.has(d.labourerId)) distByLabour.set(d.labourerId, []);
      distByLabour.get(d.labourerId)!.push(d);
    }
  }
  const violByLabour = new Map<string, typeof data.violations>();
  for (const v of data.violations) {
    if (v.labourerId) {
      if (!violByLabour.has(v.labourerId)) violByLabour.set(v.labourerId, []);
      violByLabour.get(v.labourerId)!.push(v);
    }
  }

  return (
    <div className="space-y-3">
      {data.labourers.length === 0 ? (
        <Empty><EmptyHeader><EmptyMedia variant="icon"><ShieldCheck /></EmptyMedia><EmptyTitle>Is site pe koi labour nahi</EmptyTitle></EmptyHeader></Empty>
      ) : (
        data.labourers.map(l => {
          const dists = distByLabour.get(l._id) ?? [];
          const viols = violByLabour.get(l._id) ?? [];
          return (
            <Card key={l._id}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{l.name}</p>
                    <p className="text-xs text-muted-foreground">{l.designation ?? "—"}{l.mobile ? ` · ${l.mobile}` : ""}</p>
                  </div>
                  <div className="flex gap-2">
                    {dists.length > 0 && (
                      <span className="text-xs bg-orange-500/10 text-orange-500 px-2 py-0.5 rounded font-medium">
                        {dists.length} PPE
                      </span>
                    )}
                    {viols.length > 0 && (
                      <span className="text-xs bg-red-500/10 text-red-500 px-2 py-0.5 rounded font-medium">
                        {viols.length} Violation
                      </span>
                    )}
                  </div>
                </div>
                {dists.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {dists.map(d => (
                      <span key={d._id} className="text-xs bg-muted px-2 py-0.5 rounded">
                        {d.itemName} ×{d.quantity}
                      </span>
                    ))}
                  </div>
                )}
                {viols.length > 0 && (
                  <div className="space-y-1 pt-1">
                    {viols.slice(0,2).map(v => (
                      <p key={v._id} className="text-xs text-red-500">⚠ {v.description} ({v.violationDate})</p>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}

// ============ HAJRI (ATTENDANCE) TAB ============
const ATT_OPTIONS = [
  { value: "present", label: "Present", color: "bg-green-500" },
  { value: "absent", label: "Absent", color: "bg-red-500" },
  { value: "half_day", label: "Half Day", color: "bg-yellow-500" },
  { value: "holiday", label: "Holiday", color: "bg-blue-500" },
] as const;
type AttStatus = "present" | "absent" | "half_day" | "holiday";

function HajriTab({ workerCode, data }: { workerCode: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [localMap, setLocalMap] = useState<Record<string, AttStatus>>({});
  const [saving, setSaving] = useState(false);

  const attData = useQuery(api.supervisorPortal.getPortalData, { workerCode, date });
  const bulkMark = useMutation(api.supervisorPortal.bulkMarkAttendance);

  const existingMap: Record<string, AttStatus> = {};
  if (attData) {
    for (const [labId, status] of Object.entries(attData.attendanceMap)) {
      existingMap[labId] = status as AttStatus;
    }
  }

  const getStatus = (labId: string): AttStatus =>
    localMap[labId] ?? existingMap[labId] ?? "absent";

  const setAll = (s: AttStatus) =>
    setLocalMap(Object.fromEntries(data.labourers.map((l) => [l._id, s])));

  const handleSave = async () => {
    setSaving(true);
    try {
      const entries = data.labourers.map((l) => ({
        labourerId: l._id as Id<"labourers">,
        status: getStatus(l._id),
        overtimeHours: undefined as number | undefined,
      }));
      await bulkMark({ workerCode, date, entries });
      toast.success("Attendance save ho gaya!");
      setLocalMap({});
    } catch { toast.error("Save nahi hua"); }
    finally { setSaving(false); }
  };

  const presentCount = data.labourers.filter((l) => getStatus(l._id) === "present").length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex items-center gap-2">
          <button onClick={() => { const d = new Date(date); d.setDate(d.getDate() - 1); setDate(d.toISOString().slice(0,10)); setLocalMap({}); }} className="p-1 rounded hover:bg-muted cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
          <Input type="date" value={date} onChange={(e) => { setDate(e.target.value); setLocalMap({}); }} className="w-36" />
          <button onClick={() => { const d = new Date(date); d.setDate(d.getDate() + 1); setDate(d.toISOString().slice(0,10)); setLocalMap({}); }} className="p-1 rounded hover:bg-muted cursor-pointer"><ChevronRight className="w-4 h-4" /></button>
        </div>
        <div className="flex gap-1">
          <Button size="sm" variant="ghost" onClick={() => setAll("present")}>All Present</Button>
          <Button size="sm" variant="ghost" onClick={() => setAll("absent")}>All Absent</Button>
        </div>
      </div>
      <div className="text-sm text-muted-foreground">Present: <span className="text-green-500 font-medium">{presentCount}</span> / {data.labourers.length}</div>
      <div className="space-y-2">
        {data.labourers.map((lab) => {
          const cur = getStatus(lab._id);
          return (
            <Card key={lab._id} className="py-0">
              <CardContent className="p-3">
                <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{lab.name}</p>
                    <p className="text-xs text-muted-foreground">{lab.designation ?? "Labour"}</p>
                  </div>
                  <div className="flex flex-wrap gap-1 justify-end">
                    {ATT_OPTIONS.map((opt) => (
                      <button key={opt.value} onClick={() => setLocalMap((m) => ({ ...m, [lab._id]: opt.value }))}
                        className={`px-2 py-0.5 rounded text-xs font-medium border transition-all cursor-pointer ${cur === opt.value ? opt.color + " text-white border-transparent" : "bg-muted text-muted-foreground border-border hover:border-foreground"}`}>
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <Button className="w-full cursor-pointer" onClick={handleSave} disabled={saving}>{saving ? "Saving..." : "Save Karo"}</Button>
    </div>
  );
}

// ============ ADVANCE TAB ============
function AdvanceTabSafety({ workerCode, data }: { workerCode: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const addAdvance = useMutation(api.supervisorPortal.addAdvance);
  const [dialog, setDialog] = useState(false);
  const advanceData = useQuery(api.supervisorPortal.getPortalData, { workerCode });

  const form = useForm({
    resolver: zodResolver(z.object({
      labourerId: z.string().min(1, "Labour select karo"),
      amount: z.coerce.number().positive("Amount dalein"),
      date: z.string().min(1, "Date dalein"),
      reason: z.string().optional(),
    })),
    defaultValues: { labourerId: "", amount: 0, date: new Date().toISOString().slice(0,10), reason: "" },
  });

  async function onSubmit(d: { labourerId: string; amount: number; date: string; reason?: string }) {
    try {
      await addAdvance({ workerCode, labourerId: d.labourerId as Id<"labourers">, amount: d.amount, date: d.date, reason: d.reason });
      toast.success("Advance add ho gaya!");
      setDialog(false); form.reset();
    } catch { toast.error("Kuch galat hua"); }
  }

  const advances = advanceData?.advances ?? [];

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer"><Plus className="w-3.5 h-3.5 mr-1" />Add Advance</Button>
      </div>
      {advances.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">Koi advance nahi hai</p>
      ) : (
        <div className="space-y-2">
          {advances.map((a) => (
            <Card key={a._id} className="py-0">
              <CardContent className="p-3 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">{data.labourers.find(l => l._id === a.labourerId)?.name ?? "—"}</p>
                  <p className="text-xs text-muted-foreground">{a.date}{a.reason ? ` · ${a.reason}` : ""}</p>
                </div>
                <span className="text-orange-500 font-bold">₹{a.amount.toLocaleString("en-IN")}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Advance Add Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField control={form.control} name="labourerId" render={({ field }) => (
                <FormItem>
                  <FormLabel>Labour *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select labour" /></SelectTrigger></FormControl>
                    <SelectContent>{data.labourers.map(l => <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="amount" render={({ field }) => (
                <FormItem><FormLabel>Amount (₹) *</FormLabel><FormControl><Input type="number" placeholder="500" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="date" render={({ field }) => (
                <FormItem><FormLabel>Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="reason" render={({ field }) => (
                <FormItem><FormLabel>Reason</FormLabel><FormControl><Input placeholder="Koi reason..." {...field} /></FormControl></FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ MATERIAL REQUEST TAB ============
function MaterialTabSafety({ workerCode, data }: { workerCode: string; data: NonNullable<ReturnType<typeof useQuery<typeof api.safety.supervisorPortal.getPortalData>>> }) {
  const submitReq = useMutation(api.supervisorPortal.submitMaterialRequest);
  const [dialog, setDialog] = useState(false);
  const matData = useQuery(api.supervisorPortal.getPortalData, { workerCode });

  const form = useForm({
    resolver: zodResolver(z.object({
      itemName: z.string().min(1, "Material naam zaroori hai"),
      quantity: z.coerce.number().min(1),
      unit: z.string().min(1, "Unit required"),
      urgency: z.enum(["low","medium","high"]),
      notes: z.string().optional(),
    })),
    defaultValues: { itemName: "", quantity: 1, unit: "pcs", urgency: "medium" as const, notes: "" },
  });

  async function onSubmit(d: { itemName: string; quantity: number; unit: string; urgency: "low"|"medium"|"high"; notes?: string }) {
    try {
      await submitReq({ workerCode, ...d });
      toast.success("Request submit ho gayi!");
      setDialog(false); form.reset({ itemName: "", quantity: 1, unit: "pcs", urgency: "medium", notes: "" });
    } catch { toast.error("Submit nahi hua"); }
  }

  const requests = matData?.materialRequests ?? [];

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Button size="sm" onClick={() => setDialog(true)} className="cursor-pointer"><Plus className="w-3.5 h-3.5 mr-1" />New Request</Button>
      </div>
      {requests.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">Koi request nahi hai</p>
      ) : (
        <div className="space-y-2">
          {requests.map((r) => (
            <Card key={r._id} className="py-0">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{r.itemName}</p>
                    <p className="text-xs text-muted-foreground">{r.quantity} {r.unit ?? ""}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded font-medium ${r.urgency === "high" ? "bg-red-500/10 text-red-500" : r.urgency === "medium" ? "bg-orange-500/10 text-orange-500" : "bg-green-500/10 text-green-600"}`}>
                    {r.urgency}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Material Request</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField control={form.control} name="itemName" render={({ field }) => (
                <FormItem><FormLabel>Material *</FormLabel><FormControl><Input placeholder="Cement, Steel..." {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-2">
                <FormField control={form.control} name="quantity" render={({ field }) => (
                  <FormItem><FormLabel>Quantity</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="unit" render={({ field }) => (
                  <FormItem><FormLabel>Unit</FormLabel><FormControl><Input placeholder="Bags/KG" {...field} /></FormControl></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="urgency" render={({ field }) => (
                <FormItem>
                  <FormLabel>Urgency</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High - Aaj chahiye!</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem><FormLabel>Notes</FormLabel><FormControl><Input placeholder="Optional..." {...field} /></FormControl></FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialog(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Submit</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ MY ACCOUNT TAB ============
function MyAccountTab({ token }: { token: string }) {
  const today = new Date();
  const [month, setMonth] = useState(today.toISOString().slice(0, 7));
  const accountData = useQuery(api.safety.supervisorPortal.getMyAccount, { token, month });

  const prevMonth = () => {
    const d = new Date(month + "-01");
    d.setMonth(d.getMonth() - 1);
    setMonth(d.toISOString().slice(0, 7));
  };
  const nextMonth = () => {
    const d = new Date(month + "-01");
    d.setMonth(d.getMonth() + 1);
    if (d <= today) setMonth(d.toISOString().slice(0, 7));
  };

  if (!accountData) {
    return <div className="space-y-3"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>;
  }

  const { supervisor, site, presentDays, halfDays, absentDays, myAdvances, totalAdvance, salaryEntry, myAttendance } = accountData;
  const effectiveDays = presentDays + halfDays * 0.5;
  const monthLabel = new Date(month + "-01").toLocaleDateString("en-IN", { month: "long", year: "numeric" });

  return (
    <div className="space-y-4">
      {/* Profile Card */}
      <Card>
        <CardContent className="p-4 flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
            <User className="w-7 h-7 text-orange-500" />
          </div>
          <div>
            <p className="font-bold text-lg">{supervisor.name}</p>
            <p className="text-sm text-muted-foreground">Safety Supervisor</p>
            <p className="text-xs text-muted-foreground">{site?.name ?? "—"}{site?.city ? ` · ${site.city}` : ""}</p>
            <p className="text-xs font-medium text-orange-600 mt-1">Worker ID: {supervisor.workerCode}</p>
          </div>
        </CardContent>
      </Card>

      {/* Month selector */}
      <div className="flex items-center justify-between bg-muted rounded-lg px-3 py-2">
        <button onClick={prevMonth} className="p-1 rounded hover:bg-background cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
        <span className="font-semibold text-sm">{monthLabel}</span>
        <button onClick={nextMonth} className="p-1 rounded hover:bg-background cursor-pointer"><ChevronRight className="w-4 h-4" /></button>
      </div>

      {/* Attendance Summary */}
      <Card>
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm flex items-center gap-2"><Calendar className="w-4 h-4 text-orange-500" />Attendance</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { label: "Present", value: presentDays, color: "text-green-600 bg-green-50" },
              { label: "Half Day", value: halfDays, color: "text-yellow-600 bg-yellow-50" },
              { label: "Absent", value: absentDays, color: "text-red-600 bg-red-50" },
              { label: "Effective", value: effectiveDays, color: "text-blue-600 bg-blue-50" },
            ].map(({ label, value, color }) => (
              <div key={label} className={`rounded-lg p-2 ${color}`}>
                <p className="text-xl font-bold">{value}</p>
                <p className="text-[10px] font-medium">{label}</p>
              </div>
            ))}
          </div>

          {/* Daily attendance list */}
          {myAttendance.length > 0 && (
            <div className="mt-3 space-y-1 max-h-48 overflow-y-auto">
              {[...myAttendance].sort((a, b) => a.date.localeCompare(b.date)).map((att) => (
                <div key={att._id} className="flex items-center justify-between text-xs px-1">
                  <span className="text-muted-foreground">{new Date(att.date + "T00:00:00").toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}</span>
                  <span className={`px-2 py-0.5 rounded font-medium ${att.status === "present" ? "bg-green-100 text-green-700" : att.status === "half_day" ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700"}`}>
                    {att.status === "present" ? "Present" : att.status === "half_day" ? "Half Day" : "Absent"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Salary Entry */}
      <Card>
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm flex items-center gap-2"><IndianRupee className="w-4 h-4 text-green-600" />Salary - {monthLabel}</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {salaryEntry ? (
            <div className="space-y-2">
              {[
                { label: "Daily Rate", value: salaryEntry.dailyRate ?? 0 },
                { label: "Days Worked", value: salaryEntry.daysWorked ?? effectiveDays },
                { label: "Basic Salary", value: (salaryEntry.dailyRate ?? 0) * (salaryEntry.daysWorked ?? effectiveDays) },
                { label: "Nasta / Allowance", value: (salaryEntry.nastaDays ?? 0) * (salaryEntry.nastaPerDay ?? 0) },
                { label: "Deduction", value: salaryEntry.deductions ?? 0 },
                { label: "Net Payable", value: salaryEntry.netAmount ?? 0, bold: true, green: true },
              ].map(({ label, value, bold, green }) => (
                <div key={label} className={`flex justify-between text-sm ${bold ? "font-bold border-t pt-2 mt-2" : ""}`}>
                  <span className="text-muted-foreground">{label}</span>
                  <span className={green ? "text-green-600" : ""}>₹{Number(value).toLocaleString("en-IN")}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">Is mahine ki salary sheet nahi bani hai abhi</p>
          )}
        </CardContent>
      </Card>

      {/* Advances */}
      <Card>
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm flex items-center gap-2"><FileText className="w-4 h-4 text-purple-600" />Advances - {monthLabel}</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {myAdvances.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">Koi advance nahi is mahine</p>
          ) : (
            <div className="space-y-2">
              {myAdvances.map((adv) => (
                <div key={adv._id} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{new Date(adv.date + "T00:00:00").toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}{adv.reason ? ` — ${adv.reason}` : ""}</span>
                  <span className="font-medium text-purple-700">₹{adv.amount.toLocaleString("en-IN")}</span>
                </div>
              ))}
              <div className="flex justify-between font-bold border-t pt-2 text-sm">
                <span>Total Advance</span>
                <span className="text-purple-700">₹{totalAdvance.toLocaleString("en-IN")}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ============ MAIN PORTAL PAGE ============
function PortalInner({ workerCode }: { workerCode: string }) {
  const token = workerCode;
  const data = useQuery(api.safety.supervisorPortal.getPortalData, { token });

  if (data === undefined) {
    return (
      <div className="min-h-screen p-6 space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (data === null) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-sm w-full">
          <CardContent className="p-6 text-center">
            <ShieldCheck className="w-10 h-10 text-red-500 mx-auto mb-3" />
            <h2 className="font-bold">Access Denied</h2>
            <p className="text-muted-foreground text-sm mt-2">Aap Safety Supervisor nahi hain ya Worker ID galat hai.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-orange-500 text-white px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold">{data.supervisor.name}</p>
              <p className="text-sm text-orange-100">Safety Supervisor · {data.site?.name ?? "—"}</p>
            </div>
          </div>
          <a href="/" className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 transition-colors text-white text-xs font-medium px-3 py-1.5 rounded-lg cursor-pointer">
            <Home className="w-3.5 h-3.5" /> Home
          </a>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="ppe">
          <TabsList className="w-full grid grid-cols-6 mb-4 text-[10px]">
            <TabsTrigger value="account" className="cursor-pointer text-[10px] px-0.5">
              <User className="w-3 h-3 mr-0.5" />Account
            </TabsTrigger>
            <TabsTrigger value="material" className="cursor-pointer text-[10px] px-0.5">
              <Package className="w-3 h-3 mr-0.5" />Material
            </TabsTrigger>
            <TabsTrigger value="labour" className="cursor-pointer text-[10px] px-0.5">
              Labour
            </TabsTrigger>
            <TabsTrigger value="ppe" className="cursor-pointer text-[10px] px-0.5">
              <HardHat className="w-3 h-3" />PPE
            </TabsTrigger>
            <TabsTrigger value="violations" className="cursor-pointer text-[10px] px-0.5">
              <AlertTriangle className="w-3 h-3" />Viol.
            </TabsTrigger>
            <TabsTrigger value="tools" className="cursor-pointer text-[10px] px-0.5">
              <Wrench className="w-3 h-3" />Tools
            </TabsTrigger>
          </TabsList>
          <TabsContent value="account"><MyAccountTab token={token} /></TabsContent>
          <TabsContent value="material"><MaterialTabSafety workerCode={workerCode} data={data} /></TabsContent>
          <TabsContent value="labour"><LabourListTab data={data} /></TabsContent>
          <TabsContent value="ppe"><PpeTab token={token} data={data} /></TabsContent>
          <TabsContent value="violations"><ViolationsTab token={token} data={data} /></TabsContent>
          <TabsContent value="tools"><ToolsTab token={token} data={data} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function SafetySupervisorPortal() {
  const [inputCode, setInputCode] = useState("");
  const [workerCode, setWorkerCode] = useState("");
  const [checking, setChecking] = useState(false);

  const loginData = useQuery(
    api.safety.supervisorPortal.login,
    checking || workerCode ? { workerCode: inputCode } : "skip"
  );

  const handleLogin = () => {
    if (!inputCode.trim()) return;
    setChecking(true);
  };

  if (checking && loginData !== undefined) {
    if (loginData.success && !workerCode) {
      setWorkerCode(inputCode.trim().toUpperCase());
    } else if (!loginData.success) {
      setChecking(false);
    }
  }

  if (workerCode) {
    return <PortalInner workerCode={workerCode} />;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center pb-2">
          <div className="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center mx-auto mb-3">
            <ShieldCheck className="w-8 h-8 text-orange-500" />
          </div>
          <CardTitle className="text-xl">Safety Supervisor Portal</CardTitle>
          <p className="text-sm text-muted-foreground">Apna Worker ID enter karo</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Worker ID (e.g. SS001)"
              value={inputCode}
              onChange={(e) => { setInputCode(e.target.value.toUpperCase()); setChecking(false); }}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              className="text-center text-lg font-mono tracking-widest"
              maxLength={10}
            />
            {checking && loginData && !loginData.success && (
              <p className="text-red-500 text-sm text-center">Worker ID sahi nahi hai ya Safety Supervisor nahi hain</p>
            )}
          </div>
          <Button
            className="w-full cursor-pointer"
            onClick={handleLogin}
            disabled={!inputCode.trim() || (checking && loginData === undefined)}
          >
            {checking && loginData === undefined ? "Checking..." : "Login Karo"}
          </Button>
          <p className="text-xs text-center text-muted-foreground">
            Safety Supervisor ko admin se Worker ID milega
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
