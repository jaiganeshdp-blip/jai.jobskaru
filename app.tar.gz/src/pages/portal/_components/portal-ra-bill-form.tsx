/**
 * Shared RA / Final Bill form used inside both Contractor and Supplier portals.
 * Works entirely via portal token (no Convex auth required).
 * Dark theme — full visibility.
 */
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { AlertTriangle, FileSpreadsheet, CheckCircle2, Plus, ArrowLeft, Building2 } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type POItem = { name: string; quantity: number; unit: string; ratePerUnit: number; totalAmount: number };
type PO = {
  _id: Id<"purchaseOrders">;
  poNumber: string;
  siteName: string;
  companyName?: string;
  totalValue: number;
  status: string;
  items: POItem[];
};
type RAItem = {
  srNo: number; description: string; unit: string;
  orderQty: number; thisBillQty: number; ratePerUnit: number; thisBillAmount: number;
};

type Props = {
  token: string;
  vendorType: "contractor" | "supplier";
  onSuccess?: () => void;
};

const fmt = (n: number) => `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

export function PortalRABillForm({ token, vendorType, onSuccess }: Props) {
  const [step, setStep] = useState<"list" | "form">("list");
  const [selectedPO, setSelectedPO] = useState<PO | null>(null);
  const [billType, setBillType] = useState<"ra" | "final">("ra");
  const [billNumber, setBillNumber] = useState("");
  const [billDate, setBillDate] = useState(new Date().toISOString().split("T")[0]);
  const [gstPercent, setGstPercent] = useState(18);
  const [retentionPercent, setRetentionPercent] = useState(0);
  const [notes, setNotes] = useState("");
  const [raItems, setRaItems] = useState<RAItem[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const poQuery = vendorType === "contractor"
    ? api.portal.contractor.getPOsByToken
    : api.portal.supplier.getPOsByToken;
  const prevBillsQuery = vendorType === "contractor"
    ? api.portal.contractor.getPrevBillsByPO
    : api.portal.supplier.getPrevBillsByPO;
  const submitMutation = vendorType === "contractor"
    ? api.portal.contractor.submitRABill
    : api.portal.supplier.submitRABill;

  const pos = (useQuery(poQuery, { token }) ?? []) as PO[];
  const prevBills = useQuery(
    prevBillsQuery,
    selectedPO ? { token, purchaseOrderId: selectedPO._id } : "skip"
  ) ?? [];
  const submitRABill = useMutation(submitMutation);

  useEffect(() => {
    if (!selectedPO) { setRaItems([]); return; }
    setRaItems(selectedPO.items.map((item, i) => ({
      srNo: i + 1,
      description: item.name,
      unit: item.unit,
      orderQty: item.quantity,
      thisBillQty: 0,
      ratePerUnit: item.ratePerUnit,
      thisBillAmount: 0,
    })));
  }, [selectedPO?._id]);

  const prevQtyBySrNo: Record<number, number> = {};
  for (const b of prevBills) {
    for (const item of b.raBillItems ?? []) {
      prevQtyBySrNo[item.srNo] = (prevQtyBySrNo[item.srNo] ?? 0) + item.thisBillQty;
    }
  }

  const prevBilledTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
  const subtotal = raItems.reduce((s, i) => s + i.thisBillAmount, 0);
  const gstAmount = (subtotal * gstPercent) / 100;
  const grossTotal = subtotal + gstAmount;
  const retentionAmount = (grossTotal * retentionPercent) / 100;
  const balancePayable = grossTotal - retentionAmount;
  const cumulative = prevBilledTotal + subtotal;
  const poValue = selectedPO?.totalValue ?? 0;
  const isExceeding = cumulative > poValue;
  const raNumber = prevBills.length + 1;

  function updateItem(srNo: number, value: number) {
    setRaItems(prev => prev.map(item => {
      if (item.srNo !== srNo) return item;
      return { ...item, thisBillQty: value, thisBillAmount: value * item.ratePerUnit };
    }));
  }

  function resetForm() {
    setSubmitted(false);
    setStep("list");
    setSelectedPO(null);
    setBillNumber("");
    setRaItems([]);
    setNotes("");
    setRetentionPercent(0);
    setGstPercent(18);
  }

  async function handleSubmit() {
    if (!selectedPO || !billNumber || subtotal === 0) {
      toast.error("PO, Bill Number aur kam se kam ek item fill karein");
      return;
    }
    setSubmitting(true);
    try {
      const result = await submitRABill({
        token,
        purchaseOrderId: selectedPO._id,
        billNumber,
        billDate,
        billType,
        raBillItems: raItems.filter(i => i.thisBillQty > 0),
        gstPercent,
        retentionPercent: retentionPercent || undefined,
        notes: notes || undefined,
      });
      if (result.warning) toast.warning(result.warning);
      else toast.success(`${billType === "final" ? "Final Bill" : `RA-${raNumber}`} submit ho gaya!`);
      setSubmitted(true);
      onSuccess?.();
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setSubmitting(false);
    }
  }

  /* ── SUCCESS ── */
  if (submitted) {
    return (
      <div className="text-center py-8 space-y-4">
        <CheckCircle2 className="mx-auto w-14 h-14 text-green-400" />
        <h3 className="font-bold text-xl text-white">Bill Submit Ho Gaya!</h3>
        <p className="text-slate-300 text-sm">Admin review karenge aur payment process karenge.</p>
        <Button
          className="bg-slate-700 hover:bg-slate-600 text-white border-slate-500"
          size="sm"
          onClick={resetForm}
        >
          Nayi Bill Submit Karein
        </Button>
      </div>
    );
  }

  /* ── PO LIST ── */
  if (step === "list") {
    return (
      <div className="space-y-3">
        <p className="text-slate-300 text-sm font-medium">Apna PO chunein aur bill submit karein</p>
        {pos.length === 0 ? (
          <div className="text-center py-6 text-slate-400">
            <FileSpreadsheet className="mx-auto mb-2 text-slate-600" size={32} />
            <p className="text-sm">Koi PO assign nahi hai</p>
          </div>
        ) : (
          <div className="space-y-2">
            {pos.map(po => (
              <div key={po._id} className="bg-slate-700 border border-slate-600 rounded-xl p-4">
                {/* Company name prominently shown */}
                {po.companyName && (
                  <div className="flex items-center gap-1.5 mb-2">
                    <Building2 size={13} className="text-yellow-400" />
                    <span className="text-yellow-300 text-xs font-bold uppercase tracking-wide">{po.companyName}</span>
                  </div>
                )}
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-white font-bold text-base">{po.poNumber}</div>
                    <div className="text-slate-300 text-sm mt-0.5">{po.siteName}</div>
                    <div className="text-emerald-400 font-semibold text-sm mt-0.5">{fmt(po.totalValue)}</div>
                  </div>
                  <button
                    onClick={() => { setSelectedPO(po); setStep("form"); }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-1.5 cursor-pointer shrink-0 transition-colors"
                  >
                    <Plus size={14} /> Bill Banao
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  /* ── BILL FORM ── */
  return (
    <div className="space-y-4">
      {/* Back + PO Info */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => { setStep("list"); setSelectedPO(null); }}
          className="flex items-center gap-1.5 bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold cursor-pointer transition-colors"
        >
          <ArrowLeft size={14} /> Back
        </button>
        <div className="flex-1 min-w-0">
          {selectedPO?.companyName && (
            <div className="flex items-center gap-1 mb-0.5">
              <Building2 size={12} className="text-yellow-400" />
              <span className="text-yellow-300 text-xs font-bold">{selectedPO.companyName}</span>
            </div>
          )}
          <p className="text-white text-sm font-bold truncate">{selectedPO?.poNumber} — {selectedPO?.siteName}</p>
        </div>
      </div>

      {/* PO Summary */}
      <div className="bg-slate-700 rounded-xl p-4 grid grid-cols-3 gap-3">
        <div>
          <p className="text-slate-400 text-xs mb-1">PO Value</p>
          <p className="text-white font-extrabold text-base">{fmt(poValue)}</p>
        </div>
        <div>
          <p className="text-slate-400 text-xs mb-1">Pehle Billed</p>
          <p className="text-orange-300 font-extrabold text-base">{fmt(prevBilledTotal)}</p>
        </div>
        <div>
          <p className="text-slate-400 text-xs mb-1">Balance</p>
          <p className={`font-extrabold text-base ${isExceeding ? "text-red-400" : "text-green-400"}`}>
            {fmt(Math.max(0, poValue - prevBilledTotal))}
          </p>
        </div>
      </div>

      {/* Previous bills */}
      {prevBills.length > 0 && (
        <div className="flex gap-2 flex-wrap items-center">
          <span className="text-slate-400 text-xs font-semibold">Purane bills:</span>
          {prevBills.map(b => (
            <span key={b._id} className="bg-slate-700 text-slate-200 text-xs px-2 py-0.5 rounded font-bold border border-slate-600">
              {b.billType === "final" ? "Final" : `RA-${b.raNumber}`}
              <span className="text-slate-400 ml-1">{fmt(b.subtotal)}</span>
            </span>
          ))}
        </div>
      )}

      {/* Bill Details */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">Bill Type</Label>
          <Select value={billType} onValueChange={v => setBillType(v as "ra" | "final")}>
            <SelectTrigger className="h-10 bg-slate-700 border-slate-500 text-white font-semibold">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-600 text-white">
              <SelectItem value="ra" className="text-white">RA-{raNumber} (Running Account)</SelectItem>
              <SelectItem value="final" className="text-white">Final Bill</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">Bill Number *</Label>
          <Input
            className="h-10 bg-slate-700 border-slate-500 text-white placeholder-slate-400 font-semibold"
            value={billNumber}
            onChange={e => setBillNumber(e.target.value)}
            placeholder={`RA-00${raNumber}`}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">Bill Date *</Label>
          <Input
            type="date"
            className="h-10 bg-slate-700 border-slate-500 text-white font-semibold"
            value={billDate}
            onChange={e => setBillDate(e.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">GST %</Label>
          <Input
            type="number"
            className="h-10 bg-slate-700 border-slate-500 text-white font-semibold"
            min={0} max={100}
            value={gstPercent}
            onChange={e => setGstPercent(Number(e.target.value) || 0)}
          />
        </div>
      </div>

      {/* Items Table */}
      {raItems.length > 0 && (
        <div className="space-y-2">
          <Label className="text-white text-xs font-bold">Item-wise Quantity Bharein</Label>
          <div className="overflow-x-auto rounded-xl border border-slate-600">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white">
                  <th className="px-2 py-2.5 text-left border-r border-slate-700 w-6">Sr</th>
                  <th className="px-2 py-2.5 text-left border-r border-slate-700">Item</th>
                  <th className="px-2 py-2.5 text-center border-r border-slate-700 w-10">Unit</th>
                  <th className="px-2 py-2.5 text-right border-r border-slate-700 w-14">PO Qty</th>
                  <th className="px-2 py-2.5 text-right border-r border-slate-700 w-14 text-orange-300">Prev</th>
                  <th className="px-2 py-2.5 text-right border-r border-slate-700 w-14 text-cyan-300">Bal</th>
                  <th className="px-2 py-2.5 text-center border-r border-blue-600 w-20 bg-blue-700 text-white">Is Bill Qty</th>
                  <th className="px-2 py-2.5 text-right border-r border-slate-700 w-20 text-slate-300">Rate</th>
                  <th className="px-2 py-2.5 text-right w-24 bg-emerald-700 text-white">Amount</th>
                </tr>
              </thead>
              <tbody>
                {raItems.map(item => {
                  const prevQty = prevQtyBySrNo[item.srNo] ?? 0;
                  const bal = Math.max(0, item.orderQty - prevQty);
                  const isOver = item.thisBillQty > bal && bal > 0;
                  return (
                    <tr key={item.srNo} className="border-t border-slate-700 bg-slate-800 hover:bg-slate-750">
                      <td className="px-2 py-2 text-slate-400 border-r border-slate-700">{item.srNo}</td>
                      <td className="px-2 py-2 border-r border-slate-700 max-w-[120px]">
                        <span className="block truncate text-white font-semibold" title={item.description}>{item.description}</span>
                      </td>
                      <td className="px-2 py-2 text-center text-slate-300 border-r border-slate-700">{item.unit}</td>
                      <td className="px-2 py-2 text-right border-r border-slate-700 text-slate-300 font-medium">{item.orderQty}</td>
                      <td className="px-2 py-2 text-right text-orange-400 border-r border-slate-700 font-medium">{prevQty || "—"}</td>
                      <td className={`px-2 py-2 text-right border-r border-slate-700 font-bold ${bal <= 0 ? "text-red-400" : "text-cyan-300"}`}>{bal}</td>
                      <td className="px-2 py-2 bg-blue-900/40 border-r border-blue-700">
                        <Input
                          type="number" min={0} step="0.01"
                          value={item.thisBillQty || ""}
                          placeholder="0"
                          onChange={e => updateItem(item.srNo, Number(e.target.value) || 0)}
                          className={`w-16 h-7 text-xs text-right font-bold bg-slate-800 text-white ${isOver ? "border-red-500" : "border-blue-500"}`}
                        />
                        {isOver && <div className="text-[10px] text-red-400 font-bold text-right">Zyada!</div>}
                      </td>
                      <td className="px-2 py-2 text-right border-r border-slate-700 text-slate-300">{fmt(item.ratePerUnit)}</td>
                      <td className={`px-2 py-2 text-right font-bold bg-emerald-900/40 ${item.thisBillAmount > 0 ? "text-emerald-300" : "text-slate-500"}`}>
                        {item.thisBillAmount > 0 ? fmt(item.thisBillAmount) : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-600 bg-slate-900">
                  <td colSpan={8} className="px-2 py-2.5 text-right border-r border-slate-700 text-slate-300 font-bold text-xs">Subtotal (GST se pehle)</td>
                  <td className="px-2 py-2.5 text-right text-emerald-300 font-extrabold">{fmt(subtotal)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Bill Summary */}
      {subtotal > 0 && (
        <div className="rounded-xl border border-slate-600 overflow-hidden">
          <div className="bg-slate-700 px-4 py-2 font-bold text-white text-xs uppercase tracking-wide">Bill Summary</div>
          <div className="bg-slate-800 divide-y divide-slate-700 text-sm">
            <div className="flex justify-between px-4 py-2.5">
              <span className="text-slate-300 font-semibold">Subtotal</span>
              <span className="font-bold text-white">{fmt(subtotal)}</span>
            </div>
            <div className="flex justify-between px-4 py-2.5">
              <span className="text-slate-300 font-semibold">GST @ {gstPercent}%</span>
              <span className="font-bold text-yellow-300">+ {fmt(gstAmount)}</span>
            </div>
            <div className="flex justify-between px-4 py-3 bg-slate-700">
              <span className="text-white font-bold">Gross Total</span>
              <span className="text-white font-extrabold">{fmt(grossTotal)}</span>
            </div>
            {retentionPercent > 0 && (
              <div className="flex justify-between px-4 py-2.5 bg-red-900/30">
                <span className="text-red-300 font-bold">(-) Retention @ {retentionPercent}%</span>
                <span className="text-red-300 font-bold">− {fmt(retentionAmount)}</span>
              </div>
            )}
            <div className="flex justify-between px-4 py-3 bg-emerald-700">
              <span className="text-white font-bold">Balance Payable</span>
              <span className="text-white font-extrabold text-base">{fmt(balancePayable)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Retention & Notes */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">Retention % (0 agar nahi)</Label>
          <Input
            type="number"
            className="h-10 bg-slate-700 border-slate-500 text-white font-semibold"
            min={0} max={100}
            value={retentionPercent}
            onChange={e => setRetentionPercent(Number(e.target.value) || 0)}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-white text-xs font-bold">Notes (optional)</Label>
          <Textarea
            rows={1}
            className="bg-slate-700 border-slate-500 text-white placeholder-slate-400"
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Remarks..."
          />
        </div>
      </div>

      {/* PO Exceed Warning */}
      {isExceeding && (
        <div className="flex gap-2 items-start bg-red-900/50 border border-red-600 rounded-xl p-3 text-sm text-red-300">
          <AlertTriangle size={15} className="shrink-0 mt-0.5" />
          <span>PO Value se ₹{(cumulative - poValue).toLocaleString("en-IN")} zyada hai! Admin se confirm karein.</span>
        </div>
      )}

      {/* Submit Buttons */}
      <div className="flex gap-3 pt-1">
        <button
          onClick={() => { setStep("list"); setSelectedPO(null); }}
          className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-xl cursor-pointer transition-colors text-sm"
        >
          Cancel
        </button>
        <button
          disabled={submitting || !billNumber || subtotal === 0}
          onClick={handleSubmit}
          className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold rounded-xl cursor-pointer transition-colors text-sm flex items-center justify-center gap-2"
        >
          <FileSpreadsheet size={15} />
          {submitting ? "Submit ho raha hai..." : `${billType === "final" ? "Final Bill" : `RA-${raNumber}`} Submit Karein`}
        </button>
      </div>
    </div>
  );
}
