/**
 * Attachment upload/view component for portal bills (token-based, no auth).
 * Supports photo (JPG/PNG), PDF, and Excel uploads.
 * PDF & images open in a fullscreen viewer in their original format.
 */
import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Paperclip, Upload, Eye, FileText, Image as ImageIcon,
  FileSpreadsheet, Loader2, X, Download, ZoomIn, ZoomOut,
  ChevronLeft, ChevronRight,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Props = {
  token: string;
  billId: Id<"vendorBills">;
  vendorType: "contractor" | "supplier";
};

type Attachment = {
  storageId: string;
  url: string | null;
  fileName: string;
  fileType: string;
};

const ACCEPT =
  "image/*,.pdf,.xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

function fileIcon(fileType: string) {
  if (fileType.startsWith("image/")) return <ImageIcon size={14} className="text-blue-400" />;
  if (fileType === "application/pdf") return <FileText size={14} className="text-red-400" />;
  return <FileSpreadsheet size={14} className="text-green-400" />;
}

function fileLabel(fileType: string) {
  if (fileType.startsWith("image/")) return "Photo";
  if (fileType === "application/pdf") return "PDF";
  return "Excel";
}

function isImage(fileType: string) {
  return fileType.startsWith("image/");
}

function isPDF(fileType: string) {
  return fileType === "application/pdf";
}

/* ─── Fullscreen viewer dialog ─── */
function FileViewer({
  attachments,
  startIndex,
  onClose,
}: {
  attachments: Attachment[];
  startIndex: number;
  onClose: () => void;
}) {
  const [idx, setIdx] = useState(startIndex);
  const [imgZoom, setImgZoom] = useState(1);

  const current = attachments[idx];
  if (!current || !current.url) return null;

  const canPrev = idx > 0;
  const canNext = idx < attachments.length - 1;

  function go(direction: number) {
    setIdx((i) => i + direction);
    setImgZoom(1);
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col" onClick={onClose}>
      {/* Top bar */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-700 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 min-w-0">
          {fileIcon(current.fileType)}
          <span className="text-white text-sm font-semibold truncate max-w-[200px]">{current.fileName}</span>
          <span className="text-slate-400 text-xs shrink-0">
            ({idx + 1} / {attachments.length})
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {isImage(current.fileType) && (
            <>
              <button
                onClick={() => setImgZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white cursor-pointer"
              >
                <ZoomOut size={15} />
              </button>
              <span className="text-slate-300 text-xs w-10 text-center font-mono">
                {Math.round(imgZoom * 100)}%
              </span>
              <button
                onClick={() => setImgZoom((z) => Math.min(4, z + 0.25))}
                className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white cursor-pointer"
              >
                <ZoomIn size={15} />
              </button>
            </>
          )}
          <a
            href={current.url}
            download={current.fileName}
            className="flex items-center gap-1 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
            onClick={(e) => e.stopPropagation()}
          >
            <Download size={13} /> Download
          </a>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-red-800 hover:bg-red-700 text-white cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Content area */}
      <div
        className="flex-1 overflow-auto flex items-center justify-center relative"
        onClick={(e) => e.stopPropagation()}
      >
        {isPDF(current.fileType) && (
          <iframe
            src={current.url}
            className="w-full h-full border-0"
            title={current.fileName}
            style={{ minHeight: "calc(100vh - 60px)" }}
          />
        )}

        {isImage(current.fileType) && (
          <div className="overflow-auto w-full h-full flex items-center justify-center p-4">
            <img
              src={current.url}
              alt={current.fileName}
              style={{ transform: `scale(${imgZoom})`, transformOrigin: "center", transition: "transform 0.2s" }}
              className="max-w-full object-contain rounded shadow-2xl"
            />
          </div>
        )}

        {!isPDF(current.fileType) && !isImage(current.fileType) && (
          <div className="text-center space-y-4 p-8">
            <FileSpreadsheet size={64} className="mx-auto text-green-400" />
            <p className="text-white text-lg font-bold">{current.fileName}</p>
            <p className="text-slate-400 text-sm">Excel file ko browser mein preview nahi ho sakta.</p>
            <a
              href={current.url}
              download={current.fileName}
              className="inline-flex items-center gap-2 bg-green-700 hover:bg-green-600 text-white font-bold px-5 py-3 rounded-xl cursor-pointer"
            >
              <Download size={16} /> Excel Download Karein
            </a>
          </div>
        )}

        {/* Prev / Next arrows */}
        {canPrev && (
          <button
            onClick={() => go(-1)}
            className="absolute left-3 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700 text-white p-2 rounded-full cursor-pointer shadow-xl"
          >
            <ChevronLeft size={22} />
          </button>
        )}
        {canNext && (
          <button
            onClick={() => go(1)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700 text-white p-2 rounded-full cursor-pointer shadow-xl"
          >
            <ChevronRight size={22} />
          </button>
        )}
      </div>
    </div>
  );
}

/* ─── Main component ─── */
export function PortalBillAttachments({ token, billId, vendorType }: Props) {
  const [uploading, setUploading] = useState(false);
  const [viewerIdx, setViewerIdx] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const genUrlMutation =
    vendorType === "contractor"
      ? api.portal.contractor.generateUploadUrl
      : api.portal.supplier.generateUploadUrl;
  const addAttachmentMutation =
    vendorType === "contractor"
      ? api.portal.contractor.addBillAttachment
      : api.portal.supplier.addBillAttachment;
  const attachmentsQuery =
    vendorType === "contractor"
      ? api.portal.contractor.getBillAttachmentUrls
      : api.portal.supplier.getBillAttachmentUrls;

  const generateUploadUrl = useMutation(genUrlMutation);
  const addBillAttachment = useMutation(addAttachmentMutation);
  const attachments = (useQuery(attachmentsQuery, { token, billId }) ?? []) as Attachment[];

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl({ token });
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!res.ok) throw new Error("Upload failed");
      const { storageId } = (await res.json()) as { storageId: string };
      await addBillAttachment({
        token,
        billId,
        storageId: storageId as Id<"_storage">,
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
      });
      toast.success("File upload ho gaya!");
    } catch {
      toast.error("Upload fail hua, dobara try karein");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <>
      {/* Viewer overlay */}
      {viewerIdx !== null && (
        <FileViewer
          attachments={attachments}
          startIndex={viewerIdx}
          onClose={() => setViewerIdx(null)}
        />
      )}

      <div className="mt-3 space-y-2">
        {/* Header row */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-400 text-xs font-semibold flex items-center gap-1">
            <Paperclip size={12} /> Documents ({attachments.length})
          </span>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-600 disabled:bg-slate-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer transition-colors shrink-0"
          >
            {uploading ? (
              <Loader2 size={12} className="animate-spin" />
            ) : (
              <Upload size={12} />
            )}
            {uploading ? "Upload ho raha hai..." : "📎 Photo / PDF / Excel Upload"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept={ACCEPT}
            className="hidden"
            onChange={handleFileChange}
          />
        </div>

        {/* File list */}
        {attachments.length > 0 ? (
          <div className="space-y-1.5">
            {attachments.map((a, i) => (
              <div
                key={a.storageId}
                className="flex items-center gap-2 bg-slate-700 border border-slate-600 rounded-lg px-3 py-2"
              >
                {fileIcon(a.fileType)}
                <span className="flex-1 text-white text-xs font-medium truncate">{a.fileName}</span>
                <span className="text-slate-400 text-[10px] shrink-0 font-semibold">
                  {fileLabel(a.fileType)}
                </span>
                {a.url && (
                  <button
                    onClick={() => setViewerIdx(i)}
                    className="flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 text-white text-xs px-2.5 py-1 rounded-lg font-bold cursor-pointer transition-colors shrink-0"
                  >
                    <Eye size={11} /> Dekho
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-xs italic">
            Bill ki photo, delivery challan, ya PDF yahan upload karein — original format mein dikhega
          </p>
        )}
      </div>
    </>
  );
}
