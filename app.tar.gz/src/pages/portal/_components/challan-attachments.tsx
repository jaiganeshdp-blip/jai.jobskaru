/**
 * Challan / delivery document upload component (token-based, supplier portal).
 * Supports photo (JPG/PNG) and PDF uploads. Opens in fullscreen viewer.
 */
import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Upload, Eye, FileText, Image as ImageIcon,
  Loader2, X, Download, ZoomIn, ZoomOut,
  ChevronLeft, ChevronRight, Paperclip,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Attachment = {
  storageId: string;
  url: string | null;
  fileName: string;
  fileType: string;
};

const ACCEPT = "image/*,.pdf";

function fileIcon(fileType: string) {
  if (fileType.startsWith("image/")) return <ImageIcon size={13} className="text-blue-400 shrink-0" />;
  return <FileText size={13} className="text-red-400 shrink-0" />;
}
function fileLabel(fileType: string) {
  return fileType.startsWith("image/") ? "Photo" : "PDF";
}
function isImage(ft: string) { return ft.startsWith("image/"); }
function isPDF(ft: string) { return ft === "application/pdf"; }

function FileViewer({
  attachments, startIndex, onClose,
}: { attachments: Attachment[]; startIndex: number; onClose: () => void }) {
  const [idx, setIdx] = useState(startIndex);
  const [imgZoom, setImgZoom] = useState(1);
  const current = attachments[idx];
  if (!current?.url) return null;
  const canPrev = idx > 0;
  const canNext = idx < attachments.length - 1;
  function go(d: number) { setIdx((i) => i + d); setImgZoom(1); }

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col" onClick={onClose}>
      {/* Top bar */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-700 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 min-w-0">
          {fileIcon(current.fileType)}
          <span className="text-white text-sm font-semibold truncate max-w-[200px]">{current.fileName}</span>
          <span className="text-slate-400 text-xs shrink-0">({idx + 1}/{attachments.length})</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {isImage(current.fileType) && (
            <>
              <button onClick={() => setImgZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white cursor-pointer">
                <ZoomOut size={15} />
              </button>
              <span className="text-slate-300 text-xs w-10 text-center font-mono">{Math.round(imgZoom * 100)}%</span>
              <button onClick={() => setImgZoom((z) => Math.min(4, z + 0.25))}
                className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white cursor-pointer">
                <ZoomIn size={15} />
              </button>
            </>
          )}
          <a href={current.url} download={current.fileName} onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer">
            <Download size={13} /> Download
          </a>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-red-800 hover:bg-red-700 text-white cursor-pointer">
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto flex items-center justify-center relative" onClick={(e) => e.stopPropagation()}>
        {isPDF(current.fileType) && (
          <iframe src={current.url} className="w-full h-full border-0" title={current.fileName}
            style={{ minHeight: "calc(100vh - 60px)" }} />
        )}
        {isImage(current.fileType) && (
          <div className="overflow-auto w-full h-full flex items-center justify-center p-4">
            <img src={current.url} alt={current.fileName}
              style={{ transform: `scale(${imgZoom})`, transformOrigin: "center", transition: "transform 0.2s" }}
              className="max-w-full object-contain rounded shadow-2xl" />
          </div>
        )}
        {canPrev && (
          <button onClick={() => go(-1)}
            className="absolute left-3 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700 text-white p-2 rounded-full cursor-pointer shadow-xl">
            <ChevronLeft size={22} />
          </button>
        )}
        {canNext && (
          <button onClick={() => go(1)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700 text-white p-2 rounded-full cursor-pointer shadow-xl">
            <ChevronRight size={22} />
          </button>
        )}
      </div>
    </div>
  );
}

type Props = {
  token: string;
  materialId: Id<"materials">;
};

export function ChallanAttachments({ token, materialId }: Props) {
  const [uploading, setUploading] = useState(false);
  const [viewerIdx, setViewerIdx] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.portal.supplier.generateUploadUrl);
  const addChallanAttachment = useMutation(api.portal.supplier.addChallanAttachment);
  const attachments = (useQuery(api.portal.supplier.getChallanAttachmentUrls, { token, materialId }) ?? []) as Attachment[];

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl({ token });
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!res.ok) throw new Error("Upload failed");
      const { storageId } = (await res.json()) as { storageId: string };
      await addChallanAttachment({
        token,
        materialId,
        storageId: storageId as Id<"_storage">,
        fileName: file.name,
        fileType: file.type,
      });
      toast.success("Challan upload ho gaya!");
    } catch {
      toast.error("Upload fail hua, dobara try karein");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <>
      {viewerIdx !== null && (
        <FileViewer attachments={attachments} startIndex={viewerIdx} onClose={() => setViewerIdx(null)} />
      )}
      <div className="mt-2 space-y-1.5">
        {/* Upload button */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-400 text-[11px] font-semibold flex items-center gap-1">
            <Paperclip size={11} /> Challan / Photo ({attachments.length})
          </span>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1.5 bg-orange-700 hover:bg-orange-600 disabled:bg-slate-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors shrink-0"
          >
            {uploading ? <Loader2 size={11} className="animate-spin" /> : <Upload size={11} />}
            {uploading ? "Upload ho raha hai..." : "📄 Challan / Photo Upload"}
          </button>
          <input ref={fileInputRef} type="file" accept={ACCEPT} className="hidden" onChange={handleFileChange} />
        </div>

        {/* File list */}
        {attachments.length > 0 ? (
          <div className="space-y-1">
            {attachments.map((a, i) => (
              <div key={a.storageId} className="flex items-center gap-2 bg-slate-700 border border-slate-600 rounded-lg px-2.5 py-1.5">
                {fileIcon(a.fileType)}
                <span className="flex-1 text-white text-[11px] font-medium truncate">{a.fileName}</span>
                <span className="text-slate-400 text-[10px] shrink-0 font-semibold">{fileLabel(a.fileType)}</span>
                {a.url && (
                  <button onClick={() => setViewerIdx(i)}
                    className="flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] px-2 py-1 rounded font-bold cursor-pointer transition-colors shrink-0">
                    <Eye size={10} /> Dekho
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-[11px] italic">
            Delivery challan ya photo yahan upload karein
          </p>
        )}
      </div>
    </>
  );
}
