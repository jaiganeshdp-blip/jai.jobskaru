import { useState, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Users,
  IndianRupee,
  FileText,
  Package,
  CheckCircle,
  XCircle,
  Clock,
  Camera,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  Truck,
  Plus,
  CalendarCheck,
  Home,
  UserPlus,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

// ─── Types ────────────────────────────────────────────────────────────────
type LabourerData = {
  _id: Id<"labourers">;
  name: string;
  designation?: string;
  dailyRate: number;
};

type PortalData = NonNullable<ReturnType<typeof useQuery<typeof api.supervisorPortal.getPortalData>>>;

// ─── Attendance Status Helpers ────────────────────────────────────────────
const STATUS_OPTIONS = [
  { value: "present", label: "Present", color: "bg-green-500" },
  { value: "absent", label: "Absent", color: "bg-red-500" },
  { value: "half_day", label: "Half Day", color: "bg-yellow-500" },
  { value: "holiday", label: "Holiday", color: "bg-blue-500" },
] as const;

type AttStatus = "present" | "absent" | "half_day" | "holiday";

function statusBadge(s: string) {
  if (s === "present") return <Badge className="bg-green-500/20 text-green-600 border-green-500/30">Present</Badge>;
  if (s === "absent") return <Badge className="bg-red-500/20 text-red-600 border-red-500/30">Absent</Badge>;
  if (s === "half_day") return <Badge className="bg-yellow-500/20 text-yellow-600 border-yellow-500/30">Half Day</Badge>;
  if (s === "holiday") return <Badge className="bg-blue-500/20 text-blue-600 border-blue-500/30">Holiday</Badge>;
  return <Badge variant="outline">—</Badge>;
}

// ─── Attendance Tab ────────────────────────────────────────────────────────
function AttendanceTab({ workerCode, data, selectedDate, onDateChange }: { 
  workerCode: string; 
  data: PortalData;
  selectedDate: string;
  onDateChange: (d: string) => void;
}) {
  const bulkMark = useMutation(api.supervisorPortal.bulkMarkAttendance);
  const [date, setDate] = useState(selectedDate);
  const [localMap, setLocalMap] = useState<Record<string, AttStatus>>({});
  const [localUnitsMap, setLocalUnitsMap] = useState<Record<string, string>>({}); // decimal hajri units
  const [saving, setSaving] = useState(false);

  // Sync date with parent (so query updates)
  const handleDateChange = (d: string) => {
    setDate(d);
    onDateChange(d);
    setLocalMap({});
    setLocalUnitsMap({});
  };

  const getStatus = (labId: string): AttStatus =>
    (localMap[labId] ?? data.attendanceMap[labId] ?? "absent") as AttStatus;

  // Derive status from decimal hajri units
  function unitsToStatus(units: number): AttStatus {
    if (units <= 0) return "absent";
    if (units < 1) return "half_day";
    return "present";
  }

  // Get displayed units for a labourer (local override or saved value)
  const getUnits = (labId: string): string => {
    if (localUnitsMap[labId] !== undefined) return localUnitsMap[labId];
    const saved = (data as { attendanceUnitsMap?: Record<string, number> }).attendanceUnitsMap?.[labId];
    if (saved !== undefined) return String(saved);
    // Fall back to status-based default
    const status = getStatus(labId);
    if (status === "absent") return "0";
    if (status === "half_day") return "0.5";
    if (status === "present") return "1";
    return "0";
  };

  const setAll = (status: AttStatus) => {
    const m: Record<string, AttStatus> = {};
    const u: Record<string, string> = {};
    for (const l of data.labourers) {
      m[l._id] = status;
      u[l._id] = status === "present" ? "1" : status === "half_day" ? "0.5" : "0";
    }
    setLocalMap(m);
    setLocalUnitsMap(u);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const entries = data.labourers.map((l) => {
        const unitsStr = getUnits(l._id);
        const units = parseFloat(unitsStr);
        const hajriUnits = isNaN(units) ? undefined : units;
        const status = hajriUnits !== undefined ? unitsToStatus(hajriUnits) : getStatus(l._id);
        return {
          labourerId: l._id as Id<"labourers">,
          status,
          overtimeHours: undefined as number | undefined,
          hajriUnits,
        };
      });
      await bulkMark({ workerCode, date, entries });
      toast.success("Attendance saved!");
      setLocalMap({});
      setLocalUnitsMap({});
    } catch {
      toast.error("Failed to save attendance");
    } finally {
      setSaving(false);
    }
  };

  const presentCount = data.labourers.filter((l) => {
    const u = parseFloat(getUnits(l._id));
    return !isNaN(u) && u >= 1;
  }).length;
  const halfCount = data.labourers.filter((l) => {
    const u = parseFloat(getUnits(l._id));
    return !isNaN(u) && u > 0 && u < 1;
  }).length;
  const totalUnits = data.labourers.reduce((sum, l) => {
    const u = parseFloat(getUnits(l._id));
    return sum + (isNaN(u) ? 0 : u);
  }, 0);

  return (
    <div className="space-y-4">
      {/* Date and quick actions */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const d = new Date(date);
              d.setDate(d.getDate() - 1);
              handleDateChange(d.toISOString().slice(0, 10));
            }}
            className="p-1 rounded hover:bg-muted"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <Input
            type="date"
            value={date}
            onChange={(e) => handleDateChange(e.target.value)}
            className="w-36"
          />
          <button
            onClick={() => {
              const d = new Date(date);
              d.setDate(d.getDate() + 1);
              handleDateChange(d.toISOString().slice(0, 10));
            }}
            className="p-1 rounded hover:bg-muted"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        <div className="flex gap-1">
          <Button size="sm" variant="ghost" onClick={() => setAll("present")}>All Present</Button>
          <Button size="sm" variant="ghost" onClick={() => setAll("absent")}>All Absent</Button>
        </div>
      </div>

      {/* Summary row */}
      <div className="flex gap-3 text-sm flex-wrap">
        <span className="text-green-600 font-medium">Present: {presentCount}</span>
        <span className="text-yellow-600 font-medium">Half: {halfCount}</span>
        <span className="text-blue-600 font-medium">Total Hajri: {totalUnits.toFixed(2)}</span>
        <span className="text-gray-600">Labour: {data.labourers.length}</span>
      </div>

      {/* Labour list */}
      <div className="space-y-2">
        {data.labourers.map((lab) => {
          const currentUnits = getUnits(lab._id);
          const unitsNum = parseFloat(currentUnits);
          const srcInfo = data.attendanceSourceMap?.[lab._id];
          const alreadyMarked = !!data.attendanceMap[lab._id] && !localUnitsMap[lab._id];

          // Color indicator based on units
          const unitColor = isNaN(unitsNum) || unitsNum <= 0
            ? "border-l-red-400"
            : unitsNum < 1
            ? "border-l-yellow-400"
            : unitsNum >= 2
            ? "border-l-purple-500"
            : "border-l-green-500";

          // Quick preset values
          const PRESETS = ["0", "0.5", "1", "1.5", "2", "2.5"];

          return (
            <Card key={lab._id} className={`py-0 bg-white border-l-4 ${unitColor}`}>
              <CardContent className="p-3">
                <div className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate text-gray-900">{lab.name}</p>
                    <p className="text-xs text-gray-500">{lab.designation ?? "Labour"} • ₹{lab.dailyRate}/day</p>
                    {alreadyMarked && srcInfo && (
                      <span className={`text-xs px-1.5 py-0.5 rounded font-medium mt-0.5 inline-block ${
                        srcInfo.source === "admin"
                          ? "bg-blue-100 text-blue-600"
                          : "bg-green-100 text-green-600"
                      }`}>
                        {srcInfo.source === "admin"
                          ? `✓ Admin ne bhara (${srcInfo.markedByName ?? "Admin"})`
                          : `✓ Supervisor ne bhara`}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    {/* Manual number input */}
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-gray-500">Hajri:</span>
                      <input
                        type="number"
                        min="0"
                        max="3"
                        step="0.25"
                        value={currentUnits}
                        onChange={(e) => {
                          const val = e.target.value;
                          setLocalUnitsMap((m) => ({ ...m, [lab._id]: val }));
                          const n = parseFloat(val);
                          if (!isNaN(n)) {
                            setLocalMap((m) => ({ ...m, [lab._id]: unitsToStatus(n) }));
                          }
                        }}
                        className="w-16 text-center text-sm font-bold border-2 border-gray-300 rounded-lg px-1 py-0.5 bg-white text-gray-900 focus:border-primary focus:outline-none"
                      />
                    </div>
                    {/* Quick preset buttons */}
                    <div className="flex flex-wrap gap-0.5 justify-end">
                      {PRESETS.map((p) => (
                        <button
                          key={p}
                          onClick={() => {
                            setLocalUnitsMap((m) => ({ ...m, [lab._id]: p }));
                            setLocalMap((m) => ({ ...m, [lab._id]: unitsToStatus(parseFloat(p)) }));
                          }}
                          className={`px-1.5 py-0.5 rounded text-xs font-medium border transition-all ${
                            currentUnits === p
                              ? "bg-primary text-white border-primary"
                              : "bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200"
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Button className="w-full" onClick={handleSave} disabled={saving}>
        {saving ? "Saving..." : "Save Attendance"}
      </Button>
    </div>
  );
}

// ─── Advance / Nasta / PT Tab ──────────────────────────────────────────────
function AdvanceTab({ workerCode, data }: { workerCode: string; data: PortalData }) {
  const addAdvance = useMutation(api.supervisorPortal.addAdvance);
  const [dialog, setDialog] = useState(false);

  const form = useForm({
    resolver: zodResolver(
      z.object({
        labourerId: z.string().min(1, "Labour select karo"),
        amount: z.coerce.number().positive("Amount dalein"),
        date: z.string().min(1, "Date dalein"),
        reason: z.string().optional(),
      })
    ),
    defaultValues: { labourerId: "", amount: 0, date: new Date().toISOString().slice(0, 10), reason: "" },
  });

  const onSubmit = async (values: { labourerId: string; amount: number; date: string; reason?: string }) => {
    try {
      await addAdvance({
        workerCode,
        labourerId: values.labourerId as Id<"labourers">,
        amount: values.amount,
        date: values.date,
        reason: values.reason,
      });
      toast.success("Advance record ho gaya!");
      setDialog(false);
      form.reset();
    } catch {
      toast.error("Advance save nahi hua");
    }
  };

  // Group advances by labourer
  const advancedLabs = data.labourers.map((l) => ({
    ...l,
    totalAdvance: data.advanceMap[l._id] ?? 0,
  })).filter((l) => l.totalAdvance > 0);

  return (
    <div className="space-y-4">
      <Button className="w-full" onClick={() => setDialog(true)}>
        <Plus className="w-4 h-4 mr-2" /> New Advance Entry
      </Button>

      {advancedLabs.length === 0 ? (
        <p className="text-center text-gray-500 py-8">Is mahine koi advance nahi diya</p>
      ) : (
        <div className="space-y-2">
          {advancedLabs.map((lab) => (
            <Card key={lab._id} className="py-0 bg-white">
              <CardContent className="p-3 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm text-gray-900">{lab.name}</p>
                  <p className="text-xs text-gray-500">{lab.designation ?? "Labour"}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-orange-600">₹{lab.totalAdvance.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">Total Advance</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Also show detailed list */}
      {data.advances.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-2">Is Mahine Sab Entries</h3>
          <div className="space-y-1.5">
            {data.advances.map((adv) => {
              const lab = data.labourers.find((l) => l._id === adv.labourerId);
              return (
                <div key={adv._id} className="flex justify-between text-sm bg-gray-100 rounded p-2">
                  <div>
                    <span className="font-medium text-gray-900">{lab?.name ?? "Unknown"}</span>
                    {adv.reason && <span className="text-gray-500 ml-2 text-xs">• {adv.reason}</span>}
                  </div>
                  <span className="text-orange-600 font-medium">₹{adv.amount}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Advance Entry</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="labourerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labour</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Labour chunein" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {data.labourers.map((l) => (
                          <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₹)</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (optional)</FormLabel>
                    <FormControl><Input placeholder="e.g. Medical, Personal" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Reports Tab ───────────────────────────────────────────────────────────
function ReportsTab({ workerCode, data }: { workerCode: string; data: PortalData }) {
  const submitReport = useMutation(api.supervisorPortal.submitReport);
  const genUrl = useMutation(api.supervisorPortal.generateUploadUrl);
  const [dialog, setDialog] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const form = useForm({
    resolver: zodResolver(
      z.object({
        title: z.string().min(1, "Title dalein"),
        description: z.string().optional(),
        reportDate: z.string().min(1),
      })
    ),
    defaultValues: { title: "", description: "", reportDate: new Date().toISOString().slice(0, 10) },
  });

  const uploadPhotos = async (files: FileList) => {
    setUploading(true);
    const ids: string[] = [];
    try {
      for (const file of Array.from(files)) {
        const uploadUrl = await genUrl({});
        const res = await fetch(uploadUrl, { method: "POST", body: file, headers: { "Content-Type": file.type } });
        const { storageId } = await res.json() as { storageId: string };
        ids.push(storageId);
      }
      setPhotos((p) => [...p, ...ids]);
      toast.success(`${ids.length} photo upload ho gaya`);
    } catch {
      toast.error("Photo upload nahi hua");
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (values: { title: string; description?: string; reportDate: string }) => {
    try {
      await submitReport({ workerCode, ...values, photoStorageIds: photos });
      toast.success("Report submit ho gaya!");
      setDialog(false);
      setPhotos([]);
      form.reset();
    } catch {
      toast.error("Report submit nahi hua");
    }
  };

  return (
    <div className="space-y-4">
      <Button className="w-full" onClick={() => setDialog(true)}>
        <Plus className="w-4 h-4 mr-2" /> New Report
      </Button>

      {data.reports.length === 0 ? (
        <p className="text-center text-gray-500 py-8">Koi report nahi mili</p>
      ) : (
        <div className="space-y-3">
          {data.reports.map((report) => (
            <Card key={report._id} className="py-0 bg-white">
              <CardContent className="p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-gray-900">{report.title}</p>
                    <p className="text-xs text-gray-500">{report.reportDate}</p>
                    {report.description && <p className="text-xs mt-1 text-gray-700">{report.description}</p>}
                  </div>
                  <Badge variant={report.status === "reviewed" ? "default" : "outline"} className="text-xs shrink-0">
                    {report.status === "reviewed" ? "Reviewed" : "Submitted"}
                  </Badge>
                </div>
                {report.photoUrls.length > 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {report.photoUrls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noreferrer">
                        <img src={url} alt="report photo" className="w-16 h-16 object-cover rounded border" />
                      </a>
                    ))}
                  </div>
                )}
                {report.adminNote && (
                  <p className="text-xs bg-blue-50 text-blue-700 rounded p-2">
                    Admin note: {report.adminNote}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Daily Report</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl><Input placeholder="e.g. 20 June ka report" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="reportDate" render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (optional)</FormLabel>
                  <FormControl><Textarea placeholder="Kya kaam hua, kya problem hai..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="space-y-1">
                <label className="text-sm font-medium">Photos (optional)</label>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && uploadPhotos(e.target.files)}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  {uploading ? "Uploading..." : `Photo Add Karo (${photos.length} added)`}
                </Button>
              </div>
              <DialogFooter>
                <Button type="submit">Submit Report</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Material Request Tab ──────────────────────────────────────────────────
function MaterialRequestTab({ workerCode, data }: { workerCode: string; data: PortalData }) {
  const submitRequest = useMutation(api.supervisorPortal.submitMaterialRequest);
  const genUrl = useMutation(api.supervisorPortal.generateUploadUrl);
  const [dialog, setDialog] = useState(false);
  const [photoId, setPhotoId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const form = useForm({
    resolver: zodResolver(
      z.object({
        itemName: z.string().min(1),
        quantity: z.coerce.number().positive(),
        unit: z.string().min(1),
        urgency: z.enum(["low", "medium", "high"]),
        notes: z.string().optional(),
      })
    ),
    defaultValues: { itemName: "", quantity: 1, unit: "nos", urgency: "medium" as const, notes: "" },
  });

  const uploadPhoto = async (file: File) => {
    setUploading(true);
    try {
      const url = await genUrl({});
      const res = await fetch(url, { method: "POST", body: file, headers: { "Content-Type": file.type } });
      const { storageId } = await res.json() as { storageId: string };
      setPhotoId(storageId);
      toast.success("Photo upload ho gaya");
    } catch {
      toast.error("Photo upload nahi hua");
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (values: { itemName: string; quantity: number; unit: string; urgency: "low" | "medium" | "high"; notes?: string }) => {
    try {
      await submitRequest({ workerCode, ...values, photoStorageId: photoId ?? undefined });
      toast.success("Material request bhej diya!");
      setDialog(false);
      setPhotoId(null);
      form.reset();
    } catch {
      toast.error("Request nahi gaya");
    }
  };

  const urgencyColor = (u: string) =>
    u === "high" ? "text-red-600" : u === "medium" ? "text-orange-500" : "text-green-600";

  const statusIcon = (s: string) => {
    if (s === "po_issued") return <CheckCircle className="w-4 h-4 text-green-500" />;
    if (s === "delivered") return <Truck className="w-4 h-4 text-blue-500" />;
    if (s === "rejected") return <XCircle className="w-4 h-4 text-red-500" />;
    return <Clock className="w-4 h-4 text-yellow-500" />;
  };

  return (
    <div className="space-y-4">
      <Button className="w-full" onClick={() => setDialog(true)}>
        <Plus className="w-4 h-4 mr-2" /> Material Request Karo
      </Button>

      {data.materialRequests.length === 0 ? (
        <p className="text-center text-gray-500 py-8">Koi request nahi hai</p>
      ) : (
        <div className="space-y-3">
          {data.materialRequests.map((req) => (
            <Card key={req._id} className="py-0 bg-white">
              <CardContent className="p-3 space-y-1">
                <div className="flex items-center gap-2">
                  {statusIcon(req.status)}
                  <p className="font-semibold text-sm flex-1 text-gray-900">{req.itemName}</p>
                  <span className={`text-xs font-medium ${urgencyColor(req.urgency)}`}>
                    {req.urgency.toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-gray-600">
                  {req.quantity} {req.unit}
                </p>
                {req.status === "po_issued" && req.supplierName && (
                  <div className="bg-green-50 border border-green-100 rounded p-2 text-xs space-y-0.5 text-gray-800">
                    <p className="text-green-700 font-medium">PO Issue Ho Gaya</p>
                    {req.supplierName && <p>Supplier: <span className="font-medium">{req.supplierName}</span></p>}
                    {req.supplierMobile && <p>Mobile: {req.supplierMobile}</p>}
                    {"poNumber" in req && req.poNumber && <p>PO No: <span className="font-mono font-medium">{String(req.poNumber)}</span></p>}
                    {"poExpectedDelivery" in req && req.poExpectedDelivery && <p>Expected Delivery: <span className="font-medium">{String(req.poExpectedDelivery)}</span></p>}
                  </div>
                )}
                {req.adminNote && (
                  <p className="text-xs text-gray-600">Note: {req.adminNote}</p>
                )}
                {"photoUrl" in req && req.photoUrl && (
                  <div className="mt-2">
                    <p className="text-xs text-gray-500 mb-1 font-medium">Photo:</p>
                    <img
                      src={String(req.photoUrl)}
                      alt="Material request photo"
                      className="rounded-lg max-w-full max-h-48 object-contain border border-gray-200 cursor-pointer"
                      onClick={() => window.open(String(req.photoUrl), "_blank")}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Material Request</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="itemName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Material Name</FormLabel>
                  <FormControl><Input placeholder="e.g. Cement 43 Grade, Steel Rod 12mm" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="quantity" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl><Input type="number" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="unit" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {["bags", "nos", "kg", "tons", "meter", "sqft", "litre", "other"].map((u) => (
                          <SelectItem key={u} value={u}>{u}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="urgency" render={({ field }) => (
                <FormItem>
                  <FormLabel>Urgency</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="low">Low - Jaldi nahi hai</SelectItem>
                      <SelectItem value="medium">Medium - 2-3 din mein chahiye</SelectItem>
                      <SelectItem value="high">High - Aaj zaruri hai!</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (optional)</FormLabel>
                  <FormControl><Textarea placeholder="Brand, specification, delivery location..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="space-y-1">
                <label className="text-sm font-medium">Photo (optional)</label>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && uploadPhoto(e.target.files[0])}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  {uploading ? "Uploading..." : photoId ? "Photo Added ✓" : "Photo Add Karo"}
                </Button>
              </div>
              <DialogFooter>
                <Button type="submit">Request Bhejo</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Labour Add Tab ────────────────────────────────────────────────────────
function LabourAddTab({ workerCode, data }: { workerCode: string; data: PortalData }) {
  const addLabourerMut = useMutation(api.supervisorPortal.addLabourer);
  const [showForm, setShowForm] = useState(false);

  const addSchema = z.object({
    name: z.string().min(1, "Naam zaroori hai"),
    mobile: z.string().optional(),
    designation: z.string().optional(),
    dailyRate: z.coerce.number().min(1, "Daily rate zaroori hai"),
    labourType: z.enum(["contractor", "departmental"]).optional(),
    joinDate: z.string().optional(),
  });
  type AddForm = z.infer<typeof addSchema>;

  const form = useForm<AddForm>({
    resolver: zodResolver(addSchema),
    defaultValues: { name: "", dailyRate: 0, joinDate: new Date().toISOString().slice(0, 10) },
  });

  async function onAdd(d: AddForm) {
    try {
      await addLabourerMut({
        workerCode,
        name: d.name,
        mobile: d.mobile || undefined,
        designation: d.designation || undefined,
        dailyRate: d.dailyRate,
        labourType: d.labourType,
        joinDate: d.joinDate || undefined,
      });
      toast.success(`${d.name} add ho gaya!`);
      setShowForm(false);
      form.reset({ name: "", dailyRate: 0, joinDate: new Date().toISOString().slice(0, 10) });
    } catch { toast.error("Labour add nahi hua"); }
  }

  return (
    <div className="space-y-4">
      {/* Current labourers count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600 font-medium">{data.labourers.length} labourers is site pe</p>
        <Button size="sm" className="cursor-pointer" onClick={() => setShowForm(true)}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Naya Labour Add Karo
        </Button>
      </div>

      {/* Labour list */}
      <div className="space-y-2">
        {data.labourers.length === 0 ? (
          <p className="text-sm text-center text-gray-500 py-6">Koi labour nahi hai is site pe</p>
        ) : (
          data.labourers.map((lab) => (
            <Card key={lab._id} className="py-0 bg-white">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm text-gray-900">{lab.name}</p>
                    <p className="text-xs text-gray-500">{lab.designation ?? "Labour"} · {(lab as { rateApprovalStatus?: string }).rateApprovalStatus === "pending" ? <span className="text-amber-600 font-semibold">Rate Pending (Admin approve karega)</span> : `₹${lab.dailyRate}/day`}</p>
                  </div>
                  {lab.mobile && (
                    <a href={`tel:${lab.mobile}`} className="text-xs text-primary">{lab.mobile}</a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Add Labour Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Plus className="w-4 h-4 text-orange-500" />Naya Labour Add Karo</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onAdd)} className="space-y-3">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Naam *</FormLabel>
                  <FormControl><Input placeholder="Ramesh Kumar" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-2">
                <FormField control={form.control} name="dailyRate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Daily Rate ₹ *</FormLabel>
                    <FormControl><Input type="number" placeholder="500" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="designation" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kaam</FormLabel>
                    <FormControl><Input placeholder="Mistri / Helper" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="mobile" render={({ field }) => (
                <FormItem>
                  <FormLabel>Mobile (optional)</FormLabel>
                  <FormControl><Input placeholder="9876543210" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="labourType" render={({ field }) => (
                <FormItem>
                  <FormLabel>Labour Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value ?? ""}>
                    <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Type select karo" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="contractor">Contractor Labour</SelectItem>
                      <SelectItem value="departmental">Departmental Labour</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <FormField control={form.control} name="joinDate" render={({ field }) => (
                <FormItem>
                  <FormLabel>Joining Date</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Add Karo</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Labour List Tab ───────────────────────────────────────────────────────
function LabourListTab({ data }: { data: PortalData }) {
  const thisMonth = new Date().toISOString().slice(0, 7);

  return (
    <div className="space-y-3">
      <p className="text-sm text-gray-600">{data.labourers.length} active labourers</p>
      {data.labourers.map((lab) => {
        const advance = data.advanceMap[lab._id] ?? 0;
        // Salary entry if any
        const salEntry = data.salaryEntries.find((e) => e.labourerId === lab._id);
        return (
          <Card key={lab._id} className="py-0 bg-white">
            <CardContent className="p-3 space-y-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-sm text-gray-900">{lab.name}</p>
                  <p className="text-xs text-gray-500">{lab.designation ?? "Labour"}</p>
                </div>
                <div className="text-right text-xs">
                  <p className="font-medium">₹{lab.dailyRate}/day</p>
                </div>
              </div>
              {(advance > 0 || salEntry) && (
                <div className="flex gap-3 text-xs mt-1">
                  {advance > 0 && <span className="text-orange-600">Advance: ₹{advance}</span>}
                  {salEntry && <span className="text-green-600">Nasta: {salEntry.nastaDays ?? 0} din</span>}
                  {salEntry && <span className="text-blue-600">PT: ₹{salEntry.deductions ?? 0}</span>}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

// ─── Main Portal Component ─────────────────────────────────────────────────
// ─── Registration Review Tab ──────────────────────────────────────────────
function RegistrationReviewTab({ workerCode }: { workerCode: string }) {
  const pendingRegs = useQuery(api.labourRegistration.getPendingForSite, { workerCode });
  const approve = useMutation(api.labourRegistration.supervisorApprove);
  const reject = useMutation(api.labourRegistration.supervisorReject);
  const [reviewingId, setReviewingId] = useState<Id<"labourRegistrations"> | null>(null);
  const [actionNote, setActionNote] = useState("");
  const [acting, setActing] = useState(false);

  if (!pendingRegs) return <Skeleton className="h-32 w-full" />;

  if (pendingRegs.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <UserPlus className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">Koi naya registration pending nahi hai</p>
      </div>
    );
  }

  const handleApprove = async (id: Id<"labourRegistrations">) => {
    setActing(true);
    try {
      await approve({ workerCode, registrationId: id, note: actionNote || undefined });
      toast.success("Admin ke paas bhej diya!");
      setReviewingId(null);
      setActionNote("");
    } catch { toast.error("Error hua, dobara try karo"); }
    setActing(false);
  };

  const handleReject = async (id: Id<"labourRegistrations">) => {
    setActing(true);
    try {
      await reject({ workerCode, registrationId: id, note: actionNote || undefined });
      toast.success("Reject kar diya!");
      setReviewingId(null);
      setActionNote("");
    } catch { toast.error("Error hua, dobara try karo"); }
    setActing(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm font-medium text-muted-foreground">
          {pendingRegs.length} Naye Registration Pending
        </p>
      </div>
      {pendingRegs.map((reg) => (
        <Card key={reg._id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {reg.photoUrl ? (
                <img src={reg.photoUrl} alt={reg.name} className="w-14 h-14 rounded-lg object-cover border" />
              ) : (
                <div className="w-14 h-14 rounded-lg bg-muted flex items-center justify-center border">
                  <UserPlus className="w-6 h-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-sm truncate">{reg.name}</h4>
                <p className="text-xs text-muted-foreground">{reg.designation}</p>
                <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-xs text-muted-foreground">
                  <span>📱 {reg.mobile}</span>
                  {reg.age && <span>🎂 {reg.age} yr</span>}
                  {reg.experience && <span>📅 {reg.experience}</span>}
                </div>
                {reg.dailyRateExpected && (
                  <p className="text-xs mt-0.5 text-muted-foreground">💰 ₹{reg.dailyRateExpected}/day expected</p>
                )}
              </div>
            </div>

            {/* Expand details */}
            <details className="mt-3">
              <summary className="text-xs font-medium text-primary cursor-pointer select-none">
                Poori details dekho
              </summary>
              <div className="mt-2 space-y-1 text-xs text-muted-foreground bg-muted/50 rounded-lg p-3">
                {reg.fatherName && <p><strong>Pita:</strong> {reg.fatherName}</p>}
                {reg.aadhaarNumber && <p><strong>Aadhaar:</strong> {reg.aadhaarNumber}</p>}
                {reg.address && <p><strong>Pata:</strong> {reg.address}</p>}
                {reg.previousWork && <p><strong>Pehle kaha:</strong> {reg.previousWork}</p>}
                <p><strong>Company:</strong> {reg.companyName}</p>
                <p><strong>Site:</strong> {reg.siteName}</p>
                {reg.aadhaarUrl && (
                  <a href={reg.aadhaarUrl} target="_blank" rel="noopener noreferrer" className="inline-block mt-1 text-primary underline">
                    Aadhaar Photo dekho
                  </a>
                )}
              </div>
            </details>

            {/* Action buttons */}
            {reviewingId === reg._id ? (
              <div className="mt-3 space-y-2">
                <Input
                  placeholder="Note likho (optional)..."
                  value={actionNote}
                  onChange={(e) => setActionNote(e.target.value)}
                  className="text-sm h-9"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="cursor-pointer flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => handleApprove(reg._id)}
                    disabled={acting}
                  >
                    <CheckCircle className="w-3.5 h-3.5 mr-1" />
                    Admin ko bhejo
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="cursor-pointer flex-1"
                    onClick={() => handleReject(reg._id)}
                    disabled={acting}
                  >
                    <XCircle className="w-3.5 h-3.5 mr-1" />
                    Reject
                  </Button>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="cursor-pointer w-full text-xs"
                  onClick={() => { setReviewingId(null); setActionNote(""); }}
                >
                  Cancel
                </Button>
              </div>
            ) : (
              <div className="mt-3 flex gap-2">
                <Button
                  size="sm"
                  className="cursor-pointer flex-1"
                  onClick={() => setReviewingId(reg._id)}
                >
                  Review Karo
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Portal Inner (main dashboard after login) ───────────────────────────
function PortalInner({ workerCode }: { workerCode: string }) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const data = useQuery(api.supervisorPortal.getPortalData, {
    workerCode,
    date: selectedDate,
  });

  if (data === undefined) {
    return (
      <div className="p-4 space-y-3">
        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-2">
          <AlertTriangle className="w-12 h-12 text-destructive mx-auto" />
          <p className="font-semibold">Worker ID sahi nahi hai</p>
          <p className="text-sm text-muted-foreground">Supervisor ke paas hi portal access hai</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900" style={{ colorScheme: "light", color: "#111827", backgroundColor: "#f9fafb" }}>
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-4 py-4 sticky top-0 z-10">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-bold text-lg">{data.site.name}</h1>
              <p className="text-primary-foreground/80 text-sm">{data.supervisor.name} • {data.supervisor.workerCode}</p>
            </div>
            <div className="flex gap-1 items-center">
              {data.supervisor.isSiteSupervisor && (
                <Badge className="bg-white/20 text-white border-white/30 text-xs">Site Sup.</Badge>
              )}
              {data.supervisor.isSafetySupervisor && (
                <Badge className="bg-white/20 text-white border-white/30 text-xs">Safety Sup.</Badge>
              )}
              <a href="/" className="flex items-center gap-1 bg-white/20 hover:bg-white/30 transition-colors text-primary-foreground text-xs font-medium px-2.5 py-1 rounded-lg cursor-pointer ml-1">
                <Home className="w-3.5 h-3.5" /> Home
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4">
        <Tabs defaultValue="attendance">
          <TabsList className="w-full grid grid-cols-6 mb-4">
            <TabsTrigger value="attendance" className="text-xs px-1">
              <CalendarCheck className="w-3.5 h-3.5 mr-1" />Hajri
            </TabsTrigger>
            <TabsTrigger value="advance" className="text-xs px-1">
              <IndianRupee className="w-3.5 h-3.5 mr-1" />Advance
            </TabsTrigger>
            <TabsTrigger value="labour" className="text-xs px-1">
              <Plus className="w-3.5 h-3.5 mr-0.5" />Labour
            </TabsTrigger>
            <TabsTrigger value="newreg" className="text-xs px-1">
              <UserPlus className="w-3.5 h-3.5 mr-0.5" />Naye
            </TabsTrigger>
            <TabsTrigger value="reports" className="text-xs px-1">
              <FileText className="w-3.5 h-3.5 mr-1" />Report
            </TabsTrigger>
            <TabsTrigger value="material" className="text-xs px-1">
              <Package className="w-3.5 h-3.5 mr-1" />Material
            </TabsTrigger>
          </TabsList>

          <TabsContent value="attendance">
            <AttendanceTab workerCode={workerCode} data={data} selectedDate={selectedDate} onDateChange={setSelectedDate} />
          </TabsContent>
          <TabsContent value="advance">
            <AdvanceTab workerCode={workerCode} data={data} />
          </TabsContent>
          <TabsContent value="labour">
            <LabourAddTab workerCode={workerCode} data={data} />
          </TabsContent>
          <TabsContent value="newreg">
            <RegistrationReviewTab workerCode={workerCode} />
          </TabsContent>
          <TabsContent value="reports">
            <ReportsTab workerCode={workerCode} data={data} />
          </TabsContent>
          <TabsContent value="material">
            <MaterialRequestTab workerCode={workerCode} data={data} />
          </TabsContent>
        </Tabs>

        {/* Labour list collapsible */}
        <details className="mt-4">
          <summary className="cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-900 select-none py-2">
            <Users className="inline w-4 h-4 mr-1" />
            All Labour List ({data.labourers.length})
          </summary>
          <div className="mt-2">
            <LabourListTab data={data} />
          </div>
        </details>
      </div>
    </div>
  );
}

// ─── Login Screen ──────────────────────────────────────────────────────────
export default function SupervisorPortal() {
  const [inputCode, setInputCode] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [workerCode, setWorkerCode] = useState("");
  const [checking, setChecking] = useState(false);

  const loginData = useQuery(
    api.supervisorPortal.login,
    checking || loggedIn ? { workerCode: inputCode } : "skip"
  );

  const handleLogin = () => {
    if (!inputCode.trim()) return;
    setChecking(true);
  };

  // React to login result
  if (checking && loginData !== undefined) {
    if (loginData.success) {
      if (!loggedIn) {
        setWorkerCode(inputCode.trim().toUpperCase());
        setLoggedIn(true);
      }
    } else {
      setChecking(false);
    }
  }

  if (loggedIn && workerCode) {
    return <PortalInner workerCode={workerCode} />;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center pb-2">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
            <Users className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-xl">Supervisor Portal</CardTitle>
          <p className="text-sm text-muted-foreground">Apna Worker ID enter karo</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Worker ID (e.g. S1234)"
              value={inputCode}
              onChange={(e) => { setInputCode(e.target.value.toUpperCase()); setChecking(false); }}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              className="text-center text-lg font-mono tracking-widest"
              maxLength={10}
            />
            {checking && loginData && !loginData.success && (
              <p className="text-red-500 text-sm text-center">Worker ID sahi nahi hai ya supervisor nahi hain</p>
            )}
          </div>
          <Button className="w-full" onClick={handleLogin} disabled={!inputCode.trim() || (checking && loginData === undefined)}>
            {checking && loginData === undefined ? "Checking..." : "Login Karo"}
          </Button>
          <p className="text-xs text-center text-muted-foreground">
            Supervisor ko admin se Worker ID milega
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
