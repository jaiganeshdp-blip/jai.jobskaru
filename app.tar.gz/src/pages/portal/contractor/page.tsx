import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  ClipboardList, IndianRupee, User, Receipt, FileText,
  AlertCircle, ChevronRight, Building2,
  TrendingUp, Wallet, Plus, X
} from "lucide-react";
import { format } from "date-fns";
import { PortalRABillForm } from "../_components/portal-ra-bill-form.tsx";
import { PortalBillAttachments } from "../_components/portal-bill-attachments.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

export default function ContractorPortal() {
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [showBillForm, setShowBillForm] = useState(false);

  const data = useQuery(api.portal.contractor.getByToken, token ? { token } : "skip");
  const workOrders = useQuery(api.portal.contractor.getWorkOrdersByToken, token ? { token } : "skip");
  const payments = useQuery(api.portal.contractor.getPaymentsByToken, token ? { token } : "skip");
  const bills = useQuery(api.portal.contractor.getBillsByToken, token ? { token } : "skip") ?? [];
  const pos = useQuery(api.portal.contractor.getPOsByToken, token ? { token } : "skip") ?? [];

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center p-8">
          <User className="mx-auto mb-4 text-slate-500" size={48} />
          <h2 className="text-xl font-bold text-white mb-2">Invalid Link</h2>
          <p className="text-slate-400">Apna portal link use karein.</p>
        </div>
      </div>
    );
  }

  if (data === undefined) {
    return (
      <div className="min-h-screen bg-slate-900 p-4 space-y-4 max-w-2xl mx-auto">
        <Skeleton className="h-40 w-full rounded-2xl bg-slate-800" />
        <div className="grid grid-cols-2 gap-3">
          <Skeleton className="h-28 w-full rounded-xl bg-slate-800" />
          <Skeleton className="h-28 w-full rounded-xl bg-slate-800" />
          <Skeleton className="h-28 w-full rounded-xl bg-slate-800" />
          <Skeleton className="h-28 w-full rounded-xl bg-slate-800" />
        </div>
        <Skeleton className="h-64 w-full rounded-xl bg-slate-800" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center p-8">
          <AlertCircle className="mx-auto mb-4 text-red-400" size={48} />
          <p className="text-red-400 font-semibold text-lg">Contractor nahi mila.</p>
          <p className="text-slate-400 text-sm mt-1">Link sahi hai ya nahi check karein.</p>
        </div>
      </div>
    );
  }

  const { contractor } = data;
  const totalPaid = payments?.reduce((sum, p) => sum + p.amount, 0) ?? 0;
  const totalBilled = bills.reduce((sum, b) => sum + b.totalAmount, 0);
  const totalOutstanding = bills.reduce((sum, b) => sum + (b.totalAmount - b.paidAmount), 0);
  const totalPOValue = pos.reduce((sum, po) => sum + po.totalValue, 0);

  const fmtAmt = (n: number) =>
    n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : `₹${n.toLocaleString("en-IN")}`;

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-700 to-emerald-900">
        <div className="max-w-2xl mx-auto px-4 pt-6 pb-16">
          <p className="text-emerald-200 text-xs font-bold uppercase tracking-widest mb-2">JAI SITE MANAGER ERP — CONTRACTOR PORTAL</p>
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-2xl font-bold text-white">
              {contractor.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{contractor.name}</h1>
              <p className="text-emerald-100 text-sm">{contractor.specialization ?? "Contractor"} · {contractor.mobile}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 -mt-10 pb-24 space-y-5">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-800 border border-emerald-700/50 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-emerald-900"><Building2 size={14} className="text-emerald-400" /></div>
              <p className="text-xs text-slate-400 font-semibold">PO Value</p>
            </div>
            <p className="text-2xl font-bold text-emerald-300">{fmtAmt(totalPOValue)}</p>
            <p className="text-xs text-slate-500 mt-0.5">{pos.length} POs</p>
          </div>
          <div className="bg-slate-800 border border-blue-700/50 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-blue-900"><TrendingUp size={14} className="text-blue-400" /></div>
              <p className="text-xs text-slate-400 font-semibold">Total Billed</p>
            </div>
            <p className="text-2xl font-bold text-blue-300">{fmtAmt(totalBilled)}</p>
            <p className="text-xs text-slate-500 mt-0.5">{bills.length} Bills</p>
          </div>
          <div className="bg-slate-800 border border-green-700/50 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-green-900"><Wallet size={14} className="text-green-400" /></div>
              <p className="text-xs text-slate-400 font-semibold">Paisa Mila</p>
            </div>
            <p className="text-2xl font-bold text-green-300">{fmtAmt(totalPaid)}</p>
            <p className="text-xs text-slate-500 mt-0.5">{payments?.length ?? 0} payments</p>
          </div>
          <div className={`rounded-2xl p-4 border ${totalOutstanding > 0 ? "bg-orange-900/40 border-orange-700/50" : "bg-slate-800 border-slate-700"}`}>
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1.5 rounded-lg ${totalOutstanding > 0 ? "bg-orange-900" : "bg-slate-700"}`}>
                <IndianRupee size={14} className={totalOutstanding > 0 ? "text-orange-400" : "text-slate-500"} />
              </div>
              <p className="text-xs text-slate-400 font-semibold">Baki Hai</p>
            </div>
            <p className={`text-2xl font-bold ${totalOutstanding > 0 ? "text-orange-300" : "text-slate-500"}`}>{fmtAmt(totalOutstanding)}</p>
            <p className="text-xs text-slate-500 mt-0.5">Outstanding</p>
          </div>
        </div>

        {/* Bill CTA */}
        {!showBillForm && pos.length > 0 && (
          <button
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl p-5 flex items-center justify-between transition-colors cursor-pointer"
            onClick={() => setShowBillForm(true)}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                <Plus size={22} />
              </div>
              <div className="text-left">
                <p className="font-bold text-lg">Naya Bill Submit Karein</p>
                <p className="text-emerald-100 text-sm">RA Bill ya Final Bill banayein</p>
              </div>
            </div>
            <ChevronRight size={22} className="text-emerald-100" />
          </button>
        )}

        {/* Bill Form */}
        {showBillForm && (
          <div className="bg-slate-800 border border-emerald-700/50 rounded-2xl overflow-hidden">
            <div className="bg-emerald-700 px-4 py-3 flex items-center justify-between">
              <span className="text-white font-bold flex items-center gap-2">
                <Receipt size={16} /> Naya Bill Submit Karein
              </span>
              <button onClick={() => setShowBillForm(false)} className="text-white/70 hover:text-white cursor-pointer">
                <X size={18} />
              </button>
            </div>
            <div className="p-4">
              <PortalRABillForm token={token} vendorType="contractor" onSuccess={() => setShowBillForm(false)} />
            </div>
          </div>
        )}

        {/* Purchase Orders */}
        {pos.length > 0 && (
          <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
            <div className="bg-slate-700 px-4 py-3 flex items-center gap-2">
              <FileText size={16} className="text-blue-400" />
              <span className="text-white font-bold">Purchase Orders</span>
              <span className="ml-auto bg-slate-600 text-slate-200 text-xs font-bold px-2 py-0.5 rounded-full">{pos.length}</span>
            </div>
            <div className="p-4 space-y-3">
              {pos.map((po) => {
                const poBills = bills.filter((b) => b.purchaseOrderId === po._id);
                const poBilled = poBills.reduce((s, b) => s + b.totalAmount, 0);
                const poOutstanding = poBilled - poBills.reduce((s, b) => s + b.paidAmount, 0);
                const progress = po.totalValue > 0 ? Math.min((poBilled / po.totalValue) * 100, 100) : 0;
                const poWithCompany = po as typeof po & { companyName?: string };
                return (
                  <div key={po._id} className="bg-slate-700 border border-slate-600 rounded-xl p-4 space-y-3">
                    {poWithCompany.companyName && (
                      <div className="flex items-center gap-1.5">
                        <Building2 size={12} className="text-yellow-400" />
                        <span className="text-yellow-300 text-xs font-bold uppercase">{poWithCompany.companyName}</span>
                      </div>
                    )}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-bold text-white text-base">{po.poNumber}</p>
                        <p className="text-sm text-slate-300 font-semibold">{po.siteName}</p>
                        <p className="text-xs text-slate-500">{po.issueDate}</p>
                      </div>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-600 text-slate-200">{po.status}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-slate-400">PO Value</p>
                      <p className="text-xl font-bold text-emerald-300">₹{po.totalValue.toLocaleString("en-IN")}</p>
                    </div>
                    {poBilled > 0 && (
                      <>
                        <div>
                          <div className="flex justify-between text-xs text-slate-400 mb-1">
                            <span>Billed: ₹{poBilled.toLocaleString("en-IN")}</span>
                            <span>{progress.toFixed(0)}%</span>
                          </div>
                          <div className="w-full h-2.5 bg-slate-600 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${progress >= 100 ? "bg-orange-500" : "bg-emerald-500"}`} style={{ width: `${progress}%` }} />
                          </div>
                        </div>
                        {poOutstanding > 0 && (
                          <div className="flex justify-between text-sm bg-orange-900/40 border border-orange-700/50 rounded-lg px-3 py-2">
                            <span className="text-orange-300 font-bold">Outstanding</span>
                            <span className="text-orange-300 font-bold">₹{poOutstanding.toLocaleString("en-IN")}</span>
                          </div>
                        )}
                      </>
                    )}
                    {poBills.length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-1">Koi bill submit nahi hua abhi tak</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Work Orders */}
        {(workOrders?.length ?? 0) > 0 && (
          <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
            <div className="bg-slate-700 px-4 py-3 flex items-center gap-2">
              <ClipboardList size={16} className="text-purple-400" />
              <span className="text-white font-bold">Work Orders</span>
              <span className="ml-auto bg-slate-600 text-slate-200 text-xs font-bold px-2 py-0.5 rounded-full">{workOrders?.length ?? 0}</span>
            </div>
            <div className="p-4 space-y-3">
              {workOrders?.map((wo) => (
                <div key={wo._id} className="bg-slate-700 border border-slate-600 rounded-xl p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-bold text-white">{wo.orderNumber}</p>
                      <p className="text-sm text-slate-300 font-semibold">{wo.siteName}</p>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-600 text-slate-200">
                      {wo.status.charAt(0).toUpperCase() + wo.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-sm text-slate-300">{wo.description}</p>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-slate-400">Work Order Value</p>
                    <p className="text-xl font-bold text-purple-300">₹{wo.totalValue.toLocaleString("en-IN")}</p>
                  </div>
                  {wo.amendments.length > 0 && (
                    <div className="border-t border-slate-600 pt-2 space-y-1">
                      <p className="text-xs font-bold text-slate-400">Amendment History</p>
                      {wo.amendments.map((am) => (
                        <div key={am._id} className="text-xs flex justify-between py-0.5">
                          <span className="text-slate-400">Amend #{am.amendmentNumber} · {format(new Date(am.date + "T00:00:00"), "dd MMM yy")}</span>
                          <span className="font-bold text-slate-300">₹{am.previousValue.toLocaleString("en-IN")} → ₹{am.newValue.toLocaleString("en-IN")}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-slate-500">Issued: {format(new Date(wo.issueDate + "T00:00:00"), "dd MMM yyyy")}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bills */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="bg-slate-700 px-4 py-3 flex items-center gap-2">
            <Receipt size={16} className="text-orange-400" />
            <span className="text-white font-bold">Meri Bills</span>
            <span className="ml-auto bg-slate-600 text-slate-200 text-xs font-bold px-2 py-0.5 rounded-full">{bills.length}</span>
          </div>
          <div className="p-4">
            {bills.length === 0 && (
              <div className="text-center py-8">
                <Receipt size={36} className="mx-auto text-slate-600 mb-2" />
                <p className="text-slate-400 text-sm">Koi bill nahi abhi tak</p>
                {pos.length > 0 && (
                  <button
                    className="mt-3 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    onClick={() => setShowBillForm(true)}
                  >
                    <Plus size={14} /> Pehla Bill Submit Karein
                  </button>
                )}
              </div>
            )}
            <div className="space-y-3">
              {bills.map((b) => {
                const outstanding = b.totalAmount - b.paidAmount;
                const statusColor =
                  b.status === "paid" ? "bg-green-800 text-green-200" :
                  b.status === "approved" ? "bg-blue-800 text-blue-200" :
                  b.status === "verified" ? "bg-yellow-800 text-yellow-200" :
                  "bg-slate-700 text-slate-300";
                return (
                  <div key={b._id} className="bg-slate-700 border border-slate-600 rounded-xl p-4">
                    {/* Company name */}
                    {(b as typeof b & { companyName?: string }).companyName && (b as typeof b & { companyName?: string }).companyName !== "—" && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <Building2 size={12} className="text-yellow-400 shrink-0" />
                        <span className="text-yellow-300 text-xs font-bold uppercase tracking-wide">{(b as typeof b & { companyName?: string }).companyName}</span>
                      </div>
                    )}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="font-bold text-white">{b.billNumber}</span>
                          {b.billType === "ra" && <span className="text-xs px-2 py-0.5 rounded-full bg-blue-800 text-blue-200 font-bold">RA-{b.raNumber}</span>}
                          {b.billType === "final" && <span className="text-xs px-2 py-0.5 rounded-full bg-purple-800 text-purple-200 font-bold">Final</span>}
                          <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${statusColor}`}>{b.status.toUpperCase()}</span>
                        </div>
                        <p className="text-sm text-slate-300">{b.siteName}</p>
                        <p className="text-xs text-slate-500">{b.billDate}{b.poNumber ? ` · PO: ${b.poNumber}` : ""}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-lg font-bold text-white">₹{b.totalAmount.toLocaleString("en-IN")}</p>
                        {outstanding > 0 ? (
                          <p className="text-xs text-orange-400 font-bold">₹{outstanding.toLocaleString("en-IN")} baki</p>
                        ) : b.paidAmount > 0 ? (
                          <p className="text-xs text-green-400 font-bold">Paid ✓</p>
                        ) : null}
                      </div>
                    </div>
                    {/* Attachment upload section */}
                    <PortalBillAttachments token={token} billId={b._id as Id<"vendorBills">} vendorType="contractor" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Payments */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="bg-slate-700 px-4 py-3 flex items-center gap-2">
            <IndianRupee size={16} className="text-green-400" />
            <span className="text-white font-bold">Payments Mila</span>
            {totalPaid > 0 && <span className="ml-auto text-green-300 text-sm font-bold">{fmtAmt(totalPaid)}</span>}
          </div>
          <div className="p-4">
            {(payments?.length ?? 0) === 0 && (
              <p className="text-slate-400 text-sm text-center py-6">Abhi koi payment nahi mila</p>
            )}
            <div className="space-y-2">
              {payments?.map((p) => (
                <div key={p._id} className="flex justify-between items-center bg-green-900/30 border border-green-700/40 rounded-xl px-4 py-3">
                  <div>
                    <p className="font-bold text-green-300 text-base">₹{p.amount.toLocaleString("en-IN")}</p>
                    <p className="text-xs text-slate-400">{(() => { try { return format(new Date(typeof p.date === "number" ? p.date : p.date + "T00:00:00"), "dd MMM yyyy"); } catch { return p.date; } })()} {(p as { mode?: string }).mode ? `· ${(p as { mode?: string }).mode!.toUpperCase()}` : ""}</p>
                  </div>
                  {p.referenceNumber && (
                    <p className="text-xs text-slate-300 font-semibold bg-slate-700 border border-slate-600 px-2 py-1 rounded">{p.referenceNumber}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Bill Button */}
      {!showBillForm && pos.length > 0 && (
        <div className="fixed bottom-6 right-4 left-4 max-w-2xl mx-auto md:left-auto md:right-6 md:w-auto">
          <button
            onClick={() => { setShowBillForm(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}
            className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-6 rounded-2xl shadow-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Plus size={20} /> Bill Submit Karein
          </button>
        </div>
      )}
    </div>
  );
}
