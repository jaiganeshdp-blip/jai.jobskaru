import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { XIcon } from "lucide-react";
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { BillLineItemsEditor, type BillLineItem } from "@/pages/vendor-bills/_components/bill-line-items-editor.tsx";

const schema = z.object({
  vendorType: z.enum(["supplier", "contractor"]),
  vendorName: z.string().min(1, "Vendor name required"),
  siteId: z.string().optional(),
  billNo: z.string().min(1, "Bill No required"),
  billDate: z.string().min(1, "Bill Date required"),
  dueDate: z.string().optional(),
  termsDays: z.coerce.number().optional(),
  amount: z.coerce.number().min(0),
  gstPercent: z.coerce.number(),
  tds: z.coerce.number().optional(),
  retention: z.coerce.number().optional(),
  paidAmount: z.coerce.number().optional(),
  utrNo: z.string().optional(),
  utrDate: z.string().optional(),
  invoiceQuery: z.string().optional(),
  remark: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

const OUR_COMPANIES = ["JAI AAINATH INTERIOR", "JAI GANESH INTERIOR"];
const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editId: Id<"incomingInvoices"> | null;
  financialYear: string;
  ourCompanyName: string;
};

export default function IncomingInvoiceFormDialog({ open, onOpenChange, editId, financialYear, ourCompanyName }: Props) {
  const existing = useQuery(
    api.incomingInvoices.list,
    open && editId ? { financialYear, ourCompanyName } : "skip"
  );
  const editRow = existing?.find((r) => r._id === editId);

  const suppliers = useQuery(api.suppliers.list, open ? {} : "skip") ?? [];
  const contractors = useQuery(api.contractors.list, open ? {} : "skip") ?? [];
  const sites = useQuery(api.sites.list, open ? {} : "skip") ?? [];

  const createInvoice = useMutation(api.incomingInvoices.create);
  const updateInvoice = useMutation(api.incomingInvoices.update);

  const [lineItems, setLineItems] = useState<BillLineItem[]>([]);
  const itemsTotal = lineItems.reduce((s, it) => s + (it.amount || 0), 0);
  const hasItems = lineItems.length > 0;

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      vendorType: "supplier",
      vendorName: "",
      billNo: "",
      billDate: new Date().toISOString().split("T")[0],
      amount: 0,
      gstPercent: 18,
    },
  });

  const vendorType = form.watch("vendorType");
  const amountField = form.watch("amount") ?? 0;
  const amount = hasItems ? itemsTotal : amountField;
  const gstPercent = form.watch("gstPercent") ?? 18;
  const tds = form.watch("tds") ?? 0;
  const retention = form.watch("retention") ?? 0;
  const gstAmt = Math.round((amount * gstPercent) / 100);
  const total = amount + gstAmt;
  const netPayable = total - (tds ?? 0) - (retention ?? 0);

  useEffect(() => {
    if (editRow) {
      form.reset({
        vendorType: editRow.vendorType,
        vendorName: editRow.vendorName,
        siteId: editRow.siteId ?? undefined,
        billNo: editRow.billNo,
        billDate: editRow.billDate,
        dueDate: editRow.dueDate ?? undefined,
        termsDays: editRow.termsDays ?? undefined,
        amount: editRow.amount,
        gstPercent: editRow.gstPercent,
        tds: editRow.tds ?? undefined,
        retention: editRow.retention ?? undefined,
        paidAmount: editRow.paidAmount ?? undefined,
        utrNo: editRow.utrNo ?? undefined,
        utrDate: editRow.utrDate ?? undefined,
        invoiceQuery: editRow.invoiceQuery ?? undefined,
        remark: editRow.remark ?? undefined,
      });
      setLineItems(editRow.lineItems ?? []);
    } else if (!editId && open) {
      form.reset({
        vendorType: "supplier",
        vendorName: "",
        billNo: "",
        billDate: new Date().toISOString().split("T")[0],
        amount: 0,
        gstPercent: 18,
      });
      setLineItems([]);
    }
  }, [editRow, editId, open, form]);

  const onSubmit = async (values: FormValues) => {
    try {
      const site = values.siteId ? sites.find((s) => s._id === values.siteId) : undefined;
      const cleanItems = lineItems.filter((it) => it.description.trim() !== "");
      const payload = {
        ...values,
        amount: cleanItems.length > 0 ? cleanItems.reduce((s, it) => s + (it.amount || 0), 0) : values.amount,
        lineItems: cleanItems.length > 0 ? cleanItems : undefined,
        financialYear,
        ourCompanyName,
        siteId: values.siteId as Id<"sites"> | undefined,
        siteName: site?.name,
      };
      if (editId) {
        await updateInvoice({ id: editId, ...payload });
        toast.success("Invoice updated");
      } else {
        await createInvoice(payload);
        toast.success("Invoice added");
      }
      onOpenChange(false);
    } catch {
      toast.error("Save failed");
    }
  };

  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 bg-black/50 z-40" />
        <DialogPrimitive.Content className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-background rounded-xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-6">
          <div className="flex items-center justify-between mb-4">
            <DialogPrimitive.Title className="text-base font-bold">
              {editId ? "Invoice Edit Karen" : "Naya Invoice Add Karen"}
            </DialogPrimitive.Title>
            <DialogPrimitive.Close asChild>
              <button className="cursor-pointer p-1 rounded hover:bg-muted"><XIcon className="w-4 h-4" /></button>
            </DialogPrimitive.Close>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {/* Vendor Type + Name */}
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="vendorType" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vendor Type *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="supplier">Supplier</SelectItem>
                        <SelectItem value="contractor">Sub-Contractor</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="vendorName" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vendor Name *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select vendor" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vendorType === "supplier"
                          ? suppliers.map((s) => <SelectItem key={s._id} value={s.name}>{s.name}</SelectItem>)
                          : contractors.map((c) => <SelectItem key={c._id} value={c.name}>{c.name}</SelectItem>)
                        }
                        {/* fallback: manual entry */}
                        {field.value && ![...(vendorType === "supplier" ? suppliers : contractors)].some((x) => x.name === field.value) && (
                          <SelectItem value={field.value}>{field.value}</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Bill No + Site */}
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="billNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bill / Invoice No *</FormLabel>
                    <FormControl><Input {...field} placeholder="e.g. INV/2025/001" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Site</FormLabel>
                    <Select value={field.value ?? "none"} onValueChange={(v) => field.onChange(v === "none" ? undefined : v)}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select site" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">— No Site —</SelectItem>
                        {sites.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Dates */}
              <div className="grid grid-cols-3 gap-3">
                <FormField control={form.control} name="billDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bill Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="termsDays" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Terms (Days)</FormLabel>
                    <FormControl><Input type="number" {...field} value={field.value ?? ""} placeholder="30" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="dueDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Item-wise entry (optional) */}
              <BillLineItemsEditor items={lineItems} onChange={setLineItems} />

              {/* Amount + GST */}
              <div className="grid grid-cols-3 gap-3">
                <FormField control={form.control} name="amount" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₹) *</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        value={hasItems ? itemsTotal : field.value}
                        readOnly={hasItems}
                        className={hasItems ? "bg-muted" : undefined}
                      />
                    </FormControl>
                    {hasItems && (
                      <p className="text-[10px] text-muted-foreground">Items se auto-calculate ho raha hai</p>
                    )}
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="gstPercent" render={({ field }) => (
                  <FormItem>
                    <FormLabel>GST %</FormLabel>
                    <Select value={String(field.value)} onValueChange={(v) => field.onChange(Number(v))}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="0">0%</SelectItem>
                        <SelectItem value="5">5%</SelectItem>
                        <SelectItem value="12">12%</SelectItem>
                        <SelectItem value="18">18%</SelectItem>
                        <SelectItem value="28">28%</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="flex flex-col justify-end pb-1">
                  <p className="text-xs text-muted-foreground mb-1">GST Amount</p>
                  <p className="text-sm font-bold text-blue-600">₹{gstAmt.toLocaleString("en-IN")}</p>
                  <p className="text-xs text-muted-foreground">Total: ₹{total.toLocaleString("en-IN")}</p>
                </div>
              </div>

              {/* TDS + Retention */}
              <div className="grid grid-cols-3 gap-3">
                <FormField control={form.control} name="tds" render={({ field }) => (
                  <FormItem>
                    <FormLabel>TDS (₹)</FormLabel>
                    <FormControl><Input type="number" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="retention" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Retention (₹)</FormLabel>
                    <FormControl><Input type="number" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="flex flex-col justify-end pb-1">
                  <p className="text-xs text-muted-foreground mb-1">Net Payable</p>
                  <p className="text-sm font-bold text-emerald-600">₹{netPayable.toLocaleString("en-IN")}</p>
                </div>
              </div>

              {/* Paid + UTR */}
              <div className="grid grid-cols-3 gap-3">
                <FormField control={form.control} name="paidAmount" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Paid Amount (₹)</FormLabel>
                    <FormControl><Input type="number" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="utrNo" render={({ field }) => (
                  <FormItem>
                    <FormLabel>UTR No</FormLabel>
                    <FormControl><Input {...field} value={field.value ?? ""} placeholder="UTR/NEFT/RTGS" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="utrDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>UTR Date</FormLabel>
                    <FormControl><Input type="date" {...field} value={field.value ?? ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Invoice Query */}
              <FormField control={form.control} name="invoiceQuery" render={({ field }) => (
                <FormItem>
                  <FormLabel>Invoice Query</FormLabel>
                  <FormControl><Textarea {...field} value={field.value ?? ""} placeholder="Koi issue ya query ho toh yahan likhein..." rows={2} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Remark */}
              <FormField control={form.control} name="remark" render={({ field }) => (
                <FormItem>
                  <FormLabel>Remark</FormLabel>
                  <FormControl><Input {...field} value={field.value ?? ""} placeholder="Additional notes..." /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="secondary" onClick={() => onOpenChange(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update Invoice" : "Add Invoice"}</Button>
              </div>
            </form>
          </Form>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}
