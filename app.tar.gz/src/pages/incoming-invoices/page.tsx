import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Label } from "@/components/ui/label.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import {
  PlusCircle, FileText, AlertTriangle, CheckCircle,
  Trash2, CheckSquare, Square, CheckCheck, XCircle,
  Clock, CreditCard, ChevronRight, RotateCcw
} from "lucide-react";
import { cn } from "@/lib/utils.ts";
import IncomingInvoiceFormDialog from "./_components/IncomingInvoiceFormDialog.tsx";

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];
const OUR_COMPANIES = ["JAI AAINATH INTERIOR", "JAI GANESH INTERIOR"];

type ApprovalStatus = "pending_site" | "pending_billing" | "pending_superadmin" | "pending_payment" | "paid" | "rejected";

const STATUS_META: Record<ApprovalStatus, { label: string; color: string; icon: React.ComponentType<{ className?: string }> }> = {
  pending_site:        { label: "Site Approval", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  pending_billing:     { label: "Billing Approval", color: "bg-blue-100 text-blue-800", icon: Clock },
  pending_superadmin:  { label: "Admin Approval", color: "bg-purple-100 text-purple-800", icon: Clock },
  pending_payment:     { label: "Payment Pending", color: "bg-orange-100 text-orange-800", icon: CreditCard },
  paid:                { label: "Paid", color: "bg-green-100 text-green-800", icon: CheckCircle },
  rejected:            { label: "Rejected", color: "bg-red-100 text-red-800", icon: XCircle },
};

// Approval stages for the stepper
const STAGES = [
  { key: "pending_site", label: "Site Incharge" },
  { key: "pending_billing", label: "Billing Manager" },
  { key: "pending_superadmin", label: "Super Admin" },
  { key: "pending_payment", label: "Accounts Payment" },
  { key: "paid", label: "Paid" },
];

function stageIndex(status: ApprovalStatus) {
  const order = ["pending_site", "pending_billing", "pending_superadmin", "pending_payment", "paid", "rejected"];
  return order.indexOf(status);
}

function fmt(n: number | undefined) {
  if (n === undefined || n === null) return "-";
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}
function fmtDate(d: string | undefined) {
  if (!d) return "-";
  const [y, m, day] = d.split("T")[0].split("-");
  return `${day}-${m}-${y}`;
}
function daysOutstanding(dueDate: string | undefined, status: ApprovalStatus): number | null {
  if (!dueDate || status === "paid") return null;
  const due = new Date(dueDate);
  const today = new Date();
  return Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
}

// ─── Approval Action Dialog ───────────────────────────────────────────────────
type ActionType = "site_approve" | "site_reject" | "billing_approve" | "billing_reject" | "admin_approve" | "admin_reject" | "mark_paid" | "send_back";

function ApprovalActionDialog({
  open, onClose, invoice, action, onDone
}: {
  open: boolean;
  onClose: () => void;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  invoice: any;
  action: ActionType | null;
  onDone: () => void;
}) {
  const [note, setNote] = useState("");
  const [reason, setReason] = useState("");
  const [tds, setTds] = useState("");
  const [retention, setRetention] = useState("");
  const [paidAmount, setPaidAmount] = useState("");
  const [utrNo, setUtrNo] = useState("");
  const [utrDate, setUtrDate] = useState(new Date().toISOString().split("T")[0]);
  const [bankName, setBankName] = useState("");
  const [sendBackTo, setSendBackTo] = useState<string>("pending_site");

  const siteApprove = useMutation(api.incomingInvoices.siteInchargeApprove);
  const siteReject = useMutation(api.incomingInvoices.siteInchargeReject);
  const billingApprove = useMutation(api.incomingInvoices.billingApprove);
  const billingReject = useMutation(api.incomingInvoices.billingReject);
  const adminApprove = useMutation(api.incomingInvoices.superAdminApprove);
  const adminReject = useMutation(api.incomingInvoices.superAdminReject);
  const markPaid = useMutation(api.incomingInvoices.markPaid);
  const sendBack = useMutation(api.incomingInvoices.sendBack);

  if (!invoice || !action) return null;

  const isApprove = action.endsWith("_approve") || action === "mark_paid";
  const isReject = action.endsWith("_reject");

  const handleSubmit = async () => {
    try {
      if (action === "site_approve") await siteApprove({ id: invoice._id, note: note || undefined });
      else if (action === "site_reject") await siteReject({ id: invoice._id, reason });
      else if (action === "billing_approve") await billingApprove({
        id: invoice._id, note: note || undefined,
        tds: tds ? Number(tds) : undefined,
        retention: retention ? Number(retention) : undefined,
      });
      else if (action === "billing_reject") await billingReject({ id: invoice._id, reason });
      else if (action === "admin_approve") await adminApprove({ id: invoice._id, note: note || undefined });
      else if (action === "admin_reject") await adminReject({ id: invoice._id, reason });
      else if (action === "mark_paid") await markPaid({
        id: invoice._id,
        paidAmount: Number(paidAmount) || invoice.netPayable || invoice.totalAmount,
        utrNo, utrDate,
        bankName: bankName || undefined,
        paymentNote: note || undefined,
      });
      else if (action === "send_back") await sendBack({
        id: invoice._id,
        toStage: sendBackTo as "pending_site" | "pending_billing" | "pending_superadmin" | "pending_payment",
        reason,
      });

      toast.success(isApprove ? "Approved!" : isReject ? "Rejected" : "Done");
      onDone();
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed");
    }
  };

  const titles: Record<ActionType, string> = {
    site_approve: "Site Incharge — Approve Invoice",
    site_reject: "Site Incharge — Reject Invoice",
    billing_approve: "Billing Manager — Approve Invoice",
    billing_reject: "Billing Manager — Reject Invoice",
    admin_approve: "Super Admin — Final Approval",
    admin_reject: "Super Admin — Reject Invoice",
    mark_paid: "Accounts — Record Payment",
    send_back: "Send Back to Previous Stage",
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base">{titles[action]}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1 p-3 rounded-lg bg-muted/40 text-sm mb-2">
          <p className="font-semibold">{invoice.vendorName} — {invoice.billNo}</p>
          <p className="text-muted-foreground">Amount: ₹{fmt(invoice.totalAmount)} | Net Payable: ₹{fmt(invoice.netPayable)}</p>
        </div>

        <div className="space-y-3">
          {action === "billing_approve" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">TDS (₹)</Label>
                <Input value={tds} onChange={(e) => setTds(e.target.value)} placeholder={String(invoice.tds ?? 0)} type="number" />
              </div>
              <div>
                <Label className="text-xs">Retention (₹)</Label>
                <Input value={retention} onChange={(e) => setRetention(e.target.value)} placeholder={String(invoice.retention ?? 0)} type="number" />
              </div>
            </div>
          )}

          {action === "mark_paid" && (
            <div className="space-y-3">
              <div>
                <Label className="text-xs">Paid Amount (₹) *</Label>
                <Input value={paidAmount} onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder={String(invoice.netPayable ?? invoice.totalAmount)} type="number" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">UTR / Reference No *</Label>
                  <Input value={utrNo} onChange={(e) => setUtrNo(e.target.value)} placeholder="UTR/NEFT/RTGS" />
                </div>
                <div>
                  <Label className="text-xs">Payment Date *</Label>
                  <Input type="date" value={utrDate} onChange={(e) => setUtrDate(e.target.value)} />
                </div>
              </div>
              <div>
                <Label className="text-xs">Bank Name</Label>
                <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="HDFC / SBI / ICICI..." />
              </div>
            </div>
          )}

          {action === "send_back" && (
            <div>
              <Label className="text-xs">Send back to stage</Label>
              <Select value={sendBackTo} onValueChange={setSendBackTo}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending_site">Site Incharge</SelectItem>
                  <SelectItem value="pending_billing">Billing Manager</SelectItem>
                  <SelectItem value="pending_superadmin">Super Admin</SelectItem>
                  <SelectItem value="pending_payment">Accounts Payment</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {(isReject || action === "send_back") ? (
            <div>
              <Label className="text-xs">Reason *</Label>
              <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Rejection / send back reason..." rows={2} />
            </div>
          ) : (
            <div>
              <Label className="text-xs">Note (optional)</Label>
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Koi remark..." rows={2} />
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="secondary" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button
            variant={isReject ? "destructive" : "default"}
            className="cursor-pointer"
            disabled={isReject && !reason.trim()}
            onClick={handleSubmit}
          >
            {isApprove ? (action === "mark_paid" ? "Record Payment" : "Approve") : action === "send_back" ? "Send Back" : "Reject"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Invoice Detail Dialog ─────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function InvoiceDetailDialog({ invoice, onClose, userRole }: { invoice: any; onClose: () => void; userRole: string }) {
  const [actionOpen, setActionOpen] = useState(false);
  const [currentAction, setCurrentAction] = useState<ActionType | null>(null);
  const status: ApprovalStatus = invoice.approvalStatus;

  const doAction = (a: ActionType) => { setCurrentAction(a); setActionOpen(true); };

  const canSiteApprove = (userRole === "site_incharge" || userRole === "super_admin") && status === "pending_site";
  const canBillingApprove = (userRole === "billing_manager" || userRole === "super_admin") && status === "pending_billing";
  const canAdminApprove = userRole === "super_admin" && status === "pending_superadmin";
  const canPay = (userRole === "accounts_manager" || userRole === "super_admin") && status === "pending_payment";
  const canSendBack = userRole === "super_admin" && status !== "pending_site" && status !== "paid";

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-orange-500" />
              {invoice.vendorName} — {invoice.billNo}
            </DialogTitle>
          </DialogHeader>

          {/* Approval Stepper */}
          <div className="flex items-center gap-0 mb-4 overflow-x-auto pb-1">
            {STAGES.map((stage, i) => {
              const si = stageIndex(status);
              const stageI = stageIndex(stage.key as ApprovalStatus);
              const isActive = stage.key === status;
              const isDone = status !== "rejected" && stageI < si;
              const isRejected = status === "rejected";

              return (
                <div key={stage.key} className="flex items-center">
                  <div className={cn(
                    "flex flex-col items-center px-2 py-1 rounded text-[10px] min-w-[70px] text-center",
                    isDone ? "text-green-700" : isActive && !isRejected ? "text-orange-700 font-bold" : "text-muted-foreground"
                  )}>
                    <div className={cn("w-6 h-6 rounded-full flex items-center justify-center mb-0.5 text-xs",
                      isDone ? "bg-green-100 text-green-700" :
                      isActive && !isRejected ? "bg-orange-200 text-orange-700 ring-2 ring-orange-400" :
                      "bg-muted text-muted-foreground"
                    )}>
                      {isDone ? <CheckCheck className="w-3 h-3" /> : i + 1}
                    </div>
                    {stage.label}
                  </div>
                  {i < STAGES.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground mx-0.5" />}
                </div>
              );
            })}
            {status === "rejected" && (
              <div className="ml-2 flex items-center gap-1 text-xs text-red-600 font-semibold">
                <XCircle className="w-4 h-4" /> Rejected at: {invoice.rejectedStage?.replace("_", " ")}
              </div>
            )}
          </div>

          {/* Invoice Details Grid */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground text-xs">Vendor</span><p className="font-semibold">{invoice.vendorName}</p></div>
            <div><span className="text-muted-foreground text-xs">Type</span><p>{invoice.vendorType === "supplier" ? "Supplier" : "Sub-Contractor"}</p></div>
            <div><span className="text-muted-foreground text-xs">Bill No</span><p className="font-mono">{invoice.billNo}</p></div>
            <div><span className="text-muted-foreground text-xs">Site</span><p>{invoice.siteName ?? "—"}</p></div>
            <div><span className="text-muted-foreground text-xs">Bill Date</span><p>{fmtDate(invoice.billDate)}</p></div>
            <div><span className="text-muted-foreground text-xs">Due Date</span><p>{fmtDate(invoice.dueDate)}</p></div>
          </div>

          {/* Amounts */}
          <div className="grid grid-cols-4 gap-2 mt-2 bg-muted/30 rounded-lg p-3">
            <div className="text-center"><p className="text-xs text-muted-foreground">Amount</p><p className="font-bold">₹{fmt(invoice.amount)}</p></div>
            <div className="text-center"><p className="text-xs text-muted-foreground">GST</p><p className="font-bold text-blue-700">₹{fmt(invoice.gstAmount)}</p></div>
            <div className="text-center"><p className="text-xs text-muted-foreground">Total</p><p className="font-bold">₹{fmt(invoice.totalAmount)}</p></div>
            <div className="text-center"><p className="text-xs text-muted-foreground">Net Payable</p><p className="font-bold text-emerald-700">₹{fmt(invoice.netPayable)}</p></div>
          </div>
          {(invoice.tds ?? 0) > 0 || (invoice.retention ?? 0) > 0 ? (
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-muted-foreground text-xs">TDS</span><p className="text-purple-700">₹{fmt(invoice.tds)}</p></div>
              <div><span className="text-muted-foreground text-xs">Retention</span><p className="text-orange-700">₹{fmt(invoice.retention)}</p></div>
            </div>
          ) : null}

          {/* Item-wise breakup */}
          {Array.isArray(invoice.lineItems) && invoice.lineItems.length > 0 && (
            <div className="mt-1">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Item-wise Breakup</p>
              <div className="rounded-lg border overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="text-left px-2 py-1">Item</th>
                      <th className="text-center px-2 py-1 w-16">Unit</th>
                      <th className="text-right px-2 py-1 w-16">Qty</th>
                      <th className="text-right px-2 py-1 w-20">Rate ₹</th>
                      <th className="text-right px-2 py-1 w-24">Amount ₹</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(invoice.lineItems as Array<{ description: string; unit: string; quantity: number; ratePerUnit: number; amount: number }>).map((it, i) => (
                      <tr key={i} className="border-t border-border/50">
                        <td className="px-2 py-1">{it.description}</td>
                        <td className="px-2 py-1 text-center">{it.unit}</td>
                        <td className="px-2 py-1 text-right">{it.quantity}</td>
                        <td className="px-2 py-1 text-right">{fmt(it.ratePerUnit)}</td>
                        <td className="px-2 py-1 text-right font-semibold">{fmt(it.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Approval Trail */}
          <div className="space-y-1 mt-1">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Approval Trail</p>
            {invoice.siteInchargeApprovedBy && (
              <div className="text-xs flex gap-2 items-center text-green-700">
                <CheckCheck className="w-3 h-3" />
                Site Incharge: {invoice.siteInchargeApprovedByName ?? "—"} on {fmtDate(invoice.siteInchargeApprovedAt)}
                {invoice.siteInchargeNote && <span className="text-muted-foreground">— {invoice.siteInchargeNote}</span>}
              </div>
            )}
            {invoice.billingApprovedBy && (
              <div className="text-xs flex gap-2 items-center text-green-700">
                <CheckCheck className="w-3 h-3" />
                Billing: {invoice.billingApprovedByName ?? "—"} on {fmtDate(invoice.billingApprovedAt)}
                {invoice.billingNote && <span className="text-muted-foreground">— {invoice.billingNote}</span>}
              </div>
            )}
            {invoice.superAdminApprovedBy && (
              <div className="text-xs flex gap-2 items-center text-green-700">
                <CheckCheck className="w-3 h-3" />
                Super Admin: {invoice.superAdminApprovedByName ?? "—"} on {fmtDate(invoice.superAdminApprovedAt)}
                {invoice.superAdminNote && <span className="text-muted-foreground">— {invoice.superAdminNote}</span>}
              </div>
            )}
            {invoice.paidBy && (
              <div className="text-xs flex gap-2 items-center text-green-700">
                <CreditCard className="w-3 h-3" />
                Paid by: {invoice.paidByName ?? "—"} on {fmtDate(invoice.paidAt)} | UTR: {invoice.utrNo}
                {invoice.bankName && <span className="text-muted-foreground"> ({invoice.bankName})</span>}
              </div>
            )}
            {invoice.rejectedBy && (
              <div className="text-xs flex gap-2 items-center text-red-700">
                <XCircle className="w-3 h-3" />
                Rejected by: {invoice.rejectedByName ?? "—"} — {invoice.rejectionReason}
              </div>
            )}
          </div>

          {invoice.invoiceQuery && (
            <div className="text-xs p-2 bg-orange-50 border border-orange-200 rounded text-orange-800">
              <span className="font-semibold">Invoice Query: </span>{invoice.invoiceQuery}
            </div>
          )}
          {invoice.remark && (
            <div className="text-xs text-muted-foreground">Remark: {invoice.remark}</div>
          )}

          {/* Action Buttons */}
          <DialogFooter className="flex flex-wrap gap-2 mt-2">
            {canSiteApprove && (
              <>
                <Button size="sm" className="cursor-pointer bg-green-600 hover:bg-green-700 gap-1" onClick={() => doAction("site_approve")}>
                  <CheckCheck className="w-3.5 h-3.5" /> Approve
                </Button>
                <Button size="sm" variant="destructive" className="cursor-pointer gap-1" onClick={() => doAction("site_reject")}>
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </Button>
              </>
            )}
            {canBillingApprove && (
              <>
                <Button size="sm" className="cursor-pointer bg-blue-600 hover:bg-blue-700 gap-1" onClick={() => doAction("billing_approve")}>
                  <CheckCheck className="w-3.5 h-3.5" /> Billing Approve
                </Button>
                <Button size="sm" variant="destructive" className="cursor-pointer gap-1" onClick={() => doAction("billing_reject")}>
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </Button>
              </>
            )}
            {canAdminApprove && (
              <>
                <Button size="sm" className="cursor-pointer bg-purple-600 hover:bg-purple-700 gap-1" onClick={() => doAction("admin_approve")}>
                  <CheckCheck className="w-3.5 h-3.5" /> Final Approve
                </Button>
                <Button size="sm" variant="destructive" className="cursor-pointer gap-1" onClick={() => doAction("admin_reject")}>
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </Button>
              </>
            )}
            {canPay && (
              <Button size="sm" className="cursor-pointer bg-emerald-600 hover:bg-emerald-700 gap-1" onClick={() => doAction("mark_paid")}>
                <CreditCard className="w-3.5 h-3.5" /> Record Payment
              </Button>
            )}
            {canSendBack && (
              <Button size="sm" variant="secondary" className="cursor-pointer gap-1" onClick={() => doAction("send_back")}>
                <RotateCcw className="w-3.5 h-3.5" /> Send Back
              </Button>
            )}
            <Button size="sm" variant="secondary" className="cursor-pointer ml-auto" onClick={onClose}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ApprovalActionDialog
        open={actionOpen}
        onClose={() => setActionOpen(false)}
        invoice={invoice}
        action={currentAction}
        onDone={() => {}}
      />
    </>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
function IncomingInvoicesInner() {
  const { user } = useAuth();
  const meQuery = useQuery(api.users.getCurrentUserQuery, {});
  const userRole = meQuery?.role ?? "viewer";

  const [fy, setFy] = useState("2026-27");
  const [ourCompany, setOurCompany] = useState("JAI AAINATH INTERIOR");
  const [vendorTypeFilter, setVendorTypeFilter] = useState<"all" | "supplier" | "contractor">("all");
  const [vendorFilter, setVendorFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<Id<"incomingInvoices"> | null>(null);
  const [detailInvoice, setDetailInvoice] = useState<Record<string, unknown> | null>(null);
  const [deleteId, setDeleteId] = useState<Id<"incomingInvoices"> | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);

  const removeInvoice = useMutation(api.incomingInvoices.remove);

  const rows = useQuery(api.incomingInvoices.list, {
    financialYear: fy,
    ourCompanyName: ourCompany,
    vendorType: vendorTypeFilter !== "all" ? vendorTypeFilter : undefined,
    vendorName: vendorFilter !== "all" ? vendorFilter : undefined,
    approvalStatus: statusFilter !== "all" ? statusFilter : undefined,
  });

  const summary = useQuery(api.incomingInvoices.summary, {
    financialYear: fy,
    ourCompanyName: ourCompany,
  });

  const vendors = useQuery(api.incomingInvoices.distinctVendors, {
    financialYear: fy,
    ourCompanyName: ourCompany,
  });

  const isLoading = rows === undefined;
  const allRowIds = rows?.map((r) => r._id as string) ?? [];
  const allSelected = allRowIds.length > 0 && allRowIds.every((id) => selectedIds.has(id));
  const someSelected = selectedIds.size > 0;
  const isSuperAdmin = userRole === "super_admin";

  const toggleSelectAll = () => {
    if (allSelected) setSelectedIds(new Set());
    else setSelectedIds(new Set(allRowIds));
  };
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const handleBulkDelete = async () => {
    let failed = 0;
    for (const id of Array.from(selectedIds)) {
      try { await removeInvoice({ id: id as Id<"incomingInvoices"> }); } catch { failed++; }
    }
    if (failed === 0) toast.success(`${selectedIds.size} invoice(s) delete ho gaye`);
    else toast.error(`${failed} invoice delete nahi ho sake`);
    setSelectedIds(new Set());
    setBulkDeleteOpen(false);
  };

  // My pending queue based on role
  const myPending = rows?.filter((r) => {
    if (userRole === "site_incharge") return r.approvalStatus === "pending_site";
    if (userRole === "billing_manager") return r.approvalStatus === "pending_billing";
    if (userRole === "accounts_manager") return r.approvalStatus === "pending_payment";
    if (userRole === "super_admin") return r.approvalStatus === "pending_superadmin";
    return false;
  }) ?? [];

  return (
    <div className="flex flex-col h-full min-h-screen bg-background">
      {/* Header */}
      <div className="border-b px-4 py-3 bg-card">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-orange-500" />
            <div>
              <h1 className="font-bold text-base leading-tight">INCOMING INVOICES — {ourCompany}</h1>
              <p className="text-xs text-muted-foreground">Supplier &amp; Sub-Contractor Bills | Approval Workflow</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {isSuperAdmin && (
              <Select value={ourCompany} onValueChange={(v) => { setOurCompany(v); setVendorFilter("all"); }}>
                <SelectTrigger className="w-52 h-8 text-xs font-semibold border-orange-300"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {OUR_COMPANIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            {isSuperAdmin && (
              <Select value={fy} onValueChange={setFy}>
                <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            <Select value={vendorTypeFilter} onValueChange={(v) => { setVendorTypeFilter(v as "all" | "supplier" | "contractor"); setVendorFilter("all"); }}>
              <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                <SelectItem value="supplier">Supplier</SelectItem>
                <SelectItem value="contractor">Sub-Contractor</SelectItem>
              </SelectContent>
            </Select>
            <Select value={vendorFilter} onValueChange={setVendorFilter}>
              <SelectTrigger className="w-44 h-8 text-xs"><SelectValue placeholder="All Vendors" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {vendors?.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="All Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending_site">Pending Site</SelectItem>
                <SelectItem value="pending_billing">Pending Billing</SelectItem>
                <SelectItem value="pending_superadmin">Pending Admin</SelectItem>
                <SelectItem value="pending_payment">Pending Payment</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            {isSuperAdmin && (
              <Button size="sm" onClick={() => { setEditId(null); setDialogOpen(true); }} className="h-8 text-xs cursor-pointer gap-1 bg-orange-500 hover:bg-orange-600">
                <PlusCircle className="w-3.5 h-3.5" /> Add Invoice
              </Button>
            )}
            {someSelected && isSuperAdmin && (
              <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)} className="h-8 text-xs cursor-pointer gap-1">
                <Trash2 className="w-3.5 h-3.5" /> Delete ({selectedIds.size})
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* My Pending Queue Banner */}
      {myPending.length > 0 && (
        <div className="mx-4 mt-3 p-3 rounded-lg bg-orange-50 border border-orange-200 flex items-center gap-3">
          <Clock className="w-5 h-5 text-orange-600 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-orange-800">
              Aapke paas {myPending.length} invoice(s) pending hain approval ke liye
            </p>
            <p className="text-xs text-orange-600">Neeche click karein kisi bhi invoice par approve/reject karne ke liye</p>
          </div>
        </div>
      )}

      {/* Summary bar */}
      {summary && (
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-px bg-border border-b mt-3">
          {[
            { label: "Pending Site", value: String(summary.stageCounts.pending_site), color: "text-yellow-700" },
            { label: "Pending Billing", value: String(summary.stageCounts.pending_billing), color: "text-blue-700" },
            { label: "Pending Admin", value: String(summary.stageCounts.pending_superadmin), color: "text-purple-700" },
            { label: "Pending Payment", value: String(summary.stageCounts.pending_payment), color: "text-orange-700" },
            { label: "Paid", value: String(summary.stageCounts.paid), color: "text-green-700" },
            { label: "Overdue Bills", value: String(summary.overdueCount), color: summary.overdueCount > 0 ? "text-destructive" : "text-foreground" },
          ].map((s) => (
            <div key={s.label} className="bg-card px-3 py-2 text-center">
              <div className={cn("text-sm font-bold", s.color)}>{s.value}</div>
              <div className="text-[10px] text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto mt-1">
        <table className="w-full text-[11px] border-collapse min-w-[1300px] bg-white text-gray-900">
          <thead className="sticky top-0 z-10">
            <tr className="bg-orange-600 text-white">
              {isSuperAdmin && (
                <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-8">
                  <button onClick={toggleSelectAll} className="cursor-pointer flex items-center justify-center w-full">
                    {allSelected ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5 opacity-70" />}
                  </button>
                </th>
              )}
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-8">S.No</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-20">Type</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-left min-w-[150px]">Vendor Name</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-left min-w-[110px]">Bill No</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-20">Site</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-22">Bill Date</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-28">Approval Status</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-22">Amount</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-18">GST</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-22">Total</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-18">TDS</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-20">Net Payable</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-right w-20">Paid</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-28">UTR</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-22">Due Date</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-18">Days O/S</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-left min-w-[100px]">Invoice Query</th>
              <th className="border border-orange-500/30 px-1.5 py-1.5 text-center w-8"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading && Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>{Array.from({ length: 18 }).map((__, j) => (
                <td key={j} className="border border-border px-1.5 py-1"><Skeleton className="h-3 w-full" /></td>
              ))}</tr>
            ))}
            {!isLoading && rows?.length === 0 && (
              <tr><td colSpan={18} className="text-center py-12 text-muted-foreground">
                <FileText className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>Koi invoice nahi mila.</p>
              </td></tr>
            )}
            {!isLoading && rows?.map((row, idx) => {
              const status = row.approvalStatus as ApprovalStatus;
              const meta = STATUS_META[status];
              const days = daysOutstanding(row.dueDate, status);
              const overdue = days !== null && days > 0;
              const isSelected = selectedIds.has(row._id);
              const isMyTurn =
                (userRole === "site_incharge" && status === "pending_site") ||
                (userRole === "billing_manager" && status === "pending_billing") ||
                (userRole === "super_admin" && status === "pending_superadmin") ||
                (userRole === "accounts_manager" && status === "pending_payment");

              const rowClass = isSelected ? "bg-orange-100" :
                isMyTurn ? "bg-yellow-50 hover:bg-yellow-100" :
                overdue ? "bg-red-50 hover:bg-red-100" :
                idx % 2 === 0 ? "bg-white hover:bg-orange-50/40" : "bg-orange-50/20 hover:bg-orange-50/50";

              const StatusIcon = meta.icon;

              return (
                <tr key={row._id} className={cn("cursor-pointer transition-colors", rowClass)} onClick={() => setDetailInvoice(row)}>
                  {isSuperAdmin && (
                    <td className="border border-gray-200 px-1 py-1 text-center" onClick={(e) => e.stopPropagation()}>
                      <button className="cursor-pointer flex items-center justify-center w-full" onClick={() => toggleSelect(row._id)}>
                        {isSelected ? <CheckSquare className="w-3.5 h-3.5 text-orange-600" /> : <Square className="w-3.5 h-3.5 text-gray-400" />}
                      </button>
                    </td>
                  )}
                  <td className="border border-gray-200 px-1.5 py-1 text-center text-gray-500">{idx + 1}</td>
                  <td className="border border-gray-200 px-1 py-1 text-center">
                    <span className={cn("text-[9px] px-1.5 py-0.5 rounded font-semibold",
                      row.vendorType === "supplier" ? "bg-blue-100 text-blue-800" : "bg-orange-100 text-orange-800"
                    )}>
                      {row.vendorType === "supplier" ? "SUPPLIER" : "CONTRACTOR"}
                    </span>
                  </td>
                  <td className="border border-gray-200 px-1.5 py-1 font-semibold text-[11px]">
                    {row.vendorName}
                    {isMyTurn && <span className="ml-1 text-[9px] bg-yellow-200 text-yellow-800 px-1 rounded">ACTION</span>}
                  </td>
                  <td className="border border-gray-200 px-1.5 py-1 font-mono text-[10px]">{row.billNo}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-center text-[10px]">{row.siteName ?? "—"}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-center">{fmtDate(row.billDate)}</td>
                  <td className="border border-gray-200 px-1 py-1 text-center">
                    <span className={cn("text-[9px] px-1.5 py-0.5 rounded font-semibold flex items-center gap-0.5 justify-center", meta.color)}>
                      <StatusIcon className="w-2.5 h-2.5" />
                      {meta.label}
                    </span>
                  </td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right font-bold">{fmt(row.amount)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right text-blue-700">{fmt(row.gstAmount)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right font-bold">{fmt(row.totalAmount)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right text-purple-700">{fmt(row.tds)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right font-bold text-emerald-700">{fmt(row.netPayable)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-right text-green-700">{fmt(row.paidAmount)}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-center text-[10px] font-mono">{row.utrNo ?? "—"}</td>
                  <td className="border border-gray-200 px-1.5 py-1 text-center">{fmtDate(row.dueDate)}</td>
                  <td className={cn("border border-gray-200 px-1.5 py-1 text-center font-semibold",
                    days !== null && days > 0 ? "text-red-600" : days !== null ? "text-green-700" : "text-gray-400"
                  )}>
                    {days !== null ? (days > 0 ? `+${days}` : days === 0 ? "Today" : `${days}`) : "—"}
                    {overdue && <AlertTriangle className="w-2.5 h-2.5 inline ml-0.5" />}
                  </td>
                  <td className="border border-gray-200 px-1.5 py-1 text-[10px] text-orange-700 max-w-[100px] truncate">{row.invoiceQuery ?? "—"}</td>
                  {isSuperAdmin && (
                    <td className="border border-gray-200 px-1 py-1 text-center" onClick={(e) => e.stopPropagation()}>
                      <button className="p-1 rounded hover:bg-red-100 text-red-500 hover:text-red-700 cursor-pointer" onClick={() => setDeleteId(row._id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
          {summary && !isLoading && rows && rows.length > 0 && (
            <tfoot>
              <tr className="bg-orange-50 font-bold border-t-2 border-orange-400">
                <td colSpan={isSuperAdmin ? 9 : 8} className="border border-gray-300 px-2 py-1.5 text-right text-xs">TOTAL →</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-blue-700">{fmt(summary.totalGst)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs">{fmt(summary.totalBill)}</td>
                <td className="border border-gray-300 px-1.5 py-1.5 text-right text-xs text-purple-700">{fmt(summary.totalTds)}</td>
                <td colSpan={isSuperAdmin ? 7 : 6} className="border border-gray-300" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {/* Detail Dialog */}
      {detailInvoice && (
        <InvoiceDetailDialog
          invoice={detailInvoice}
          onClose={() => setDetailInvoice(null)}
          userRole={userRole}
        />
      )}

      {/* Add/Edit Form */}
      {isSuperAdmin && (
        <IncomingInvoiceFormDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          editId={editId}
          financialYear={fy}
          ourCompanyName={ourCompany}
        />
      )}

      {/* Bulk Delete */}
      <Dialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{selectedIds.size} Invoice(s) Delete Karen?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Yeh <strong>{selectedIds.size}</strong> invoice permanently delete ho jaayenge.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setBulkDeleteOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={handleBulkDelete}>Delete {selectedIds.size}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Single Delete */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Invoice Delete Karen?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Permanently delete ho jaayega.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteId(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteId) return;
              try { await removeInvoice({ id: deleteId }); toast.success("Deleted"); } catch { toast.error("Failed"); }
              setDeleteId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function IncomingInvoicesPage() {
  return (
    <>
      <Unauthenticated><div className="flex items-center justify-center h-64"><SignInButton /></div></Unauthenticated>
      <Authenticated><IncomingInvoicesInner /></Authenticated>
    </>
  );
}
