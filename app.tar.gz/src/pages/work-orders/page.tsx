import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Plus, Search, Pencil, Trash2, FileText, Eye, TrendingUp, ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  active: "bg-blue-500/10 text-blue-600",
  amended: "bg-orange-500/10 text-orange-600",
  completed: "bg-green-500/10 text-green-600",
  cancelled: "bg-red-500/10 text-red-600",
};

const schema = z.object({
  orderType: z.enum(["incoming", "outgoing"]),
  orderNumber: z.string().min(1, "Order number required"),
  siteId: z.string().min(1, "Site required"),
  clientId: z.string().optional(),
  contractorId: z.string().optional(),
  companyId: z.string().min(1, "Company required"),
  description: z.string().min(1, "Description required"),
  totalValue: z.coerce.number().min(1, "Value required"),
  status: z.enum(["draft", "active", "amended", "completed", "cancelled"]),
  issueDate: z.string().min(1, "Issue date required"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  terms: z.string().optional(),
});
type WOForm = z.infer<typeof schema>;

export default function WorkOrders() {
  const navigate = useNavigate();
  const workOrders = useQuery(api.workOrders.list, {});
  const sites = useQuery(api.sites.list, {});
  const clients = useQuery(api.clients.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const companies = useQuery(api.companies.list, {});
  const createWO = useMutation(api.workOrders.create);
  const updateWO = useMutation(api.workOrders.update);
  const removeWO = useMutation(api.workOrders.remove);

  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterSiteId, setFilterSiteId] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((wo) => wo._id)));
    }
  }
  function clearSelection() { setSelectedIds(new Set()); }

  async function handleBulkDelete() {
    setBulkDeleting(true);
    try {
      await Promise.all([...selectedIds].map((id) => removeWO({ id: id as Id<"workOrders"> })));
      toast.success(`Deleted ${selectedIds.size} work order${selectedIds.size !== 1 ? "s" : ""}`);
      clearSelection();
    } catch { toast.error("Some deletes failed"); }
    finally { setBulkDeleting(false); }
  }

  const form = useForm<WOForm>({
    resolver: zodResolver(schema),
    defaultValues: {
      orderType: "incoming",
      orderNumber: "",
      description: "",
      totalValue: 0,
      status: "draft",
      issueDate: new Date().toISOString().split("T")[0],
    },
  });

  const watchOrderType = form.watch("orderType");

  const filtered = (workOrders ?? []).filter((wo) => {
    const q = search.toLowerCase();
    const matchSearch =
      wo.orderNumber.toLowerCase().includes(q) ||
      (wo.siteName ?? "").toLowerCase().includes(q) ||
      (wo.clientName ?? "").toLowerCase().includes(q) ||
      (wo.contractorName ?? "").toLowerCase().includes(q) ||
      wo.description.toLowerCase().includes(q);
    const matchStatus = filterStatus === "all" || wo.status === filterStatus;
    const matchSite = filterSiteId === "all" || wo.siteId === filterSiteId;
    const woType = wo.orderType ?? "incoming";
    const matchType = filterType === "all" || woType === filterType;
    return matchSearch && matchStatus && matchSite && matchType;
  });

  const totalValue = filtered.reduce((s, wo) => s + wo.totalValue, 0);
  const activeCount = (workOrders ?? []).filter((wo) => wo.status === "active").length;
  const completedCount = (workOrders ?? []).filter((wo) => wo.status === "completed").length;
  const incomingCount = (workOrders ?? []).filter((wo) => (wo.orderType ?? "incoming") === "incoming").length;
  const outgoingCount = (workOrders ?? []).filter((wo) => wo.orderType === "outgoing").length;

  function openCreate(type: "incoming" | "outgoing" = "incoming") {
    setEditId(null);
    form.reset({
      orderType: type,
      orderNumber: `WO-${type === "outgoing" ? "OUT" : "IN"}-${Date.now().toString().slice(-5)}`,
      description: "",
      totalValue: 0,
      status: "draft",
      issueDate: new Date().toISOString().split("T")[0],
    });
    setDialogOpen(true);
  }

  function openEdit(wo: (typeof filtered)[number]) {
    setEditId(wo._id);
    form.reset({
      orderType: (wo.orderType ?? "incoming") as "incoming" | "outgoing",
      orderNumber: wo.orderNumber,
      siteId: wo.siteId,
      clientId: wo.clientId ?? "",
      contractorId: wo.contractorId ?? "",
      companyId: wo.companyId,
      description: wo.description,
      totalValue: wo.totalValue,
      status: wo.status,
      issueDate: wo.issueDate,
      startDate: wo.startDate ?? "",
      endDate: wo.endDate ?? "",
      terms: wo.terms ?? "",
    });
    setDialogOpen(true);
  }

  async function onSubmit(data: WOForm) {
    try {
      const isIncoming = data.orderType === "incoming";
      const payload = {
        orderType: data.orderType,
        orderNumber: data.orderNumber,
        siteId: data.siteId as Id<"sites">,
        clientId: isIncoming && data.clientId ? (data.clientId as Id<"clients">) : undefined,
        contractorId: !isIncoming && data.contractorId ? (data.contractorId as Id<"contractors">) : undefined,
        companyId: data.companyId as Id<"companies">,
        description: data.description,
        totalValue: data.totalValue,
        status: data.status,
        issueDate: data.issueDate,
        startDate: data.startDate || undefined,
        endDate: data.endDate || undefined,
        terms: data.terms || undefined,
      };
      if (editId) {
        await updateWO({ id: editId as Id<"workOrders">, ...payload });
        toast.success("Work order updated");
      } else {
        await createWO(payload);
        toast.success("Work order created");
      }
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Something went wrong");
    }
  }

  // When site changes, auto-populate companyId
  const watchSiteId = form.watch("siteId");
  const selectedSite = sites?.find((s) => s._id === watchSiteId);

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Work Orders</h1>
          <p className="text-muted-foreground text-sm">
            {workOrders
              ? `${workOrders.length} orders · ${incomingCount} received from clients · ${outgoingCount} issued to contractors`
              : "Loading..."}
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => openCreate("incoming")} className="cursor-pointer gap-1.5">
            <ArrowDownLeft className="w-4 h-4" /> Received from Client
          </Button>
          <Button onClick={() => openCreate("outgoing")} variant="secondary" className="cursor-pointer gap-1.5">
            <ArrowUpRight className="w-4 h-4" /> Issue to Contractor
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      {workOrders && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "From Clients", value: incomingCount, color: "text-blue-500" },
            { label: "To Contractors", value: outgoingCount, color: "text-orange-500" },
            { label: "Active", value: activeCount, color: "text-green-500" },
            {
              label: "Total Value",
              value: `₹${(workOrders.reduce((s, w) => s + w.totalValue, 0) / 100000).toFixed(1)}L`,
              color: "text-purple-500",
            },
          ].map((s) => (
            <Card key={s.label} className="py-3">
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search order no., site, client, contractor..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-44 cursor-pointer">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="incoming">Received from Client</SelectItem>
            <SelectItem value="outgoing">Issued to Contractor</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-36 cursor-pointer">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="amended">Amended</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterSiteId} onValueChange={setFilterSiteId}>
          <SelectTrigger className="w-full sm:w-44 cursor-pointer">
            <SelectValue placeholder="All Sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk delete bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        itemLabel="work order"
        onDelete={handleBulkDelete}
        onClear={clearSelection}
      />

      {/* Table */}
      {!workOrders ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><FileText /></EmptyMedia>
            <EmptyTitle>No work orders found</EmptyTitle>
            <EmptyDescription>Create a work order to track project scope and value</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={() => openCreate("incoming")} size="sm" className="cursor-pointer">Received from Client</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox
                      checked={filtered.length > 0 && selectedIds.size === filtered.length}
                      indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length}
                      onChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Type</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Order No.</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Client / Contractor</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Issue Date</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Value</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((wo) => {
                  const isIncoming = (wo.orderType ?? "incoming") === "incoming";
                  return (
                    <tr
                      key={wo._id}
                      className="hover:bg-muted/30 cursor-pointer"
                      onClick={() => navigate(`/work-orders/${wo._id}`)}
                    >
                      <td className="px-4 py-3 w-10" onClick={(e) => e.stopPropagation()}>
                        <BulkCheckbox
                          checked={selectedIds.has(wo._id)}
                          onChange={() => toggleSelect(wo._id)}
                        />
                      </td>
                      <td className="px-4 py-3">
                        {isIncoming ? (
                          <Badge className="bg-blue-500/10 text-blue-600 border-0 gap-1 text-xs font-medium whitespace-nowrap">
                            <ArrowDownLeft className="w-3 h-3" /> From Client
                          </Badge>
                        ) : (
                          <Badge className="bg-orange-500/10 text-orange-600 border-0 gap-1 text-xs font-medium whitespace-nowrap">
                            <ArrowUpRight className="w-3 h-3" /> To Contractor
                          </Badge>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isIncoming ? "bg-blue-500/10" : "bg-orange-500/10"}`}>
                            <FileText className={`w-4 h-4 ${isIncoming ? "text-blue-500" : "text-orange-500"}`} />
                          </div>
                          <div>
                            <p className="font-semibold">{wo.orderNumber}</p>
                            {wo.amendmentCount > 0 && (
                              <p className="text-xs text-orange-500">v{wo.version} · {wo.amendmentCount} amendment{wo.amendmentCount > 1 ? "s" : ""}</p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell text-muted-foreground text-xs max-w-[150px] truncate">{wo.siteName ?? "—"}</td>
                      <td className="px-4 py-3 hidden md:table-cell text-muted-foreground text-xs max-w-[150px] truncate">
                        {isIncoming ? (wo.clientName ?? "—") : (wo.contractorName ?? "—")}
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground text-xs">{wo.issueDate}</td>
                      <td className="px-4 py-3 text-right font-semibold">
                        ₹{(wo.totalValue / 100000).toFixed(2)}L
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[wo.status] ?? ""}`}>
                          {wo.status}
                        </span>
                      </td>
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                            onClick={() => navigate(`/work-orders/${wo._id}`)}>
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                            onClick={() => openEdit(wo)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(wo._id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {/* Footer total */}
          <div className="px-4 py-3 bg-muted/30 border-t border-border flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{filtered.length} work orders</span>
            <span className="font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-orange-500" />
              Total: ₹{totalValue.toLocaleString("en-IN")}
            </span>
          </div>
        </div>
      )}

      {/* Create / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editId ? "Edit Work Order" : watchOrderType === "outgoing" ? "Issue Work Order to Contractor" : "Work Order Received from Client"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {/* Order Type selector (only on create) */}
                {!editId && (
                  <FormField control={form.control} name="orderType" render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Work Order Type *</FormLabel>
                      <Select onValueChange={(v) => {
                        field.onChange(v);
                        form.setValue("orderNumber", `WO-${v === "outgoing" ? "OUT" : "IN"}-${Date.now().toString().slice(-5)}`);
                      }} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="cursor-pointer">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="incoming">
                            Received from Client (Client ne hamare company ko diya)
                          </SelectItem>
                          <SelectItem value="outgoing">
                            Issued to Contractor / Subcontractor (Hum ne contractor ko diya)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}
                <FormField control={form.control} name="orderNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order Number *</FormLabel>
                    <FormControl><Input placeholder="WO-IN-001" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Site *</FormLabel>
                    <Select onValueChange={(v) => {
                      field.onChange(v);
                      const site = sites?.find((s) => s._id === v);
                      if (site) form.setValue("companyId", site.companyId);
                    }} value={field.value}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name} — {s.city}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Show Client field for incoming, Contractor for outgoing */}
                {watchOrderType === "incoming" ? (
                  <FormField control={form.control} name="clientId" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client (jo kaam diya)</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ?? ""}>
                        <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select client" /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="none">No client</SelectItem>
                          {clients?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                ) : (
                  <FormField control={form.control} name="contractorId" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contractor / Subcontractor *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ?? ""}>
                        <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select contractor" /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="none">Not assigned</SelectItem>
                          {contractors?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                )}

                <FormField control={form.control} name="companyId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Our Company *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select company" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {companies?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    {selectedSite && <p className="text-xs text-muted-foreground">Auto-filled from site</p>}
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="totalValue" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Value (₹) *</FormLabel>
                    <FormControl><Input type="number" placeholder="5000000" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="issueDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Issue Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="startDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="endDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Scope / Description *</FormLabel>
                    <FormControl><Textarea placeholder="Describe the scope of work..." rows={3} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="terms" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Terms & Conditions</FormLabel>
                    <FormControl><Textarea placeholder="Payment terms, milestones..." rows={2} {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Create"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Work Order</DialogTitle></DialogHeader>
          <p className="text-muted-foreground text-sm">This will permanently delete the work order and cannot be undone.</p>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteId) return;
              try { await removeWO({ id: deleteId as Id<"workOrders"> }); toast.success("Deleted"); }
              catch { toast.error("Failed"); }
              setDeleteId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
