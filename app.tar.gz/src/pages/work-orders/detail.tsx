import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  ArrowLeft, Building2, UserCheck, MapPin, CalendarDays,
  IndianRupee, TrendingUp, TrendingDown, FilePen, History,
  CheckCircle2, Clock, XCircle, CreditCard, ArrowDownCircle, ArrowUpCircle,
  Wallet, Layers, RefreshCw, CheckCheck, AlertCircle,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  active: "bg-blue-500/10 text-blue-600",
  amended: "bg-orange-500/10 text-orange-600",
  completed: "bg-green-500/10 text-green-600",
  cancelled: "bg-red-500/10 text-red-600",
};

const STATUS_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  draft: Clock,
  active: TrendingUp,
  amended: FilePen,
  completed: CheckCircle2,
  cancelled: XCircle,
};

const PAYMENT_MODES = ["cash", "cheque", "neft", "rtgs", "upi", "other"] as const;
type PaymentMode = typeof PAYMENT_MODES[number];

export default function WorkOrderDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const woId = id as Id<"workOrders">;

  const detail = useQuery(api.workOrders.getDetail, id ? { id: woId } : "skip");
  const payments = useQuery(api.payments.listByWorkOrder, id ? { workOrderId: woId } : "skip");
  const milestones = useQuery(api.workOrderMilestones.listByWorkOrder, id ? { workOrderId: woId } : "skip");
  const addAmendment = useMutation(api.workOrders.addAmendment);
  const updateStatus = useMutation(api.workOrders.updateStatus);
  const recordFromClient = useMutation(api.payments.recordFromClient);
  const generateMilestones = useMutation(api.workOrderMilestones.generateMilestones);
  const markCompleted = useMutation(api.workOrderMilestones.markCompleted);
  const revertToPending = useMutation(api.workOrderMilestones.revertToPending);
  const deleteAllMilestones = useMutation(api.workOrderMilestones.deleteAll);

  const [amendmentOpen, setAmendmentOpen] = useState(false);
  const [amendReason, setAmendReason] = useState("");
  const [amendValue, setAmendValue] = useState("");

  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState<string>("");

  const [paymentOpen, setPaymentOpen] = useState(false);
  const [payAmount, setPayAmount] = useState("");
  const [payDate, setPayDate] = useState(new Date().toISOString().split("T")[0]);
  const [payMode, setPayMode] = useState<PaymentMode>("neft");
  const [payRef, setPayRef] = useState("");
  const [payNotes, setPayNotes] = useState("");
  const [paySubmitting, setPaySubmitting] = useState(false);

  // Milestone states
  const [setupOpen, setSetupOpen] = useState(false);
  const [totalUnits, setTotalUnits] = useState("");
  const [unitLabel, setUnitLabel] = useState("Floor");
  const [setupLoading, setSetupLoading] = useState(false);
  const [completeDialogId, setCompleteDialogId] = useState<Id<"workOrderMilestones"> | null>(null);
  const [completionNote, setCompletionNote] = useState("");

  if (!detail) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const { workOrder: wo, site, client, company, amendments, financials } = detail;
  const StatusIcon = STATUS_ICON[wo.status] ?? Clock;
  const marginPct = financials.totalValue > 0
    ? ((financials.margin / financials.totalValue) * 100).toFixed(1)
    : "0";
  const receivedPct = financials.totalValue > 0
    ? Math.min((financials.totalReceived / financials.totalValue) * 100, 100)
    : 0;

  async function submitAmendment() {
    const val = parseFloat(amendValue);
    if (!amendReason.trim() || isNaN(val) || val <= 0) {
      toast.error("Please fill in reason and valid new value");
      return;
    }
    try {
      await addAmendment({ workOrderId: woId, reason: amendReason.trim(), newValue: val });
      toast.success("Amendment added");
      setAmendmentOpen(false);
      setAmendReason("");
      setAmendValue("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  async function changeStatus() {
    if (!newStatus) return;
    try {
      await updateStatus({ id: woId, status: newStatus as "draft" | "active" | "amended" | "completed" | "cancelled" });
      toast.success("Status updated");
      setStatusDialogOpen(false);
    } catch {
      toast.error("Failed");
    }
  }

  async function submitPayment() {
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) { toast.error("Enter a valid amount"); return; }
    if (!detail?.workOrder.clientId) { toast.error("No client on this work order"); return; }
    setPaySubmitting(true);
    try {
      await recordFromClient({
        siteId: wo.siteId,
        clientId: wo.clientId as Id<"clients">,
        workOrderId: woId,
        amount: amt,
        date: payDate,
        mode: payMode,
        referenceNumber: payRef.trim() || undefined,
        notes: payNotes.trim() || undefined,
      });
      toast.success("Payment recorded");
      setPaymentOpen(false);
      setPayAmount("");
      setPayRef("");
      setPayNotes("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setPaySubmitting(false);
    }
  }

  async function handleGenerateMilestones() {
    const n = parseInt(totalUnits);
    if (isNaN(n) || n < 1 || n > 500) { toast.error("Valid number of units chahiye (1-500)"); return; }
    if (!unitLabel.trim()) { toast.error("Unit label enter karo"); return; }
    setSetupLoading(true);
    try {
      await generateMilestones({ workOrderId: woId, totalUnits: n, unitLabel: unitLabel.trim() });
      toast.success(`${n} ${unitLabel} milestones create ho gaye`);
      setSetupOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSetupLoading(false);
    }
  }

  async function handleMarkCompleted() {
    if (!completeDialogId) return;
    try {
      await markCompleted({ id: completeDialogId, note: completionNote.trim() || undefined });
      toast.success("Milestone completed! Billing team ko dikhega.");
      setCompleteDialogId(null);
      setCompletionNote("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  async function handleRevert(milestoneId: Id<"workOrderMilestones">) {
    try {
      await revertToPending({ id: milestoneId });
      toast.success("Milestone pending pe revert ho gaya");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  const pendingCount = (milestones ?? []).filter((m) => m.status === "pending").length;
  const completedCount = (milestones ?? []).filter((m) => m.status === "completed").length;
  const billedCount = (milestones ?? []).filter((m) => m.status === "billed").length;
  const billedAmount = (milestones ?? []).filter((m) => m.status === "billed").reduce((s, m) => s + m.amount, 0);
  const completedUnbilledAmount = (milestones ?? []).filter((m) => m.status === "completed").reduce((s, m) => s + m.amount, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4 flex-wrap">
        <Button variant="ghost" size="icon" className="cursor-pointer mt-1" onClick={() => navigate("/work-orders")}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <StatusIcon className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{wo.orderNumber}</h1>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[wo.status]}`}>
                  {wo.status}
                </span>
                <span className="text-muted-foreground text-sm">v{wo.version}</span>
                {amendments.length > 0 && (
                  <span className="text-orange-500 text-sm">{amendments.length} amendment{amendments.length > 1 ? "s" : ""}</span>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="secondary" className="cursor-pointer" onClick={() => { setNewStatus(wo.status); setStatusDialogOpen(true); }}>
            Change Status
          </Button>
          <Button variant="secondary" className="cursor-pointer" onClick={() => setAmendmentOpen(true)}>
            <FilePen className="w-4 h-4 mr-1" /> Amendment
          </Button>
          <Button className="cursor-pointer" onClick={() => setPaymentOpen(true)}>
            <CreditCard className="w-4 h-4 mr-1" /> Record Payment
          </Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <IndianRupee className="w-8 h-8 text-blue-500 bg-blue-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Contract Value</p>
              <p className="font-bold text-lg">₹{(financials.totalValue / 100000).toFixed(2)}L</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <ArrowDownCircle className="w-8 h-8 text-green-500 bg-green-500/10 rounded-lg p-1.5 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Received</p>
              <p className="font-bold text-lg text-green-600">₹{(financials.totalReceived / 100000).toFixed(2)}L</p>
              <p className="text-xs text-muted-foreground">{receivedPct.toFixed(0)}% collected</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <Wallet className={`w-8 h-8 rounded-lg p-1.5 flex-shrink-0 ${financials.balanceDue > 0 ? "text-red-500 bg-red-500/10" : "text-green-500 bg-green-500/10"}`} />
            <div>
              <p className="text-xs text-muted-foreground">Balance Due</p>
              <p className={`font-bold text-lg ${financials.balanceDue > 0 ? "text-red-600" : "text-green-600"}`}>
                ₹{(Math.abs(financials.balanceDue) / 100000).toFixed(2)}L
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <TrendingUp className={`w-8 h-8 rounded-lg p-1.5 flex-shrink-0 ${financials.margin >= 0 ? "text-green-500 bg-green-500/10" : "text-red-500 bg-red-500/10"}`} />
            <div>
              <p className="text-xs text-muted-foreground">Margin ({marginPct}%)</p>
              <p className={`font-bold text-lg ${financials.margin >= 0 ? "text-green-600" : "text-red-600"}`}>
                ₹{(Math.abs(financials.margin) / 100000).toFixed(2)}L
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment progress bar */}
      <Card>
        <CardContent className="px-4 py-4">
          <div className="flex items-center justify-between mb-2 text-sm">
            <span className="text-muted-foreground font-medium">Payment Collection Progress</span>
            <span className="font-semibold">{receivedPct.toFixed(1)}%</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${receivedPct >= 100 ? "bg-green-500" : "bg-blue-500"}`}
              style={{ width: `${receivedPct}%` }}
            />
          </div>
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            <span>Received: ₹{financials.totalReceived.toLocaleString("en-IN")}</span>
            <span>Total: ₹{financials.totalValue.toLocaleString("en-IN")}</span>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Details + Cost breakdown */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Work Order Details</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {site && (
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">{site.name}</p>
                    <p className="text-muted-foreground text-xs">{site.city}</p>
                  </div>
                </div>
              )}
              {client && (
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-muted-foreground" />
                  <span>{client.name}</span>
                </div>
              )}
              {company && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-muted-foreground" />
                  <span>{company.name}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-muted-foreground" />
                <span>Issued: {wo.issueDate}</span>
              </div>
              {wo.startDate && (
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-muted-foreground" />
                  <span>Start: {wo.startDate}</span>
                </div>
              )}
              {wo.endDate && (
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-muted-foreground" />
                  <span>End: {wo.endDate}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Scope of Work</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground leading-relaxed">{wo.description}</p>
            </CardContent>
          </Card>

          {wo.terms && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Terms & Conditions</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">{wo.terms}</p>
              </CardContent>
            </Card>
          )}

          {/* Cost breakdown */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Cost Breakdown</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              {[
                { label: "Materials", value: financials.materialsCost, color: "bg-orange-500" },
                { label: "Labour Salary", value: financials.salaryCost, color: "bg-blue-500" },
              ].map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between mb-1">
                    <span className="text-muted-foreground">{item.label}</span>
                    <span className="font-medium">₹{item.value.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full`}
                      style={{ width: financials.totalValue > 0 ? `${Math.min((item.value / financials.totalValue) * 100, 100)}%` : "0%" }}
                    />
                  </div>
                </div>
              ))}
              <div className="pt-2 border-t border-border">
                <div className="flex justify-between text-muted-foreground mb-1">
                  <span>Paid to Vendors</span>
                  <span className="text-red-600 font-medium">₹{financials.paidToVendors.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between font-semibold">
                  <span>Margin ({marginPct}%)</span>
                  <span className={financials.margin >= 0 ? "text-green-600" : "text-red-600"}>
                    ₹{financials.margin.toLocaleString("en-IN")}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right: Tabs for Milestones, Amendments + Payments */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="milestones">
            <TabsList className="mb-4">
              <TabsTrigger value="milestones" className="cursor-pointer">
                <Layers className="w-3.5 h-3.5 mr-1.5" />
                Progress Billing
                {completedCount > 0 && (
                  <span className="ml-1.5 bg-orange-500 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">
                    {completedCount} pending bill
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="amendments" className="cursor-pointer">
                <History className="w-3.5 h-3.5 mr-1.5" /> Amendments ({amendments.length})
              </TabsTrigger>
              <TabsTrigger value="payments" className="cursor-pointer">
                <CreditCard className="w-3.5 h-3.5 mr-1.5" /> Payments ({payments?.length ?? 0})
              </TabsTrigger>
            </TabsList>

            {/* ── MILESTONES TAB ── */}
            <TabsContent value="milestones">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div>
                      <CardTitle className="text-base">Progress Billing Milestones</CardTitle>
                      {milestones && milestones.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {wo.totalUnits} {wo.unitLabel ?? "Units"} · {pendingCount} pending · {completedCount} completed (billing due) · {billedCount} billed
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {milestones && milestones.length > 0 && (
                        <Button
                          size="sm" variant="secondary" className="cursor-pointer text-xs h-8"
                          onClick={() => {
                            setTotalUnits(wo.totalUnits?.toString() ?? "");
                            setUnitLabel(wo.unitLabel ?? "Floor");
                            setSetupOpen(true);
                          }}
                        >
                          <RefreshCw className="w-3 h-3 mr-1" /> Regenerate
                        </Button>
                      )}
                      <Button
                        size="sm" className="cursor-pointer text-xs h-8"
                        onClick={() => {
                          setTotalUnits(wo.totalUnits?.toString() ?? "");
                          setUnitLabel(wo.unitLabel ?? "Floor");
                          setSetupOpen(true);
                        }}
                      >
                        <Layers className="w-3 h-3 mr-1" />
                        {milestones && milestones.length > 0 ? "Edit Setup" : "Setup Milestones"}
                      </Button>
                    </div>
                  </div>

                  {/* Summary strip */}
                  {milestones && milestones.length > 0 && (
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div className="rounded-lg bg-orange-500/10 px-3 py-2 text-center">
                        <p className="text-[10px] text-muted-foreground">Billing Due (Completed)</p>
                        <p className="font-bold text-orange-600 text-sm">₹{completedUnbilledAmount.toLocaleString("en-IN")}</p>
                      </div>
                      <div className="rounded-lg bg-green-500/10 px-3 py-2 text-center">
                        <p className="text-[10px] text-muted-foreground">Billed So Far</p>
                        <p className="font-bold text-green-600 text-sm">₹{billedAmount.toLocaleString("en-IN")}</p>
                      </div>
                      <div className="rounded-lg bg-muted/50 px-3 py-2 text-center">
                        <p className="text-[10px] text-muted-foreground">Per {wo.unitLabel ?? "Unit"}</p>
                        <p className="font-bold text-foreground text-sm">
                          ₹{milestones[0] ? milestones[0].amount.toLocaleString("en-IN") : "—"}
                        </p>
                      </div>
                    </div>
                  )}
                </CardHeader>
                <CardContent className="p-0">
                  {!milestones || milestones.length === 0 ? (
                    <div className="px-4 py-10 text-center">
                      <Layers className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-30" />
                      <p className="font-medium text-sm mb-1">Milestones setup nahi hai</p>
                      <p className="text-xs text-muted-foreground mb-4">
                        "Setup Milestones" click karo aur total floors/phases enter karo.<br />
                        Amount automatically split ho jaayega.
                      </p>
                      <Button size="sm" className="cursor-pointer" onClick={() => setSetupOpen(true)}>
                        <Layers className="w-3.5 h-3.5 mr-1.5" /> Setup Progress Billing
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                          <tr>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground text-xs w-10">#</th>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground text-xs">Name</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground text-xs">%</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground text-xs">Amount</th>
                            <th className="text-center px-4 py-2 font-medium text-muted-foreground text-xs">Status</th>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground text-xs">Completed By</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground text-xs">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                          {milestones.map((m) => (
                            <tr key={m._id} className={`${m.status === "completed" ? "bg-orange-50/50 dark:bg-orange-900/10" : m.status === "billed" ? "bg-green-50/50 dark:bg-green-900/10" : ""}`}>
                              <td className="px-4 py-2.5 text-muted-foreground text-xs">{m.unitNumber}</td>
                              <td className="px-4 py-2.5 font-medium">{m.name}</td>
                              <td className="px-4 py-2.5 text-right text-xs text-muted-foreground">{m.percentage.toFixed(2)}%</td>
                              <td className="px-4 py-2.5 text-right font-semibold">₹{m.amount.toLocaleString("en-IN")}</td>
                              <td className="px-4 py-2.5 text-center">
                                {m.status === "pending" && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                                    <Clock className="w-3 h-3" /> Pending
                                  </span>
                                )}
                                {m.status === "completed" && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400">
                                    <AlertCircle className="w-3 h-3" /> Billing Due
                                  </span>
                                )}
                                {m.status === "billed" && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                    <CheckCheck className="w-3 h-3" /> Billed
                                  </span>
                                )}
                              </td>
                              <td className="px-4 py-2.5 text-xs text-muted-foreground">
                                {m.status !== "pending" && m.completedAt ? (
                                  <div>
                                    <p>{m.completedAt.split("T")[0]}</p>
                                    {m.completionNote && <p className="text-[10px] italic">{m.completionNote}</p>}
                                  </div>
                                ) : "—"}
                              </td>
                              <td className="px-4 py-2.5 text-right">
                                {m.status === "pending" && (
                                  <Button
                                    size="sm" variant="secondary" className="cursor-pointer text-xs h-7 gap-1"
                                    onClick={() => { setCompleteDialogId(m._id); setCompletionNote(""); }}
                                  >
                                    <CheckCircle2 className="w-3 h-3" /> Mark Done
                                  </Button>
                                )}
                                {m.status === "completed" && (
                                  <div className="flex gap-1 justify-end">
                                    <Button
                                      size="sm" variant="ghost" className="cursor-pointer text-xs h-7 text-muted-foreground"
                                      onClick={() => void handleRevert(m._id)}
                                    >
                                      Undo
                                    </Button>
                                  </div>
                                )}
                                {m.status === "billed" && (
                                  <span className="text-xs text-green-600 font-medium">✓</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="amendments">
              <Card>
                <CardContent className="p-0">
                  {amendments.length === 0 ? (
                    <div className="px-4 py-8 text-center">
                      <History className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-40" />
                      <p className="text-muted-foreground text-sm">No amendments yet</p>
                      <p className="text-xs text-muted-foreground mt-1">Click "Amendment" to create a change order</p>
                    </div>
                  ) : (
                    <div className="relative">
                      {/* Original value */}
                      <div className="px-4 py-4 flex items-start gap-4 border-b border-border">
                        <div className="flex flex-col items-center">
                          <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                            <span className="text-blue-500 font-bold text-xs">v1</span>
                          </div>
                          <div className="w-0.5 flex-1 bg-border mt-1 min-h-[20px]" />
                        </div>
                        <div className="flex-1 min-w-0 pb-2">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-sm">Original Work Order</p>
                            <p className="font-bold text-sm">₹{(amendments[0]?.previousValue ?? wo.totalValue).toLocaleString("en-IN")}</p>
                          </div>
                          <p className="text-xs text-muted-foreground">{wo.issueDate}</p>
                        </div>
                      </div>

                      {amendments.map((a, i) => (
                        <div key={a._id} className="px-4 py-4 flex items-start gap-4 border-b border-border last:border-0">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                              <span className="text-orange-500 font-bold text-xs">v{i + 2}</span>
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <p className="font-medium text-sm">Amendment #{a.amendmentNumber}</p>
                                <p className="text-xs text-muted-foreground mt-0.5">{a.reason}</p>
                                {a.approverName && (
                                  <p className="text-xs text-muted-foreground">Approved by: {a.approverName}</p>
                                )}
                              </div>
                              <div className="text-right flex-shrink-0">
                                <div className="flex items-center gap-2 text-sm">
                                  <span className="text-muted-foreground line-through text-xs">₹{a.previousValue.toLocaleString("en-IN")}</span>
                                  <span className="font-bold text-orange-600">₹{a.newValue.toLocaleString("en-IN")}</span>
                                </div>
                                <p className={`text-xs font-medium ${a.newValue > a.previousValue ? "text-green-600" : "text-red-600"}`}>
                                  {a.newValue > a.previousValue ? "+" : ""}₹{(a.newValue - a.previousValue).toLocaleString("en-IN")}
                                </p>
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">{a.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payments">
              <Card>
                {/* Payment summary bar */}
                <CardHeader className="pb-2">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="rounded-lg bg-green-500/10 px-3 py-2 text-center">
                      <p className="text-xs text-muted-foreground">Received from Client</p>
                      <p className="font-bold text-green-600 text-sm">₹{financials.totalReceived.toLocaleString("en-IN")}</p>
                    </div>
                    <div className="rounded-lg bg-red-500/10 px-3 py-2 text-center">
                      <p className="text-xs text-muted-foreground">Paid to Vendors</p>
                      <p className="font-bold text-red-600 text-sm">₹{financials.paidToVendors.toLocaleString("en-IN")}</p>
                    </div>
                    <div className="rounded-lg bg-blue-500/10 px-3 py-2 text-center">
                      <p className="text-xs text-muted-foreground">Balance Due</p>
                      <p className={`font-bold text-sm ${financials.balanceDue > 0 ? "text-red-600" : "text-green-600"}`}>
                        ₹{financials.balanceDue.toLocaleString("en-IN")}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  {!payments || payments.length === 0 ? (
                    <div className="px-4 py-8 text-center">
                      <CreditCard className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-40" />
                      <p className="text-muted-foreground text-sm">No payments recorded</p>
                      <p className="text-xs text-muted-foreground mt-1">Click "Record Payment" to add a payment</p>
                    </div>
                  ) : (
                    <div>
                      {payments.map((p) => (
                        <div key={p._id} className="px-4 py-3 flex items-center gap-3 border-b border-border last:border-0">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            p.type === "received" ? "bg-green-500/10" : "bg-red-500/10"
                          }`}>
                            {p.type === "received"
                              ? <ArrowDownCircle className="w-4 h-4 text-green-600" />
                              : <ArrowUpCircle className="w-4 h-4 text-red-500" />
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-sm truncate">{p.partyName}</p>
                              <p className={`font-bold text-sm flex-shrink-0 ml-2 ${p.type === "received" ? "text-green-600" : "text-red-600"}`}>
                                {p.type === "received" ? "+" : "-"}₹{p.amount.toLocaleString("en-IN")}
                              </p>
                            </div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-xs text-muted-foreground">{p.date}</span>
                              <Badge variant="secondary" className="text-xs px-1.5 py-0">{p.mode.toUpperCase()}</Badge>
                              {p.referenceNumber && <span className="text-xs text-muted-foreground">Ref: {p.referenceNumber}</span>}
                            </div>
                            {p.notes && <p className="text-xs text-muted-foreground mt-0.5 truncate">{p.notes}</p>}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Setup Milestones Dialog */}
      <Dialog open={setupOpen} onOpenChange={setSetupOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Progress Billing Setup</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-3 text-sm">
              <p className="font-medium text-blue-600 mb-1">Work Order Value</p>
              <p className="text-2xl font-bold">₹{wo.totalValue.toLocaleString("en-IN")}</p>
            </div>
            <div className="space-y-1.5">
              <Label>Unit Type (e.g. Floor, Phase, Block) *</Label>
              <Input
                placeholder="Floor"
                value={unitLabel}
                onChange={(e) => setUnitLabel(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Total Number of {unitLabel || "Units"} *</Label>
              <Input
                type="number"
                placeholder="e.g. 27"
                value={totalUnits}
                onChange={(e) => setTotalUnits(e.target.value)}
              />
            </div>
            {totalUnits && !isNaN(parseInt(totalUnits)) && parseInt(totalUnits) > 0 && (
              <div className="rounded-lg bg-muted/50 p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Per {unitLabel || "unit"} amount</span>
                  <span className="font-bold">₹{Math.round(wo.totalValue / parseInt(totalUnits)).toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Per {unitLabel || "unit"} percentage</span>
                  <span className="font-bold">{(100 / parseInt(totalUnits)).toFixed(2)}%</span>
                </div>
                <p className="text-xs text-muted-foreground pt-1">
                  ⚠ Existing milestones delete ho jaayenge aur naye create honge
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setSetupOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button onClick={() => void handleGenerateMilestones()} disabled={setupLoading} className="cursor-pointer">
              {setupLoading ? "Creating..." : "Generate Milestones"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mark Completed Dialog */}
      <Dialog open={!!completeDialogId} onOpenChange={() => setCompleteDialogId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Milestone Complete Mark Karen</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Yeh milestone complete mark ho jaayega aur billing team ko dikhayi dega.
          </p>
          <div className="space-y-1.5">
            <Label>Note (optional)</Label>
            <Textarea
              placeholder="e.g. Inspection done, photos uploaded..."
              value={completionNote}
              onChange={(e) => setCompletionNote(e.target.value)}
              rows={2}
            />
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setCompleteDialogId(null)} className="cursor-pointer">Cancel</Button>
            <Button onClick={() => void handleMarkCompleted()} className="cursor-pointer">
              <CheckCircle2 className="w-4 h-4 mr-1" /> Mark as Completed
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Amendment Dialog */}
      <Dialog open={amendmentOpen} onOpenChange={setAmendmentOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Amendment (Change Order)</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Current value</p>
              <p className="font-bold text-lg">₹{wo.totalValue.toLocaleString("en-IN")}</p>
            </div>
            <div className="space-y-1.5">
              <Label>Reason for Amendment *</Label>
              <Textarea
                placeholder="Describe the reason for this change order..."
                value={amendReason}
                onChange={(e) => setAmendReason(e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-1.5">
              <Label>New Contract Value (₹) *</Label>
              <Input
                type="number"
                placeholder={wo.totalValue.toString()}
                value={amendValue}
                onChange={(e) => setAmendValue(e.target.value)}
              />
              {amendValue && !isNaN(parseFloat(amendValue)) && (
                <p className={`text-xs font-medium ${parseFloat(amendValue) > wo.totalValue ? "text-green-600" : "text-red-600"}`}>
                  Change: {parseFloat(amendValue) > wo.totalValue ? "+" : ""}₹{(parseFloat(amendValue) - wo.totalValue).toLocaleString("en-IN")}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setAmendmentOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" onClick={() => void submitAmendment()}>Save Amendment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Status Change Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Change Status</DialogTitle></DialogHeader>
          <Select value={newStatus} onValueChange={setNewStatus}>
            <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setStatusDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" onClick={() => void changeStatus()}>Update</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Record Payment Dialog */}
      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Record Payment from Client</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg bg-muted/50 p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Contract Value</span>
                <span className="font-semibold">₹{wo.totalValue.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-muted-foreground">Already Received</span>
                <span className="font-semibold text-green-600">₹{financials.totalReceived.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between mt-1 border-t border-border pt-1">
                <span className="text-muted-foreground">Balance Due</span>
                <span className={`font-bold ${financials.balanceDue > 0 ? "text-red-600" : "text-green-600"}`}>
                  ₹{financials.balanceDue.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Amount (₹) *</Label>
                <Input type="number" placeholder="0" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Date *</Label>
                <Input type="date" value={payDate} onChange={(e) => setPayDate(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Payment Mode *</Label>
                <Select value={payMode} onValueChange={(v) => setPayMode(v as PaymentMode)}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PAYMENT_MODES.map((m) => <SelectItem key={m} value={m}>{m.toUpperCase()}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Reference No.</Label>
                <Input placeholder="UTR / Cheque no." value={payRef} onChange={(e) => setPayRef(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea placeholder="Optional notes..." value={payNotes} onChange={(e) => setPayNotes(e.target.value)} rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setPaymentOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={paySubmitting} onClick={() => void submitPayment()}>
              {paySubmitting ? "Saving..." : "Record Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
