import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { HardHat, Clock, XCircle, LogOut, Upload, Camera, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const ROLES = [
  { value: "contractor", label: "Contractor / Thekedaar" },
  { value: "supplier", label: "Supplier / Saamaan Dene Wala" },
  { value: "site_supervisor", label: "Site Supervisor" },
  { value: "safety_supervisor", label: "Safety Supervisor" },
  { value: "labour", label: "Labour / Worker" },
  { value: "other", label: "Other / Staff" },
] as const;

const schema = z.object({
  name: z.string().min(2, "Name kam se kam 2 characters ka hona chahiye"),
  mobile: z.string().min(10, "Mobile number sahi daalo").max(15),
  requestedRole: z.enum(["contractor", "supplier", "site_supervisor", "safety_supervisor", "labour", "other"]),
  companyId: z.string().optional(),
  companyName: z.string().optional(),
  siteId: z.string().optional(),
  note: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

// ---- Pending Screen ----
function PendingScreen({ adminNote }: { adminNote?: string }) {
  const { signout } = useAuth();
  return (
    <div className="min-h-screen bg-[oklch(0.14_0.025_250)] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center space-y-5">
        <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8 text-amber-500" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">Request Pending Hai</h2>
          <p className="text-gray-500 text-sm mt-2">
            Aapka registration request submit ho gaya hai. Admin verification ke baad aapko access milega.
          </p>
          {adminNote && (
            <div className="mt-3 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
              Admin ka note: {adminNote}
            </div>
          )}
        </div>
        <p className="text-xs text-gray-400">Agar koi problem ho toh admin se contact karein.</p>
        <Button variant="ghost" onClick={() => void signout()} className="cursor-pointer w-full gap-2 text-gray-500">
          <LogOut className="w-4 h-4" /> Sign Out
        </Button>
      </div>
    </div>
  );
}

// ---- Rejected Screen ----
function RejectedScreen({ adminNote, onReapply }: { adminNote?: string; onReapply: () => void }) {
  const { signout } = useAuth();
  return (
    <div className="min-h-screen bg-[oklch(0.14_0.025_250)] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center space-y-5">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
          <XCircle className="w-8 h-8 text-red-500" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">Request Reject Hua</h2>
          <p className="text-gray-500 text-sm mt-2">Aapka registration request admin ne reject kar diya.</p>
          {adminNote && (
            <div className="mt-3 bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
              Reason: {adminNote}
            </div>
          )}
        </div>
        <Button onClick={onReapply} className="cursor-pointer w-full">Dobara Apply Karein</Button>
        <Button variant="ghost" onClick={() => void signout()} className="cursor-pointer w-full gap-2 text-gray-500">
          <LogOut className="w-4 h-4" /> Sign Out
        </Button>
      </div>
    </div>
  );
}

// ---- File Upload Button ----
function FileUploadButton({ label, icon: Icon, file, onFileChange, accept }: {
  label: string;
  icon: typeof Upload;
  file: File | null;
  onFileChange: (f: File | null) => void;
  accept: string;
}) {
  return (
    <div>
      <label className="text-sm font-semibold text-gray-800 block mb-1.5">
        {label}
      </label>
      <div className="flex items-center gap-3">
        <label className="cursor-pointer flex items-center gap-2 px-4 py-2.5 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-200 transition-colors">
          <Icon className="w-4 h-4" />
          {file ? file.name.slice(0, 25) : "Choose File"}
          <input
            type="file"
            accept={accept}
            className="hidden"
            onChange={(e) => onFileChange(e.target.files?.[0] ?? null)}
          />
        </label>
        {file && (
          <button type="button" onClick={() => onFileChange(null)} className="text-xs text-red-500 cursor-pointer">
            Hatao
          </button>
        )}
      </div>
    </div>
  );
}

// ---- Main Registration Page ----
export default function RegisterPage() {
  const navigate = useNavigate();
  const { user, signout } = useAuth();
  const submitRegistration = useMutation(api.registration.submitRegistration);
  const generateUploadUrl = useMutation(api.registration.generateUploadUrl);
  const myReg = useQuery(api.registration.getMyRegistration);
  const currentUser = useQuery(api.users.getCurrentUserQuery);
  const companies = useQuery(api.registration.getCompanies);
  const [showForm, setShowForm] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [aadhaarFile, setAadhaarFile] = useState<File | null>(null);
  const [panFile, setPanFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const sites = useQuery(
    api.registration.getSitesByCompany,
    selectedCompanyId ? { companyId: selectedCompanyId as Id<"companies"> } : "skip"
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: user?.profile.name ?? "",
      mobile: "",
      requestedRole: "other",
      companyId: "",
      companyName: "",
      siteId: "",
      note: "",
    },
  });

  // If user is already approved / has a real role → redirect to dashboard
  if (currentUser && currentUser.role !== "pending") {
    navigate("/dashboard", { replace: true });
    return null;
  }

  // Show pending/rejected screen based on registration status
  if (myReg && !showForm) {
    if (myReg.status === "pending") return <PendingScreen adminNote={myReg.adminNote} />;
    if (myReg.status === "rejected") return <RejectedScreen adminNote={myReg.adminNote} onReapply={() => setShowForm(true)} />;
  }

  const uploadFile = async (file: File): Promise<string> => {
    const url = await generateUploadUrl();
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": file.type },
      body: file,
    });
    const { storageId } = await response.json();
    return storageId as string;
  };

  const onSubmit = async (values: FormValues) => {
    try {
      setUploading(true);
      let photoStorageId: string | undefined;
      let aadhaarStorageId: string | undefined;
      let panStorageId: string | undefined;

      if (photoFile) photoStorageId = await uploadFile(photoFile);
      if (aadhaarFile) aadhaarStorageId = await uploadFile(aadhaarFile);
      if (panFile) panStorageId = await uploadFile(panFile);

      await submitRegistration({
        name: values.name,
        mobile: values.mobile,
        requestedRole: values.requestedRole,
        companyId: values.companyId ? (values.companyId as Id<"companies">) : undefined,
        companyName: values.companyName || undefined,
        siteId: values.siteId ? (values.siteId as Id<"sites">) : undefined,
        note: values.note || undefined,
        photoStorageId,
        aadhaarStorageId,
        panStorageId,
      });
      toast.success("Registration request submit ho gaya! Admin approve karega.");
      setShowForm(false);
    } catch {
      toast.error("Kuch gadbad hua, dobara try karein.");
    } finally {
      setUploading(false);
    }
  };

  const watchedRole = form.watch("requestedRole");

  return (
    <div className="min-h-screen bg-[oklch(0.14_0.025_250)] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden">
        {/* Header */}
        <div className="bg-primary px-8 py-6 text-white">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-9 h-9 bg-white/20 rounded-lg flex items-center justify-center">
              <HardHat className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg">JAI SITE MANAGER ERP</span>
          </div>
          <h1 className="text-2xl font-bold mt-3">Registration Form</h1>
          <p className="text-white/70 text-sm mt-1">Apni details bharo. Admin verify karke access dega.</p>
        </div>

        {/* Form */}
        <div className="px-8 py-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">

              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800 font-semibold">Poora Naam *</FormLabel>
                  <FormControl>
                    <Input placeholder="Jaise: Rajesh Kumar" className="h-11 text-gray-900" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="mobile" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800 font-semibold">Mobile Number *</FormLabel>
                  <FormControl>
                    <Input placeholder="9876543210" type="tel" className="h-11 text-gray-900" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="requestedRole" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800 font-semibold">Aap Kya Hain? *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="h-11 text-gray-900">
                        <SelectValue placeholder="Role select karein..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ROLES.map(r => (
                        <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Company Dropdown */}
              <FormField control={form.control} name="companyId" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800 font-semibold">Konsi Company Me? *</FormLabel>
                  <Select onValueChange={(val) => {
                    field.onChange(val);
                    setSelectedCompanyId(val);
                    // Set company name too
                    const comp = companies?.find(c => c._id === val);
                    if (comp) form.setValue("companyName", comp.name);
                    form.setValue("siteId", "");
                  }} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="h-11 text-gray-900">
                        <SelectValue placeholder="Company select karo..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {companies?.map((c) => (
                        <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Site Dropdown */}
              <FormField control={form.control} name="siteId" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800 font-semibold">Konsi Site Pe?</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value} disabled={!selectedCompanyId}>
                    <FormControl>
                      <SelectTrigger className="h-11 text-gray-900">
                        <SelectValue placeholder={selectedCompanyId ? "Site select karo..." : "Pehle company select karo"} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {sites?.map((s) => (
                        <SelectItem key={s._id} value={s._id}>{s.name} — {s.city}</SelectItem>
                      ))}
                      {sites?.length === 0 && (
                        <div className="px-3 py-2 text-sm text-muted-foreground">Is company ki koi active site nahi hai</div>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Contractor specific: company name if needed */}
              {watchedRole === "contractor" && (
                <FormField control={form.control} name="companyName" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Aapki Firm / Company Ka Naam</FormLabel>
                    <FormControl>
                      <Input placeholder="Jaise: Sharma Construction" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              )}

              {/* Document Uploads */}
              <div className="border-t border-gray-200 pt-4 mt-4">
                <p className="text-sm font-semibold text-gray-800 mb-3">Documents Upload Karo</p>

                <div className="space-y-3">
                  {/* Photo */}
                  <FileUploadButton
                    label="Apni Photo (Selfie)"
                    icon={Camera}
                    file={photoFile}
                    onFileChange={setPhotoFile}
                    accept="image/*"
                  />

                  {/* Aadhaar */}
                  <FileUploadButton
                    label="Aadhaar Card Photo"
                    icon={Upload}
                    file={aadhaarFile}
                    onFileChange={setAadhaarFile}
                    accept="image/*,.pdf"
                  />

                  {/* PAN - for contractors */}
                  {watchedRole === "contractor" && (
                    <FileUploadButton
                      label="PAN Card Photo"
                      icon={CreditCard}
                      file={panFile}
                      onFileChange={setPanFile}
                      accept="image/*,.pdf"
                    />
                  )}
                </div>
              </div>

              <FormField control={form.control} name="note" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-800">Koi Baat Admin Ko Batani Hai? (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Jaise: Main Site T07 pe kaam karta hoon..." rows={2} className="text-gray-900 resize-none" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="pt-2 flex flex-col gap-2">
                <Button type="submit" className="cursor-pointer w-full h-11 text-base font-semibold" disabled={form.formState.isSubmitting || uploading}>
                  {uploading ? "Upload Ho Raha Hai..." : form.formState.isSubmitting ? "Submit Ho Raha Hai..." : "Submit Registration"}
                </Button>
                <Button type="button" variant="ghost" onClick={() => void signout()} className="cursor-pointer w-full gap-2 text-gray-500">
                  <LogOut className="w-4 h-4" /> Sign Out
                </Button>
              </div>

            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
