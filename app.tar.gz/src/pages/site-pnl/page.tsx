import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { toast } from "sonner";
import {
  BarChart3, Plus, Trash2, Pencil, TrendingUp, TrendingDown,
  IndianRupee, Truck, Utensils, Droplets, Wrench, ShieldCheck, Zap, Home, MoreHorizontal, Fuel,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
} from "recharts";
import { cn } from "@/lib/utils.ts";
import { Authenticated } from "convex/react";

type ExpenseCategory =
  | "food" | "water" | "transport" | "diesel"
  | "tools" | "safety" | "electricity" | "rent" | "miscellaneous";

type PaymentMode = "cash" | "upi" | "other";

const CATEGORIES: {
  value: ExpenseCategory;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  twColor: string;
}[] = [
  { value: "food", label: "Food", icon: Utensils, color: "#f97316", twColor: "text-orange-500" },
  { value: "water", label: "Water", icon: Droplets, color: "#3b82f6", twColor: "text-blue-500" },
  { value: "transport", label: "Transport", icon: Truck, color: "#8b5cf6", twColor: "text-purple-500" },
  { value: "diesel", label: "Diesel", icon: Fuel, color: "#ca8a04", twColor: "text-yellow-600" },
  { value: "tools", label: "Tools", icon: Wrench, color: "#6b7280", twColor: "text-gray-500" },
  { value: "safety", label: "Safety", icon: ShieldCheck, color: "#10b981", twColor: "text-emerald-500" },
  { value: "electricity", label: "Electricity", icon: Zap, color: "#f59e0b", twColor: "text-amber-500" },
  { value: "rent", label: "Rent", icon: Home, color: "#14b8a6", twColor: "text-teal-500" },
  { value: "miscellaneous", label: "Misc", icon: MoreHorizontal, color: "#9ca3af", twColor: "text-gray-400" },
];

function getCategoryInfo(cat: string) {
  return CATEGORIES.find((c) => c.value === cat) ?? CATEGORIES[8];
}

function fmt(n: number) {
  return "₹" + n.toLocaleString("en-IN");
}

type ExpenseRow = {
  _id: Id<"expenses">;
  siteId: Id<"sites">;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  paymentMode: PaymentMode;
  notes?: string;
  siteName: string;
  enteredByName: string;
};

type FormState = {
  siteId: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: string;
  paymentMode: PaymentMode;
  notes: string;
};

const EMPTY_FORM: FormState = {
  siteId: "",
  date: new Date().toISOString().split("T")[0],
  category: "food",
  description: "",
  amount: "",
  paymentMode: "cash",
  notes: "",
};

function SitePnLInner() {
  const sites = useQuery(api.sites.list, {});
  const [selectedSiteId, setSelectedSiteId] = useState<string>("");
  const allExpenses = useQuery(api.expenses.list, {}) as ExpenseRow[] | undefined;
  const createExpense = useMutation(api.expenses.create);
  const updateExpense = useMutation(api.expenses.update);
  const removeExpense = useMutation(api.expenses.remove);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<Id<"expenses"> | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const siteExpenses = (allExpenses ?? []).filter(
    (e) => !selectedSiteId || e.siteId === selectedSiteId
  );

  const summaryMap: Record<string, number> = {};
  for (const exp of siteExpenses) {
    summaryMap[exp.category] = (summaryMap[exp.category] ?? 0) + exp.amount;
  }
  const totalExpenses = Object.values(summaryMap).reduce((a, b) => a + b, 0);

  const pieData = CATEGORIES.filter((c) => (summaryMap[c.value] ?? 0) > 0).map((c) => ({
    name: c.label,
    value: summaryMap[c.value] ?? 0,
    color: c.color,
  }));

  function openAdd() {
    setEditId(null);
    setForm({ ...EMPTY_FORM, siteId: selectedSiteId });
    setDialogOpen(true);
  }

  function openEdit(exp: ExpenseRow) {
    setEditId(exp._id);
    setForm({
      siteId: exp.siteId,
      date: exp.date,
      category: exp.category,
      description: exp.description,
      amount: exp.amount.toString(),
      paymentMode: exp.paymentMode,
      notes: exp.notes ?? "",
    });
    setDialogOpen(true);
  }

  async function handleSubmit() {
    if (!form.siteId || !form.description.trim() || !form.amount) {
      toast.error("Please fill all required fields");
      return;
    }
    const amt = parseFloat(form.amount);
    if (isNaN(amt) || amt <= 0) { toast.error("Enter a valid amount"); return; }
    setSubmitting(true);
    try {
      if (editId) {
        await updateExpense({
          id: editId,
          date: form.date,
          category: form.category,
          description: form.description.trim(),
          amount: amt,
          paymentMode: form.paymentMode,
          notes: form.notes.trim() || undefined,
        });
        toast.success("Expense updated");
      } else {
        await createExpense({
          siteId: form.siteId as Id<"sites">,
          date: form.date,
          category: form.category,
          description: form.description.trim(),
          amount: amt,
          paymentMode: form.paymentMode,
          notes: form.notes.trim() || undefined,
        });
        toast.success("Expense added");
      }
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <BarChart3 className="w-6 h-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Site P&L Dashboard</h1>
            <p className="text-muted-foreground text-sm">Track expenses per site — food, diesel, transport, tools & more</p>
          </div>
        </div>
        <Button onClick={openAdd} className="cursor-pointer self-start sm:self-auto">
          <Plus className="w-4 h-4 mr-1" /> Add Expense
        </Button>
      </div>

      {/* Site filter */}
      <div className="flex flex-wrap gap-2 items-center">
        <button
          onClick={() => setSelectedSiteId("")}
          className={cn(
            "px-3 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer",
            !selectedSiteId ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
          )}
        >
          All Sites
        </button>
        {(sites ?? []).map((site) => (
          <button
            key={site._id}
            onClick={() => setSelectedSiteId(site._id)}
            className={cn(
              "px-3 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer",
              selectedSiteId === site._id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
            )}
          >
            {site.name}
          </button>
        ))}
      </div>

      {/* Summary cards */}
      {!allExpenses ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-1">
                <CardTitle className="text-sm text-muted-foreground font-normal flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-red-500" /> Total Expenses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-500">{fmt(totalExpenses)}</div>
                <div className="text-xs text-muted-foreground">{siteExpenses.length} entries</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1">
                <CardTitle className="text-sm text-muted-foreground font-normal flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-500" /> Work Order Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">—</div>
                <div className="text-xs text-muted-foreground">Add work orders to see revenue</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1">
                <CardTitle className="text-sm text-muted-foreground font-normal flex items-center gap-2">
                  <IndianRupee className="w-4 h-4 text-primary" /> Net P&L
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">—</div>
                <div className="text-xs text-muted-foreground">Revenue - Expenses</div>
              </CardContent>
            </Card>
          </div>

          {/* Category breakdown + chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div>
              <h2 className="font-semibold text-sm mb-3 text-muted-foreground uppercase tracking-wider">Expense Breakdown</h2>
              <div className="grid grid-cols-2 gap-2">
                {CATEGORIES.map((cat) => {
                  const amount = summaryMap[cat.value] ?? 0;
                  const pct = totalExpenses > 0 ? Math.round((amount / totalExpenses) * 100) : 0;
                  return (
                    <div
                      key={cat.value}
                      className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card"
                      style={{ borderLeftColor: cat.color, borderLeftWidth: 3 }}
                    >
                      <cat.icon className={cn("w-4 h-4 flex-shrink-0", cat.twColor)} />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs text-muted-foreground truncate">{cat.label}</div>
                        <div className="font-semibold text-sm">{fmt(amount)}</div>
                        {pct > 0 && <div className="text-xs text-muted-foreground">{pct}%</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <h2 className="font-semibold text-sm mb-3 text-muted-foreground uppercase tracking-wider">Expense Distribution</h2>
              <Card className="h-[300px] flex items-center justify-center">
                {pieData.length === 0 ? (
                  <div className="text-muted-foreground text-sm text-center p-6">
                    <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    No expenses recorded yet.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={260}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                      </Pie>
                      <Tooltip
                        formatter={(value: number) => fmt(value)}
                        contentStyle={{ fontSize: 12 }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </Card>
            </div>
          </div>

          {/* Expense list */}
          <div>
            <h2 className="font-semibold text-sm mb-3 text-muted-foreground uppercase tracking-wider">All Entries</h2>
            {siteExpenses.length === 0 ? (
              <div className="border border-dashed border-border rounded-xl p-8 text-center text-muted-foreground text-sm">
                No expenses recorded for {selectedSiteId ? "this site" : "any site"}.
              </div>
            ) : (
              <div className="rounded-lg border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Date</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Category</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground">Description</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                        <th className="text-right px-4 py-3 font-medium text-muted-foreground">Amount</th>
                        <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {siteExpenses
                        .slice()
                        .sort((a, b) => b.date.localeCompare(a.date))
                        .map((exp) => {
                          const cat = getCategoryInfo(exp.category);
                          return (
                            <tr key={exp._id} className="hover:bg-muted/30">
                              <td className="px-4 py-3 text-muted-foreground">{exp.date}</td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-1.5">
                                  <cat.icon className={cn("w-3.5 h-3.5", cat.twColor)} />
                                  <span className="text-xs">{cat.label}</span>
                                </div>
                              </td>
                              <td className="px-4 py-3">
                                <div>{exp.description}</div>
                                {exp.notes && <div className="text-xs text-muted-foreground">{exp.notes}</div>}
                              </td>
                              <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell text-xs">{exp.siteName}</td>
                              <td className="px-4 py-3 text-right font-semibold">{fmt(exp.amount)}</td>
                              <td className="px-4 py-3">
                                <div className="flex items-center justify-end gap-1">
                                  <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(exp)}>
                                    <Pencil className="w-3.5 h-3.5" />
                                  </Button>
                                  <Button
                                    size="icon" variant="ghost"
                                    className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                                    onClick={async () => {
                                      try { await removeExpense({ id: exp._id }); toast.success("Deleted"); }
                                      catch { toast.error("Failed"); }
                                    }}
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                    <tfoot className="bg-muted/30 border-t border-border font-semibold">
                      <tr>
                        <td colSpan={4} className="px-4 py-3 text-right">Total</td>
                        <td className="px-4 py-3 text-right text-red-500">{fmt(totalExpenses)}</td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* Add/Edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Expense" : "Add Expense"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {!editId && (
              <div className="space-y-1.5">
                <Label>Site *</Label>
                <Select value={form.siteId} onValueChange={(v) => setForm({ ...form, siteId: v })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger>
                  <SelectContent>
                    {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Date *</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Amount (₹) *</Label>
                <Input type="number" placeholder="0" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Category *</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as ExpenseCategory })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Payment Mode</Label>
                <Select value={form.paymentMode} onValueChange={(v) => setForm({ ...form, paymentMode: v as PaymentMode })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description *</Label>
              <Input placeholder="Lunch for 20 workers..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea placeholder="Optional notes..." rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={submitting} onClick={() => void handleSubmit()}>
              {submitting ? "Saving..." : editId ? "Update" : "Add Expense"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function SitePnL() {
  return (
    <Authenticated>
      <SitePnLInner />
    </Authenticated>
  );
}
