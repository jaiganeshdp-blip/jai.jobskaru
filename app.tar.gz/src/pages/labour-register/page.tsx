import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { HardHat, CheckCircle, Upload, Search, Clock, XCircle, ThumbsUp } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const DESIGNATIONS = [
  "Helper / Beldar",
  "Mason / Rajmistri",
  "Painter",
  "Electrician",
  "Plumber",
  "Carpenter / Mistri",
  "Welder",
  "Tile Worker",
  "Bar Bender / Sariya",
  "Shuttering",
  "Waterproofing",
  "POP / Plaster",
  "Labour / Mazdoor",
  "Driver",
  "Watchman / Guard",
  "Supervisor",
  "Other",
] as const;

const schema = z.object({
  name: z.string().min(2, "Naam kam se kam 2 letters ka hona chahiye"),
  fatherName: z.string().optional(),
  mobile: z.string().min(10, "Mobile number sahi daalo (10 digit)").max(10, "Mobile number 10 digit ka hona chahiye"),
  aadhaarNumber: z.string().optional(),
  age: z.string().optional(),
  address: z.string().optional(),
  designation: z.string().min(1, "Kya kaam karte ho wo select karo"),
  companyId: z.string().min(1, "Company select karo"),
  siteId: z.string().min(1, "Site select karo"),
  experience: z.string().optional(),
  previousWork: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

// ---- Status Check Section ----
function StatusCheck() {
  const [mobile, setMobile] = useState("");
  const [searched, setSearched] = useState(false);
  const statuses = useQuery(
    api.labourRegistration.checkStatusByMobile,
    mobile.length === 10 && searched ? { mobile } : "skip"
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_supervisor":
        return <span className="inline-flex items-center gap-1 text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full"><Clock className="w-3 h-3" />Supervisor ke paas pending</span>;
      case "supervisor_approved":
        return <span className="inline-flex items-center gap-1 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full"><ThumbsUp className="w-3 h-3" />Admin ke paas bheja gaya</span>;
      case "supervisor_rejected":
        return <span className="inline-flex items-center gap-1 text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full"><XCircle className="w-3 h-3" />Supervisor ne reject kiya</span>;
      case "admin_approved":
        return <span className="inline-flex items-center gap-1 text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full"><CheckCircle className="w-3 h-3" />Approved! Aap site pe add ho gaye</span>;
      case "admin_rejected":
        return <span className="inline-flex items-center gap-1 text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full"><XCircle className="w-3 h-3" />Admin ne reject kiya</span>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
      <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
        <Search className="w-4 h-4 text-primary" />
        Apna Status Check Karo
      </h3>
      <div className="flex gap-2">
        <Input
          placeholder="Mobile number daalo"
          value={mobile}
          onChange={(e) => { setMobile(e.target.value); setSearched(false); }}
          type="tel"
          maxLength={10}
          className="bg-white/10 border-white/20 text-white placeholder:text-white/40 h-10"
        />
        <Button
          onClick={() => setSearched(true)}
          disabled={mobile.length !== 10}
          size="sm"
          className="cursor-pointer h-10 px-4"
        >
          Check
        </Button>
      </div>
      {searched && statuses && (
        <div className="mt-3 space-y-2">
          {statuses.length === 0 ? (
            <p className="text-white/50 text-xs">Koi registration nahi mili is number se.</p>
          ) : (
            statuses.map((s) => (
              <div key={s._id} className="bg-white/5 rounded-lg p-3 border border-white/10">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-white text-sm font-medium">{s.name}</span>
                    <span className="text-white/50 text-xs ml-2">({s.designation})</span>
                  </div>
                  {getStatusBadge(s.status)}
                </div>
                {s.supervisorNote && (
                  <p className="text-xs text-amber-300 mt-1">Supervisor: {s.supervisorNote}</p>
                )}
                {s.adminNote && (
                  <p className="text-xs text-blue-300 mt-1">Admin: {s.adminNote}</p>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

// ---- Success Screen ----
function SuccessScreen({ onNewForm }: { onNewForm: () => void }) {
  return (
    <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center space-y-5">
      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
        <CheckCircle className="w-8 h-8 text-green-500" />
      </div>
      <div>
        <h2 className="text-xl font-bold text-gray-900">Form Submit Ho Gaya!</h2>
        <p className="text-gray-500 text-sm mt-2">
          Aapka form site supervisor ke paas bhej diya gaya hai. Wo verify karke admin ko bhejega.
          Jab approve hoga tab aap us site pe kaam kar sakte ho.
        </p>
      </div>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
        Apna status check karne ke liye upar mobile number se check karo.
      </div>
      <Button onClick={onNewForm} className="cursor-pointer w-full">Ek Aur Form Bharo</Button>
    </div>
  );
}

// ---- Main Page ----
export default function LabourRegisterPage() {
  const [submitted, setSubmitted] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [aadhaarFile, setAadhaarFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const companies = useQuery(api.labourRegistration.getActiveCompanies);
  const sites = useQuery(
    api.labourRegistration.getSitesByCompany,
    selectedCompanyId ? { companyId: selectedCompanyId as Id<"companies"> } : "skip"
  );
  const submitRegistration = useMutation(api.labourRegistration.submitLabourRegistration);
  const generateUploadUrl = useMutation(api.labourRegistration.generateUploadUrl);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      fatherName: "",
      mobile: "",
      aadhaarNumber: "",
      age: "",
      address: "",
      designation: "",
      companyId: "",
      siteId: "",
      experience: "",
      previousWork: "",
    },
  });

  const uploadFile = async (file: File): Promise<string> => {
    const url = await generateUploadUrl();
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": file.type },
      body: file,
    });
    const { storageId } = await response.json();
    return storageId as string;
  };

  const onSubmit = async (values: FormValues) => {
    try {
      setUploading(true);
      let photoStorageId: string | undefined;
      let aadhaarStorageId: string | undefined;

      if (photoFile) {
        photoStorageId = await uploadFile(photoFile);
      }
      if (aadhaarFile) {
        aadhaarStorageId = await uploadFile(aadhaarFile);
      }

      await submitRegistration({
        name: values.name,
        mobile: values.mobile,
        fatherName: values.fatherName || undefined,
        aadhaarNumber: values.aadhaarNumber || undefined,
        age: values.age ? parseInt(values.age) : undefined,
        address: values.address || undefined,
        designation: values.designation,
        companyId: values.companyId as Id<"companies">,
        siteId: values.siteId as Id<"sites">,
        experience: values.experience || undefined,
        previousWork: values.previousWork || undefined,
        photoStorageId,
        aadhaarStorageId,
      });

      toast.success("Form submit ho gaya!");
      setSubmitted(true);
    } catch {
      toast.error("Kuch gadbad ho gayi, dobara try karo.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[oklch(0.14_0.025_250)] flex flex-col items-center p-4 py-8">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
          <HardHat className="w-5 h-5 text-white" />
        </div>
        <span className="font-bold text-lg text-white tracking-tight">JAI SITE MANAGER ERP</span>
      </div>

      {/* Status Check */}
      <div className="w-full max-w-lg">
        <StatusCheck />
      </div>

      {/* Form or Success */}
      {submitted ? (
        <SuccessScreen onNewForm={() => {
          setSubmitted(false);
          form.reset();
          setPhotoFile(null);
          setAadhaarFile(null);
        }} />
      ) : (
        <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden">
          {/* Form Header */}
          <div className="bg-primary px-6 py-5 text-white">
            <h1 className="text-xl font-bold">Labour Registration Form</h1>
            <p className="text-white/70 text-sm mt-1">
              Apni details bharo. Supervisor verify karega, phir admin approve karega.
            </p>
          </div>

          {/* Form Body */}
          <div className="px-6 py-5">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">

                {/* Name */}
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Poora Naam *</FormLabel>
                    <FormControl>
                      <Input placeholder="Jaise: Rajesh Kumar" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Father Name */}
                <FormField control={form.control} name="fatherName" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Pita Ka Naam</FormLabel>
                    <FormControl>
                      <Input placeholder="Jaise: Shyam Kumar" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Mobile */}
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Mobile Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="9876543210" type="tel" maxLength={10} className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Aadhaar */}
                <FormField control={form.control} name="aadhaarNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Aadhaar Number</FormLabel>
                    <FormControl>
                      <Input placeholder="1234 5678 9012" maxLength={14} className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Age */}
                <FormField control={form.control} name="age" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Umar (Age)</FormLabel>
                    <FormControl>
                      <Input placeholder="25" type="number" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Address */}
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Pata (Address)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Gaon / Mohalla / City" rows={2} className="text-gray-900 resize-none" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Designation */}
                <FormField control={form.control} name="designation" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Kya Kaam Karte Ho? *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-11 text-gray-900">
                          <SelectValue placeholder="Kaam select karo..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {DESIGNATIONS.map((d) => (
                          <SelectItem key={d} value={d}>{d}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Company */}
                <FormField control={form.control} name="companyId" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Konsi Company Me? *</FormLabel>
                    <Select onValueChange={(val) => {
                      field.onChange(val);
                      setSelectedCompanyId(val);
                      form.setValue("siteId", "");
                    }} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-11 text-gray-900">
                          <SelectValue placeholder="Company select karo..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {companies?.map((c) => (
                          <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Site */}
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Konsi Site Pe? *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={!selectedCompanyId}>
                      <FormControl>
                        <SelectTrigger className="h-11 text-gray-900">
                          <SelectValue placeholder={selectedCompanyId ? "Site select karo..." : "Pehle company select karo"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {sites?.map((s) => (
                          <SelectItem key={s._id} value={s._id}>{s.name} — {s.city}</SelectItem>
                        ))}
                        {sites?.length === 0 && (
                          <div className="px-3 py-2 text-sm text-muted-foreground">Is company ki koi active site nahi hai</div>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Experience */}
                <FormField control={form.control} name="experience" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Kitne Saal Ka Experience?</FormLabel>
                    <FormControl>
                      <Input placeholder="Jaise: 5 saal" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Previous Work */}
                <FormField control={form.control} name="previousWork" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-800 font-semibold">Pehle Kaha Kaam Kiya?</FormLabel>
                    <FormControl>
                      <Input placeholder="Jaise: XYZ Builders, Jaipur" className="h-11 text-gray-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Photo Upload */}
                <div>
                  <label className="text-sm font-semibold text-gray-800 block mb-1.5">
                    Photo Upload (Optional)
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="cursor-pointer flex items-center gap-2 px-4 py-2.5 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-200 transition-colors">
                      <Upload className="w-4 h-4" />
                      {photoFile ? photoFile.name.slice(0, 20) : "Photo Choose Karo"}
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => setPhotoFile(e.target.files?.[0] ?? null)}
                      />
                    </label>
                    {photoFile && (
                      <button type="button" onClick={() => setPhotoFile(null)} className="text-xs text-red-500 cursor-pointer">
                        Hatao
                      </button>
                    )}
                  </div>
                </div>

                {/* Aadhaar Upload */}
                <div>
                  <label className="text-sm font-semibold text-gray-800 block mb-1.5">
                    Aadhaar Card Photo (Optional)
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="cursor-pointer flex items-center gap-2 px-4 py-2.5 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-200 transition-colors">
                      <Upload className="w-4 h-4" />
                      {aadhaarFile ? aadhaarFile.name.slice(0, 20) : "Aadhaar Choose Karo"}
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => setAadhaarFile(e.target.files?.[0] ?? null)}
                      />
                    </label>
                    {aadhaarFile && (
                      <button type="button" onClick={() => setAadhaarFile(null)} className="text-xs text-red-500 cursor-pointer">
                        Hatao
                      </button>
                    )}
                  </div>
                </div>

                {/* Submit */}
                <div className="pt-3">
                  <Button
                    type="submit"
                    className="cursor-pointer w-full h-12 text-base font-semibold"
                    disabled={form.formState.isSubmitting || uploading}
                  >
                    {uploading ? "Upload Ho Raha Hai..." : form.formState.isSubmitting ? "Submit Ho Raha Hai..." : "Submit Karo"}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      )}

      {/* Footer info */}
      <p className="text-white/40 text-xs mt-6 text-center max-w-sm">
        Yeh form bina login ke kaam karta hai. Submit hone ke baad site supervisor verify karega aur admin final approve karega.
      </p>
    </div>
  );
}
