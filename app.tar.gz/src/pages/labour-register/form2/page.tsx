import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { HardHat, Phone, Search, CheckCircle, Building2, CreditCard } from "lucide-react";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type FormStep = "search" | "select" | "form" | "success";

export default function LabourForm2Page() {
  const [step, setStep] = useState<FormStep>("search");
  const [mobile, setMobile] = useState("");
  const [searchMobile, setSearchMobile] = useState("");
  const [selectedLabourerId, setSelectedLabourerId] = useState<Id<"labourers"> | null>(null);
  const [selectedName, setSelectedName] = useState("");

  // Form 2 fields
  const [fatherName, setFatherName] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const approvedRegistrations = useQuery(
    api.labourRegistration.getApprovedByMobile,
    searchMobile ? { mobile: searchMobile } : "skip"
  );

  const submitForm2 = useMutation(api.labourRegistration.submitForm2);

  const handleSearch = () => {
    if (!mobile || mobile.length < 10) {
      toast.error("Sahi mobile number daalo (10 digit)");
      return;
    }
    setSearchMobile(mobile);
    setStep("select");
  };

  const handleSelectLabourer = (labourerId: Id<"labourers">, name: string, prefillFather?: string, prefillWhatsapp?: string) => {
    setSelectedLabourerId(labourerId);
    setSelectedName(name);
    if (prefillFather) setFatherName(prefillFather);
    if (prefillWhatsapp) setWhatsappNumber(prefillWhatsapp);
    setStep("form");
  };

  const handleSubmitForm2 = async () => {
    if (!selectedLabourerId) return;

    if (!fatherName.trim()) {
      toast.error("Baap ka naam daalo");
      return;
    }
    if (!whatsappNumber.trim() || whatsappNumber.length < 10) {
      toast.error("Sahi WhatsApp number daalo");
      return;
    }
    if (!bankName.trim()) {
      toast.error("Bank ka naam daalo");
      return;
    }
    if (!accountNumber.trim()) {
      toast.error("Account number daalo");
      return;
    }
    if (!ifscCode.trim()) {
      toast.error("IFSC code daalo");
      return;
    }

    setIsSubmitting(true);
    try {
      await submitForm2({
        labourerId: selectedLabourerId,
        mobile: searchMobile,
        fatherName: fatherName.trim(),
        whatsappNumber: whatsappNumber.trim(),
        bankName: bankName.trim(),
        accountNumber: accountNumber.trim(),
        ifscCode: ifscCode.trim().toUpperCase(),
      });
      toast.success("Form 2 successfully submit ho gaya!");
      setStep("success");
    } catch (error) {
      toast.error("Error: Form submit nahi ho paya. Dobara try karo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 dark:from-gray-900 dark:to-gray-800 py-8 px-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <HardHat className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Form 2 - Puri Jaankari</h1>
          <p className="text-sm text-muted-foreground mt-1">Approval ke baad apni bank details aur WhatsApp number bharein</p>
        </div>

        {/* Step: Search by Mobile */}
        {step === "search" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Phone className="w-5 h-5 text-orange-600" />
                Mobile Number Daalo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Mobile Number</Label>
                <Input
                  type="tel"
                  placeholder="9876543210"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                  maxLength={10}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Registration mein jo mobile diya tha wahi daalo
                </p>
              </div>
              <Button onClick={handleSearch} className="w-full cursor-pointer" disabled={mobile.length < 10}>
                <Search className="w-4 h-4 mr-2" />
                Search Karo
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step: Select Registration */}
        {step === "select" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Apna Registration Chunein</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {approvedRegistrations === undefined && (
                <p className="text-muted-foreground text-center py-4">Loading...</p>
              )}
              {approvedRegistrations && approvedRegistrations.length === 0 && (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-2">Koi approved registration nahi mila</p>
                  <p className="text-xs text-muted-foreground">
                    Yeh form sirf unke liye hai jinki registration approve ho chuki hai
                  </p>
                  <Button variant="ghost" className="mt-4 cursor-pointer" onClick={() => { setStep("search"); setSearchMobile(""); }}>
                    Vapas Jaao
                  </Button>
                </div>
              )}
              {approvedRegistrations && approvedRegistrations.map((reg) => (
                <div
                  key={reg.labourerId}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    reg.isForm2Complete
                      ? "border-green-300 bg-green-50 dark:border-green-700 dark:bg-green-950"
                      : "border-orange-200 bg-white dark:border-orange-700 dark:bg-gray-800 hover:border-orange-400 dark:hover:border-orange-500"
                  }`}
                  onClick={() => {
                    if (reg.isForm2Complete) {
                      toast.info("Yeh form pehle se bhara hua hai");
                      return;
                    }
                    handleSelectLabourer(reg.labourerId, reg.name, reg.fatherName ?? "", reg.whatsappNumber ?? "");
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">{reg.name}</p>
                      <p className="text-sm text-muted-foreground">{reg.designation}</p>
                    </div>
                    {reg.isForm2Complete ? (
                      <Badge className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Complete
                      </Badge>
                    ) : (
                      <Badge className="bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300">
                        Pending
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
              {approvedRegistrations && approvedRegistrations.length > 0 && (
                <Button variant="ghost" className="w-full mt-2 cursor-pointer" onClick={() => { setStep("search"); setSearchMobile(""); }}>
                  Dusra Number Try Karo
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step: Form 2 - Full Details */}
        {step === "form" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-orange-600" />
                {selectedName} - Puri Jaankari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Personal Details */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">Personal Details</h3>

                <div>
                  <Label>Baap ka Naam <span className="text-red-500">*</span></Label>
                  <Input
                    placeholder="Father's Name"
                    value={fatherName}
                    onChange={(e) => setFatherName(e.target.value)}
                  />
                </div>

                <div>
                  <Label>WhatsApp Number <span className="text-red-500">*</span></Label>
                  <Input
                    type="tel"
                    placeholder="9876543210"
                    value={whatsappNumber}
                    onChange={(e) => setWhatsappNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    maxLength={10}
                  />
                </div>
              </div>

              {/* Bank Details */}
              <div className="space-y-3 pt-2 border-t">
                <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  Bank Details
                </h3>

                <div>
                  <Label>Bank ka Naam <span className="text-red-500">*</span></Label>
                  <Input
                    placeholder="SBI, HDFC, ICICI etc."
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                  />
                </div>

                <div>
                  <Label>Account Number <span className="text-red-500">*</span></Label>
                  <Input
                    placeholder="Account Number"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
                  />
                </div>

                <div>
                  <Label>IFSC Code <span className="text-red-500">*</span></Label>
                  <Input
                    placeholder="SBIN0001234"
                    value={ifscCode}
                    onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                    maxLength={11}
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  variant="ghost"
                  className="flex-1 cursor-pointer"
                  onClick={() => setStep("select")}
                  disabled={isSubmitting}
                >
                  Vapas
                </Button>
                <Button
                  className="flex-1 cursor-pointer"
                  onClick={handleSubmitForm2}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Submit ho raha hai..." : "Submit Karo"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step: Success */}
        {step === "success" && (
          <Card className="text-center">
            <CardContent className="py-10 space-y-4">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Form 2 Submit Ho Gaya!</h2>
              <p className="text-muted-foreground">
                Aapki bank details aur WhatsApp number save ho gaye hain.
              </p>
              <Button
                className="cursor-pointer"
                onClick={() => {
                  setStep("search");
                  setMobile("");
                  setSearchMobile("");
                  setFatherName("");
                  setWhatsappNumber("");
                  setBankName("");
                  setAccountNumber("");
                  setIfscCode("");
                }}
              >
                Naya Form Bharo
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
