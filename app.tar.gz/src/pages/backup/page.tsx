import { useState } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Download, Upload, ShieldAlert, Database, CheckCircle2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { useNavigate } from "react-router-dom";

const TABLE_LABELS: Record<string, string> = {
  users: "Users",
  companies: "Companies",
  sites: "Sites",
  clients: "Clients",
  suppliers: "Suppliers",
  contractors: "Contractors",
  labourers: "Labourers",
  attendance: "Attendance",
  workOrders: "Work Orders",
  purchaseOrders: "Purchase Orders",
  poReceipts: "PO Receipts",
  workOrderAmendments: "WO Amendments",
  materials: "Materials",
  salarySheets: "Salary Sheets",
  salaryEntries: "Salary Entries",
  invoices: "Invoices",
  expenses: "Expenses",
  siteDiary: "Site Diary",
  deliveryChallans: "Delivery Challans",
  payments: "Payments",
  vendorBills: "Vendor Bills",
  siteExpenses: "Site Expenses",
  notifications: "Notifications",
  notificationPreferences: "Notification Prefs",
  screensaverSlides: "Screensaver Slides",
  screensaverSettings: "Screensaver Settings",
};

type BackupData = {
  tables: Record<string, unknown[]>;
  exportedAt: string;
  version: string;
};

function BackupPageInner() {
  const currentUser = useQuery(api.users.getCurrentUserQuery, {});
  const exportAll = useAction(api.backup.exportAll);
  const navigate = useNavigate();

  const [exporting, setExporting] = useState(false);
  const [importedData, setImportedData] = useState<BackupData | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);

  if (currentUser === undefined) {
    return <div className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>;
  }

  if (currentUser?.role !== "super_admin") {
    return (
      <div className="p-6 flex flex-col items-center justify-center gap-4 py-24">
        <ShieldAlert className="w-12 h-12 text-destructive" />
        <h2 className="text-xl font-bold">Access Denied</h2>
        <p className="text-muted-foreground">Only Super Admins can access Backup & Restore.</p>
        <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
      </div>
    );
  }

  async function handleExport() {
    setExporting(true);
    try {
      const data = await exportAll({});
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const date = new Date().toISOString().slice(0, 10);
      a.download = `jai-site-manager-backup-${date}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Backup downloaded successfully");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Export failed");
    } finally {
      setExporting(false);
    }
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string) as BackupData;
        if (!parsed.tables || !parsed.exportedAt || !parsed.version) {
          toast.error("Invalid backup file format");
          return;
        }
        setImportedData(parsed);
        setConfirmOpen(true);
      } catch {
        toast.error("Failed to parse backup file");
      }
    };
    reader.readAsText(file);
    // Reset input so same file can be selected again
    e.target.value = "";
  }

  const tableNames = importedData ? Object.keys(importedData.tables) : [];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Database className="w-6 h-6 text-primary" />
          Backup & Restore
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">Export all app data to your PC or restore from a backup file</p>
      </div>

      {/* Export */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Download className="w-5 h-5 text-green-600" />
            Export Backup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Downloads a complete JSON backup of all your app data — companies, sites, labour, materials, expenses, invoices, and more.
            Store this file on your PC or Google Drive for safekeeping.
          </p>
          <div className="flex flex-wrap gap-2">
            {Object.values(TABLE_LABELS).map((label) => (
              <Badge key={label} variant="secondary" className="text-xs">{label}</Badge>
            ))}
          </div>
          <Button className="cursor-pointer" onClick={() => void handleExport()} disabled={exporting}>
            <Download className="w-4 h-4 mr-2" />
            {exporting ? "Exporting..." : "Download Backup (.json)"}
          </Button>
        </CardContent>
      </Card>

      {/* Restore */}
      <Card className="border-orange-500/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Upload className="w-5 h-5 text-orange-500" />
            Restore from Backup
            <Badge variant="secondary" className="text-xs bg-orange-500/10 text-orange-600 border-0">Coming Soon</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="rounded-lg bg-orange-500/10 border border-orange-500/20 px-4 py-3 flex gap-2">
            <ShieldAlert className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-orange-700 dark:text-orange-400">
              Restore will overwrite existing data. This action cannot be undone. Make sure to download a fresh backup first before restoring.
            </p>
          </div>
          <p className="text-sm text-muted-foreground">
            Select a previously downloaded <code className="text-xs bg-muted px-1 rounded">.json</code> backup file to restore your data.
            The restore shows a preview of record counts before you confirm.
          </p>
          <label className="cursor-pointer">
            <input type="file" accept=".json" className="hidden" onChange={handleFileSelect} />
            <Button variant="secondary" className="cursor-pointer pointer-events-none">
              <Upload className="w-4 h-4 mr-2" /> Select Backup File
            </Button>
          </label>
          <p className="text-xs text-muted-foreground">Full restore functionality requires additional setup. Contact your system administrator.</p>
        </CardContent>
      </Card>

      {/* Confirm Restore Dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-orange-500" />
              Preview Backup File
            </DialogTitle>
          </DialogHeader>
          {importedData && (
            <div className="space-y-3">
              <div className="rounded-md bg-muted px-3 py-2 text-sm space-y-1">
                <p><span className="text-muted-foreground">Exported at:</span> {new Date(importedData.exportedAt).toLocaleString()}</p>
                <p><span className="text-muted-foreground">Version:</span> {importedData.version}</p>
                <p><span className="text-muted-foreground">Tables:</span> {tableNames.length}</p>
              </div>
              <p className="text-sm font-medium">Record counts in this backup:</p>
              <div className="grid grid-cols-2 gap-1.5">
                {tableNames.map((t) => (
                  <div key={t} className="flex items-center justify-between bg-muted/50 rounded px-2 py-1">
                    <span className="text-xs text-muted-foreground">{TABLE_LABELS[t] ?? t}</span>
                    <span className="text-xs font-bold">{(importedData.tables[t] as unknown[]).length}</span>
                  </div>
                ))}
              </div>
              <div className="rounded-lg bg-orange-500/10 border border-orange-500/20 px-3 py-2 flex gap-2">
                <ShieldAlert className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-orange-700 dark:text-orange-400">
                  Restore is view-only in this version. Contact your system administrator to perform a full restore.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setConfirmOpen(false)}>Close</Button>
            <Button className="cursor-pointer" onClick={() => { setConfirmOpen(false); toast.success("Backup file verified successfully"); }}>
              <CheckCircle2 className="w-4 h-4 mr-1" /> Confirm Preview
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function BackupPage() {
  return (
    <Authenticated>
      <BackupPageInner />
    </Authenticated>
  );
}
