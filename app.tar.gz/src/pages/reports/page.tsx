import { useState } from "react";
import { useQuery } from "convex/react";
import { Authenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  FileText, Download, IndianRupee, Users, CalendarCheck, BarChart3, FileSpreadsheet,
} from "lucide-react";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { downloadSalarySheetPDF, downloadInvoicePDF, downloadSiteSummaryPDF } from "@/lib/pdf-exports.ts";
import { downloadAttendanceCSV, downloadExpensesCSV, downloadPaymentLedgerCSV, downloadSalaryCSV } from "@/lib/csv-exports.ts";

function ReportCard({
  icon: Icon,
  title,
  description,
  children,
  badge,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  children: React.ReactNode;
  badge?: string;
}) {
  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-primary/10 rounded-lg text-primary">
            <Icon className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <CardTitle className="text-sm font-semibold">{title}</CardTitle>
              {badge && (
                <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">{badge}</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-3">{children}</CardContent>
    </Card>
  );
}

// ─── Salary Sheet PDF Report ──────────────────────────────────────────────────
function SalaryPDFReport() {
  const [siteId, setSiteId] = useState("");
  const [month, setMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  });
  const sites = useQuery(api.sites.list, {});
  const sheets = useQuery(api.salary.list, siteId ? { siteId: siteId as Id<"sites"> } : "skip");
  const sheetDetail = useQuery(
    api.salary.getDetail,
    sheets && month
      ? (() => {
          const found = (sheets ?? []).find((s) => s.month === month);
          return found ? { id: found._id } : "skip";
        })()
      : "skip"
  );
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    if (!sheetDetail) { toast.error("No salary sheet found for this site/month"); return; }
    setLoading(true);
    try {
      downloadSalarySheetPDF({
        siteName: sheetDetail.siteName,
        siteCity: sheetDetail.siteCity,
        month: sheetDetail.month,
        status: sheetDetail.status,
        preparedByName: sheetDetail.preparedByName,
        approvedByName: sheetDetail.approvedByName ?? undefined,
        totalAmount: sheetDetail.totalAmount,
        entries: sheetDetail.entries.map((e) => ({
          labourerName: e.labourerName,
          designation: e.designation ?? undefined,
          contractorName: e.contractorName ?? undefined,
          daysWorked: e.daysWorked,
          halfDays: e.halfDays,
          dailyRate: e.dailyRate,
          grossAmount: e.grossAmount,
          deductions: e.deductions,
          netAmount: e.netAmount,
          paymentMode: e.paymentMode ?? undefined,
        })),
      });
      toast.success("Salary PDF downloaded");
    } finally {
      setLoading(false);
    }
  };

  const handleCSV = () => {
    if (!sheetDetail) { toast.error("No salary sheet found for this site/month"); return; }
    downloadSalaryCSV(
      sheetDetail.entries.map((e) => ({
        labourerName: e.labourerName,
        designation: e.designation ?? undefined,
        contractorName: e.contractorName ?? undefined,
        daysWorked: e.daysWorked,
        halfDays: e.halfDays,
        dailyRate: e.dailyRate,
        grossAmount: e.grossAmount,
        deductions: e.deductions,
        netAmount: e.netAmount,
        paymentMode: e.paymentMode ?? undefined,
      })),
      sheetDetail.siteName,
      sheetDetail.month
    );
    toast.success("Salary CSV downloaded");
  };

  return (
    <ReportCard
      icon={IndianRupee}
      title="Salary Sheet"
      description="PDF payroll register or CSV export per site per month"
      badge="PDF + CSV"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site</Label>
        <Select value={siteId} onValueChange={setSiteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select site…" />
          </SelectTrigger>
          <SelectContent>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label className="text-xs">Month</Label>
        <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-8 text-sm" />
      </div>
      <div className="flex gap-2 pt-1">
        <Button size="sm" className="flex-1 cursor-pointer" disabled={!siteId || loading} onClick={handleDownload}>
          <Download className="w-3.5 h-3.5 mr-1" /> PDF
        </Button>
        <Button size="sm" variant="secondary" className="flex-1 cursor-pointer" disabled={!siteId} onClick={handleCSV}>
          <FileSpreadsheet className="w-3.5 h-3.5 mr-1" /> CSV
        </Button>
      </div>
    </ReportCard>
  );
}

// ─── Invoice PDF Report ───────────────────────────────────────────────────────
function InvoicePDFReport() {
  const [siteId, setSiteId] = useState("");
  const [invoiceId, setInvoiceId] = useState("");
  const sites = useQuery(api.sites.list, {});
  const invoices = useQuery(api.invoices.list, siteId ? { siteId: siteId as Id<"sites"> } : "skip");
  const invoiceDetail = useQuery(api.invoices.getDetail, invoiceId ? { id: invoiceId as Id<"invoices"> } : "skip");
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    if (!invoiceDetail) { toast.error("Please select an invoice"); return; }
    setLoading(true);
    try {
      downloadInvoicePDF({
        invoiceNumber: invoiceDetail.invoiceNumber,
        issueDate: invoiceDetail.issueDate,
        dueDate: invoiceDetail.dueDate ?? undefined,
        status: invoiceDetail.status,
        clientName: invoiceDetail.clientName,
        clientMobile: invoiceDetail.clientMobile ?? undefined,
        clientGst: invoiceDetail.clientGst ?? undefined,
        siteName: invoiceDetail.siteName,
        siteCity: invoiceDetail.siteCity,
        workOrderNumber: invoiceDetail.workOrderNumber ?? undefined,
        items: invoiceDetail.items,
        subtotal: invoiceDetail.subtotal,
        taxPercent: invoiceDetail.taxPercent,
        taxAmount: invoiceDetail.taxAmount,
        totalAmount: invoiceDetail.totalAmount,
        paidAmount: invoiceDetail.paidAmount,
        notes: invoiceDetail.notes ?? undefined,
      });
      toast.success("Invoice PDF downloaded");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ReportCard
      icon={FileText}
      title="Invoice"
      description="Formatted PDF invoice with client & payment details"
      badge="PDF"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site</Label>
        <Select value={siteId} onValueChange={(v) => { setSiteId(v); setInvoiceId(""); }}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select site…" />
          </SelectTrigger>
          <SelectContent>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label className="text-xs">Invoice</Label>
        <Select value={invoiceId} onValueChange={setInvoiceId} disabled={!siteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select invoice…" />
          </SelectTrigger>
          <SelectContent>
            {(invoices ?? []).map((inv) => (
              <SelectItem key={inv._id} value={inv._id}>{inv.invoiceNumber} · ₹{inv.totalAmount.toLocaleString("en-IN")}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button size="sm" className="w-full cursor-pointer" disabled={!invoiceId || loading} onClick={handleDownload}>
        <Download className="w-3.5 h-3.5 mr-1" /> Download Invoice PDF
      </Button>
    </ReportCard>
  );
}

// ─── Attendance CSV Report ────────────────────────────────────────────────────
function AttendanceCSVReport() {
  const [siteId, setSiteId] = useState("");
  const [month, setMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  });
  const sites = useQuery(api.sites.list, {});
  const attendanceData = useQuery(
    api.labourers.monthlySummary,
    siteId && month ? { siteId: siteId as Id<"sites">, month } : "skip"
  );

  const handleDownload = () => {
    if (!attendanceData) { toast.error("No data found"); return; }
    const siteName = sites?.find((s) => s._id === siteId)?.name ?? "Site";
    const rows = attendanceData.flatMap((row) => {
      return [
        {
          date: month,
          labourerName: row.name,
          designation: row.designation ?? "",
          contractorName: undefined,
          status: `P:${row.present} A:${row.absent} H:${row.halfDay}`,
          overtimeHours: row.overtimeHours,
          siteName,
        },
      ];
    });
    downloadAttendanceCSV(rows, `${siteName}-${month}`);
    toast.success("Attendance CSV downloaded");
  };

  return (
    <ReportCard
      icon={CalendarCheck}
      title="Attendance Register"
      description="Monthly attendance summary per labourer exported to CSV"
      badge="CSV"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site</Label>
        <Select value={siteId} onValueChange={setSiteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select site…" />
          </SelectTrigger>
          <SelectContent>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label className="text-xs">Month</Label>
        <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-8 text-sm" />
      </div>
      <Button size="sm" className="w-full cursor-pointer" disabled={!siteId} onClick={handleDownload}>
        <FileSpreadsheet className="w-3.5 h-3.5 mr-1" /> Export Attendance CSV
      </Button>
    </ReportCard>
  );
}

// ─── Expenses CSV Report ──────────────────────────────────────────────────────
function ExpensesCSVReport() {
  const [siteId, setSiteId] = useState("");
  const sites = useQuery(api.sites.list, {});
  const expenses = useQuery(api.expenses.list, {});

  const handleDownload = () => {
    const siteName = siteId ? (sites?.find((s) => s._id === siteId)?.name ?? "All") : "All";
    const filtered = (expenses ?? []).filter((e) => !siteId || siteId === "__all__" || e.siteId === siteId);
    if (!filtered.length) { toast.error("No expenses found"); return; }
    downloadExpensesCSV(
      filtered.map((e) => ({
        date: e.date,
        category: e.category,
        description: e.description,
        amount: e.amount,
        paymentMode: e.paymentMode,
        siteName: e.siteName,
        enteredByName: e.enteredByName,
        notes: e.notes ?? undefined,
      })),
      siteName
    );
    toast.success("Expenses CSV downloaded");
  };

  return (
    <ReportCard
      icon={BarChart3}
      title="Expenses Ledger"
      description="All petty cash expense entries filtered by site or all sites"
      badge="CSV"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site (optional)</Label>
        <Select value={siteId} onValueChange={setSiteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="All sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Sites</SelectItem>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <Button size="sm" className="w-full cursor-pointer" onClick={handleDownload}>
        <FileSpreadsheet className="w-3.5 h-3.5 mr-1" /> Export Expenses CSV
      </Button>
    </ReportCard>
  );
}

// ─── Payment Ledger CSV Report ─────────────────────────────────────────────────
function PaymentLedgerCSVReport() {
  const [siteId, setSiteId] = useState("");
  const sites = useQuery(api.sites.list, {});
  const payments = useQuery(api.payments.list, siteId ? { siteId: siteId as Id<"sites"> } : "skip");

  const handleDownload = () => {
    if (!payments?.length) { toast.error("No payments found"); return; }
    const siteName = sites?.find((s) => s._id === siteId)?.name ?? siteId;
    downloadPaymentLedgerCSV(
      payments.map((p) => ({
        date: p.date,
        type: p.type,
        amount: p.amount,
        mode: p.mode,
        referenceNumber: p.referenceNumber ?? undefined,
        siteName,
        clientName: p.type === "received" ? p.partyName : undefined,
        supplierName: p.type === "paid" ? p.partyName : undefined,
        contractorName: undefined,
        notes: p.notes ?? undefined,
      })),
      siteName
    );
    toast.success("Payment ledger CSV downloaded");
  };

  return (
    <ReportCard
      icon={IndianRupee}
      title="Payment Ledger"
      description="All inbound and outbound payments for a site as CSV"
      badge="CSV"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site *</Label>
        <Select value={siteId} onValueChange={setSiteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select site…" />
          </SelectTrigger>
          <SelectContent>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <Button size="sm" className="w-full cursor-pointer" disabled={!siteId} onClick={handleDownload}>
        <FileSpreadsheet className="w-3.5 h-3.5 mr-1" /> Export Payment Ledger CSV
      </Button>
    </ReportCard>
  );
}

// ─── Site Summary PDF Report ──────────────────────────────────────────────────
function SiteSummaryPDFReport() {
  const [siteId, setSiteId] = useState("");
  const [loading, setLoading] = useState(false);
  const sites = useQuery(api.sites.list, {});
  const pnl = useQuery(api.analytics.companyPnL, {});

  const handleDownload = () => {
    const siteSummary = pnl?.siteSummaries.find((s) => s.siteId === siteId);
    const site = sites?.find((s) => s._id === siteId);
    if (!siteSummary || !site) { toast.error("Site data not found"); return; }
    setLoading(true);
    try {
      downloadSiteSummaryPDF({
        siteName: siteSummary.siteName,
        siteCity: site.city ?? "",
        companyName: siteSummary.companyName,
        status: siteSummary.status,
        startDate: site.startDate ?? undefined,
        endDate: site.endDate ?? undefined,
        woValue: siteSummary.woValue,
        totalCost: siteSummary.totalCost,
        grossProfit: siteSummary.grossProfit,
        margin: siteSummary.margin,
        received: siteSummary.received,
        outstanding: siteSummary.outstanding,
        expenseTotal: siteSummary.expenseTotal,
        billTotal: siteSummary.billTotal,
        salaryTotal: siteSummary.salaryTotal,
      });
      toast.success("Site summary PDF downloaded");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ReportCard
      icon={Users}
      title="Site Summary Report"
      description="WO value, costs, payments, margin & balance for a site"
      badge="PDF"
    >
      <div className="space-y-2">
        <Label className="text-xs">Site *</Label>
        <Select value={siteId} onValueChange={setSiteId}>
          <SelectTrigger className="cursor-pointer h-8 text-sm">
            <SelectValue placeholder="Select site…" />
          </SelectTrigger>
          <SelectContent>
            {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <Button size="sm" className="w-full cursor-pointer" disabled={!siteId || loading} onClick={handleDownload}>
        <Download className="w-3.5 h-3.5 mr-1" /> Download Site Summary PDF
      </Button>
    </ReportCard>
  );
}

function ReportsInner() {
  const sites = useQuery(api.sites.list, {});
  const isLoading = sites === undefined;

  return (
    <div className="p-4 md:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <FileText className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports & Exports</h1>
          <p className="text-muted-foreground text-sm">Download PDFs and CSV exports for salary, invoices, attendance, expenses and more</p>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <SalaryPDFReport />
          <InvoicePDFReport />
          <SiteSummaryPDFReport />
          <AttendanceCSVReport />
          <ExpensesCSVReport />
          <PaymentLedgerCSVReport />
        </div>
      )}
    </div>
  );
}

export default function ReportsPage() {
  return (
    <Authenticated>
      <ReportsInner />
    </Authenticated>
  );
}
