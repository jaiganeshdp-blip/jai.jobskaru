import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { toast } from "sonner";
import {
  Copy,
  Download,
  ExternalLink,
  Link2,
  Users,
  Truck,
  HardHat,
  ShieldCheck,
  HardHat as SupervisorIcon,
} from "lucide-react";
import * as XLSX from "xlsx";

const BASE_URL = window.location.origin;

type PortalType = "all" | "supplier" | "contractor" | "supervisor" | "safety_supervisor";

function copyToClipboard(text: string) {
  void navigator.clipboard.writeText(text);
  toast.success("Link copy ho gaya!");
}

function getPortalLabel(type: string) {
  switch (type) {
    case "supplier": return "Supplier Portal";
    case "contractor": return "Contractor Portal";
    case "supervisor": return "Site Supervisor Portal";
    case "safety_supervisor": return "Safety Supervisor Portal";
    default: return type;
  }
}

function getTypeColor(type: string) {
  switch (type) {
    case "supplier": return "bg-blue-700 text-white";
    case "contractor": return "bg-orange-700 text-white";
    case "supervisor": return "bg-green-700 text-white";
    case "safety_supervisor": return "bg-purple-700 text-white";
    default: return "bg-slate-700 text-white";
  }
}

function getTypeIcon(type: string) {
  switch (type) {
    case "supplier": return <Truck className="h-4 w-4" />;
    case "contractor": return <HardHat className="h-4 w-4" />;
    case "supervisor": return <SupervisorIcon className="h-4 w-4" />;
    case "safety_supervisor": return <ShieldCheck className="h-4 w-4" />;
    default: return <Users className="h-4 w-4" />;
  }
}

type PortalRow = {
  type: string;
  name: string;
  mobile?: string;
  email?: string;
  workerCode?: string;
  portalToken: string;
  portalPath: string;
  isActive: boolean;
  siteName?: string;
};

function PortalAccessInner() {
  const data = useQuery(api.portalAccess.getAllPortalAccess);
  const [filter, setFilter] = useState<PortalType>("all");

  if (data === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (!data) {
    return <div className="text-red-400 p-4">Access denied</div>;
  }

  const allRows: PortalRow[] = [
    ...data.suppliers.map((s) => ({ ...s, type: "supplier" })),
    ...data.contractors.map((c) => ({ ...c, type: "contractor" })),
    ...data.supervisors.map((sv) => ({ ...sv, mobile: sv.mobile ?? undefined })),
  ];

  const filtered = filter === "all" ? allRows : allRows.filter((r) => r.type === filter);

  function downloadExcel() {
    const rows = allRows.map((r) => ({
      "Portal Type": getPortalLabel(r.type),
      "Name": r.name,
      "Mobile": r.mobile ?? "",
      "Email": r.email ?? "",
      "Worker Code": r.workerCode ?? "",
      "Site": r.siteName ?? "",
      "Portal URL": `${BASE_URL}${r.portalPath}?token=${r.portalToken}`,
      "Token": r.portalToken,
      "Status": r.isActive ? "Active" : "Inactive",
    }));

    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [
      { wch: 22 }, { wch: 28 }, { wch: 15 }, { wch: 28 },
      { wch: 12 }, { wch: 20 }, { wch: 60 }, { wch: 38 }, { wch: 10 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Portal Access");
    XLSX.writeFile(wb, "portal-access-list.xlsx");
    toast.success("Excel download ho raha hai!");
  }

  const counts = {
    all: allRows.length,
    supplier: data.suppliers.length,
    contractor: data.contractors.length,
    supervisor: data.supervisors.filter((s) => s.type === "supervisor").length,
    safety_supervisor: data.supervisors.filter((s) => s.type === "safety_supervisor").length,
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Portal Access Manager</h1>
          <p className="text-slate-400 text-sm mt-1">
            Sabhi vendors, contractors aur supervisors ke portal links aur passwords
          </p>
        </div>
        <Button
          onClick={downloadExcel}
          className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
        >
          <Download className="h-4 w-4" />
          Excel Download Karo
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="bg-blue-900/60 border-blue-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-300">{counts.supplier}</div>
            <div className="text-blue-200 text-sm">Suppliers</div>
          </CardContent>
        </Card>
        <Card className="bg-orange-900/60 border-orange-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-300">{counts.contractor}</div>
            <div className="text-orange-200 text-sm">Contractors</div>
          </CardContent>
        </Card>
        <Card className="bg-green-900/60 border-green-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-300">{counts.supervisor}</div>
            <div className="text-green-200 text-sm">Site Supervisors</div>
          </CardContent>
        </Card>
        <Card className="bg-purple-900/60 border-purple-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-300">{counts.safety_supervisor}</div>
            <div className="text-purple-200 text-sm">Safety Supervisors</div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {(["all", "supplier", "contractor", "supervisor", "safety_supervisor"] as PortalType[]).map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium cursor-pointer transition-colors ${
              filter === t
                ? "bg-white text-slate-900"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            {t === "all" ? `Sabhi (${counts.all})` : `${getPortalLabel(t)} (${counts[t]})`}
          </button>
        ))}
      </div>

      {/* Table */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base">
            Portal Links List — {filtered.length} records
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-900 text-slate-300 text-left">
                  <th className="px-4 py-3 font-semibold">Type</th>
                  <th className="px-4 py-3 font-semibold">Naam</th>
                  <th className="px-4 py-3 font-semibold">Mobile</th>
                  <th className="px-4 py-3 font-semibold hidden md:table-cell">Site / Code</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Portal Link</th>
                  <th className="px-4 py-3 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center text-slate-400 py-10">
                      Koi record nahi mila
                    </td>
                  </tr>
                )}
                {filtered.map((row, i) => {
                  const url = `${BASE_URL}${row.portalPath}?token=${row.portalToken}`;
                  return (
                    <tr
                      key={i}
                      className="border-t border-slate-700 hover:bg-slate-750 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium ${getTypeColor(row.type)}`}
                        >
                          {getTypeIcon(row.type)}
                          {row.type === "supplier"
                            ? "Supplier"
                            : row.type === "contractor"
                            ? "Contractor"
                            : row.type === "supervisor"
                            ? "Supervisor"
                            : "Safety Sup."}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-white font-medium">{row.name}</td>
                      <td className="px-4 py-3 text-slate-300">{row.mobile ?? "—"}</td>
                      <td className="px-4 py-3 text-slate-300 hidden md:table-cell">
                        {row.siteName && row.siteName !== "—" ? (
                          <span className="text-slate-200">{row.siteName}</span>
                        ) : row.workerCode ? (
                          <span className="bg-slate-700 px-2 py-0.5 rounded text-xs text-yellow-300">
                            Code: {row.workerCode}
                          </span>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          className={
                            row.isActive
                              ? "bg-green-800 text-green-200"
                              : "bg-red-800 text-red-200"
                          }
                        >
                          {row.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 max-w-xs">
                        <div className="text-xs text-slate-400 truncate max-w-[180px]" title={url}>
                          {url}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => copyToClipboard(url)}
                            className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-300 cursor-pointer"
                            title="Link Copy Karo"
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </button>
                          {row.mobile && (
                            <a
                              href={`https://wa.me/91${row.mobile.replace(/\D/g, "")}?text=${encodeURIComponent(`Namaste ${row.name} ji 🙏\n\nAapka portal link yahan hai:\n${url}\n\nIs link se aap apna kaam, bills aur payments dekh sakte hain.`)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 bg-green-700 hover:bg-green-600 rounded text-white cursor-pointer"
                              title="WhatsApp pe bhejo"
                            >
                              <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                              </svg>
                            </a>
                          )}
                          <a
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-300 cursor-pointer"
                            title="Portal Kholein"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Info Box */}
      <Card className="bg-yellow-900/30 border-yellow-700">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Link2 className="h-5 w-5 text-yellow-400 mt-0.5 shrink-0" />
            <div>
              <div className="text-yellow-200 font-semibold text-sm">Portal Links ke baare mein</div>
              <ul className="text-yellow-300/80 text-xs mt-1 space-y-1">
                <li>• Supplier Portal: Suppliers apne bills submit karte hain</li>
                <li>• Contractor Portal: Contractors work orders, bills aur payments dekhte hain</li>
                <li>• Site Supervisor Portal: Material request, attendance, aur reports</li>
                <li>• Safety Supervisor Portal: PPE, violations aur safety management</li>
                <li>• Excel download karein aur WhatsApp pe share karein</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function PortalAccessPage() {
  return (
    <Authenticated>
      <PortalAccessInner />
    </Authenticated>
  );
}
