import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import {
  Building2,
  Users,
  UserCheck,
  IndianRupee,
  Package,
  CalendarCheck,
  MapPin,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  ClipboardList,
  TrendingUp,
  Eye,
} from "lucide-react";
import { cn } from "@/lib/utils.ts";
import { format } from "date-fns";

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-100 text-green-700 border-green-200",
  planning: "bg-blue-100 text-blue-700 border-blue-200",
  on_hold: "bg-yellow-100 text-yellow-700 border-yellow-200",
  completed: "bg-gray-100 text-gray-600 border-gray-200",
};

function SummaryCard({
  title,
  value,
  sub,
  icon: Icon,
  color = "text-primary",
}: {
  title: string;
  value: string | number;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  color?: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
          <Icon className={cn("w-4 h-4", color)} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground mt-1">{sub}</p>
      </CardContent>
    </Card>
  );
}

type SiteSummary = {
  siteId: string;
  siteName: string;
  city: string;
  status: string;
  companyId: string;
  companyName: string;
  activeLabourers: number;
  totalLabourers: number;
  supervisors: Array<{ name: string; workerCode: string; isSiteSupervisor: boolean; isSafetySupervisor: boolean }>;
  attendance: { present: number; absent: number; halfDay: number; holiday: number; unmarked: number };
  advanceTotal: number;
  pendingMaterialRequests: number;
  totalMaterialRequests: number;
  recentReports: number;
};

function AttendanceBar({ att, total }: { att: SiteSummary["attendance"]; total: number }) {
  if (total === 0) return <span className="text-xs text-muted-foreground">No labour</span>;
  const pct = (n: number) => Math.round((n / total) * 100);
  return (
    <div className="flex flex-col gap-1">
      <div className="flex h-2 rounded-full overflow-hidden w-full bg-muted">
        <div className="bg-green-500" style={{ width: `${pct(att.present)}%` }} />
        <div className="bg-yellow-500" style={{ width: `${pct(att.halfDay)}%` }} />
        <div className="bg-red-400" style={{ width: `${pct(att.absent)}%` }} />
        <div className="bg-blue-400" style={{ width: `${pct(att.holiday)}%` }} />
      </div>
      <div className="flex flex-wrap gap-x-2 text-xs text-muted-foreground">
        {att.present > 0 && <span className="text-green-600">✓ {att.present}P</span>}
        {att.halfDay > 0 && <span className="text-yellow-600">½ {att.halfDay}H</span>}
        {att.absent > 0 && <span className="text-red-500">✗ {att.absent}A</span>}
        {att.unmarked > 0 && <span className="text-muted-foreground">? {att.unmarked}</span>}
      </div>
    </div>
  );
}

function SiteDetailDialog({
  site,
  date,
  onClose,
}: {
  site: SiteSummary;
  date: string;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<"attendance" | "advances" | "supervisors">("attendance");
  const month = date.slice(0, 7);

  const attDetail = useQuery(
    api.superAdminDashboard.getSiteAttendanceDetail,
    tab === "attendance" ? { siteId: site.siteId as never, date } : "skip"
  );
  const advDetail = useQuery(
    api.superAdminDashboard.getSiteAdvancesDetail,
    tab === "advances" ? { siteId: site.siteId as never, month } : "skip"
  );

  const tabs = [
    { id: "attendance" as const, label: "Attendance" },
    { id: "advances" as const, label: "Advances" },
    { id: "supervisors" as const, label: "Supervisors" },
  ];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            {site.siteName}
            <Badge variant="outline" className={cn("text-xs", STATUS_COLORS[site.status])}>
              {site.status}
            </Badge>
          </DialogTitle>
          <p className="text-sm text-muted-foreground">{site.city} · {site.companyName}</p>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex gap-1 border-b pb-2">
          {tabs.map((t) => (
            <Button
              key={t.id}
              size="sm"
              variant={tab === t.id ? "default" : "ghost"}
              onClick={() => setTab(t.id)}
              className="cursor-pointer"
            >
              {t.label}
            </Button>
          ))}
        </div>

        {/* Attendance Tab */}
        {tab === "attendance" && (
          <div>
            <p className="text-xs text-muted-foreground mb-3">Date: {format(new Date(date + "T00:00:00"), "dd MMM yyyy")}</p>
            {!attDetail ? (
              <Skeleton className="h-40 w-full" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>OT Hrs</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attDetail.labourers.map((l) => (
                    <TableRow key={l._id}>
                      <TableCell className="font-medium">{l.name}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{l.designation ?? "—"}</TableCell>
                      <TableCell className="text-xs">₹{l.dailyRate}</TableCell>
                      <TableCell>
                        {l.attendance ? (
                          <Badge
                            variant="outline"
                            className={cn("text-xs capitalize", {
                              "bg-green-100 text-green-700": l.attendance.status === "present",
                              "bg-yellow-100 text-yellow-700": l.attendance.status === "half_day",
                              "bg-red-100 text-red-600": l.attendance.status === "absent",
                              "bg-blue-100 text-blue-700": l.attendance.status === "holiday",
                            })}
                          >
                            {l.attendance.status.replace("_", " ")}
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">Unmarked</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">{l.attendance?.overtimeHours ?? "—"}</TableCell>
                    </TableRow>
                  ))}
                  {attDetail.labourers.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">No active labourers</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        )}

        {/* Advances Tab */}
        {tab === "advances" && (
          <div>
            <p className="text-xs text-muted-foreground mb-3">Month: {month}</p>
            {!advDetail ? (
              <Skeleton className="h-40 w-full" />
            ) : (
              <>
                <div className="text-sm font-semibold mb-2">
                  Total: ₹{advDetail.reduce((s, a) => s + a.amount, 0).toLocaleString("en-IN")}
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Labourer</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Reason</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {advDetail.map((adv) => (
                      <TableRow key={adv._id}>
                        <TableCell className="font-medium">{adv.labourerName}</TableCell>
                        <TableCell className="text-orange-600 font-medium">₹{adv.amount.toLocaleString("en-IN")}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{adv.date}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{adv.reason ?? "—"}</TableCell>
                      </TableRow>
                    ))}
                    {advDetail.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">No advances this month</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </>
            )}
          </div>
        )}

        {/* Supervisors Tab */}
        {tab === "supervisors" && (
          <div>
            {site.supervisors.length === 0 ? (
              <p className="text-muted-foreground text-sm py-4">No supervisors assigned</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Worker Code</TableHead>
                    <TableHead>Role</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {site.supervisors.map((s, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{s.name}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="font-mono text-xs">{s.workerCode || "—"}</Badge>
                      </TableCell>
                      <TableCell className="text-xs space-x-1">
                        {s.isSiteSupervisor && <Badge variant="outline" className="text-xs">Site Sup.</Badge>}
                        {s.isSafetySupervisor && <Badge variant="outline" className="text-xs bg-orange-50 text-orange-700">Safety Sup.</Badge>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function SiteRow({ site, date, expanded, onToggle }: {
  site: SiteSummary;
  date: string;
  expanded: boolean;
  onToggle: () => void;
}) {
  const [showDetail, setShowDetail] = useState(false);
  const total = site.activeLabourers;

  return (
    <>
      {showDetail && (
        <SiteDetailDialog site={site} date={date} onClose={() => setShowDetail(false)} />
      )}
      <Card className="overflow-hidden">
        <div
          className="flex items-start justify-between px-4 py-3 cursor-pointer hover:bg-muted/30 transition-colors"
          onClick={onToggle}
        >
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <MapPin className="w-4 h-4 text-primary" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm">{site.siteName}</span>
                <Badge variant="outline" className={cn("text-xs", STATUS_COLORS[site.status])}>
                  {site.status}
                </Badge>
                {site.pendingMaterialRequests > 0 && (
                  <Badge variant="outline" className="text-xs bg-red-50 text-red-600 border-red-200">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    {site.pendingMaterialRequests} pending
                  </Badge>
                )}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {site.city} · {site.companyName}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0 ml-2">
            <Button
              size="sm"
              variant="ghost"
              className="h-7 w-7 p-0 cursor-pointer"
              onClick={(e) => { e.stopPropagation(); setShowDetail(true); }}
              title="View Details"
            >
              <Eye className="w-3.5 h-3.5" />
            </Button>
            {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </div>
        </div>

        {expanded && (
          <div className="border-t bg-muted/10 px-4 py-3 grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Labour */}
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                <Users className="w-3 h-3" />Labour
              </div>
              <div className="text-sm font-semibold">{site.activeLabourers} active</div>
              <div className="text-xs text-muted-foreground">{site.totalLabourers} total</div>
            </div>

            {/* Attendance */}
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                <CalendarCheck className="w-3 h-3" />Attendance
              </div>
              <AttendanceBar att={site.attendance} total={total} />
            </div>

            {/* Advances */}
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                <IndianRupee className="w-3 h-3" />Advances (Month)
              </div>
              <div className="text-sm font-semibold text-orange-600">
                ₹{site.advanceTotal.toLocaleString("en-IN")}
              </div>
            </div>

            {/* Reports & Material */}
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                <ClipboardList className="w-3 h-3" />Activity
              </div>
              <div className="text-xs space-y-0.5">
                <div>{site.recentReports} report(s) in 7 days</div>
                <div className={cn(site.pendingMaterialRequests > 0 ? "text-red-600 font-medium" : "text-muted-foreground")}>
                  {site.pendingMaterialRequests} material req. pending
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>
    </>
  );
}

export default function SuperAdminDashboard() {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [expandedSites, setExpandedSites] = useState<Set<string>>(new Set());
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterCompany, setFilterCompany] = useState<string>("all");

  const data = useQuery(api.superAdminDashboard.getAllSitesSummary, { date });

  const toggleSite = (siteId: string) => {
    setExpandedSites((prev) => {
      const next = new Set(prev);
      if (next.has(siteId)) next.delete(siteId);
      else next.add(siteId);
      return next;
    });
  };

  const expandAll = () => {
    if (data) setExpandedSites(new Set(data.sites.map((s) => s.siteId)));
  };
  const collapseAll = () => setExpandedSites(new Set());

  const companies = data
    ? Array.from(new Map(data.sites.map((s) => [s.companyId, s.companyName])).entries())
    : [];

  const filteredSites = data?.sites.filter((s) => {
    if (filterStatus !== "all" && s.status !== filterStatus) return false;
    if (filterCompany !== "all" && s.companyId !== filterCompany) return false;
    return true;
  }) ?? [];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-primary" />
            All Sites Overview
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Super Admin · Live dashboard across all sites</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={date}
            max={today}
            onChange={(e) => setDate(e.target.value)}
            className="text-sm border border-border rounded-md px-3 py-1.5 bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 cursor-pointer"
          />
        </div>
      </div>

      {/* Summary Cards */}
      {!data ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <SummaryCard
            title="Active Sites"
            value={data.totals.activeSites}
            sub={`of ${data.sites.length} total`}
            icon={Building2}
            color="text-blue-600"
          />
          <SummaryCard
            title="Total Labour"
            value={data.totals.totalLabourers}
            sub="active workers"
            icon={Users}
            color="text-violet-600"
          />
          <SummaryCard
            title="Present Today"
            value={data.totals.presentToday}
            sub="marked present"
            icon={UserCheck}
            color="text-green-600"
          />
          <SummaryCard
            title="Absent Today"
            value={data.totals.absentToday}
            sub="marked absent"
            icon={CalendarCheck}
            color="text-red-500"
          />
          <SummaryCard
            title="Advances (Month)"
            value={`₹${(data.totals.advanceTotal / 1000).toFixed(1)}K`}
            sub={`${data.date.slice(0, 7)}`}
            icon={IndianRupee}
            color="text-orange-500"
          />
          <SummaryCard
            title="Pending Requests"
            value={data.totals.pendingMaterialRequests}
            sub="material requests"
            icon={Package}
            color="text-red-600"
          />
        </div>
      )}

      {/* Filters & Controls */}
      {data && (
        <div className="flex flex-wrap items-center gap-2">
          {/* Status filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="text-sm border border-border rounded-md px-2 py-1.5 bg-background focus:outline-none cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="planning">Planning</option>
            <option value="on_hold">On Hold</option>
            <option value="completed">Completed</option>
          </select>

          {/* Company filter */}
          {companies.length > 1 && (
            <select
              value={filterCompany}
              onChange={(e) => setFilterCompany(e.target.value)}
              className="text-sm border border-border rounded-md px-2 py-1.5 bg-background focus:outline-none cursor-pointer"
            >
              <option value="all">All Companies</option>
              {companies.map(([id, name]) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </select>
          )}

          <div className="ml-auto flex gap-2">
            <Button size="sm" variant="ghost" onClick={expandAll} className="cursor-pointer text-xs">
              Expand All
            </Button>
            <Button size="sm" variant="ghost" onClick={collapseAll} className="cursor-pointer text-xs">
              Collapse All
            </Button>
          </div>
          <span className="text-xs text-muted-foreground">
            {filteredSites.length} site{filteredSites.length !== 1 ? "s" : ""}
          </span>
        </div>
      )}

      {/* Sites List */}
      {!data ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      ) : filteredSites.length === 0 ? (
        <Card className="py-12 text-center text-muted-foreground">
          No sites match the current filters.
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredSites.map((site) => (
            <SiteRow
              key={site.siteId}
              site={site}
              date={date}
              expanded={expandedSites.has(site.siteId)}
              onToggle={() => toggleSite(site.siteId)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
