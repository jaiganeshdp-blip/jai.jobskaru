import { useParams, Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { ArrowLeft, Phone, Mail, MapPin, FileText, Building2, ClipboardList, AlertCircle } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  planning: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  on_hold: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  completed: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
  draft: "bg-gray-100 text-gray-700",
  amended: "bg-orange-100 text-orange-800",
  cancelled: "bg-red-100 text-red-800",
};

function fmt(amount: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}

export default function ClientDetail() {
  const { id } = useParams<{ id: string }>();
  const data = useQuery(api.clients.getDetail, id ? { id: id as Id<"clients"> } : "skip");

  if (data === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6 text-center space-y-2">
        <AlertCircle className="w-8 h-8 mx-auto text-muted-foreground" />
        <p className="text-muted-foreground">Client not found</p>
        <Link to="/clients"><Button variant="ghost" size="sm">Back to Clients</Button></Link>
      </div>
    );
  }

  const { client, sites, workOrderCount, totalWorkOrderValue, invoiceCount, totalInvoiced, totalPaid, recentWorkOrders } = data;
  const outstanding = totalInvoiced - totalPaid;

  return (
    <div className="p-6 space-y-6">
      <Link to="/clients">
        <Button variant="ghost" size="sm" className="cursor-pointer gap-1 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Clients
        </Button>
      </Link>

      {/* Hero */}
      <div className="rounded-xl bg-[oklch(0.14_0.025_250)] text-white p-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">{client.name}</h1>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-white/70">
              {client.mobile && <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {client.mobile}</span>}
              {client.email && <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {client.email}</span>}
              {client.gstNumber && <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" /> GST: {client.gstNumber}</span>}
              {client.city && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {client.city}</span>}
            </div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold self-start ${client.isActive ? "bg-green-500/20 text-green-300" : "bg-gray-500/20 text-gray-300"}`}>
            {client.isActive ? "Active" : "Inactive"}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <Building2 className="w-3.5 h-3.5" /> Sites
          </div>
          <div className="text-2xl font-bold">{sites.length}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{sites.filter((s) => s.status === "active").length} active</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <ClipboardList className="w-3.5 h-3.5" /> Work Orders
          </div>
          <div className="text-2xl font-bold">{workOrderCount}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{fmt(totalWorkOrderValue)} value</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <FileText className="w-3.5 h-3.5" /> Invoiced
          </div>
          <div className="text-2xl font-bold">{invoiceCount}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{fmt(totalInvoiced)} billed</div>
        </div>
        <div className={`border rounded-lg p-4 ${outstanding > 0 ? "border-orange-300 bg-orange-50 dark:border-orange-700 dark:bg-orange-900/10" : "border-border"}`}>
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            Outstanding
          </div>
          <div className={`text-2xl font-bold ${outstanding > 0 ? "text-orange-600 dark:text-orange-400" : "text-green-600 dark:text-green-400"}`}>
            {fmt(outstanding)}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">{fmt(totalPaid)} paid</div>
        </div>
      </div>

      {/* Info + Sites + Work Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Contact Info */}
        <div className="space-y-4">
          <div className="border border-border rounded-lg p-4 space-y-3">
            <h3 className="font-semibold text-sm">Client Information</h3>
            {[
              { label: "Name", value: client.name },
              { label: "Contact Person", value: client.contactPerson ?? "—" },
              { label: "GST Number", value: client.gstNumber ?? "—" },
              { label: "PAN Number", value: client.panNumber ?? "—" },
              { label: "Mobile", value: client.mobile },
              { label: "Email", value: client.email ?? "—" },
              { label: "City", value: client.city ?? "—" },
              { label: "Address", value: client.address ?? "—" },
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{row.label}</span>
                <span className="font-medium text-right max-w-[200px]">{row.value}</span>
              </div>
            ))}
          </div>

          {/* Sites linked to client */}
          <div className="border border-border rounded-lg p-4 space-y-3">
            <h3 className="font-semibold text-sm">Sites</h3>
            {sites.length === 0 ? (
              <p className="text-sm text-muted-foreground">No sites linked to this client</p>
            ) : (
              <div className="space-y-2">
                {sites.map((site) => (
                  <Link key={site._id} to={`/sites/${site._id}`} className="flex items-center justify-between py-2 border-b border-border last:border-0 hover:text-primary transition-colors">
                    <span className="text-sm font-medium">{site.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{site.city}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full capitalize ${STATUS_COLORS[site.status] ?? ""}`}>
                        {site.status.replace("_", " ")}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recent Work Orders */}
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm">Recent Work Orders</h3>
            <Link to="/work-orders" className="text-xs text-primary cursor-pointer">View all</Link>
          </div>
          {recentWorkOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground">No work orders yet</p>
          ) : (
            <div className="space-y-2">
              {recentWorkOrders.map((wo) => (
                <div key={wo._id} className="flex items-start justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <div className="text-sm font-medium">{wo.orderNumber}</div>
                    <div className="text-xs text-muted-foreground truncate max-w-[200px]">{wo.description}</div>
                    <div className="text-xs text-muted-foreground">{wo.issueDate}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold">{fmt(wo.totalValue)}</div>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full capitalize ${STATUS_COLORS[wo.status] ?? ""}`}>
                      {wo.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
