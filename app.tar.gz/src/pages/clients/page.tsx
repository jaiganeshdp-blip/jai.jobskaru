import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Plus, Search, Eye, Pencil, Trash2, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  mobile: z.string().min(10, "Valid mobile required"),
  email: z.string().email().optional().or(z.literal("")),
  gstNumber: z.string().optional(),
  panNumber: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  contactPerson: z.string().optional(),
});
type ClientForm = z.infer<typeof schema>;

export default function Clients() {
  const clients = useQuery(api.clients.list, {});
  const createClient = useMutation(api.clients.create);
  const updateClient = useMutation(api.clients.update);
  const removeClient = useMutation(api.clients.remove);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const form = useForm<ClientForm>({ resolver: zodResolver(schema), defaultValues: { name: "", mobile: "" } });

  const filtered = (clients ?? []).filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.city ?? "").toLowerCase().includes(search.toLowerCase()) ||
    (c.contactPerson ?? "").toLowerCase().includes(search.toLowerCase())
  );

  function openCreate() { setEditId(null); form.reset({ name: "", mobile: "" }); setDialogOpen(true); }
  function openEdit(c: (typeof filtered)[number]) {
    setEditId(c._id);
    form.reset({
      name: c.name,
      mobile: c.mobile,
      email: c.email ?? "",
      gstNumber: c.gstNumber ?? "",
      panNumber: c.panNumber ?? "",
      address: c.address ?? "",
      city: c.city ?? "",
      contactPerson: c.contactPerson ?? "",
    });
    setDialogOpen(true);
  }

  async function onSubmit(data: ClientForm) {
    try {
      const payload = {
        ...data,
        email: data.email || undefined,
        gstNumber: data.gstNumber || undefined,
        panNumber: data.panNumber || undefined,
        address: data.address || undefined,
        city: data.city || undefined,
        contactPerson: data.contactPerson || undefined,
      };
      if (editId) {
        await updateClient({ id: editId as Id<"clients">, ...payload });
        toast.success("Client updated");
      } else {
        await createClient(payload);
        toast.success("Client added");
      }
      setDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    }
  }

  async function handleDelete(id: string) {
    try {
      await removeClient({ id: id as Id<"clients"> });
      toast.success("Client deleted");
      setDeleteConfirm(null);
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Clients</h1>
          <p className="text-muted-foreground text-sm">Manage client records and project owners</p>
        </div>
        <Button onClick={openCreate} className="cursor-pointer"><Plus className="w-4 h-4 mr-1" /> Add Client</Button>
      </div>
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search by name, city or contact..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>
      {!clients ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Users /></EmptyMedia>
            <EmptyTitle>No clients found</EmptyTitle>
            <EmptyDescription>{search ? "Try adjusting your search" : "Add your first client"}</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={openCreate} size="sm" className="cursor-pointer">Add Client</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Contact Person</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Mobile</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">GST</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">City</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((c) => (
                  <tr key={c._id} className="hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${c.isActive ? "bg-green-500" : "bg-gray-400"}`} />
                        <span className="truncate max-w-[140px]">{c.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{c.contactPerson ?? "—"}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">{c.mobile}</td>
                    <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{c.gstNumber ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{c.city ?? "—"}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${c.isActive ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-gray-100 text-gray-600"}`}>
                        {c.isActive ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link to={`/clients/${c._id}`}><Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"><Eye className="w-3.5 h-3.5" /></Button></Link>
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive" onClick={() => setDeleteConfirm(c._id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Edit Client" : "Add Client"}</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (<FormItem className="col-span-2"><FormLabel>Name *</FormLabel><FormControl><Input placeholder="Government Authority / Builder Name" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="contactPerson" render={({ field }) => (<FormItem><FormLabel>Contact Person</FormLabel><FormControl><Input placeholder="Raj Kumar" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="mobile" render={({ field }) => (<FormItem><FormLabel>Mobile *</FormLabel><FormControl><Input placeholder="9876543210" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="email" render={({ field }) => (<FormItem><FormLabel>Email</FormLabel><FormControl><Input placeholder="client@example.com" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="gstNumber" render={({ field }) => (<FormItem><FormLabel>GST Number</FormLabel><FormControl><Input placeholder="27ABCDE1234F1Z5" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="panNumber" render={({ field }) => (<FormItem><FormLabel>PAN Number</FormLabel><FormControl><Input placeholder="ABCDE1234F" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="city" render={({ field }) => (<FormItem><FormLabel>City</FormLabel><FormControl><Input placeholder="Mumbai" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="address" render={({ field }) => (<FormItem className="col-span-2"><FormLabel>Address</FormLabel><FormControl><Input placeholder="123 Main St, Mumbai" {...field} /></FormControl><FormMessage /></FormItem>)} />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Add Client"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Client?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete the client record.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteConfirm(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" onClick={() => deleteConfirm && handleDelete(deleteConfirm)} className="cursor-pointer">Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
