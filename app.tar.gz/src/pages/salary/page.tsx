import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { toast } from "sonner";
import {
  IndianRupee,
  Plus,
  Zap,
  CheckCircle,
  Clock,
  FileText,
  Eye,
  Trash2,
  Send,
  Check,
  Banknote,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const STATUS_CONFIG = {
  draft: { label: "Draft", color: "bg-zinc-700 text-zinc-200" },
  submitted: { label: "Submitted", color: "bg-amber-700 text-amber-100" },
  approved: { label: "Approved", color: "bg-blue-700 text-blue-100" },
  paid: { label: "Paid", color: "bg-green-700 text-green-100" },
} as const;

function formatINR(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

function getMonthOptions() {
  const options = [];
  const now = new Date();
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = d.toLocaleDateString("en-IN", { month: "long", year: "numeric" });
    options.push({ value, label });
  }
  return options;
}

function SalaryPageInner() {
  const navigate = useNavigate();
  const sheets = useQuery(api.salary.list, {});
  const sites = useQuery(api.sites.list, {});
  const generate = useMutation(api.salary.generate);
  const remove = useMutation(api.salary.remove);
  const submit = useMutation(api.salary.submit);
  const approve = useMutation(api.salary.approve);
  const markPaid = useMutation(api.salary.markPaid);

  const [filterSite, setFilterSite] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [generateOpen, setGenerateOpen] = useState(false);
  const [genSiteId, setGenSiteId] = useState("");
  const [genMonth, setGenMonth] = useState(getMonthOptions()[0].value);
  const [paidDialogId, setPaidDialogId] = useState<Id<"salarySheets"> | null>(null);
  const [paidDate, setPaidDate] = useState(new Date().toISOString().slice(0, 10));
  const [loading, setLoading] = useState(false);

  const monthOptions = getMonthOptions();

  const filtered = (sheets ?? []).filter((s) => {
    if (filterSite !== "all" && s.siteId !== filterSite) return false;
    if (filterStatus !== "all" && s.status !== filterStatus) return false;
    return true;
  });

  // Summary stats
  const totalSheets = (sheets ?? []).length;
  const pendingApproval = (sheets ?? []).filter((s) => s.status === "submitted").length;
  const totalPaid = (sheets ?? []).filter((s) => s.status === "paid").reduce((sum, s) => sum + s.totalAmount, 0);
  const totalPending = (sheets ?? []).filter((s) => s.status !== "paid").reduce((sum, s) => sum + s.totalAmount, 0);

  const handleGenerate = async () => {
    if (!genSiteId || !genMonth) return;
    setLoading(true);
    try {
      const id = await generate({ siteId: genSiteId as Id<"sites">, month: genMonth });
      toast.success("Salary sheet generated from attendance data");
      setGenerateOpen(false);
      navigate(`/salary/${id}`);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to generate sheet");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: Id<"salarySheets">) => {
    try {
      await remove({ id });
      toast.success("Salary sheet deleted");
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to delete");
    }
  };

  const handleSubmit = async (id: Id<"salarySheets">) => {
    try {
      await submit({ id });
      toast.success("Sheet submitted for approval");
    } catch {
      toast.error("Failed to submit");
    }
  };

  const handleApprove = async (id: Id<"salarySheets">) => {
    try {
      await approve({ id });
      toast.success("Sheet approved");
    } catch {
      toast.error("Failed to approve");
    }
  };

  const handleMarkPaid = async () => {
    if (!paidDialogId) return;
    try {
      await markPaid({ id: paidDialogId, paidDate });
      toast.success("Marked as paid");
      setPaidDialogId(null);
    } catch {
      toast.error("Failed to mark as paid");
    }
  };

  if (!sheets) {
    return (
      <div className="p-6 space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Salary & Payroll</h1>
          <p className="text-muted-foreground text-sm mt-1">Monthly salary sheets per site</p>
        </div>
        <Button onClick={() => setGenerateOpen(true)} className="gap-2">
          <Zap className="h-4 w-4" />
          Generate from Attendance
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <FileText className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Sheets</p>
                <p className="text-2xl font-bold">{totalSheets}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Clock className="h-5 w-5 text-amber-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pending Approval</p>
                <p className="text-2xl font-bold">{pendingApproval}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <CheckCircle className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Paid</p>
                <p className="text-lg font-bold">{formatINR(totalPaid)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <IndianRupee className="h-5 w-5 text-orange-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pending Amount</p>
                <p className="text-lg font-bold">{formatINR(totalPending)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Select value={filterSite} onValueChange={setFilterSite}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All Sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {(sites ?? []).map((s) => (
              <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="submitted">Submitted</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Sheets List */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <IndianRupee className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No salary sheets found</p>
            <p className="text-sm text-muted-foreground mt-1">Generate one from attendance data or add manually</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((sheet) => {
            const cfg = STATUS_CONFIG[sheet.status as keyof typeof STATUS_CONFIG];
            const monthLabel = new Date(`${sheet.month}-01`).toLocaleDateString("en-IN", {
              month: "long",
              year: "numeric",
            });
            return (
              <Card key={sheet._id} className="hover:border-primary/50 transition-colors">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-4">
                      <div className="p-2.5 rounded-lg bg-primary/10">
                        <IndianRupee className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{sheet.siteName}</span>
                          <span className="text-muted-foreground">·</span>
                          <span className="text-sm text-muted-foreground">{monthLabel}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                          <span>{sheet.labourCount} labourers</span>
                          <span>·</span>
                          <span>Prepared by {sheet.preparedByName}</span>
                          {sheet.paidDate && (
                            <>
                              <span>·</span>
                              <span>Paid: {new Date(sheet.paidDate).toLocaleDateString("en-IN")}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="font-bold text-lg">{formatINR(sheet.totalAmount)}</span>
                      <Badge className={cfg.color}>{cfg.label}</Badge>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => navigate(`/salary/${sheet._id}`)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {sheet.status === "draft" && (
                          <>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleSubmit(sheet._id)}
                              title="Submit for approval"
                            >
                              <Send className="h-4 w-4 text-amber-400" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDelete(sheet._id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </>
                        )}
                        {sheet.status === "submitted" && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleApprove(sheet._id)}
                            title="Approve"
                          >
                            <Check className="h-4 w-4 text-blue-400" />
                          </Button>
                        )}
                        {sheet.status === "approved" && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => { setPaidDialogId(sheet._id); setPaidDate(new Date().toISOString().slice(0, 10)); }}
                            title="Mark as paid"
                          >
                            <Banknote className="h-4 w-4 text-green-400" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Generate Dialog */}
      <Dialog open={generateOpen} onOpenChange={setGenerateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Generate Salary Sheet</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm text-muted-foreground">
              Auto-calculates salary from attendance records for the selected site and month.
            </p>
            <div className="space-y-2">
              <Label>Site</Label>
              <Select value={genSiteId} onValueChange={setGenSiteId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select site" />
                </SelectTrigger>
                <SelectContent>
                  {(sites ?? []).map((s) => (
                    <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Month</Label>
              <Select value={genMonth} onValueChange={setGenMonth}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setGenerateOpen(false)}>Cancel</Button>
            <Button onClick={handleGenerate} disabled={!genSiteId || loading}>
              {loading ? "Generating..." : "Generate Sheet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mark Paid Dialog */}
      <Dialog open={!!paidDialogId} onOpenChange={(o) => !o && setPaidDialogId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mark as Paid</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label>Payment Date</Label>
            <Input type="date" value={paidDate} onChange={(e) => setPaidDate(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPaidDialogId(null)}>Cancel</Button>
            <Button onClick={handleMarkPaid}>Confirm Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function SalaryPage() {
  return (
    <Authenticated>
      <SalaryPageInner />
    </Authenticated>
  );
}
