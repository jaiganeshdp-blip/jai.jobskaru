import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { toast } from "sonner";
import {
  ArrowLeft,
  Pencil,
  Trash2,
  Plus,
  Send,
  Check,
  Banknote,
  Printer,
  Download,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { downloadSalarySheetPDF } from "@/lib/pdf-exports.ts";
import { downloadSalaryCSV } from "@/lib/csv-exports.ts";

function formatINR(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

const STATUS_CONFIG = {
  draft: { label: "Draft", color: "bg-zinc-700 text-zinc-200" },
  submitted: { label: "Submitted", color: "bg-amber-700 text-amber-100" },
  approved: { label: "Approved", color: "bg-blue-700 text-blue-100" },
  paid: { label: "Paid", color: "bg-green-700 text-green-100" },
} as const;

type EntryEditState = {
  daysWorked: string;
  halfDays: string;
  dailyRate: string;
  deductions: string;
  paymentMode: string;
  notes: string;
  nastaDays: string;
  nastaPerDay: string;
};

function EditEntryDialog({
  entry,
  onClose,
}: {
  entry: {
    _id: Id<"salaryEntries">;
    labourerName: string;
    daysWorked: number;
    halfDays: number;
    dailyRate: number;
    deductions: number;
    paymentMode?: string;
    notes?: string;
    nastaDays?: number;
    nastaPerDay?: number;
  };
  onClose: () => void;
}) {
  const updateEntry = useMutation(api.salary.updateEntry);
  const [form, setForm] = useState<EntryEditState>({
    daysWorked: String(entry.daysWorked),
    halfDays: String(entry.halfDays),
    dailyRate: String(entry.dailyRate),
    deductions: String(entry.deductions),
    paymentMode: entry.paymentMode ?? "",
    notes: entry.notes ?? "",
    nastaDays: String(entry.nastaDays ?? 0),
    nastaPerDay: String(entry.nastaPerDay ?? 0),
  });
  const [saving, setSaving] = useState(false);

  const set = (key: keyof EntryEditState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const gross =
    (parseFloat(form.daysWorked) || 0) * (parseFloat(form.dailyRate) || 0) +
    (parseFloat(form.halfDays) || 0) * 0.5 * (parseFloat(form.dailyRate) || 0);
  const nastaAmt = (parseFloat(form.nastaDays) || 0) * (parseFloat(form.nastaPerDay) || 0);
  const net = gross + nastaAmt - (parseFloat(form.deductions) || 0);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateEntry({
        entryId: entry._id,
        daysWorked: parseFloat(form.daysWorked) || 0,
        halfDays: parseFloat(form.halfDays) || 0,
        dailyRate: parseFloat(form.dailyRate) || 0,
        deductions: parseFloat(form.deductions) || 0,
        paymentMode: form.paymentMode || undefined,
        notes: form.notes || undefined,
        nastaDays: parseFloat(form.nastaDays) || undefined,
        nastaPerDay: parseFloat(form.nastaPerDay) || undefined,
      });
      toast.success("Entry updated");
      onClose();
    } catch {
      toast.error("Failed to update");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Entry — {entry.labourerName}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          <div className="space-y-1">
            <Label>Days Worked (Hajri)</Label>
            <Input type="number" min="0" value={form.daysWorked} onChange={set("daysWorked")} />
          </div>
          <div className="space-y-1">
            <Label>Half Days</Label>
            <Input type="number" min="0" value={form.halfDays} onChange={set("halfDays")} />
          </div>
          <div className="space-y-1">
            <Label>Daily Rate (₹)</Label>
            <Input type="number" min="0" value={form.dailyRate} onChange={set("dailyRate")} />
          </div>
          <div className="space-y-1">
            <Label>Deductions (₹)</Label>
            <Input type="number" min="0" value={form.deductions} onChange={set("deductions")} />
          </div>
          <div className="col-span-2 border-t pt-3">
            <p className="text-xs font-semibold text-orange-500 mb-2 uppercase tracking-wide">🍽 Nasta / Khaana Allowance</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Nasta Kitne Din? (Days)</Label>
                <Input type="number" min="0" value={form.nastaDays} onChange={set("nastaDays")} placeholder="20" />
              </div>
              <div className="space-y-1">
                <Label>Nasta Per Day (₹)</Label>
                <Input type="number" min="0" value={form.nastaPerDay} onChange={set("nastaPerDay")} placeholder="50" />
              </div>
            </div>
            {nastaAmt > 0 && (
              <p className="text-xs text-orange-500 mt-1">Nasta Total: ₹{nastaAmt.toLocaleString("en-IN")}</p>
            )}
          </div>
          <div className="space-y-1">
            <Label>Payment Mode</Label>
            <Select
              value={form.paymentMode || "none"}
              onValueChange={(v) => setForm((f) => ({ ...f, paymentMode: v === "none" ? "" : v }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— None —</SelectItem>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="upi">UPI</SelectItem>
                <SelectItem value="neft">NEFT</SelectItem>
                <SelectItem value="cheque">Cheque</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label>Notes</Label>
            <Input value={form.notes} onChange={set("notes")} placeholder="Optional" />
          </div>
        </div>
        <div className="flex justify-between text-sm bg-muted rounded-lg px-4 py-3">
          <span>Gross: <strong>{formatINR(gross)}</strong></span>
          {nastaAmt > 0 && <span>+Nasta: <strong className="text-orange-400">{formatINR(nastaAmt)}</strong></span>}
          <span>Net Pay: <strong className="text-green-400">{formatINR(Math.max(0, net))}</strong></span>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AddEntryDialog({
  sheetId,
  siteId,
  onClose,
}: {
  sheetId: Id<"salarySheets">;
  siteId: Id<"sites">;
  onClose: () => void;
}) {
  const addEntry = useMutation(api.salary.addEntry);
  const labourers = useQuery(api.labourers.list, { siteId });
  const [labourerId, setLabourerId] = useState("");
  const [form, setForm] = useState<EntryEditState>({
    daysWorked: "26",
    halfDays: "0",
    dailyRate: "500",
    deductions: "0",
    paymentMode: "",
    notes: "",
    nastaDays: "0",
    nastaPerDay: "0",
  });
  const [saving, setSaving] = useState(false);

  const set = (key: keyof EntryEditState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const gross =
    (parseFloat(form.daysWorked) || 0) * (parseFloat(form.dailyRate) || 0) +
    (parseFloat(form.halfDays) || 0) * 0.5 * (parseFloat(form.dailyRate) || 0);
  const nastaAmt = (parseFloat(form.nastaDays) || 0) * (parseFloat(form.nastaPerDay) || 0);
  const net = gross + nastaAmt - (parseFloat(form.deductions) || 0);

  const handleAdd = async () => {
    if (!labourerId) return;
    setSaving(true);
    try {
      await addEntry({
        salarySheetId: sheetId,
        labourerId: labourerId as Id<"labourers">,
        daysWorked: parseFloat(form.daysWorked) || 0,
        halfDays: parseFloat(form.halfDays) || 0,
        dailyRate: parseFloat(form.dailyRate) || 0,
        deductions: parseFloat(form.deductions) || 0,
        paymentMode: form.paymentMode || undefined,
        notes: form.notes || undefined,
        nastaDays: parseFloat(form.nastaDays) || undefined,
        nastaPerDay: parseFloat(form.nastaPerDay) || undefined,
      });
      toast.success("Labourer added to sheet");
      onClose();
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to add");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Labourer to Sheet</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1">
            <Label>Labourer</Label>
            <Select value={labourerId} onValueChange={setLabourerId}>
              <SelectTrigger>
                <SelectValue placeholder="Select labourer" />
              </SelectTrigger>
              <SelectContent>
                {(labourers ?? []).map((l) => (
                  <SelectItem key={l._id} value={l._id}>{l.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Days Worked (Hajri)</Label>
              <Input type="number" min="0" value={form.daysWorked} onChange={set("daysWorked")} />
            </div>
            <div className="space-y-1">
              <Label>Half Days</Label>
              <Input type="number" min="0" value={form.halfDays} onChange={set("halfDays")} />
            </div>
            <div className="space-y-1">
              <Label>Daily Rate (₹)</Label>
              <Input type="number" min="0" value={form.dailyRate} onChange={set("dailyRate")} />
            </div>
            <div className="space-y-1">
              <Label>Deductions (₹)</Label>
              <Input type="number" min="0" value={form.deductions} onChange={set("deductions")} />
            </div>
          </div>
          <div className="border-t pt-3">
            <p className="text-xs font-semibold text-orange-500 mb-2 uppercase tracking-wide">🍽 Nasta / Khaana Allowance</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Nasta Kitne Din?</Label>
                <Input type="number" min="0" value={form.nastaDays} onChange={set("nastaDays")} placeholder="20" />
              </div>
              <div className="space-y-1">
                <Label>Nasta Per Day (₹)</Label>
                <Input type="number" min="0" value={form.nastaPerDay} onChange={set("nastaPerDay")} placeholder="50" />
              </div>
            </div>
            {nastaAmt > 0 && <p className="text-xs text-orange-500 mt-1">Nasta Total: ₹{nastaAmt.toLocaleString("en-IN")}</p>}
          </div>
          <div className="flex justify-between text-sm bg-muted rounded-lg px-4 py-3">
            <span>Gross: <strong>{formatINR(gross)}</strong></span>
            {nastaAmt > 0 && <span>+Nasta: <strong className="text-orange-400">{formatINR(nastaAmt)}</strong></span>}
            <span>Net Pay: <strong className="text-green-400">{formatINR(Math.max(0, net))}</strong></span>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleAdd} disabled={!labourerId || saving}>Add Entry</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SalaryDetailInner({ id }: { id: Id<"salarySheets"> }) {
  const navigate = useNavigate();
  const sheet = useQuery(api.salary.getDetail, { id });
  const removeEntry = useMutation(api.salary.removeEntry);
  const removeSheet = useMutation(api.salary.remove);
  const submit = useMutation(api.salary.submit);
  const approve = useMutation(api.salary.approve);
  const markPaid = useMutation(api.salary.markPaid);

  const [editEntry, setEditEntry] = useState<(typeof sheet extends null | undefined ? never : NonNullable<typeof sheet>["entries"][number]) | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [paidDialogOpen, setPaidDialogOpen] = useState(false);
  const [paidDate, setPaidDate] = useState(new Date().toISOString().slice(0, 10));

  if (sheet === undefined) {
    return (
      <div className="p-6 space-y-4">
        {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
      </div>
    );
  }
  if (!sheet) return <div className="p-6 text-muted-foreground">Sheet not found.</div>;

  const cfg = STATUS_CONFIG[sheet.status as keyof typeof STATUS_CONFIG];
  const monthLabel = new Date(`${sheet.month}-01`).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric",
  });
  const canEdit = true; // Allow edit/delete on any status

  const handleRemoveEntry = async (entryId: Id<"salaryEntries">) => {
    try {
      await removeEntry({ entryId });
      toast.success("Entry removed");
    } catch {
      toast.error("Failed to remove");
    }
  };

  const handlePrint = () => window.print();

  const handleDeleteSheet = async () => {
    if (!confirm("Yeh salary sheet delete karein? Yeh undo nahi hoga.")) return;
    try {
      await removeSheet({ id });
      toast.success("Salary sheet delete ho gayi");
      navigate("/salary");
    } catch {
      toast.error("Delete nahi hua");
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate("/salary")}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{sheet.siteName}</h1>
            <Badge className={cfg.color}>{cfg.label}</Badge>
          </div>
          <p className="text-muted-foreground text-sm">{monthLabel} · {sheet.siteCity}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive cursor-pointer" onClick={() => void handleDeleteSheet()}>
            <Trash2 className="h-4 w-4 mr-1" /> Delete Sheet
          </Button>
          <Button variant="ghost" size="sm" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-1" /> Print
          </Button>
          <Button variant="ghost" size="sm" onClick={() => {
            downloadSalarySheetPDF({
              siteName: sheet.siteName,
              siteCity: sheet.siteCity,
              month: sheet.month,
              status: sheet.status,
              preparedByName: sheet.preparedByName,
              approvedByName: sheet.approvedByName ?? undefined,
              totalAmount: sheet.totalAmount,
              entries: sheet.entries.map((e) => ({
                labourerName: e.labourerName,
                designation: e.designation ?? undefined,
                contractorName: e.contractorName ?? undefined,
                daysWorked: e.daysWorked,
                halfDays: e.halfDays,
                dailyRate: e.dailyRate,
                grossAmount: e.grossAmount,
                deductions: e.deductions,
                netAmount: e.netAmount,
                paymentMode: e.paymentMode ?? undefined,
              })),
            });
            toast.success("PDF downloaded");
          }}>
            <Download className="h-4 w-4 mr-1" /> PDF
          </Button>
          <Button variant="ghost" size="sm" onClick={() => {
            downloadSalaryCSV(sheet.entries.map((e) => ({
              labourerName: e.labourerName,
              designation: e.designation ?? undefined,
              contractorName: e.contractorName ?? undefined,
              daysWorked: e.daysWorked,
              halfDays: e.halfDays,
              dailyRate: e.dailyRate,
              grossAmount: e.grossAmount,
              deductions: e.deductions,
              netAmount: e.netAmount,
              paymentMode: e.paymentMode ?? undefined,
            })), sheet.siteName, sheet.month);
            toast.success("CSV downloaded");
          }}>
            <Download className="h-4 w-4 mr-1" /> CSV
          </Button>
          {canEdit && (
            <Button size="sm" onClick={() => setAddOpen(true)}>
              <Plus className="h-4 w-4 mr-1" /> Add Labourer
            </Button>
          )}
          {sheet.status === "draft" && (
            <Button size="sm" onClick={async () => { await submit({ id }); toast.success("Submitted for approval"); }}>
              <Send className="h-4 w-4 mr-1" /> Submit
            </Button>
          )}
          {sheet.status === "submitted" && (
            <Button size="sm" onClick={async () => { await approve({ id }); toast.success("Approved"); }}>
              <Check className="h-4 w-4 mr-1" /> Approve
            </Button>
          )}
          {sheet.status === "approved" && (
            <Button size="sm" onClick={() => setPaidDialogOpen(true)}>
              <Banknote className="h-4 w-4 mr-1" /> Mark Paid
            </Button>
          )}
        </div>
      </div>

      {/* Meta Info */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground">Prepared By</p>
            <p className="font-semibold">{sheet.preparedByName}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground">Approved By</p>
            <p className="font-semibold">{sheet.approvedByName || "—"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground">Total Labourers</p>
            <p className="font-semibold">{sheet.entries.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 text-sm">
            <p className="text-muted-foreground">Total Payable</p>
            <p className="font-bold text-lg text-green-400">{formatINR(sheet.totalAmount)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Payroll Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Salary Register — {monthLabel}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left px-4 py-3 font-medium">#</th>
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">Designation</th>
                  <th className="text-left px-4 py-3 font-medium">Contractor</th>
                  <th className="text-right px-4 py-3 font-medium">Days</th>
                  <th className="text-right px-4 py-3 font-medium">½ Days</th>
                  <th className="text-right px-4 py-3 font-medium">Rate/Day</th>
                  <th className="text-right px-4 py-3 font-medium">Gross</th>
                  <th className="text-right px-4 py-3 font-medium">Deductions</th>
                  <th className="text-right px-4 py-3 font-medium text-green-400">Net Pay</th>
                  <th className="text-left px-4 py-3 font-medium">Mode</th>
                  {canEdit && <th className="px-4 py-3"></th>}
                </tr>
              </thead>
              <tbody>
                {sheet.entries.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="text-center py-10 text-muted-foreground">
                      No entries. Add labourers to this sheet.
                    </td>
                  </tr>
                ) : (
                  sheet.entries.map((entry, idx) => (
                    <tr key={entry._id} className="border-b border-border/50 hover:bg-muted/30">
                      <td className="px-4 py-3 text-muted-foreground">{idx + 1}</td>
                      <td className="px-4 py-3 font-medium">{entry.labourerName}</td>
                      <td className="px-4 py-3 text-muted-foreground">{entry.designation || "—"}</td>
                      <td className="px-4 py-3 text-muted-foreground">{entry.contractorName || "—"}</td>
                      <td className="px-4 py-3 text-right">{entry.daysWorked}</td>
                      <td className="px-4 py-3 text-right">{entry.halfDays}</td>
                      <td className="px-4 py-3 text-right">{formatINR(entry.dailyRate)}</td>
                      <td className="px-4 py-3 text-right">{formatINR(entry.grossAmount)}</td>
                      <td className="px-4 py-3 text-right text-red-400">
                        {entry.deductions > 0 ? (
                          <div>
                            <span>- {formatINR(entry.deductions)}</span>
                            {(entry.totalAdvance ?? 0) > 0 && (
                              <p className="text-xs text-orange-400 font-normal">Advance: {formatINR(entry.totalAdvance ?? 0)}</p>
                            )}
                          </div>
                        ) : "—"}
                      </td>
                      <td className="px-4 py-3 text-right font-semibold text-green-400">
                        {formatINR(entry.netAmount)}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground capitalize">
                        {entry.paymentMode || "—"}
                      </td>
                      {canEdit && (
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditEntry(entry)}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveEntry(entry._id)}
                            >
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </Button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
              {sheet.entries.length > 0 && (
                <tfoot>
                  <tr className="bg-muted/50 font-semibold border-t-2 border-border">
                    <td colSpan={7} className="px-4 py-3 text-right">Totals</td>
                    <td className="px-4 py-3 text-right">
                      {formatINR(sheet.entries.reduce((s, e) => s + e.grossAmount, 0))}
                    </td>
                    <td className="px-4 py-3 text-right text-red-400">
                      {formatINR(sheet.entries.reduce((s, e) => s + e.deductions, 0))}
                    </td>
                    <td className="px-4 py-3 text-right text-green-400">
                      {formatINR(sheet.totalAmount)}
                    </td>
                    <td colSpan={canEdit ? 2 : 1}></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      {editEntry && (
        <EditEntryDialog entry={editEntry} onClose={() => setEditEntry(null)} />
      )}
      {addOpen && (
        <AddEntryDialog
          sheetId={id}
          siteId={sheet.siteId as Id<"sites">}
          onClose={() => setAddOpen(false)}
        />
      )}
      <Dialog open={paidDialogOpen} onOpenChange={setPaidDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mark as Paid</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label>Payment Date</Label>
            <Input type="date" value={paidDate} onChange={(e) => setPaidDate(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPaidDialogOpen(false)}>Cancel</Button>
            <Button
              onClick={async () => {
                await markPaid({ id, paidDate });
                toast.success("Marked as paid");
                setPaidDialogOpen(false);
              }}
            >
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function SalaryDetailPage() {
  const { id } = useParams<{ id: string }>();
  if (!id) return null;
  return (
    <Authenticated>
      <SalaryDetailInner id={id as Id<"salarySheets">} />
    </Authenticated>
  );
}
