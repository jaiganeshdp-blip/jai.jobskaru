import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Input } from "@/components/ui/input.tsx";
import { toast } from "sonner";
import { Settings, PauseCircle, PlayCircle, Trash2, ShieldCheck, HardHat } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const ROLES = [
  { value: "super_admin", label: "Super Admin" },
  { value: "site_incharge", label: "Site Incharge" },
  { value: "site_supervisor", label: "Site Supervisor" },
  { value: "safety_supervisor", label: "Safety Supervisor" },
  { value: "billing_manager", label: "Billing Manager" },
  { value: "accounts_manager", label: "Accounts Manager" },
  { value: "supplier", label: "Supplier" },
  { value: "contractor", label: "Contractor" },
  { value: "labour", label: "Labour" },
  { value: "viewer", label: "Viewer" },
  { value: "pending", label: "Pending" },
] as const;

type Role = (typeof ROLES)[number]["value"];

// Roles that can have custom permissions (super_admin always has all)
const ROLES_WITH_PERMISSIONS: Role[] = [
  "site_incharge", "site_supervisor", "safety_supervisor",
  "billing_manager", "accounts_manager", "supplier", "contractor", "viewer",
];

type UserPermissions = {
  canViewLabour: boolean;
  canMarkAttendance: boolean;
  canViewSiteDiary: boolean;
  canAddSiteDiary: boolean;
  canViewMaterials: boolean;
  canRequestMaterials: boolean;
  canViewWorkOrders: boolean;
  canViewSafety: boolean;
  canAddSafetyReport: boolean;
  canViewSites: boolean;
  canViewSalary: boolean;
  canViewInvoices: boolean;
  canViewPayments: boolean;
  canViewExpenses: boolean;
  canViewPurchaseOrders: boolean;
  canViewVendorBills: boolean;
  canViewIncomingInvoices: boolean;
  canViewBankStatement: boolean;
  canViewGstTracking: boolean;
  canViewBillingDashboard: boolean;
  canViewAnalytics: boolean;
  canViewReports: boolean;
  canViewSitePnl: boolean;
  canViewBoq: boolean;
  canViewDeliveryChallans: boolean;
  canViewLabourCorrections: boolean;
  canViewCompanies: boolean;
  canViewPartners: boolean;
  canViewClients: boolean;
  canViewSuppliers: boolean;
  canViewContractors: boolean;
};

type PermissionDef = { key: keyof UserPermissions; label: string; desc: string };

const PERMISSION_GROUPS: { title: string; items: PermissionDef[] }[] = [
  {
    title: "Site Operations",
    items: [
      { key: "canViewSites", label: "Sites Dekhna", desc: "Construction sites list" },
      { key: "canViewLabour", label: "Labour Dekhna", desc: "Labour ki list" },
      { key: "canMarkAttendance", label: "Attendance Dalna", desc: "Labour attendance mark karna" },
      { key: "canViewSiteDiary", label: "Site Diary Dekhna", desc: "Daily site diary entries" },
      { key: "canAddSiteDiary", label: "Site Diary Likhna", desc: "Nai diary entry add karna" },
      { key: "canViewMaterials", label: "Materials Dekhna", desc: "Site materials list" },
      { key: "canRequestMaterials", label: "Material Request Karna", desc: "Naya material request" },
      { key: "canViewWorkOrders", label: "Work Orders Dekhna", desc: "Work orders aur progress" },
      { key: "canViewSafety", label: "Safety Reports Dekhna", desc: "Safety incidents" },
      { key: "canAddSafetyReport", label: "Safety Report Dalna", desc: "Naya safety report" },
    ],
  },
  {
    title: "Finance & Billing",
    items: [
      { key: "canViewSalary", label: "Salary Dekhna", desc: "Labour salary sheets" },
      { key: "canViewInvoices", label: "Invoices Dekhna", desc: "Client invoices" },
      { key: "canViewPayments", label: "Payments Dekhna", desc: "Payment records" },
      { key: "canViewExpenses", label: "Expenses Dekhna", desc: "Site expenses" },
      { key: "canViewPurchaseOrders", label: "Purchase Orders", desc: "PO list" },
      { key: "canViewVendorBills", label: "Vendor Bills", desc: "Contractor/supplier bills" },
      { key: "canViewIncomingInvoices", label: "Incoming Invoices", desc: "Received invoices" },
      { key: "canViewBankStatement", label: "Bank Statement", desc: "Bank transactions" },
      { key: "canViewGstTracking", label: "GST Invoice Tracking", desc: "GST invoice status" },
      { key: "canViewBillingDashboard", label: "Billing Dashboard", desc: "Billing overview" },
    ],
  },
  {
    title: "Reports & Analytics",
    items: [
      { key: "canViewAnalytics", label: "Analytics", desc: "Charts aur graphs" },
      { key: "canViewReports", label: "Reports", desc: "Downloadable reports" },
      { key: "canViewSitePnl", label: "Site P&L", desc: "Profit & Loss per site" },
      { key: "canViewBoq", label: "BOQ Management", desc: "Bill of quantities" },
      { key: "canViewDeliveryChallans", label: "Delivery Challans", desc: "Material delivery records" },
      { key: "canViewLabourCorrections", label: "Labour Corrections", desc: "Attendance corrections" },
    ],
  },
  {
    title: "Master Data",
    items: [
      { key: "canViewCompanies", label: "Companies Dekhna", desc: "Company list" },
      { key: "canViewPartners", label: "Partners Dekhna", desc: "Partners/investors" },
      { key: "canViewClients", label: "Clients Dekhna", desc: "Client list" },
      { key: "canViewSuppliers", label: "Suppliers Dekhna", desc: "Supplier list" },
      { key: "canViewContractors", label: "Contractors Dekhna", desc: "Contractor list" },
    ],
  },
];

// Default permissions per role
function getDefaultPermissions(role: Role): UserPermissions {
  const none: UserPermissions = {
    canViewLabour: false, canMarkAttendance: false, canViewSiteDiary: false,
    canAddSiteDiary: false, canViewMaterials: false, canRequestMaterials: false,
    canViewWorkOrders: false, canViewSafety: false, canAddSafetyReport: false,
    canViewSites: false, canViewSalary: false, canViewInvoices: false,
    canViewPayments: false, canViewExpenses: false, canViewPurchaseOrders: false,
    canViewVendorBills: false, canViewIncomingInvoices: false, canViewBankStatement: false,
    canViewGstTracking: false, canViewBillingDashboard: false, canViewAnalytics: false,
    canViewReports: false, canViewSitePnl: false, canViewBoq: false,
    canViewDeliveryChallans: false, canViewLabourCorrections: false, canViewCompanies: false,
    canViewPartners: false, canViewClients: false, canViewSuppliers: false,
    canViewContractors: false,
  };

  if (role === "site_incharge") return {
    ...none,
    canViewSites: true, canViewLabour: true, canMarkAttendance: true,
    canViewSiteDiary: true, canAddSiteDiary: true, canViewMaterials: true,
    canRequestMaterials: true, canViewWorkOrders: true, canViewSafety: true,
    canViewSalary: true, canViewExpenses: true, canViewVendorBills: true,
    canViewAnalytics: true, canViewReports: true, canViewSuppliers: true,
    canViewContractors: true, canViewDeliveryChallans: true, canViewLabourCorrections: true,
    canViewBillingDashboard: true, canViewBoq: true,
  };

  if (role === "site_supervisor") return {
    ...none,
    canViewSites: true, canViewLabour: true, canMarkAttendance: true,
    canViewSiteDiary: true, canAddSiteDiary: true, canViewWorkOrders: true,
  };

  if (role === "safety_supervisor") return {
    ...none,
    canViewSites: true, canViewLabour: true, canViewSafety: true, canAddSafetyReport: true,
  };

  if (role === "billing_manager") return {
    ...none,
    canViewSites: true, canViewSalary: true, canViewInvoices: true, canViewPayments: true,
    canViewExpenses: true, canViewPurchaseOrders: true, canViewVendorBills: true,
    canViewIncomingInvoices: true, canViewBillingDashboard: true, canViewReports: true,
    canViewDeliveryChallans: true, canViewContractors: true, canViewSuppliers: true,
  };

  if (role === "accounts_manager") return {
    ...none,
    canViewSites: true, canViewLabour: true, canViewSalary: true, canViewInvoices: true,
    canViewPayments: true, canViewExpenses: true, canViewPurchaseOrders: true,
    canViewVendorBills: true, canViewIncomingInvoices: true, canViewBankStatement: true,
    canViewGstTracking: true, canViewBillingDashboard: true, canViewAnalytics: true,
    canViewReports: true, canViewSitePnl: true, canViewBoq: true,
    canViewDeliveryChallans: true, canViewLabourCorrections: true, canViewCompanies: true,
    canViewPartners: true, canViewClients: true, canViewSuppliers: true,
    canViewContractors: true, canViewWorkOrders: true,
  };

  if (role === "contractor") return {
    ...none,
    canViewSites: true, canViewLabour: true, canViewWorkOrders: true,
    canViewVendorBills: true,
  };

  if (role === "supplier") return {
    ...none,
    canViewSites: true, canViewPurchaseOrders: true, canViewVendorBills: true,
    canViewDeliveryChallans: true,
  };

  if (role === "viewer") return {
    ...none,
    canViewSites: true, canViewLabour: true, canViewSiteDiary: true,
    canViewMaterials: true, canViewWorkOrders: true, canViewAnalytics: true,
    canViewReports: true,
  };

  return none;
}

type UserRow = {
  _id: Id<"users">;
  name?: string;
  email?: string;
  role: string;
  isActive?: boolean;
  userPermissions?: UserPermissions;
  labourerRef?: Id<"labourers">;
  mobile?: string;
};

// ---- Universal Permissions Dialog ----
function PermissionsDialog({
  user,
  open,
  onClose,
}: {
  user: UserRow;
  open: boolean;
  onClose: () => void;
}) {
  const updatePerms = useMutation(api.users.updateUserPermissions);
  const [perms, setPerms] = useState<UserPermissions>(
    user.userPermissions ?? getDefaultPermissions(user.role as Role)
  );
  const [saving, setSaving] = useState(false);

  const toggle = (key: keyof UserPermissions) => {
    setPerms((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const setAll = (value: boolean) => {
    const all = {} as UserPermissions;
    for (const group of PERMISSION_GROUPS) {
      for (const item of group.items) {
        all[item.key] = value;
      }
    }
    setPerms(all);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updatePerms({ userId: user._id, userPermissions: perms });
      toast.success(`${user.name ?? "User"} ki permissions save ho gayi!`);
      onClose();
    } catch {
      toast.error("Permissions save nahi hui, dobara try karo.");
    } finally {
      setSaving(false);
    }
  };

  const roleName = ROLES.find(r => r.value === user.role)?.label ?? user.role;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-primary">
            <ShieldCheck className="w-5 h-5" />
            {user.name} — {roleName} Permissions
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            Yeh user ke dashboard mein sirf wahi dikhega jo yahan ON hai.
          </p>
        </DialogHeader>

        {/* Select All / None */}
        <div className="flex gap-2 pt-1">
          <Button size="sm" variant="ghost" onClick={() => setAll(true)} className="cursor-pointer text-xs h-7">
            Sabhi ON
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setAll(false)} className="cursor-pointer text-xs h-7">
            Sabhi OFF
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setPerms(getDefaultPermissions(user.role as Role))} className="cursor-pointer text-xs h-7">
            Default Reset
          </Button>
        </div>

        <div className="space-y-5 py-1">
          {PERMISSION_GROUPS.map((group) => (
            <div key={group.title}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 border-b pb-1">
                {group.title}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {group.items.map(({ key, label, desc }) => (
                  <div
                    key={key}
                    className={`flex items-center justify-between gap-3 rounded-lg border p-2.5 cursor-pointer transition-colors ${
                      perms[key] ? "border-primary/30 bg-primary/5" : "border-border hover:bg-muted/30"
                    }`}
                    onClick={() => toggle(key)}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium leading-tight">{label}</div>
                      <div className="text-xs text-muted-foreground">{desc}</div>
                    </div>
                    <Switch
                      checked={perms[key]}
                      onCheckedChange={() => toggle(key)}
                      className="cursor-pointer flex-shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleSave} disabled={saving} className="cursor-pointer gap-2">
            <ShieldCheck className="w-4 h-4" />
            {saving ? "Save ho raha hai..." : "Permissions Save Karo"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Create Labourer Record Dialog ----
function CreateLabourerDialog({
  user,
  open,
  onClose,
}: {
  user: UserRow;
  open: boolean;
  onClose: () => void;
}) {
  const createLabourer = useMutation(api.labourers.createLabourerForUser);
  const sites = useQuery(api.sites.list, {});
  const [siteId, setSiteId] = useState("");
  const [dailyRate, setDailyRate] = useState("");
  const [saving, setSaving] = useState(false);

  const handleCreate = async () => {
    if (!siteId) { toast.error("Site select karo"); return; }
    if (!dailyRate || isNaN(Number(dailyRate))) { toast.error("Daily rate daalo"); return; }
    setSaving(true);
    try {
      await createLabourer({ userId: user._id, siteId: siteId as Id<"sites">, dailyRate: Number(dailyRate) });
      toast.success(`${user.name ?? "User"} ka labourer record ban gaya!`);
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Error hua");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-primary">
            <HardHat className="w-5 h-5" />
            {user.name} ka Labour Record Banao
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1">
            <Label className="font-semibold">Site *</Label>
            <Select value={siteId} onValueChange={setSiteId}>
              <SelectTrigger><SelectValue placeholder="Site choose karo..." /></SelectTrigger>
              <SelectContent>
                {(sites ?? []).map(s => (
                  <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="font-semibold">Daily Rate (₹) *</Label>
            <Input type="number" placeholder="Jaise: 600" value={dailyRate} onChange={e => setDailyRate(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleCreate} disabled={saving} className="cursor-pointer gap-2">
            <HardHat className="w-4 h-4" />
            {saving ? "Ban raha hai..." : "Record Banao"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Main Page ----
export default function Users() {
  const users = useQuery(api.users.listUsers, {});
  const updateRole = useMutation(api.users.updateUserRole);
  const toggleSuspend = useMutation(api.users.toggleUserSuspend);
  const deleteUser = useMutation(api.users.deleteUser);

  const [updating, setUpdating] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<{ id: Id<"users">; name: string } | null>(null);
  const [permUser, setPermUser] = useState<UserRow | null>(null);
  const [labourUser, setLabourUser] = useState<UserRow | null>(null);

  async function handleRoleChange(userId: string, role: Role) {
    setUpdating(userId);
    try {
      await updateRole({ userId: userId as Id<"users">, role });
      toast.success("Role update ho gaya");
    } catch {
      toast.error("Role update nahi hua");
    } finally {
      setUpdating(null);
    }
  }

  async function handleToggleSuspend(userId: Id<"users">, isActive: boolean) {
    try {
      await toggleSuspend({ userId });
      toast.success(isActive ? "User suspend ho gaya" : "User active ho gaya");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update nahi hua");
    }
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    try {
      await deleteUser({ userId: confirmDelete.id });
      toast.success("User delete ho gaya");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete nahi hua");
    } finally {
      setConfirmDelete(null);
    }
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        <Settings className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold tracking-tight">User Management</h1>
          <p className="text-muted-foreground text-sm">
            Roles assign karo. Shield icon se har user ki permissions customize karo.
          </p>
        </div>
      </div>

      {!users ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">User</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Email</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Role</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {users.map((user) => (
                  <tr key={user._id} className={`hover:bg-muted/30 ${!user.isActive ? "opacity-60" : ""}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary flex-shrink-0">
                          {user.name?.[0]?.toUpperCase() ?? "U"}
                        </div>
                        <div>
                          <div className="font-medium">{user.name ?? "Unknown"}</div>
                          {/* Show permissions set indicator */}
                          {user.userPermissions && (
                            <div className="text-[10px] text-primary flex items-center gap-0.5 mt-0.5">
                              <ShieldCheck className="w-2.5 h-2.5" /> Custom permissions
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{user.email ?? "—"}</td>
                    <td className="px-4 py-3">
                      <Select
                        value={user.role}
                        onValueChange={(val) => handleRoleChange(user._id, val as Role)}
                        disabled={updating === user._id}
                      >
                        <SelectTrigger className="w-40 h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ROLES.map((r) => (
                            <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={user.isActive ? "default" : "destructive"}>
                        {user.isActive ? "Active" : "Suspended"}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {/* Permissions button — for all non-super_admin roles */}
                        {ROLES_WITH_PERMISSIONS.includes(user.role as Role) && (
                          <button
                            onClick={() => setPermUser(user as UserRow)}
                            title="Permissions set karo"
                            className={`cursor-pointer p-1.5 rounded hover:bg-muted transition-colors ${
                              user.userPermissions ? "text-primary" : "text-muted-foreground hover:text-primary"
                            }`}
                          >
                            <ShieldCheck className="w-4 h-4" />
                          </button>
                        )}
                        {/* Labour record button — for labour users without a labourer record */}
                        {user.role === "labour" && !user.labourerRef && (
                          <button
                            onClick={() => setLabourUser(user as UserRow)}
                            title="Labour record banao"
                            className="cursor-pointer p-1.5 rounded hover:bg-muted transition-colors text-amber-500"
                          >
                            <HardHat className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleToggleSuspend(user._id as Id<"users">, user.isActive ?? true)}
                          title={user.isActive ? "Suspend" : "Activate"}
                          className="cursor-pointer p-1.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                        >
                          {user.isActive ? <PauseCircle className="w-4 h-4 text-amber-500" /> : <PlayCircle className="w-4 h-4 text-green-500" />}
                        </button>
                        <button
                          onClick={() => setConfirmDelete({ id: user._id as Id<"users">, name: user.name ?? "this user" })}
                          title="Delete"
                          className="cursor-pointer p-1.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Permissions Dialog */}
      {permUser && (
        <PermissionsDialog user={permUser} open={!!permUser} onClose={() => setPermUser(null)} />
      )}

      {/* Labour Record Dialog */}
      {labourUser && (
        <CreateLabourerDialog user={labourUser} open={!!labourUser} onClose={() => setLabourUser(null)} />
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => { if (!o) setConfirmDelete(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>User Delete Karein?</AlertDialogTitle>
            <AlertDialogDescription>
              Kya aap <strong>{confirmDelete?.name}</strong> ko delete karna chahte ho? Yeh action undo nahi hoga.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
