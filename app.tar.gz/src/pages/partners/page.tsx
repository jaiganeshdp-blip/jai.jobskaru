import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs.tsx";
import {
  Plus, Pencil, Trash2, Users, TrendingUp, TrendingDown, Building2,
  MapPin, Percent, Phone, ChevronDown, ChevronRight,
} from "lucide-react";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function fmt(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

type PartnerFormData = {
  companyId: string;
  name: string;
  mobile: string;
  email: string;
  sharePercent: string;
  capitalInvested: string;
  notes: string;
};

const emptyForm: PartnerFormData = {
  companyId: "", name: "", mobile: "", email: "",
  sharePercent: "0", capitalInvested: "", notes: "",
};

function PartnerFormDialog({
  open, onClose, initial, editId,
}: {
  open: boolean;
  onClose: () => void;
  initial?: PartnerFormData;
  editId?: Id<"partners">;
}) {
  const companies = useQuery(api.companies.list, {});
  const create = useMutation(api.partners.create);
  const update = useMutation(api.partners.update);
  const [form, setForm] = useState<PartnerFormData>(initial ?? emptyForm);
  const [saving, setSaving] = useState(false);

  const set = (k: keyof PartnerFormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSave = async () => {
    if (!form.name || !form.companyId) { toast.error("Name and company required"); return; }
    setSaving(true);
    try {
      if (editId) {
        await update({
          id: editId,
          name: form.name,
          mobile: form.mobile || undefined,
          email: form.email || undefined,
          sharePercent: parseFloat(form.sharePercent) || 0,
          capitalInvested: form.capitalInvested ? parseFloat(form.capitalInvested) : undefined,
          notes: form.notes || undefined,
        });
        toast.success("Partner updated");
      } else {
        await create({
          companyId: form.companyId as Id<"companies">,
          name: form.name,
          mobile: form.mobile || undefined,
          email: form.email || undefined,
          sharePercent: parseFloat(form.sharePercent) || 0,
          capitalInvested: form.capitalInvested ? parseFloat(form.capitalInvested) : undefined,
          notes: form.notes || undefined,
        });
        toast.success("Partner added");
      }
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{editId ? "Edit Partner" : "Add New Partner"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-2">
          {!editId && (
            <div className="col-span-2 space-y-1">
              <Label>Company *</Label>
              <Select value={form.companyId} onValueChange={(v) => setForm((f) => ({ ...f, companyId: v }))}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select company" /></SelectTrigger>
                <SelectContent>
                  {(companies ?? []).map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="col-span-2 space-y-1">
            <Label>Partner Name *</Label>
            <Input placeholder="Full name" value={form.name} onChange={set("name")} />
          </div>
          <div className="space-y-1">
            <Label>Mobile</Label>
            <Input placeholder="9876543210" value={form.mobile} onChange={set("mobile")} />
          </div>
          <div className="space-y-1">
            <Label>Email</Label>
            <Input placeholder="partner@email.com" value={form.email} onChange={set("email")} />
          </div>
          <div className="space-y-1">
            <Label>Company Share % (default)</Label>
            <Input type="number" min="0" max="100" step="0.01" value={form.sharePercent} onChange={set("sharePercent")} />
          </div>
          <div className="space-y-1">
            <Label>Capital Invested (₹)</Label>
            <Input type="number" min="0" placeholder="0" value={form.capitalInvested} onChange={set("capitalInvested")} />
          </div>
          <div className="col-span-2 space-y-1">
            <Label>Notes</Label>
            <Input placeholder="Optional notes" value={form.notes} onChange={set("notes")} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={handleSave} disabled={saving} className="cursor-pointer">{editId ? "Update" : "Add Partner"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Site-level partner assignment
function SitePartnerSection({ siteId, siteName }: { siteId: Id<"sites">; siteName: string }) {
  const sitePartners = useQuery(api.partners.listSitePartners, { siteId });
  const allPartners = useQuery(api.partners.list, {});
  const addSitePartner = useMutation(api.partners.addSitePartner);
  const updateSitePartner = useMutation(api.partners.updateSitePartner);
  const removeSitePartner = useMutation(api.partners.removeSitePartner);
  const [addOpen, setAddOpen] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState("");
  const [sharePercent, setSharePercent] = useState("0");
  const [editingId, setEditingId] = useState<Id<"sitePartners"> | null>(null);
  const [editShare, setEditShare] = useState("0");

  const availablePartners = (allPartners ?? []).filter(
    (p) => !(sitePartners ?? []).some((sp) => sp.partnerId === p._id)
  );

  return (
    <div className="border border-border rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="font-medium text-sm flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-orange-500" /> {siteName}
        </h4>
        <Button size="sm" variant="secondary" className="h-7 text-xs cursor-pointer" onClick={() => setAddOpen(true)}>
          <Plus className="w-3 h-3 mr-1" /> Add Partner
        </Button>
      </div>

      {!sitePartners ? (
        <Skeleton className="h-8 w-full" />
      ) : sitePartners.length === 0 ? (
        <p className="text-xs text-muted-foreground">No partners assigned to this site</p>
      ) : (
        <div className="space-y-2">
          {sitePartners.map((sp) => (
            <div key={sp._id} className="flex items-center justify-between text-sm py-1 border-b border-border/50 last:border-0">
              <div>
                <span className="font-medium">{sp.partnerName}</span>
                {sp.partnerMobile && <span className="ml-2 text-xs text-muted-foreground">{sp.partnerMobile}</span>}
              </div>
              <div className="flex items-center gap-2">
                {editingId === sp._id ? (
                  <>
                    <Input
                      type="number" min="0" max="100" step="0.01"
                      value={editShare}
                      onChange={(e) => setEditShare(e.target.value)}
                      className="w-20 h-7 text-xs"
                    />
                    <span className="text-xs">%</span>
                    <Button size="sm" className="h-7 text-xs cursor-pointer" onClick={async () => {
                      try {
                        await updateSitePartner({ id: sp._id as Id<"sitePartners">, sharePercent: parseFloat(editShare) || 0 });
                        toast.success("Updated"); setEditingId(null);
                      } catch { toast.error("Failed"); }
                    }}>Save</Button>
                    <Button size="sm" variant="ghost" className="h-7 cursor-pointer" onClick={() => setEditingId(null)}>Cancel</Button>
                  </>
                ) : (
                  <>
                    <Badge variant="secondary" className="text-xs">{sp.sharePercent}%</Badge>
                    <Button size="icon" variant="ghost" className="w-6 h-6 cursor-pointer"
                      onClick={() => { setEditingId(sp._id as Id<"sitePartners">); setEditShare(String(sp.sharePercent)); }}>
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="w-6 h-6 cursor-pointer text-destructive hover:text-destructive"
                      onClick={async () => {
                        try { await removeSitePartner({ id: sp._id as Id<"sitePartners"> }); toast.success("Removed"); }
                        catch { toast.error("Failed"); }
                      }}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add partner dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add Partner to {siteName}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label>Partner</Label>
              <Select value={selectedPartner} onValueChange={setSelectedPartner}>
                <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select partner" /></SelectTrigger>
                <SelectContent>
                  {availablePartners.map((p) => <SelectItem key={p._id} value={p._id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Share % for this site</Label>
              <Input type="number" min="0" max="100" value={sharePercent} onChange={(e) => setSharePercent(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setAddOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button disabled={!selectedPartner} className="cursor-pointer" onClick={async () => {
              try {
                await addSitePartner({
                  siteId,
                  partnerId: selectedPartner as Id<"partners">,
                  sharePercent: parseFloat(sharePercent) || 0,
                });
                toast.success("Partner added to site");
                setAddOpen(false); setSelectedPartner(""); setSharePercent("0");
              } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
            }}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function PartnersPage() {
  const partners = useQuery(api.partners.list, {});
  const companies = useQuery(api.companies.list, {});
  const sites = useQuery(api.sites.list, {});
  const pnlData = useQuery(api.partners.getPnLDashboard, {});
  const removePartner = useMutation(api.partners.remove);

  const [addOpen, setAddOpen] = useState(false);
  const [editPartner, setEditPartner] = useState<{ id: Id<"partners">; form: PartnerFormData } | null>(null);
  const [filterCompany, setFilterCompany] = useState("all");
  const [expandedCompany, setExpandedCompany] = useState<string | null>(null);

  const filteredPartners = (partners ?? []).filter(
    (p) => filterCompany === "all" || p.companyId === filterCompany
  );

  const groupedByCompany = (companies ?? []).map((c) => ({
    company: c,
    partners: filteredPartners.filter((p) => p.companyId === c._id),
    sites: (sites ?? []).filter((s) => s.companyId === c._id),
  })).filter((g) => filterCompany === "all" || g.company._id === filterCompany);

  if (!partners || !companies) {
    return <div className="p-6 space-y-4">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Partners</h1>
          <p className="text-sm text-muted-foreground">{partners.length} partners across {companies.length} companies</p>
        </div>
        <Button onClick={() => setAddOpen(true)} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Partner
        </Button>
      </div>

      <Tabs defaultValue="list">
        <TabsList>
          <TabsTrigger value="list" className="cursor-pointer"><Users className="w-3.5 h-3.5 mr-1" /> Partners</TabsTrigger>
          <TabsTrigger value="sites" className="cursor-pointer"><MapPin className="w-3.5 h-3.5 mr-1" /> Site Assignments</TabsTrigger>
          <TabsTrigger value="pnl" className="cursor-pointer"><TrendingUp className="w-3.5 h-3.5 mr-1" /> P&L Dashboard</TabsTrigger>
        </TabsList>

        {/* Partners List Tab */}
        <TabsContent value="list" className="space-y-4 mt-4">
          <div className="flex gap-3">
            <Select value={filterCompany} onValueChange={setFilterCompany}>
              <SelectTrigger className="w-48 cursor-pointer"><SelectValue placeholder="All Companies" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Companies</SelectItem>
                {companies.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {filteredPartners.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><Users /></EmptyMedia>
                <EmptyTitle>No partners yet</EmptyTitle>
                <EmptyDescription>Add partners/investors to track profit sharing</EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button size="sm" onClick={() => setAddOpen(true)} className="cursor-pointer">Add Partner</Button>
              </EmptyContent>
            </Empty>
          ) : (
            <div className="space-y-4">
              {groupedByCompany.filter((g) => g.partners.length > 0).map((g) => (
                <Card key={g.company._id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-orange-500" /> {g.company.name}
                      </CardTitle>
                      <Badge variant="secondary">{g.partners.length} partners</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {g.partners.map((p) => (
                        <div key={p._id} className="flex items-center justify-between px-4 py-3 hover:bg-muted/30">
                          <div>
                            <p className="font-medium">{p.name}</p>
                            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                              {p.mobile && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{p.mobile}</span>}
                              {p.capitalInvested && <span>Capital: {fmt(p.capitalInvested)}</span>}
                              {!p.isActive && <Badge variant="secondary" className="text-xs">Inactive</Badge>}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="font-semibold text-sm flex items-center gap-1">
                                <Percent className="w-3 h-3" />{p.sharePercent}%
                              </p>
                              <p className="text-xs text-muted-foreground">default share</p>
                            </div>
                            <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                              onClick={() => setEditPartner({
                                id: p._id,
                                form: {
                                  companyId: p.companyId,
                                  name: p.name,
                                  mobile: p.mobile ?? "",
                                  email: p.email ?? "",
                                  sharePercent: String(p.sharePercent),
                                  capitalInvested: p.capitalInvested ? String(p.capitalInvested) : "",
                                  notes: p.notes ?? "",
                                },
                              })}>
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                              onClick={async () => {
                                if (!confirm(`Delete partner "${p.name}"?`)) return;
                                try { await removePartner({ id: p._id }); toast.success("Partner deleted"); }
                                catch { toast.error("Failed"); }
                              }}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Site Assignments Tab */}
        <TabsContent value="sites" className="space-y-4 mt-4">
          <p className="text-sm text-muted-foreground">Assign partners to specific sites with custom share percentages</p>
          {!sites ? (
            <Skeleton className="h-40 w-full" />
          ) : (
            <div className="space-y-4">
              {groupedByCompany.map((g) => (
                <div key={g.company._id}>
                  <button
                    className="flex items-center gap-2 w-full text-left py-2 font-semibold text-sm cursor-pointer hover:text-orange-500 transition-colors"
                    onClick={() => setExpandedCompany(expandedCompany === g.company._id ? null : g.company._id)}
                  >
                    {expandedCompany === g.company._id
                      ? <ChevronDown className="w-4 h-4" />
                      : <ChevronRight className="w-4 h-4" />}
                    <Building2 className="w-4 h-4 text-orange-500" />
                    {g.company.name}
                    <Badge variant="secondary" className="ml-2 text-xs">{g.sites.length} sites</Badge>
                  </button>
                  {expandedCompany === g.company._id && (
                    <div className="ml-6 space-y-3 pb-4">
                      {g.sites.length === 0 ? (
                        <p className="text-xs text-muted-foreground">No sites for this company</p>
                      ) : (
                        g.sites.map((site) => (
                          <SitePartnerSection key={site._id} siteId={site._id} siteName={site.name} />
                        ))
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* P&L Dashboard Tab */}
        <TabsContent value="pnl" className="space-y-6 mt-4">
          {!pnlData ? (
            <div className="space-y-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
          ) : (
            <>
              {/* Partner totals summary */}
              <div>
                <h3 className="font-semibold mb-3">Partner-wise Profit Share (All Sites)</h3>
                {pnlData.partnerTotals.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No partners with site assignments yet</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pnlData.partnerTotals.map((pt) => (
                      <Card key={pt.partnerId} className={pt.totalProfitShare >= 0 ? "border-green-200 dark:border-green-800" : "border-red-200 dark:border-red-800"}>
                        <CardContent className="pt-4 pb-4">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-semibold">{pt.partnerName}</p>
                              <p className="text-xs text-muted-foreground">{pt.companyName}</p>
                            </div>
                            <Badge variant="secondary">{pt.sharePercent}%</Badge>
                          </div>
                          <div className="flex items-center justify-between mt-3">
                            <div>
                              <p className="text-xs text-muted-foreground">Total P&L Share</p>
                              <p className={`text-xl font-bold ${pt.totalProfitShare >= 0 ? "text-green-500" : "text-red-500"}`}>
                                {pt.totalProfitShare >= 0 ? <TrendingUp className="inline w-4 h-4 mr-1" /> : <TrendingDown className="inline w-4 h-4 mr-1" />}
                                {fmt(Math.abs(pt.totalProfitShare))}
                              </p>
                            </div>
                            <p className="text-xs text-muted-foreground">{pt.siteCount} sites</p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>

              {/* Site-wise P&L */}
              <div>
                <h3 className="font-semibold mb-3">Site-wise P&L Breakdown</h3>
                <div className="rounded-lg border border-border overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="text-left px-4 py-3 font-medium text-muted-foreground">Site</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">Revenue</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Material</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Salary</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Expenses</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">Total Cost</th>
                          <th className="text-right px-4 py-3 font-medium text-muted-foreground">Profit / Loss</th>
                          <th className="text-left px-4 py-3 font-medium text-muted-foreground">Partners</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {pnlData.sitePnL.map((s) => (
                          <tr key={s.siteId} className="hover:bg-muted/30">
                            <td className="px-4 py-3">
                              <p className="font-medium">{s.siteName}</p>
                              <p className="text-xs text-muted-foreground">{s.siteCity}</p>
                            </td>
                            <td className="px-4 py-3 text-right font-medium text-blue-500">{fmt(s.revenue)}</td>
                            <td className="px-4 py-3 text-right text-muted-foreground hidden md:table-cell">{fmt(s.materialCost)}</td>
                            <td className="px-4 py-3 text-right text-muted-foreground hidden md:table-cell">{fmt(s.salaryCost)}</td>
                            <td className="px-4 py-3 text-right text-muted-foreground hidden lg:table-cell">{fmt(s.expenseCost)}</td>
                            <td className="px-4 py-3 text-right text-red-400">{fmt(s.totalCost)}</td>
                            <td className="px-4 py-3 text-right">
                              <span className={`font-bold ${s.profit >= 0 ? "text-green-500" : "text-red-500"}`}>
                                {s.profit >= 0 ? "+" : ""}{fmt(s.profit)}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              {s.partners.length === 0 ? (
                                <span className="text-xs text-muted-foreground">—</span>
                              ) : (
                                <div className="space-y-0.5">
                                  {s.partners.map((p) => (
                                    <div key={p.partnerId} className="text-xs">
                                      <span className="font-medium">{p.partnerName}</span>
                                      <span className="text-muted-foreground ml-1">({p.sharePercent}%)</span>
                                      <span className={`ml-1 font-medium ${p.profitShare >= 0 ? "text-green-500" : "text-red-500"}`}>
                                        {p.profitShare >= 0 ? "+" : ""}{fmt(p.profitShare)}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-muted/30 border-t-2 border-border font-semibold">
                        <tr>
                          <td className="px-4 py-3">Total</td>
                          <td className="px-4 py-3 text-right text-blue-500">
                            {fmt(pnlData.sitePnL.reduce((s, r) => s + r.revenue, 0))}
                          </td>
                          <td className="px-4 py-3 text-right hidden md:table-cell">
                            {fmt(pnlData.sitePnL.reduce((s, r) => s + r.materialCost, 0))}
                          </td>
                          <td className="px-4 py-3 text-right hidden md:table-cell">
                            {fmt(pnlData.sitePnL.reduce((s, r) => s + r.salaryCost, 0))}
                          </td>
                          <td className="px-4 py-3 text-right hidden lg:table-cell">
                            {fmt(pnlData.sitePnL.reduce((s, r) => s + r.expenseCost, 0))}
                          </td>
                          <td className="px-4 py-3 text-right text-red-400">
                            {fmt(pnlData.sitePnL.reduce((s, r) => s + r.totalCost, 0))}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {(() => {
                              const total = pnlData.sitePnL.reduce((s, r) => s + r.profit, 0);
                              return <span className={`font-bold ${total >= 0 ? "text-green-500" : "text-red-500"}`}>{total >= 0 ? "+" : ""}{fmt(total)}</span>;
                            })()}
                          </td>
                          <td />
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>

      {addOpen && <PartnerFormDialog open onClose={() => setAddOpen(false)} />}
      {editPartner && (
        <PartnerFormDialog
          open
          onClose={() => setEditPartner(null)}
          initial={editPartner.form}
          editId={editPartner.id}
        />
      )}
    </div>
  );
}
