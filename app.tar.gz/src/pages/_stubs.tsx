import { Users as UsersIcon, FileText, Package, IndianRupee, Receipt, Settings, Construction } from "lucide-react";

type ComingSoonProps = {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  milestone: string;
};

function ComingSoonPage({ title, description, icon: Icon, milestone }: ComingSoonProps) {
  return (
    <div className="p-6 flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-primary" />
      </div>
      <h1 className="text-2xl font-bold mb-2">{title}</h1>
      <p className="text-muted-foreground max-w-md mb-4">{description}</p>
      <div className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-full text-sm">
        <Construction className="w-4 h-4" />
        Coming in {milestone}
      </div>
    </div>
  );
}

export function Labour() {
  return <ComingSoonPage title="Labour Management" description="Track individual labourers, attendance, daily rates per site and contractor." icon={UsersIcon} milestone="Milestone 5" />;
}

export function WorkOrders() {
  return <ComingSoonPage title="Work Orders" description="Manage work orders from clients, amendments, per-site tracking and cost vs value reports." icon={FileText} milestone="Milestone 6" />;
}

export function Materials() {
  return <ComingSoonPage title="Materials & Delivery" description="Log material deliveries by vehicle number and photo, MTC uploads, supplier bills." icon={Package} milestone="Milestone 7" />;
}

export function SalarySheets() {
  return <ComingSoonPage title="Salary & Payroll" description="Monthly salary sheets per site, approval flow, salary slips and payment tracking." icon={IndianRupee} milestone="Milestone 8" />;
}

export function Invoices() {
  return <ComingSoonPage title="Invoices & Payments" description="Client invoices, supplier/contractor bills, payment tracking and P&L per site." icon={Receipt} milestone="Milestone 9" />;
}

export function Users() {
  return <ComingSoonPage title="User Management" description="Manage user accounts, assign roles (Super Admin, Site Incharge, Supplier, Contractor)." icon={Settings} milestone="Milestone 1b" />;
}
