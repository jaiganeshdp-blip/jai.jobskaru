import { Outlet, NavLink, useNavigate, useLocation } from "react-router-dom";
import { Authenticated, Unauthenticated, AuthLoading, useQuery } from "convex/react";
import { Screensaver } from "@/components/screensaver.tsx";
import { api } from "@/convex/_generated/api.js";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import { cn } from "@/lib/utils.ts";
import {
  LayoutDashboard,
  Building2,
  MapPin,
  Users,
  Truck,
  HardHat,
  UserCheck,
  FileText,
  Package,
  IndianRupee,
  Receipt,
  Banknote,
  Bell,
  ChevronRight,
  Menu,
  X,
  LogOut,
  Settings,
  Monitor,
  BarChart3,
  Database,
  Wallet,
  ShoppingCart,
  CalendarCheck,
  BookOpen,
  Activity,
  FileDown,
  MoreHorizontal,
  AlertCircle,
  ShieldCheck,
  TrendingUp,
  FileSpreadsheet,
  Link2,
  Landmark,
} from "lucide-react";
import { NotificationBell } from "@/components/notification-bell.tsx";
import { useState } from "react";
import { Button } from "@/components/ui/button.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";

type NavItem = {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: string[];
};

const ADMIN_ROLES = ["super_admin", "site_incharge", "viewer", "accounts_manager"];
const BILLING_ROLES = ["super_admin", "billing_manager", "accounts_manager", "site_incharge"];
// All non-super roles that can have custom permissions.
// NOTE: "supplier" and "contractor" are intentionally excluded — vendor logins
// only get their own self-service dashboard (their own POs, bills, payments),
// never the admin list pages which would expose everyone's data.
const ALL_MANAGED_ROLES = ["site_incharge", "site_supervisor", "safety_supervisor", "billing_manager", "accounts_manager", "viewer"];

const NAV_ITEMS: NavItem[] = [
  { label: "All Sites Dashboard", path: "/super-admin", icon: TrendingUp, roles: ["super_admin"] },
  { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
  { label: "Analytics", path: "/analytics", icon: Activity, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Reports", path: "/reports", icon: FileDown, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Site P&L", path: "/site-pnl", icon: BarChart3, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Companies", path: "/companies", icon: Building2, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Partners", path: "/partners", icon: Users, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Sites", path: "/sites", icon: MapPin, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Clients", path: "/clients", icon: UserCheck, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Suppliers", path: "/suppliers", icon: Truck, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Contractors", path: "/contractors", icon: HardHat, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Labour", path: "/labour", icon: Users, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Attendance", path: "/attendance", icon: CalendarCheck, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Work Orders", path: "/work-orders", icon: FileText, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Billing Dashboard", path: "/billing-dashboard", icon: AlertCircle, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Materials", path: "/materials", icon: Package, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Item Master", path: "/item-master", icon: Package, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Salary", path: "/salary", icon: IndianRupee, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Invoices", path: "/invoices", icon: Receipt, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Payments", path: "/payments", icon: Banknote, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Expenses", path: "/expenses", icon: Wallet, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Purchase Orders", path: "/purchase-orders", icon: ShoppingCart, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Vendor Bills", path: "/vendor-bills", icon: Receipt, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Site Diary", path: "/site-diary", icon: BookOpen, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Material Requests", path: "/material-requests", icon: Package, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "BOQ Management", path: "/boq", icon: FileSpreadsheet, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "GST Invoice Tracking", path: "/gst-invoice-tracking", icon: FileSpreadsheet, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Incoming Invoices", path: "/incoming-invoices", icon: FileText, roles: [...BILLING_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Sale-Purchase Register", path: "/sale-purchase-register", icon: BookOpen, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Bank Statement", path: "/bank-statement", icon: Landmark, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Delivery Challans", path: "/delivery-challans", icon: Truck, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Labour Corrections", path: "/labour-corrections", icon: AlertCircle, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Safety", path: "/safety", icon: ShieldCheck, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Notifications", path: "/notifications", icon: Bell, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
  { label: "Screensaver", path: "/screensaver-admin", icon: Monitor, roles: ["super_admin"] },
  { label: "Portal Access Manager", path: "/portal-access", icon: Link2, roles: ["super_admin"] },
  { label: "User Approvals", path: "/user-approvals", icon: UserCheck, roles: ["super_admin"] },
  { label: "Users", path: "/users", icon: Settings, roles: ["super_admin"] },
  { label: "Backup & Restore", path: "/backup", icon: Database, roles: ["super_admin"] },
  { label: "Seed Test Data", path: "/seed-data", icon: Database, roles: ["super_admin"] },
  { label: "Help & Guide", path: "/help", icon: BookOpen, roles: [...ADMIN_ROLES, ...ALL_MANAGED_ROLES] },
];

// Bottom nav: the 4 most-used pages + "More" to open full sidebar
const BOTTOM_NAV: NavItem[] = [
  { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
  { label: "Attendance", path: "/attendance", icon: CalendarCheck },
  { label: "Expenses", path: "/expenses", icon: Wallet },
  { label: "Site Diary", path: "/site-diary", icon: BookOpen },
];

function SidebarContent({
  user,
  role,
  userPermissions,
  onClose,
}: {
  user: { name?: string; email?: string } | null | undefined;
  role: string | undefined;
  userPermissions?: Record<string, boolean>;
  onClose?: () => void;
}) {
  const { signout } = useAuth();
  const navigate = useNavigate();
  const pendingBills = useQuery(
    api.vendorBills.list,
    role ? { status: "received" } : "skip"
  ) ?? [];
  const pendingCount = pendingBills.length;
  const pendingApprovals = useQuery(
    api.registration.listRequests,
    role === "super_admin" ? { status: "pending" } : "skip"
  );
  const pendingApprovalsCount = pendingApprovals?.length ?? 0;

  // Map nav path -> permission key
  const PATH_PERMISSION_MAP: Record<string, string> = {
    "/labour": "canViewLabour",
    "/attendance": "canMarkAttendance",
    "/site-diary": "canViewSiteDiary",
    "/material-requests": "canRequestMaterials",
    "/materials": "canViewMaterials",
    "/work-orders": "canViewWorkOrders",
    "/safety": "canViewSafety",
    "/sites": "canViewSites",
    "/salary": "canViewSalary",
    "/invoices": "canViewInvoices",
    "/payments": "canViewPayments",
    "/expenses": "canViewExpenses",
    "/purchase-orders": "canViewPurchaseOrders",
    "/vendor-bills": "canViewVendorBills",
    "/incoming-invoices": "canViewIncomingInvoices",
    "/sale-purchase-register": "canViewIncomingInvoices",
    "/bank-statement": "canViewBankStatement",
    "/gst-invoice-tracking": "canViewGstTracking",
    "/billing-dashboard": "canViewBillingDashboard",
    "/analytics": "canViewAnalytics",
    "/reports": "canViewReports",
    "/site-pnl": "canViewSitePnl",
    "/boq": "canViewBoq",
    "/delivery-challans": "canViewDeliveryChallans",
    "/labour-corrections": "canViewLabourCorrections",
    "/companies": "canViewCompanies",
    "/partners": "canViewPartners",
    "/clients": "canViewClients",
    "/suppliers": "canViewSuppliers",
    "/contractors": "canViewContractors",
  };

  const filteredItems = NAV_ITEMS.filter((item) => {
    if (!item.roles) return true;
    if (!item.roles.includes(role ?? "")) return false;

    // super_admin always sees everything
    if (role === "super_admin") return true;

    // If user has custom permissions set, apply them
    if (userPermissions) {
      const permKey = PATH_PERMISSION_MAP[item.path];
      if (permKey) return userPermissions[permKey] === true;
    }

    return true;
  });

  return (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 bg-sidebar-primary rounded-md flex items-center justify-center flex-shrink-0">
          <HardHat className="w-4 h-4 text-sidebar-primary-foreground" />
        </div>
        <div>
          <div className="font-bold text-sm">JAI SITE MANAGER ERP</div>
          <div className="text-xs text-sidebar-foreground/50 capitalize">{role?.replace("_", " ") ?? "Loading..."}</div>
        </div>
        {onClose && (
          <button onClick={onClose} className="ml-auto cursor-pointer text-sidebar-foreground/60 hover:text-sidebar-foreground">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-0.5">
        {filteredItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            onClick={onClose}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors cursor-pointer",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )
            }
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <span className="flex-1">{item.label}</span>
            {item.path === "/vendor-bills" && pendingCount > 0 && (
                <span className="ml-auto bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {pendingCount}
                </span>
              )}
              {item.path === "/user-approvals" && pendingApprovalsCount > 0 && (
                <span className="ml-auto bg-amber-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {pendingApprovalsCount}
                </span>
              )}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div className="border-t border-sidebar-border p-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 w-full px-3 py-2 rounded-md hover:bg-sidebar-accent/50 transition-colors cursor-pointer">
              <div className="w-7 h-7 rounded-full bg-sidebar-primary flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                {user?.name?.[0]?.toUpperCase() ?? "U"}
              </div>
              <div className="text-left min-w-0 flex-1">
                <div className="text-xs font-medium truncate">{user?.name ?? "User"}</div>
                <div className="text-xs text-sidebar-foreground/50 truncate">{user?.email}</div>
              </div>
              <ChevronRight className="w-3 h-3 text-sidebar-foreground/40 flex-shrink-0" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" side="top" className="w-48">
            <DropdownMenuItem
              onClick={async () => {
                await signout();
                navigate("/");
              }}
              className="cursor-pointer"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function BottomNav({
  role,
  onMoreClick,
}: {
  role: string | undefined;
  onMoreClick: () => void;
}) {
  const location = useLocation();

  // Vendor logins (contractor/supplier) only get their own dashboard — hide
  // the admin quick-links and the "More" menu entirely.
  const isVendor = role === "contractor" || role === "supplier";
  const items = isVendor
    ? [{ label: "Dashboard", path: "/dashboard", icon: LayoutDashboard }]
    : BOTTOM_NAV;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 flex md:hidden border-t border-border bg-sidebar">
      {items.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <NavLink
            key={item.path}
            to={item.path}
            className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 cursor-pointer"
          >
            <item.icon
              className={cn(
                "w-5 h-5 transition-colors",
                isActive ? "text-primary" : "text-sidebar-foreground/50"
              )}
            />
            <span
              className={cn(
                "text-[10px] font-medium transition-colors",
                isActive ? "text-primary" : "text-sidebar-foreground/50"
              )}
            >
              {item.label}
            </span>
          </NavLink>
        );
      })}
      {/* More button opens full sidebar — hidden for vendor logins */}
      {!isVendor && (
        <button
          onClick={onMoreClick}
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 cursor-pointer"
        >
          <MoreHorizontal className="w-5 h-5 text-sidebar-foreground/50" />
          <span className="text-[10px] font-medium text-sidebar-foreground/50">More</span>
        </button>
      )}
    </nav>
  );
}

function AppLayoutInner() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user } = useAuth();
  const currentUser = useQuery(api.users.getCurrentUserQuery, {});
  const navigate = useNavigate();
  const location = useLocation();

  // Redirect pending users to registration page
  if (currentUser && currentUser.role === "pending") {
    navigate("/register", { replace: true });
    return null;
  }

  // Vendor logins (contractor/supplier) may only visit their own dashboard.
  // Guard against typing an admin URL directly — send them back to /dashboard.
  const isVendor = currentUser?.role === "contractor" || currentUser?.role === "supplier";
  if (isVendor && location.pathname !== "/dashboard") {
    navigate("/dashboard", { replace: true });
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Screensaver — sits above everything */}
      <Screensaver />

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-56 flex-shrink-0 flex-col border-r border-border">
        <SidebarContent user={user?.profile} role={currentUser?.role} userPermissions={currentUser?.userPermissions ?? undefined} />
      </aside>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="relative z-50 w-64 h-full">
            <SidebarContent
              user={user?.profile}
              role={currentUser?.role}
              userPermissions={currentUser?.userPermissions ?? undefined}
              onClose={() => setMobileOpen(false)}
            />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Desktop topbar */}
        <div className="hidden md:flex items-center justify-end px-4 py-2 border-b border-border bg-card/50">
          <NotificationBell />
        </div>

        {/* Mobile topbar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
          <button
            onClick={() => setMobileOpen(true)}
            className="cursor-pointer text-muted-foreground hover:text-foreground"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 flex-1">
            <HardHat className="w-5 h-5 text-primary" />
            <span className="font-semibold text-sm">JAI SITE MANAGER ERP</span>
          </div>
          <NotificationBell />
        </div>

        {/* Page content — extra bottom padding on mobile for bottom nav */}
        <main className="flex-1 overflow-auto pb-0 md:pb-0" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
          <div className="pb-16 md:pb-0 h-full overflow-auto">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Bottom nav — mobile only */}
      <BottomNav role={currentUser?.role} onMoreClick={() => setMobileOpen(true)} />
    </div>
  );
}

export default function AppLayout() {
  return (
    <>
      <AuthLoading>
        <div className="min-h-screen flex items-center justify-center">
          <Skeleton className="w-64 h-64" />
        </div>
      </AuthLoading>
      <Unauthenticated>
        <div className="min-h-screen flex flex-col items-center justify-center gap-4">
          <HardHat className="w-12 h-12 text-primary" />
          <h1 className="text-xl font-bold">JAI SITE MANAGER ERP</h1>
          <p className="text-muted-foreground">Please sign in to continue</p>
          <SignInButton />
        </div>
      </Unauthenticated>
      <Authenticated>
        <AppLayoutInner />
      </Authenticated>
    </>
  );
}
