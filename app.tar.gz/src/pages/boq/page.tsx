import { useState, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Upload, FileSpreadsheet, Plus, Share2, Copy, MessageSquare, Mail, Users, Eye, BarChart3, Pencil, CalendarDays } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import InviteDialog from "./_components/InviteDialog.tsx";
import SubmissionsDialog from "./_components/SubmissionsDialog.tsx";

type BOQItem = { srNo: number; description: string; unit: string; nos?: number; quantity: number; rate?: number; totalAmount?: number };

function BOQPageInner() {
  const companies = useQuery(api.companies.list, {}) ?? [];
  const navigate = useNavigate();
  const [selectedCompany, setSelectedCompany] = useState<Id<"companies"> | "">("");
  const boqList = useQuery(
    api.boq.projects.list,
    selectedCompany ? { companyId: selectedCompany } : {}
  ) ?? [];

  const [createOpen, setCreateOpen] = useState(false);
  const [inviteBoqId, setInviteBoqId] = useState<Id<"boqProjects"> | null>(null);
  const [submissionsBoqId, setSubmissionsBoqId] = useState<Id<"boqProjects"> | null>(null);
  const [deadlineEditId, setDeadlineEditId] = useState<Id<"boqProjects"> | null>(null);
  const [newDeadline, setNewDeadline] = useState("");

  // --- Create BOQ form state ---
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [companyId, setCompanyId] = useState<Id<"companies"> | "">("");
  const [deadline, setDeadline] = useState("");
  const [parsedItems, setParsedItems] = useState<BOQItem[]>([]);
  const [uploading, setUploading] = useState(false);
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [storageId, setStorageId] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.boq.projects.generateUploadUrl);
  const createBOQ = useMutation(api.boq.projects.create);
  const updateDeadline = useMutation(api.boq.projects.updateDeadline);

  const statusColors: Record<string, string> = {
    draft: "bg-gray-100 text-gray-700",
    invited: "bg-blue-100 text-blue-700",
    comparing: "bg-yellow-100 text-yellow-700",
    finalized: "bg-green-100 text-green-700",
    ordered: "bg-purple-100 text-purple-700",
  };
  const statusLabels: Record<string, string> = {
    draft: "Draft",
    invited: "Invited",
    comparing: "Comparing",
    finalized: "Finalized",
    ordered: "Ordered",
  };

  async function handleExcelPick(file: File) {
    setExcelFile(file);
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data, { type: "array" });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "", raw: false });

    // Smart column detector — finds best match for each field regardless of header name
    function findCol(row: Record<string, unknown>, patterns: RegExp[]): string | undefined {
      return Object.keys(row).find((k) => patterns.some((p) => p.test(k.trim())));
    }

    if (rows.length === 0) { toast.error("Excel mein koi data nahi mila"); return; }

    const sample = rows[0];
    const descKey  = findCol(sample, [/desc/i, /item/i, /work/i, /material/i, /particular/i, /detail/i, /name/i, /scope/i]);
    const unitKey  = findCol(sample, [/unit/i, /uom/i, /measure/i]);
    const nosKey   = findCol(sample, [/^nos$/i, /^no\.?s$/i, /^no$/i, /^number$/i, /nos\./i]);
    const qtyKey   = findCol(sample, [/qty/i, /quant/i, /^q$/i]);
    const rateKey  = findCol(sample, [/rate/i, /price/i, /cost/i, /^r$/i]);
    const totalKey = findCol(sample, [/total/i, /amount/i, /amt/i, /value/i]);
    const srKey    = findCol(sample, [/sr/i, /s\.?no/i, /sl/i, /serial/i, /^sno$/i]);

    const items: BOQItem[] = rows
      .map((row, i) => {
        const desc = String(descKey ? (row[descKey] ?? "") : Object.values(row)[1] ?? "").trim();
        const unit = String(unitKey ? (row[unitKey] ?? "") : "").trim();
        const nos  = nosKey  ? (Number(row[nosKey])  || undefined) : undefined;
        const qty  = qtyKey  ? (Number(row[qtyKey])  || 0) : (nosKey ? 0 : Number(Object.values(row)[3] ?? 0));
        const rate = rateKey ? (Number(row[rateKey]) || undefined) : undefined;
        const totalFromExcel = totalKey ? (Number(String(row[totalKey]).replace(/,/g, "")) || undefined) : undefined;
        const totalAmount = totalFromExcel ?? (rate && qty ? rate * qty : undefined);
        const srRaw = srKey ? row[srKey] : undefined;
        const srNo  = srRaw ? (Number(srRaw) || i + 1) : i + 1;
        return { srNo, description: desc, unit, nos, quantity: qty, rate, totalAmount };
      })
      .filter((r) => {
        const d = r.description.toUpperCase();
        return r.description && d !== "TOTAL AMOUNT" && d !== "GRAND TOTAL" && d !== "TOTAL" && !/^s\.?r\.?\s*no/i.test(d);
      });

    if (items.length === 0) {
      toast.error("Items parse nahi hue. Excel ka pehla row header hona chahiye (Description, Unit, QTY etc.)");
      return;
    }
    setParsedItems(items);
  }

  function downloadTemplate() {
    const ws = XLSX.utils.aoa_to_sheet([
      ["SR NO", "Description", "Unit", "nos", "QTY", "Rate", "Total Amount"],
      [1, "Fixing of VITRIFIED TILE Flooring (1000x1000mm)", "SFT", 1, 555, 680, 377400],
      [2, "INTERIOR WARDROBE", "SFT", 1, 555, 680, 377400],
      [3, "PANALING 12MM PLY", "SFT", 2, 555, 680, 754800],
      [4, "DADO", "SFT", 1, 555, 680, 377400],
      [5, "PARTIOTON", "SFT", 1, 555, 680, 377400],
      [6, "DOOR", "NOS", 1, 555, 680, 377400],
      [7, "MARBLE FIXING", "SFT", 32, 555, 680, 377400],
      ["", "", "", "", "", "TOTAL AMOUNT", { f: "SUM(G2:G8)" }],
    ]);
    ws["!cols"] = [{ wch: 7 }, { wch: 45 }, { wch: 6 }, { wch: 5 }, { wch: 8 }, { wch: 8 }, { wch: 14 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "BOQ");
    XLSX.writeFile(wb, "BOQ_Template.xlsx");
    toast.success("Template download ho raha hai!");
  }

  async function handleUploadAndCreate() {
    if (!excelFile || !title || !companyId || parsedItems.length === 0) {
      toast.error("Title, Company, Excel file aur items zaroori hain");
      return;
    }
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl();
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": excelFile.type },
        body: excelFile,
      });
      const { storageId: sid } = (await res.json()) as { storageId: string };
      setStorageId(sid);
      await createBOQ({
        title,
        companyId,
        description: description || undefined,
        excelStorageId: sid,
        excelFileName: excelFile.name,
        items: parsedItems,
        deadlineDate: deadline || undefined,
      });
      toast.success("BOQ create ho gaya!");
      setCreateOpen(false);
      setTitle(""); setDescription(""); setCompanyId(""); setDeadline("");
      setParsedItems([]); setExcelFile(null); setStorageId("");
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setUploading(false);
    }
  }

  async function handleSaveDeadline() {
    if (!deadlineEditId) return;
    try {
      await updateDeadline({ id: deadlineEditId, deadlineDate: newDeadline || undefined });
      toast.success("Deadline update ho gayi!");
      setDeadlineEditId(null);
      setNewDeadline("");
    } catch (e) {
      toast.error("Error: " + String(e));
    }
  }

  function getShareLink(token: string) {
    return `${window.location.origin}/portal/boq-vendor?token=${token}`;
  }

  function copyLink(token: string) {
    navigator.clipboard.writeText(getShareLink(token));
    toast.success("Link copy ho gaya!");
  }

  function shareWhatsApp(token: string, title: string) {
    const link = getShareLink(token);
    const msg = encodeURIComponent(
      `Namaste! Aapko BOQ rate bharne ke liye invite kiya gaya hai.\n\nBOQ: ${title}\n\nLink: ${link}\n\nLink open karein, rates bharen aur submit karein.`
    );
    window.open(`https://wa.me/?text=${msg}`, "_blank");
  }

  function shareEmail(token: string, title: string) {
    const link = getShareLink(token);
    const subject = encodeURIComponent(`BOQ Rate Request: ${title}`);
    const body = encodeURIComponent(
      `Namaste,\n\nAapko ${title} BOQ ke liye rate submit karne ka invite bheja gaya hai.\n\nLink: ${link}\n\nLink par jayein, BOQ Excel download karein, rates bharen aur upload karein.\n\nDhanyawad`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`, "_blank");
  }

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">BOQ Management</h1>
          <p className="text-muted-foreground text-sm">Bill of Quantities — upload karein, vendors ko invite karein, rates compare karein</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus size={16} /> New BOQ Upload</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>New BOQ Upload</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">

              {/* Step 1: Download template */}
              <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-blue-700 dark:text-blue-400">Step 1: Template Download Karein</p>
                  <p className="text-xs text-blue-600 dark:text-blue-500 mt-0.5">Format: SR NO | Description | Unit | nos | QTY | Rate | Total Amount</p>
                </div>
                <Button size="sm" variant="secondary" className="gap-1 shrink-0" onClick={downloadTemplate}>
                  <FileSpreadsheet size={14} /> Template
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <p className="text-sm font-semibold mb-2">Step 2: BOQ Details Bharein</p>
                </div>
                <div className="md:col-span-2 space-y-1">
                  <Label>BOQ Title *</Label>
                  <Input placeholder="e.g. Site A Civil Work BOQ" value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Company *</Label>
                  <Select value={companyId} onValueChange={(v) => setCompanyId(v as Id<"companies">)}>
                    <SelectTrigger><SelectValue placeholder="Company chunen" /></SelectTrigger>
                    <SelectContent>
                      {companies.map((c) => (
                        <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Deadline (optional)</Label>
                  <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
                </div>
                <div className="md:col-span-2 space-y-1">
                  <Label>Description (optional)</Label>
                  <Textarea placeholder="Koi note..." value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
                </div>
              </div>

              {/* Step 3: Upload filled Excel */}
              <p className="text-sm font-semibold">Step 3: Filled Excel Upload Karein</p>
              <div
                className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:bg-accent/30 transition"
                onClick={() => fileRef.current?.click()}
              >
                <FileSpreadsheet className="mx-auto text-muted-foreground mb-2" size={32} />
                {excelFile ? (
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-green-600">{excelFile.name} — {parsedItems.length} items mila</div>
                    {parsedItems.some(i => i.totalAmount) && (
                      <div className="text-sm font-bold text-green-700">
                        Total BOQ Amount: ₹{parsedItems.reduce((s, i) => s + (i.totalAmount ?? 0), 0).toLocaleString("en-IN")}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-muted-foreground text-sm">Filled Excel yahan drop karein ya click karein<br /><span className="text-xs">Format: SR NO | Description | Unit | nos | QTY | Rate | Total Amount</span></div>
                )}
                <input
                  ref={fileRef}
                  type="file"
                  accept=".xlsx,.xls"
                  className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleExcelPick(f); }}
                />
              </div>

              {parsedItems.length > 0 && (
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-muted px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center justify-between">
                    <span>Preview — {parsedItems.length} items</span>
                    {parsedItems.some(i => i.totalAmount) && (
                      <span className="text-foreground">
                        Total: ₹{parsedItems.reduce((s, i) => s + (i.totalAmount ?? 0), 0).toLocaleString("en-IN")}
                      </span>
                    )}
                  </div>
                  <div className="max-h-48 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="px-2 py-1.5 text-left border-r">SR NO</th>
                          <th className="px-2 py-1.5 text-left border-r">Description</th>
                          <th className="px-2 py-1.5 text-center border-r">Unit</th>
                          <th className="px-2 py-1.5 text-center border-r">nos</th>
                          <th className="px-2 py-1.5 text-center border-r">QTY</th>
                          <th className="px-2 py-1.5 text-right border-r">Rate</th>
                          <th className="px-2 py-1.5 text-right font-semibold">Total Amount</th>
                        </tr>
                      </thead>
                      <tbody>
                        {parsedItems.map((item) => (
                          <tr key={item.srNo} className="border-t">
                            <td className="px-2 py-1 border-r">{item.srNo}</td>
                            <td className="px-2 py-1 border-r font-medium">{item.description}</td>
                            <td className="px-2 py-1 text-center border-r">{item.unit}</td>
                            <td className="px-2 py-1 text-center border-r">{item.nos ?? 1}</td>
                            <td className="px-2 py-1 text-center border-r">{item.quantity}</td>
                            <td className="px-2 py-1 text-right border-r">{item.rate?.toLocaleString("en-IN") ?? "—"}</td>
                            <td className="px-2 py-1 text-right font-semibold">{item.totalAmount?.toLocaleString("en-IN") ?? "—"}</td>
                          </tr>
                        ))}
                        {parsedItems.some(i => i.totalAmount) && (
                          <tr className="border-t bg-muted/40 font-bold">
                            <td colSpan={5} className="px-2 py-1.5 text-right border-r uppercase tracking-wide text-xs">TOTAL AMOUNT</td>
                            <td className="px-2 py-1.5 border-r"></td>
                            <td className="px-2 py-1.5 text-right text-green-700">
                              ₹{parsedItems.reduce((s, i) => s + (i.totalAmount ?? 0), 0).toLocaleString("en-IN")}
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              <Button onClick={handleUploadAndCreate} disabled={uploading} className="w-full text-base py-5">
                {uploading ? "Upload ho raha hai..." : parsedItems.length > 0
                  ? `BOQ Create Karein — ${parsedItems.length} items, ₹${parsedItems.reduce((s, i) => s + (i.totalAmount ?? 0), 0).toLocaleString("en-IN")} Total`
                  : "BOQ Create Karein"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={selectedCompany} onValueChange={(v) => setSelectedCompany(v as Id<"companies"> | "")}>
          <SelectTrigger className="w-56"><SelectValue placeholder="Company filter" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Sab Companies</SelectItem>
            {companies.map((c) => (
              <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* BOQ List */}
      {boqList.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <FileSpreadsheet size={48} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">Koi BOQ nahi mila</p>
          <p className="text-sm">New BOQ Upload button se pehla BOQ banayein</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {boqList.map((boq) => (
            <Card key={boq._id} className="hover:shadow-md transition">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <CardTitle className="text-base">{boq.title}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">{boq.excelFileName} • {boq.items.length} items</p>
                    {(() => {
                      const total = boq.items.reduce((s, item) => s + (item.totalAmount ?? 0), 0);
                      return total > 0 ? (
                        <p className="text-xs font-semibold text-green-600 mt-0.5">Total BOQ: ₹{total.toLocaleString("en-IN")}</p>
                      ) : null;
                    })()}
                    {boq.deadlineDate ? (
                      <div className="flex items-center gap-1 mt-0.5">
                        <p className="text-xs text-orange-600">Deadline: {boq.deadlineDate}</p>
                        <button
                          className="text-muted-foreground hover:text-foreground cursor-pointer"
                          onClick={() => { setDeadlineEditId(boq._id); setNewDeadline(boq.deadlineDate ?? ""); }}
                        >
                          <Pencil size={11} />
                        </button>
                      </div>
                    ) : (
                      <button
                        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-orange-600 cursor-pointer mt-0.5"
                        onClick={() => { setDeadlineEditId(boq._id); setNewDeadline(""); }}
                      >
                        <CalendarDays size={11} /> Deadline set karein
                      </button>
                    )}
                  </div>
                  <Badge className={statusColors[boq.status] ?? ""}>{statusLabels[boq.status] ?? boq.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap gap-2 mt-2">
                  {/* Share buttons */}
                  <Button size="sm" variant="secondary" className="gap-1" onClick={() => copyLink(boq.token)}>
                    <Copy size={13} /> Link Copy
                  </Button>
                  <Button size="sm" className="gap-1 bg-green-600 hover:bg-green-700 text-white" onClick={() => shareWhatsApp(boq.token, boq.title)}>
                    <MessageSquare size={13} /> WhatsApp
                  </Button>
                  <Button size="sm" variant="outline" className="gap-1" onClick={() => shareEmail(boq.token, boq.title)}>
                    <Mail size={13} /> Email
                  </Button>
                  {/* Invite vendors */}
                  <Button size="sm" variant="outline" className="gap-1" onClick={() => setInviteBoqId(boq._id)}>
                    <Users size={13} /> Vendors Invite
                  </Button>
                  {/* View submissions */}
                  <Button size="sm" variant="outline" className="gap-1" onClick={() => setSubmissionsBoqId(boq._id)}>
                    <Eye size={13} /> Submissions
                  </Button>
                  {/* Compare rates */}
                  <Button size="sm" className="gap-1" onClick={() => navigate(`/boq/${boq._id}/compare`)}>
                    <BarChart3 size={13} /> Compare & Issue PO
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Invite dialog */}
      {inviteBoqId && (
        <InviteDialog boqId={inviteBoqId} open={!!inviteBoqId} onClose={() => setInviteBoqId(null)} />
      )}

      {/* Submissions dialog */}
      {submissionsBoqId && (
        <SubmissionsDialog boqId={submissionsBoqId} open={!!submissionsBoqId} onClose={() => setSubmissionsBoqId(null)} />
      )}

      {/* Deadline edit dialog */}
      <Dialog open={!!deadlineEditId} onOpenChange={(v) => { if (!v) { setDeadlineEditId(null); setNewDeadline(""); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><CalendarDays size={16} /> Deadline Change Karein</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1">
              <Label>Nai Deadline</Label>
              <Input type="date" value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => { setDeadlineEditId(null); setNewDeadline(""); }}>Cancel</Button>
              {newDeadline && (
                <Button variant="secondary" onClick={() => { void updateDeadline({ id: deadlineEditId!, deadlineDate: undefined }).then(() => { toast.success("Deadline hata di!"); setDeadlineEditId(null); setNewDeadline(""); }); }}>
                  Deadline Hatao
                </Button>
              )}
              <Button onClick={handleSaveDeadline}>Save Karein</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function BOQPage() {
  return (
    <Authenticated>
      <BOQPageInner />
    </Authenticated>
  );
}
