import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  ArrowLeft, BarChart3, CheckCircle, XCircle, Download,
  FileText, Trophy, AlertTriangle, Users, TrendingDown,
  ClipboardList, Share2, Eye, RefreshCw
} from "lucide-react";
import * as XLSX from "xlsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const RANK_LABELS = ["L1", "L2", "L3", "L4", "L5"];
const RANK_COLORS = [
  "bg-green-100 text-green-800 border-green-300",
  "bg-blue-100 text-blue-800 border-blue-300",
  "bg-orange-100 text-orange-800 border-orange-300",
  "bg-gray-100 text-gray-700 border-gray-300",
  "bg-gray-100 text-gray-700 border-gray-300",
];

function BOQCompareInner() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const boqId = id as Id<"boqProjects">;

  const boq = useQuery(api.boq.projects.get, { id: boqId });
  const submissions = useQuery(api.boq.submissions.listByBoq, { boqId }) ?? [];
  const invitations = useQuery(api.boq.invitations.listByBoq, { boqId }) ?? [];
  const sites = useQuery(api.sites.list, {}) ?? [];
  const suppliers = useQuery(api.suppliers.list, {}) ?? [];
  const contractors = useQuery(api.contractors.list, {}) ?? [];

  const selectSub = useMutation(api.boq.submissions.select);
  const rejectSub = useMutation(api.boq.submissions.reject);
  const issuePO = useMutation(api.boq.projects.issuePurchaseOrder);
  const publishComparison = useMutation(api.boq.projects.publishComparison);

  const [poDialog, setPoDialog] = useState(false);
  const [selectedSubForPO, setSelectedSubForPO] = useState<Id<"boqSubmissions"> | null>(null);
  const [poSiteId, setPoSiteId] = useState<Id<"sites"> | "">("");
  const [poSupplierId, setPoSupplierId] = useState<Id<"suppliers"> | "">("");
  const [poContractorId, setPoContractorId] = useState<Id<"contractors"> | "">("");
  const [poVendorType, setPoVendorType] = useState<"supplier" | "contractor">("supplier");
  const [poDelivery, setPoDelivery] = useState("");
  const [poTerms, setPoTerms] = useState("");
  const [issuingPO, setIssuingPO] = useState(false);

  const [publishDialog, setPublishDialog] = useState(false);
  const [revisionDeadline, setRevisionDeadline] = useState("");
  const [publishing, setPublishing] = useState(false);

  const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;

  const statusColors: Record<string, string> = {
    submitted: "bg-blue-100 text-blue-700",
    selected: "bg-green-100 text-green-700",
    rejected: "bg-red-100 text-red-700",
  };

  const boqStatusColors: Record<string, string> = {
    draft: "bg-gray-100 text-gray-700",
    invited: "bg-blue-100 text-blue-700",
    comparing: "bg-yellow-100 text-yellow-700",
    finalized: "bg-green-100 text-green-700",
    ordered: "bg-purple-100 text-purple-700",
  };

  const activeSubmissions = submissions.filter((s) => s.status !== "rejected");
  const ranked = [...activeSubmissions].sort((a, b) => a.totalAmount - b.totalAmount);
  // All submissions for full record (rejected shown separately at end)
  const rejectedSubmissions = submissions.filter((s) => s.status === "rejected");
  const allForTable = [...ranked, ...rejectedSubmissions];

  function getLowestRate(srNo: number): number | null {
    const rates = activeSubmissions
      .map((s) => s.items.find((i) => i.srNo === srNo)?.ratePerUnit ?? null)
      .filter((r): r is number => r !== null);
    return rates.length > 0 ? Math.min(...rates) : null;
  }

  const winnerSub = ranked.length > 0 ? ranked[0] : null;

  async function handleSelect(subId: Id<"boqSubmissions">) {
    try { await selectSub({ submissionId: subId }); toast.success("Vendor select ho gaya!"); }
    catch (e) { toast.error("Error: " + String(e)); }
  }

  async function handleReject(subId: Id<"boqSubmissions">) {
    try { await rejectSub({ submissionId: subId }); toast.success("Reject ho gayi"); }
    catch (e) { toast.error("Error: " + String(e)); }
  }

  async function handlePublish() {
    setPublishing(true);
    try {
      await publishComparison({ id: boqId, revisionDeadline: revisionDeadline || undefined });
      toast.success("L1/L2/L3 rankings vendors ko visible ho gayi!");
      setPublishDialog(false);
    } catch (e) { toast.error("Error: " + String(e)); }
    finally { setPublishing(false); }
  }

  async function handleIssuePO() {
    if (!selectedSubForPO || !poSiteId || !boq) { toast.error("Site zaroori hai"); return; }
    if (poVendorType === "supplier" && !poSupplierId) { toast.error("Supplier select karein"); return; }
    if (poVendorType === "contractor" && !poContractorId) { toast.error("Contractor select karein"); return; }
    setIssuingPO(true);
    try {
      const poId = await issuePO({
        boqId,
        submissionId: selectedSubForPO,
        supplierId: poVendorType === "supplier" ? poSupplierId as Id<"suppliers"> : undefined,
        contractorId: poVendorType === "contractor" ? poContractorId as Id<"contractors"> : undefined,
        siteId: poSiteId,
        companyId: boq.companyId,
        expectedDeliveryDate: poDelivery || undefined,
        terms: poTerms || undefined,
      });
      toast.success("Purchase Order issue ho gaya!");
      setPoDialog(false);
      navigate(`/purchase-orders/${poId}`);
    } catch (e) { toast.error("Error: " + String(e)); }
    finally { setIssuingPO(false); }
  }

  function openPODialog(subId: Id<"boqSubmissions">) {
    const sub = submissions.find((s) => s._id === subId);
    const inv = invitations.find((i) => i._id === sub?.invitationId);
    const vType = inv?.vendorType ?? "supplier";
    setPoVendorType(vType);
    if (vType === "supplier" && inv?.supplierId) setPoSupplierId(inv.supplierId);
    if (vType === "contractor" && inv?.contractorId) setPoContractorId(inv.contractorId);
    if (boq?.siteId) setPoSiteId(boq.siteId);
    setSelectedSubForPO(subId);
    setPoDialog(true);
  }

  function exportComparison() {
    if (!boq) return;
    const headers = ["Sr", "Description", "Unit", "Qty",
      ...ranked.map((s, i) => `${RANK_LABELS[i] ?? `L${i + 1}`} ${s.vendorName} Rate`),
      ...ranked.map((s, i) => `${RANK_LABELS[i] ?? `L${i + 1}`} ${s.vendorName} Total`),
      "Lowest Rate", "Savings"];
    const rows = boq.items.map((item) => {
      const rates = ranked.map((s) => s.items.find((i) => i.srNo === item.srNo)?.ratePerUnit ?? "");
      const totals = ranked.map((s) => s.items.find((i) => i.srNo === item.srNo)?.totalAmount ?? "");
      const low = getLowestRate(item.srNo);
      const rateVals = rates.filter((r): r is number => typeof r === "number");
      const maxRate = rateVals.length > 0 ? Math.max(...rateVals) : 0;
      const saving = low !== null && maxRate > 0 ? (maxRate - low) * item.quantity : "";
      return [item.srNo, item.description, item.unit, item.quantity, ...rates, ...totals, low ?? "", saving];
    });
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    ws["!cols"] = [{ wch: 5 }, { wch: 35 }, { wch: 8 }, { wch: 6 }, ...ranked.flatMap(() => [{ wch: 16 }, { wch: 16 }]), { wch: 14 }, { wch: 14 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "L1-L2-L3 Comparison");
    XLSX.writeFile(wb, `BOQ_L1L2L3_${boq.title.replace(/\s+/g, "_")}.xlsx`);
  }

  if (!boq) return <div className="flex items-center justify-center h-64"><p className="text-muted-foreground">Loading...</p></div>;

  const selectedSub = submissions.find((s) => s.status === "selected");

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={() => navigate("/boq")} className="gap-1 -ml-2">
          <ArrowLeft size={15} /> BOQ List
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-xl font-bold truncate">{boq.title}</h1>
            <Badge className={boqStatusColors[boq.status] ?? ""}>{boq.status}</Badge>
            {boq.comparisonPublished && <Badge className="bg-teal-100 text-teal-700 gap-1"><Eye size={11} /> L1/L2/L3 Published</Badge>}
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {boq.items.length} items • {submissions.length} submissions • {invitations.length} invited
            {boq.deadlineDate && ` • Deadline: ${boq.deadlineDate}`}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="secondary" size="sm" className="gap-1" onClick={exportComparison} disabled={submissions.length === 0}>
            <Download size={14} /> Excel (L1/L2/L3)
          </Button>
          {submissions.length >= 2 && !boq.comparisonPublished && boq.status !== "ordered" && (
            <Button size="sm" className="gap-1 bg-teal-600 hover:bg-teal-700" onClick={() => setPublishDialog(true)}>
              <Share2 size={14} /> Vendors Ko L1/L2/L3 Dikhayein
            </Button>
          )}
          {boq.comparisonPublished && boq.status !== "ordered" && (
            <Button size="sm" variant="secondary" className="gap-1 text-teal-700" onClick={() => setPublishDialog(true)}>
              <RefreshCw size={14} /> Re-publish
            </Button>
          )}
        </div>
      </div>

      {/* Published banner */}
      {boq.comparisonPublished && (
        <div className="bg-teal-50 border border-teal-200 rounded-xl p-4 flex items-center gap-4 flex-wrap">
          <Eye size={22} className="text-teal-600 flex-shrink-0" />
          <div className="flex-1">
            <p className="font-semibold text-teal-800">L1/L2/L3 Rankings Vendors Ko Visible Hain</p>
            <p className="text-sm text-teal-700">
              Har vendor apni rank dekh sakta hai aur rate revise kar sakta hai.
              {boq.revisionDeadline && ` Revision deadline: ${boq.revisionDeadline}`}
            </p>
          </div>
          <Button size="sm" variant="secondary" className="gap-1"
            onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/portal/boq-vendor?token=${boq.token}`); toast.success("Link copied!"); }}>
            <Share2 size={13} /> Link Copy
          </Button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1"><Users size={16} className="text-muted-foreground" /><span className="text-xs text-muted-foreground">Invited</span></div>
          <p className="text-2xl font-bold">{invitations.length}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1"><ClipboardList size={16} className="text-muted-foreground" /><span className="text-xs text-muted-foreground">Submissions</span></div>
          <p className="text-2xl font-bold">{submissions.length}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1"><TrendingDown size={16} className="text-green-600" /><span className="text-xs text-muted-foreground">L1 (Lowest)</span></div>
          <p className="text-2xl font-bold text-green-700">{winnerSub ? fmt(winnerSub.totalAmount) : "—"}</p>
          {winnerSub && <p className="text-xs text-muted-foreground">{winnerSub.vendorName}</p>}
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1"><Trophy size={16} className="text-yellow-600" /><span className="text-xs text-muted-foreground">Savings L1 vs L{ranked.length}</span></div>
          {ranked.length >= 2 ? (
            <>
              <p className="text-2xl font-bold text-yellow-600">{fmt(ranked[ranked.length - 1].totalAmount - ranked[0].totalAmount)}</p>
              <p className="text-xs text-muted-foreground">{(((ranked[ranked.length - 1].totalAmount - ranked[0].totalAmount) / ranked[ranked.length - 1].totalAmount) * 100).toFixed(1)}% fark</p>
            </>
          ) : <p className="text-2xl font-bold text-muted-foreground">—</p>}
        </Card>
      </div>

      {/* Selected winner banner */}
      {selectedSub && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-4 flex-wrap">
          <CheckCircle size={28} className="text-green-600 flex-shrink-0" />
          <div className="flex-1">
            <p className="font-semibold text-green-800">Finalized: {selectedSub.vendorName} (L1)</p>
            <p className="text-sm text-green-700">Grand Total: {fmt(selectedSub.totalAmount)}</p>
          </div>
          {boq.status !== "ordered" && (
            <Button className="gap-2 bg-green-700 hover:bg-green-800" onClick={() => openPODialog(selectedSub._id)}>
              <FileText size={15} /> Purchase Order Issue Karein
            </Button>
          )}
          {boq.status === "ordered" && <Badge className="bg-purple-100 text-purple-700 px-3 py-1.5">PO Issued — Kaam Shuru Ho Sakta Hai</Badge>}
        </div>
      )}

      {submissions.length === 0 && (
        <div className="text-center py-16 text-muted-foreground border rounded-xl">
          <BarChart3 size={48} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">Koi submission nahi aayi abhi tak</p>
          <Button variant="secondary" size="sm" className="mt-4" onClick={() => navigate("/boq")}><ArrowLeft size={13} className="mr-1" /> BOQ Page</Button>
        </div>
      )}

      {/* L1/L2/L3 Comparison Table */}
      {submissions.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 size={17} /> L1 / L2 / L3 Rate Comparison
              <span className="text-xs font-normal text-muted-foreground">(L1 = Lowest bid)</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-muted border-b">
                    <th className="px-3 py-2.5 text-left text-xs font-semibold border-r w-8">Sr</th>
                    <th className="px-3 py-2.5 text-left text-xs font-semibold border-r min-w-[200px]">Description</th>
                    <th className="px-3 py-2.5 text-center text-xs font-semibold border-r w-20">Unit/Qty</th>
                    {allForTable.map((s, i) => {
                      const isRejected = s.status === "rejected";
                      const rankIdx = ranked.findIndex((r) => r._id === s._id);
                      return (
                        <th key={s._id} className={`px-3 py-2.5 text-center text-xs font-semibold border-r min-w-[150px] ${rankIdx === 0 && !isRejected ? "bg-green-50" : ""} ${isRejected ? "bg-red-50/30" : ""}`}>
                          <div className="flex flex-col items-center gap-1">
                            {isRejected ? (
                              <span className="text-xs font-bold px-2 py-0.5 rounded border bg-red-100 text-red-700 border-red-300">Rejected</span>
                            ) : (
                              <span className={`text-xs font-bold px-2 py-0.5 rounded border ${RANK_COLORS[rankIdx] ?? RANK_COLORS[3]}`}>{RANK_LABELS[rankIdx] ?? `L${rankIdx + 1}`}</span>
                            )}
                            <span className={isRejected ? "line-through text-muted-foreground" : ""}>{s.vendorName}</span>
                            <span className={`font-bold ${isRejected ? "text-muted-foreground line-through" : ""}`}>{fmt(s.totalAmount)}</span>
                            {s.status === "selected" && <Badge className="bg-green-100 text-green-700 text-[10px]">Selected</Badge>}
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {boq.items.map((item) => {
                    const lowestRate = getLowestRate(item.srNo);
                    return (
                      <tr key={item.srNo} className="border-b hover:bg-muted/20">
                        <td className="px-3 py-2 text-xs border-r">{item.srNo}</td>
                        <td className="px-3 py-2 text-xs border-r">{item.description}</td>
                        <td className="px-3 py-2 text-xs text-center border-r">
                          <span className="font-medium">{item.unit}</span><br />
                          <span className="text-muted-foreground">{item.quantity}</span>
                        </td>
                        {allForTable.map((s) => {
                          const si = s.items.find((x) => x.srNo === item.srNo);
                          const isRejected = s.status === "rejected";
                          const rankIdx = ranked.findIndex((r) => r._id === s._id);
                          const isLowest = si && lowestRate !== null && si.ratePerUnit === lowestRate && !isRejected;
                          const l1 = ranked[0]?.items.find((x) => x.srNo === item.srNo);
                          return (
                            <td key={s._id} className={`px-3 py-2 text-xs text-center border-r ${isLowest ? "bg-green-50 text-green-800" : ""} ${rankIdx === 0 && !isLowest && !isRejected ? "bg-green-50/30" : ""} ${isRejected ? "bg-red-50/20" : ""}`}>
                              {si ? (
                                <>
                                  <div className={`font-semibold ${isRejected ? "text-muted-foreground" : ""}`}>{fmt(si.ratePerUnit)}<span className="text-[10px] text-muted-foreground">/{item.unit}</span></div>
                                  <div className="text-muted-foreground text-[11px]">{fmt(si.totalAmount)}</div>
                                  {isLowest && <div className="text-[10px] text-green-700 font-medium">Lowest</div>}
                                  {!isLowest && !isRejected && l1 && l1.ratePerUnit < si.ratePerUnit && (
                                    <div className="text-[10px] text-orange-600">+{fmt(si.ratePerUnit - l1.ratePerUnit)} vs L1</div>
                                  )}
                                  {isRejected && l1 && (
                                    <div className="text-[10px] text-red-500">
                                      {si.ratePerUnit > l1.ratePerUnit ? `+${fmt(si.ratePerUnit - l1.ratePerUnit)} vs L1` : si.ratePerUnit < l1.ratePerUnit ? `-${fmt(l1.ratePerUnit - si.ratePerUnit)} vs L1` : "= L1"}
                                    </div>
                                  )}
                                </>
                              ) : <span className="text-muted-foreground">—</span>}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                  <tr className="bg-muted font-semibold border-t-2">
                    <td colSpan={3} className="px-3 py-3 text-sm text-right border-r">Grand Total</td>
                    {allForTable.map((s) => {
                      const isRejected = s.status === "rejected";
                      const rankIdx = ranked.findIndex((r) => r._id === s._id);
                      return (
                        <td key={s._id} className={`px-3 py-3 text-sm text-center border-r ${rankIdx === 0 && !isRejected ? "bg-green-100 text-green-800" : ""} ${isRejected ? "bg-red-50/30" : ""}`}>
                          <div className={`font-bold ${isRejected ? "text-muted-foreground line-through" : ""}`}>{fmt(s.totalAmount)}</div>
                          {rankIdx === 0 && !isRejected && <div className="text-[10px] text-green-600">L1 — Lowest</div>}
                          {rankIdx > 0 && !isRejected && ranked[0] && (
                            <div className="text-[10px] text-orange-600">+{fmt(s.totalAmount - ranked[0].totalAmount)}</div>
                          )}
                          {isRejected && ranked[0] && (
                            <div className="text-[10px] text-red-500">
                              Rejected • {s.totalAmount > ranked[0].totalAmount ? `+${fmt(s.totalAmount - ranked[0].totalAmount)} vs L1` : `${fmt(ranked[0].totalAmount - s.totalAmount)} saved`}
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Vendor action cards */}
      {submissions.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Vendor Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {ranked.map((s, i) => (
              <Card key={s._id} className={`transition ${s.status === "selected" ? "ring-2 ring-green-400" : ""} ${i === 0 ? "border-green-300" : ""}`}>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded border ${RANK_COLORS[i] ?? RANK_COLORS[3]}`}>{RANK_LABELS[i] ?? `L${i + 1}`}</span>
                        <p className="font-semibold">{s.vendorName}</p>
                      </div>
                      {s.vendorMobile && <p className="text-xs text-muted-foreground">{s.vendorMobile}</p>}
                      <p className="text-lg font-bold text-primary mt-1">{fmt(s.totalAmount)}</p>
                      {i === 0 && <p className="text-xs text-green-600 flex items-center gap-1"><Trophy size={11} /> Lowest Bid (L1)</p>}
                      {i > 0 && ranked[0] && <p className="text-xs text-orange-600">+{fmt(s.totalAmount - ranked[0].totalAmount)} vs L1</p>}
                    </div>
                    <Badge className={statusColors[s.status] ?? ""}>{s.status}</Badge>
                  </div>
                  {s.notes && <p className="text-xs text-muted-foreground bg-muted/50 rounded p-2">{s.notes}</p>}
                  <p className="text-xs text-muted-foreground">{new Date(s.submittedAt).toLocaleDateString("hi-IN")} ko submit</p>
                  {s.status === "submitted" && (
                    <div className="flex gap-2">
                      <Button size="sm" className="gap-1 flex-1 bg-green-600 hover:bg-green-700" onClick={() => handleSelect(s._id)}><CheckCircle size={13} /> Select</Button>
                      <Button size="sm" variant="destructive" className="gap-1 flex-1" onClick={() => handleReject(s._id)}><XCircle size={13} /> Reject</Button>
                    </div>
                  )}
                  {s.status === "selected" && boq.status !== "ordered" && (
                    <Button className="w-full gap-2" onClick={() => openPODialog(s._id)}><FileText size={14} /> PO Issue Karein</Button>
                  )}
                  {s.status === "selected" && boq.status === "ordered" && (
                    <div className="text-center text-xs text-green-600 font-medium py-1">PO Issued — Kaam Shuru</div>
                  )}
                  <ExcelDownloadBtn storageId={s.excelStorageId} fileName={s.excelFileName} />
                </CardContent>
              </Card>
            ))}
            {submissions.filter((s) => s.status === "rejected").map((s) => (
              <Card key={s._id} className="border-red-200">
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold px-2 py-0.5 rounded border bg-red-100 text-red-700 border-red-300">Rejected</span>
                        <p className="font-semibold text-muted-foreground">{s.vendorName}</p>
                      </div>
                      {s.vendorMobile && <p className="text-xs text-muted-foreground">{s.vendorMobile}</p>}
                      <p className="text-lg font-bold text-muted-foreground mt-1">{fmt(s.totalAmount)}</p>
                      {ranked[0] && (
                        <p className="text-xs text-red-600">
                          {s.totalAmount > ranked[0].totalAmount
                            ? `L1 se +${fmt(s.totalAmount - ranked[0].totalAmount)} zyada tha`
                            : `L1 se ${fmt(ranked[0].totalAmount - s.totalAmount)} kam tha`}
                        </p>
                      )}
                    </div>
                    <Badge className="bg-red-100 text-red-700">Rejected</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{new Date(s.submittedAt).toLocaleDateString("hi-IN")} ko submit</p>
                  <ExcelDownloadBtn storageId={s.excelStorageId} fileName={s.excelFileName} />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Publish Dialog */}
      <Dialog open={publishDialog} onOpenChange={setPublishDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Share2 size={18} /> Vendors Ko L1/L2/L3 Dikhayein</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-teal-50 border border-teal-200 rounded-lg p-3 text-sm text-teal-700 space-y-1">
              <p className="font-medium">Publish karne ke baad:</p>
              <ul className="text-xs space-y-1 list-disc list-inside">
                <li>Har vendor apni rank (L1/L2/L3) dekhega</li>
                <li>Apna total aur dusron ka total dikhega</li>
                <li>Har item pe apna rate aur L1 se fark dikhega</li>
                <li>Vendor apna rate revise (kam) kar sakta hai</li>
              </ul>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 space-y-1">
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Current Rankings</p>
              {ranked.map((s, i) => (
                <div key={s._id} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded border ${RANK_COLORS[i] ?? RANK_COLORS[3]}`}>{RANK_LABELS[i] ?? `L${i + 1}`}</span>
                    {s.vendorName}
                  </span>
                  <span className="font-medium">{fmt(s.totalAmount)}</span>
                </div>
              ))}
            </div>
            <div className="space-y-1">
              <Label>Rate Revision Deadline (optional)</Label>
              <Input type="date" value={revisionDeadline} onChange={(e) => setRevisionDeadline(e.target.value)} />
              <p className="text-xs text-muted-foreground">Is date tak vendors rate revise kar sakte hain</p>
            </div>
            <div className="flex gap-3">
              <Button variant="ghost" className="flex-1" onClick={() => setPublishDialog(false)}>Cancel</Button>
              <Button className="flex-1 gap-2 bg-teal-600 hover:bg-teal-700" onClick={handlePublish} disabled={publishing}>
                <Share2 size={14} />{publishing ? "Publishing..." : "Publish Karein"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* PO Dialog */}
      <Dialog open={poDialog} onOpenChange={setPoDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><FileText size={18} /> Purchase Order Issue Karein</DialogTitle></DialogHeader>
          {selectedSubForPO && (() => {
            const sub = submissions.find((s) => s._id === selectedSubForPO);
            return (
              <div className="space-y-4 py-2">
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm">
                  <p className="font-semibold text-green-800">{sub?.vendorName} — L1 (Lowest Bid)</p>
                  <p className="text-green-700">{sub ? fmt(sub.totalAmount) : ""} • {boq.items.length} items</p>
                </div>
                <div className="space-y-1">
                  <Label>Site *</Label>
                  <Select value={poSiteId} onValueChange={(v) => setPoSiteId(v as Id<"sites">)}>
                    <SelectTrigger><SelectValue placeholder="Site chunen" /></SelectTrigger>
                    <SelectContent>{sites.map((s) => <SelectItem key={s._id} value={s._id}>{s.name} — {s.city}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>{poVendorType === "contractor" ? "Contractor *" : "Supplier *"}</Label>
                  {poVendorType === "contractor" ? (
                    <Select value={poContractorId} onValueChange={(v) => setPoContractorId(v as Id<"contractors">)}>
                      <SelectTrigger><SelectValue placeholder="Contractor chunen" /></SelectTrigger>
                      <SelectContent>{contractors.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}</SelectContent>
                    </Select>
                  ) : (
                    <Select value={poSupplierId} onValueChange={(v) => setPoSupplierId(v as Id<"suppliers">)}>
                      <SelectTrigger><SelectValue placeholder="Supplier chunen" /></SelectTrigger>
                      <SelectContent>{suppliers.filter((s) => s.isActive).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1"><Label>Expected Delivery</Label><Input type="date" value={poDelivery} onChange={(e) => setPoDelivery(e.target.value)} /></div>
                  <div className="space-y-1"><Label>PO Date</Label><Input value={new Date().toLocaleDateString("hi-IN")} disabled className="bg-muted" /></div>
                </div>
                <div className="space-y-1">
                  <Label>Terms (optional)</Label>
                  <Textarea rows={2} placeholder="Payment terms..." value={poTerms} onChange={(e) => setPoTerms(e.target.value)} />
                </div>
                <Separator />
                <div className="flex items-center justify-between font-semibold">
                  <span>PO Total</span><span className="text-primary text-lg">{sub ? fmt(sub.totalAmount) : ""}</span>
                </div>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-xs text-yellow-700 flex gap-2">
                  <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" /> PO issue hone ke baad supply / kaam shuru ho sakti hai.
                </div>
                <div className="flex gap-3">
                  <Button variant="ghost" className="flex-1" onClick={() => setPoDialog(false)}>Cancel</Button>
                  <Button className="flex-1 gap-2" onClick={handleIssuePO} disabled={issuingPO || !poSiteId || (poVendorType === "supplier" ? !poSupplierId : !poContractorId)}>
                    <FileText size={14} />{issuingPO ? "Issue ho raha hai..." : "PO Issue Karein"}
                  </Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ExcelDownloadBtn({ storageId, fileName }: { storageId?: string; fileName?: string }) {
  const url = useQuery(api.boq.projects.getFileUrl, storageId ? { storageId } : "skip");
  if (!url || !storageId) return null;
  return (
    <a href={url} download={fileName ?? "submission.xlsx"} target="_blank" rel="noreferrer">
      <Button size="sm" variant="secondary" className="gap-1 w-full"><Download size={12} /> Submitted Excel</Button>
    </a>
  );
}

export default function BOQComparePage() {
  return (
    <Authenticated>
      <BOQCompareInner />
    </Authenticated>
  );
}
