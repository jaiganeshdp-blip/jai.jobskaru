import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { BarChart3, CheckCircle, XCircle, Download } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Props = { boqId: Id<"boqProjects">; open: boolean; onClose: () => void };

export default function SubmissionsDialog({ boqId, open, onClose }: Props) {
  const boq = useQuery(api.boq.projects.get, { id: boqId });
  const submissions = useQuery(api.boq.submissions.listByBoq, { boqId }) ?? [];
  const selectSub = useMutation(api.boq.submissions.select);
  const rejectSub = useMutation(api.boq.submissions.reject);
  const getFileUrl = useQuery(
    api.boq.projects.getFileUrl,
    submissions.length > 0 && submissions[0].excelStorageId
      ? { storageId: submissions[0].excelStorageId }
      : "skip"
  );

  const statusColors: Record<string, string> = {
    submitted: "bg-blue-100 text-blue-700",
    selected: "bg-green-100 text-green-700",
    rejected: "bg-red-100 text-red-700",
  };

  async function handleSelect(id: Id<"boqSubmissions">) {
    try {
      await selectSub({ submissionId: id });
      toast.success("Submission select ho gayi! BOQ finalize ho gaya.");
    } catch (e) {
      toast.error("Error: " + String(e));
    }
  }

  async function handleReject(id: Id<"boqSubmissions">) {
    try {
      await rejectSub({ submissionId: id });
      toast.success("Submission reject ho gayi");
    } catch (e) {
      toast.error("Error: " + String(e));
    }
  }

  const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 size={18} /> Rate Submissions — {boq?.title}
          </DialogTitle>
        </DialogHeader>

        {submissions.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <BarChart3 size={40} className="mx-auto mb-2 opacity-30" />
            <p>Abhi tak koi vendor ne rates submit nahi kiye</p>
            <p className="text-xs mt-1">WhatsApp/email se link share karein</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Side by side comparison header */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-muted">
                    <th className="px-3 py-2 text-left border text-xs font-semibold">Sr</th>
                    <th className="px-3 py-2 text-left border text-xs font-semibold">Description</th>
                    <th className="px-3 py-2 text-center border text-xs font-semibold">Unit / Qty</th>
                    {submissions.map((s) => (
                      <th key={s._id} className="px-3 py-2 text-center border text-xs font-semibold min-w-[120px]">
                        <div>{s.vendorName}</div>
                        <Badge className={`text-[10px] ${statusColors[s.status] ?? ""}`}>{s.status}</Badge>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {boq?.items.map((item) => {
                    // Find minimum rate across submissions for this item
                    const rates = submissions
                      .map((s) => s.items.find((si) => si.srNo === item.srNo)?.ratePerUnit ?? null)
                      .filter((r): r is number => r !== null);
                    const minRate = rates.length > 0 ? Math.min(...rates) : null;

                    return (
                      <tr key={item.srNo} className="border-b hover:bg-muted/30">
                        <td className="px-3 py-2 border text-xs">{item.srNo}</td>
                        <td className="px-3 py-2 border text-xs">{item.description}</td>
                        <td className="px-3 py-2 border text-xs text-center">
                          {item.unit}<br /><span className="text-muted-foreground">{item.quantity}</span>
                        </td>
                        {submissions.map((s) => {
                          const si = s.items.find((x) => x.srNo === item.srNo);
                          const isMin = si && minRate !== null && si.ratePerUnit === minRate;
                          return (
                            <td key={s._id} className={`px-3 py-2 border text-xs text-center ${isMin ? "bg-green-50 font-semibold text-green-700" : ""}`}>
                              {si ? (
                                <>
                                  <div>{fmt(si.ratePerUnit)}/unit</div>
                                  <div className="text-muted-foreground">{fmt(si.totalAmount)}</div>
                                  {isMin && <div className="text-[10px] text-green-600">Lowest</div>}
                                </>
                              ) : "—"}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                  {/* Total row */}
                  <tr className="bg-muted font-semibold">
                    <td colSpan={3} className="px-3 py-2 border text-xs text-right">Total</td>
                    {submissions.map((s) => (
                      <td key={s._id} className="px-3 py-2 border text-xs text-center">{fmt(s.totalAmount)}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Action buttons per submission */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {submissions.map((s) => (
                <div key={s._id} className="border rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{s.vendorName}</p>
                      <p className="text-xs text-muted-foreground">Total: {fmt(s.totalAmount)}</p>
                      {s.notes && <p className="text-xs text-muted-foreground">Note: {s.notes}</p>}
                    </div>
                    <Badge className={statusColors[s.status] ?? ""}>{s.status}</Badge>
                  </div>
                  {s.status === "submitted" && (
                    <div className="flex gap-2">
                      <Button size="sm" className="gap-1 flex-1" onClick={() => handleSelect(s._id)}>
                        <CheckCircle size={13} /> Select (Final)
                      </Button>
                      <Button size="sm" variant="destructive" className="gap-1 flex-1" onClick={() => handleReject(s._id)}>
                        <XCircle size={13} /> Reject
                      </Button>
                    </div>
                  )}
                  {s.excelStorageId && (
                    <ExcelDownloadBtn storageId={s.excelStorageId} fileName={s.excelFileName ?? "submission.xlsx"} />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ExcelDownloadBtn({ storageId, fileName }: { storageId: string; fileName: string }) {
  const url = useQuery(api.boq.projects.getFileUrl, { storageId });
  if (!url) return null;
  return (
    <a href={url} download={fileName} target="_blank" rel="noreferrer">
      <Button size="sm" variant="outline" className="gap-1 w-full">
        <Download size={13} /> Excel Download
      </Button>
    </a>
  );
}
