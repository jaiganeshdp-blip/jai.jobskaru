import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Users, CheckCheck, Copy, MessageSquare, Mail } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Props = { boqId: Id<"boqProjects">; open: boolean; onClose: () => void };

export default function InviteDialog({ boqId, open, onClose }: Props) {
  const suppliers = useQuery(api.suppliers.list, {}) ?? [];
  const contractors = useQuery(api.contractors.list, {}) ?? [];
  const existingInvites = useQuery(api.boq.invitations.listByBoq, { boqId }) ?? [];
  const invite = useMutation(api.boq.invitations.invite);

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);

  // Track invited vendors by supplierId or contractorId
  const existingSupplierIds = new Set(existingInvites.map((i) => i.supplierId ?? "").filter(Boolean));
  const existingContractorIds = new Set(existingInvites.map((i) => i.contractorId ?? "").filter(Boolean));

  function toggle(key: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(key)) { next.delete(key); } else { next.add(key); }
      return next;
    });
  }

  function getVendorLink(token: string) {
    return `${window.location.origin}/portal/boq-vendor?vendorToken=${token}`;
  }

  function copyVendorLink(token: string, name: string) {
    navigator.clipboard.writeText(getVendorLink(token));
    toast.success(`${name} ka link copy ho gaya!`);
  }

  function shareWhatsApp(token: string, name: string, boqTitle: string) {
    const link = getVendorLink(token);
    const msg = encodeURIComponent(
      `Namaste ${name}!\n\nAapko "${boqTitle}" BOQ mein rate bharne ke liye invite kiya gaya hai.\n\nLink: ${link}\n\nLink open karein, rates bharen aur submit karein.\n\nDhanyawad`
    );
    window.open(`https://wa.me/?text=${msg}`, "_blank");
  }

  function shareEmail(token: string, name: string, email: string | undefined, boqTitle: string) {
    const link = getVendorLink(token);
    const subject = encodeURIComponent(`BOQ Rate Request: ${boqTitle}`);
    const body = encodeURIComponent(
      `Namaste ${name},\n\nAapko "${boqTitle}" BOQ ke liye rate submit karne ka invite bheja gaya hai.\n\nLink: ${link}\n\nDhanyawad`
    );
    window.open(`mailto:${email ?? ""}?subject=${subject}&body=${body}`, "_blank");
  }

  const boq = useQuery(api.boq.projects.get, { id: boqId });

  async function handleInvite() {
    if (selected.size === 0) { toast.error("Koi vendor select nahi kiya"); return; }
    setSaving(true);
    try {
      const vendors: Parameters<typeof invite>[0]["vendors"] = [];
      for (const key of selected) {
        if (key.startsWith("s_")) {
          const s = suppliers.find((x) => x._id === key.slice(2));
          if (s) vendors.push({ vendorType: "supplier", supplierId: s._id, vendorName: s.name, vendorMobile: s.mobile, vendorEmail: s.email });
        } else {
          const c = contractors.find((x) => x._id === key.slice(2));
          if (c) vendors.push({ vendorType: "contractor", contractorId: c._id, vendorName: c.name, vendorMobile: c.mobile, vendorEmail: c.email });
        }
      }
      await invite({ boqId, vendors });
      toast.success(`${vendors.length} vendors ko invite bheja gaya! Ab unhe links share karein.`);
      setSelected(new Set());
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setSaving(false);
    }
  }

  const boqTitle = boq?.title ?? "";

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Users size={18} /> Vendors Invite Karein</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground mb-3">Vendor select karein, invite karein, phir unhe alag-alag link share karein</p>

        <div className="space-y-4">
          {/* Suppliers */}
          {suppliers.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Suppliers</p>
              <div className="space-y-2">
                {suppliers.map((s) => {
                  const key = `s_${s._id}`;
                  const inv = existingInvites.find((i) => i.supplierId === s._id);
                  const alreadyInvited = existingSupplierIds.has(s._id);
                  return (
                    <div key={s._id} className={`border rounded-lg p-2 ${alreadyInvited ? "bg-green-50/30 dark:bg-green-950/10" : ""}`}>
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={selected.has(key)}
                          onCheckedChange={() => !alreadyInvited && toggle(key)}
                          disabled={alreadyInvited}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{s.name}</p>
                          <p className="text-xs text-muted-foreground">{s.mobile}</p>
                        </div>
                        {alreadyInvited
                          ? <Badge className="bg-green-100 text-green-700 text-xs">Invited</Badge>
                          : null}
                      </div>
                      {/* Show share buttons for already invited vendors */}
                      {alreadyInvited && inv?.token && (
                        <div className="flex gap-1 mt-2 pl-7">
                          <Button size="sm" variant="secondary" className="gap-1 h-7 text-xs px-2" onClick={() => copyVendorLink(inv.token!, s.name)}>
                            <Copy size={11} /> Link
                          </Button>
                          <Button size="sm" className="gap-1 h-7 text-xs px-2 bg-green-600 hover:bg-green-700 text-white" onClick={() => shareWhatsApp(inv.token!, s.name, boqTitle)}>
                            <MessageSquare size={11} /> WhatsApp
                          </Button>
                          {s.email && (
                            <Button size="sm" variant="secondary" className="gap-1 h-7 text-xs px-2" onClick={() => shareEmail(inv.token!, s.name, s.email, boqTitle)}>
                              <Mail size={11} /> Email
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Contractors */}
          {contractors.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Contractors</p>
              <div className="space-y-2">
                {contractors.map((c) => {
                  const key = `c_${c._id}`;
                  const inv = existingInvites.find((i) => i.contractorId === c._id);
                  const alreadyInvited = existingContractorIds.has(c._id);
                  return (
                    <div key={c._id} className={`border rounded-lg p-2 ${alreadyInvited ? "bg-green-50/30 dark:bg-green-950/10" : ""}`}>
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={selected.has(key)}
                          onCheckedChange={() => !alreadyInvited && toggle(key)}
                          disabled={alreadyInvited}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{c.name}</p>
                          <p className="text-xs text-muted-foreground">{c.mobile}</p>
                        </div>
                        {alreadyInvited
                          ? <Badge className="bg-green-100 text-green-700 text-xs">Invited</Badge>
                          : null}
                      </div>
                      {/* Share buttons for already invited */}
                      {alreadyInvited && inv?.token && (
                        <div className="flex gap-1 mt-2 pl-7">
                          <Button size="sm" variant="secondary" className="gap-1 h-7 text-xs px-2" onClick={() => copyVendorLink(inv.token!, c.name)}>
                            <Copy size={11} /> Link
                          </Button>
                          <Button size="sm" className="gap-1 h-7 text-xs px-2 bg-green-600 hover:bg-green-700 text-white" onClick={() => shareWhatsApp(inv.token!, c.name, boqTitle)}>
                            <MessageSquare size={11} /> WhatsApp
                          </Button>
                          {c.email && (
                            <Button size="sm" variant="secondary" className="gap-1 h-7 text-xs px-2" onClick={() => shareEmail(inv.token!, c.name, c.email, boqTitle)}>
                              <Mail size={11} /> Email
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {suppliers.length === 0 && contractors.length === 0 && (
            <p className="text-sm text-muted-foreground py-4 text-center">Koi supplier ya contractor nahi mila.</p>
          )}
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Close</Button>
          {selected.size > 0 && (
            <Button onClick={handleInvite} disabled={saving} className="gap-2">
              <CheckCheck size={15} /> {saving ? "Inviting..." : `${selected.size} Vendor Invite Karein`}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
