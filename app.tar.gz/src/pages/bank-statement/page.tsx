import { useState, useRef, useEffect, useCallback } from "react";
import * as XLSX from "xlsx";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated, Unauthenticated } from "convex/react";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog.tsx";
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormMessage
} from "@/components/ui/form.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Landmark, Upload, Download, PlusCircle, Trash2, FileSpreadsheet,
  TrendingUp, TrendingDown, Wallet, Loader2, Calendar, Building2, Settings2
} from "lucide-react";
import { cn } from "@/lib/utils.ts";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const FINANCIAL_YEARS = ["2026-27", "2025-26", "2024-25"];

function fmt(n: number | undefined) {
  if (n === undefined || n === null) return "-";
  return n.toLocaleString("en-IN", { maximumFractionDigits: 2 });
}
function fmtDate(d: string | undefined) {
  if (!d) return "-";
  const [y, m, day] = d.split("-");
  return `${day}-${m}-${y}`;
}
function parseDate(val: unknown): string | undefined {
  if (!val) return undefined;
  if (typeof val === "number") {
    const d = XLSX.SSF.parse_date_code(val);
    if (d) return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const s = String(val).trim();
  const m1 = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  if (m1) return `${m1[3]}-${m1[2].padStart(2, "0")}-${m1[1].padStart(2, "0")}`;
  const m2 = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if (m2) return `${m2[1]}-${m2[2].padStart(2, "0")}-${m2[3].padStart(2, "0")}`;
  return undefined;
}
function parseNum(val: unknown): number | undefined {
  if (val === "" || val === undefined || val === null) return undefined;
  const n = parseFloat(String(val).replace(/,/g, ""));
  return isNaN(n) ? undefined : n;
}
function norm(s: unknown): string {
  return String(s ?? "").toLowerCase().replace(/[\s_\-&./()]/g, "").trim();
}

// ── Date Range Picker with F2 shortcut ───────────────────────────────────────
function DateRangeFilter({
  dateFrom,
  dateTo,
  onDateFromChange,
  onDateToChange,
}: {
  dateFrom: string;
  dateTo: string;
  onDateFromChange: (v: string) => void;
  onDateToChange: (v: string) => void;
}) {
  const fromRef = useRef<HTMLInputElement>(null);
  const toRef = useRef<HTMLInputElement>(null);
  const [showDateFilter, setShowDateFilter] = useState(false);

  // F2 shortcut to toggle date filter
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "F2") {
        e.preventDefault();
        setShowDateFilter((prev) => {
          const next = !prev;
          if (next) {
            setTimeout(() => fromRef.current?.showPicker?.(), 100);
          } else {
            onDateFromChange("");
            onDateToChange("");
          }
          return next;
        });
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onDateFromChange, onDateToChange]);

  if (!showDateFilter) {
    return (
      <Button
        size="sm"
        variant="secondary"
        className="h-8 text-xs cursor-pointer gap-1"
        onClick={() => setShowDateFilter(true)}
        title="F2 se bhi open ho sakta hai"
      >
        <Calendar className="w-3.5 h-3.5" /> Date Filter (F2)
      </Button>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      <Input
        ref={fromRef}
        type="date"
        className="h-8 text-xs w-32"
        value={dateFrom}
        onChange={(e) => onDateFromChange(e.target.value)}
        placeholder="From"
      />
      <span className="text-xs text-muted-foreground">to</span>
      <Input
        ref={toRef}
        type="date"
        className="h-8 text-xs w-32"
        value={dateTo}
        onChange={(e) => onDateToChange(e.target.value)}
        placeholder="To"
      />
      <Button
        size="sm"
        variant="ghost"
        className="h-8 text-xs cursor-pointer px-2"
        onClick={() => {
          onDateFromChange("");
          onDateToChange("");
          setShowDateFilter(false);
        }}
      >
        Clear
      </Button>
    </div>
  );
}

// ── Manage Banks Dialog ──────────────────────────────────────────────────────
function ManageBanksDialog({
  open,
  onOpenChange,
  companyId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  companyId: Id<"companies">;
}) {
  const banksList = useQuery(api.banks.list, { companyId });
  const addBank = useMutation(api.banks.create);
  const deleteBank = useMutation(api.banks.remove);
  const [newBankName, setNewBankName] = useState("");
  const [newAccountNo, setNewAccountNo] = useState("");
  const [adding, setAdding] = useState(false);

  const handleAdd = async () => {
    if (!newBankName.trim()) {
      toast.error("Bank name daalna zaroori hai");
      return;
    }
    setAdding(true);
    try {
      await addBank({ companyId, name: newBankName.trim(), accountNumber: newAccountNo.trim() || undefined });
      toast.success("Bank add ho gayi");
      setNewBankName("");
      setNewAccountNo("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Error adding bank";
      toast.error(msg);
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id: Id<"banks">, name: string) => {
    if (!confirm(`"${name}" bank delete karein?`)) return;
    try {
      await deleteBank({ id });
      toast.success(`"${name}" delete ho gayi`);
    } catch {
      toast.error("Error deleting bank");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-[95vw]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="w-4 h-4" /> Banks Manage Karein
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Add new bank */}
          <div className="flex flex-col gap-2 p-3 bg-muted/50 rounded-lg border">
            <p className="text-xs font-medium text-muted-foreground">Nayi Bank Add Karein</p>
            <div className="flex gap-2">
              <Input
                placeholder="Bank Name (e.g. HDFC Bank)"
                value={newBankName}
                onChange={(e) => setNewBankName(e.target.value)}
                className="h-9 text-sm flex-1"
                onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
              />
              <Input
                placeholder="Account No (optional)"
                value={newAccountNo}
                onChange={(e) => setNewAccountNo(e.target.value)}
                className="h-9 text-sm w-36"
                onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
              />
            </div>
            <Button
              size="sm"
              className="h-8 text-xs cursor-pointer self-end gap-1"
              onClick={handleAdd}
              disabled={adding || !newBankName.trim()}
            >
              {adding ? <Loader2 className="w-3 h-3 animate-spin" /> : <PlusCircle className="w-3 h-3" />}
              Add Bank
            </Button>
          </div>

          {/* Banks list */}
          <div className="space-y-1 max-h-60 overflow-y-auto">
            {!banksList && <Skeleton className="h-10 w-full" />}
            {banksList && banksList.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-4">Abhi koi bank nahi hai. Upar se add karein.</p>
            )}
            {banksList?.map((bank) => (
              <div
                key={bank._id}
                className="flex items-center justify-between px-3 py-2 rounded-md bg-card border hover:bg-muted/30 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium">{bank.name}</p>
                  {bank.accountNumber && (
                    <p className="text-[10px] text-muted-foreground font-mono">{bank.accountNumber}</p>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 cursor-pointer text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={() => handleDelete(bank._id, bank.name)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="secondary" size="sm" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Add/Edit Dialog ─────────────────────────────────────────────────────────
const txSchema = z.object({
  bankName: z.string().min(1, "Bank name required"),
  accountNumber: z.string().optional(),
  date: z.string().min(1, "Date required"),
  narration: z.string().optional(),
  chequeNo: z.string().optional(),
  debit: z.coerce.number().optional(),
  credit: z.coerce.number().optional(),
  balance: z.coerce.number().optional(),
  utrNo: z.string().optional(),
  category: z.string().optional(),
  remarks: z.string().optional(),
});
type TxForm = z.infer<typeof txSchema>;

function TxDialog({
  open, onOpenChange, editId, financialYear, defaultBank, companyId,
}: {
  open: boolean; onOpenChange: (v: boolean) => void;
  editId: Id<"bankStatements"> | null; financialYear: string; defaultBank: string;
  companyId: Id<"companies">;
}) {
  const createTx = useMutation(api.bankStatements.create);
  const updateTx = useMutation(api.bankStatements.update);
  const removeTx = useMutation(api.bankStatements.remove);
  const existing = useQuery(api.bankStatements.list, { companyId, financialYear });
  const banksList = useQuery(api.banks.list, { companyId });

  const form = useForm<TxForm>({
    resolver: zodResolver(txSchema),
    defaultValues: { bankName: defaultBank, date: "", debit: undefined, credit: undefined, balance: undefined },
  });

  const editRow = editId ? (existing ?? []).find((r) => r._id === editId) : null;

  // fill form when editing
  useState(() => {
    if (editRow) {
      form.reset({
        bankName: editRow.bankName,
        accountNumber: editRow.accountNumber ?? "",
        date: editRow.date,
        narration: editRow.narration ?? "",
        chequeNo: editRow.chequeNo ?? "",
        debit: editRow.debit,
        credit: editRow.credit,
        balance: editRow.balance,
        utrNo: editRow.utrNo ?? "",
        category: editRow.category ?? "",
        remarks: editRow.remarks ?? "",
      });
    }
  });

  const onSubmit = async (v: TxForm) => {
    try {
      if (editId) {
        await updateTx({ id: editId, ...v });
        toast.success("Transaction updated");
      } else {
        await createTx({ ...v, companyId, financialYear });
        toast.success("Transaction added");
      }
      onOpenChange(false);
      form.reset({ bankName: defaultBank, date: "" });
    } catch {
      toast.error("Error saving transaction");
    }
  };

  const handleDelete = async () => {
    if (!editId || !confirm("Delete karein?")) return;
    await removeTx({ id: editId });
    toast.success("Deleted");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl w-[95vw] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editId ? "Transaction Edit" : "Naya Transaction Add Karein"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="bankName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Bank Name *</FormLabel>
                  {banksList && banksList.length > 0 ? (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger className="h-10">
                          <SelectValue placeholder="Bank select karein" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {banksList.map((b) => (
                          <SelectItem key={b._id} value={b.name}>{b.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <FormControl><Input placeholder="HDFC Bank" className="h-10" {...field} /></FormControl>
                  )}
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="accountNumber" render={({ field }) => (
                <FormItem>
                  <FormLabel>Account No</FormLabel>
                  <FormControl><Input placeholder="XXXX1234" className="h-10" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="date" render={({ field }) => (
                <FormItem>
                  <FormLabel>Date *</FormLabel>
                  <FormControl><Input type="date" className="h-10" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="chequeNo" render={({ field }) => (
                <FormItem>
                  <FormLabel>Cheque / Ref No</FormLabel>
                  <FormControl><Input placeholder="CHQ001" className="h-10" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="narration" render={({ field }) => (
              <FormItem>
                <FormLabel>Narration / Description</FormLabel>
                <FormControl><Input placeholder="Payment from client / salary..." className="h-10" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-3 gap-3">
              <FormField control={form.control} name="debit" render={({ field }) => (
                <FormItem>
                  <FormLabel>Debit (₹)</FormLabel>
                  <FormControl><Input type="number" placeholder="0" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="credit" render={({ field }) => (
                <FormItem>
                  <FormLabel>Credit (₹)</FormLabel>
                  <FormControl><Input type="number" placeholder="0" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="balance" render={({ field }) => (
                <FormItem>
                  <FormLabel>Balance (₹)</FormLabel>
                  <FormControl><Input type="number" placeholder="0" className="h-10" {...field} value={field.value ?? ""} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="utrNo" render={({ field }) => (
                <FormItem>
                  <FormLabel>UTR No</FormLabel>
                  <FormControl><Input placeholder="UTR number" className="h-10" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="category" render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl><Input placeholder="Client Payment / Salary..." className="h-10" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="remarks" render={({ field }) => (
              <FormItem>
                <FormLabel>Remarks</FormLabel>
                <FormControl><Input placeholder="Koi note..." className="h-10" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter className="flex-row gap-2 justify-between pt-2">
              {editId && (
                <Button type="button" variant="destructive" size="sm" onClick={handleDelete} className="cursor-pointer gap-1">
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </Button>
              )}
              <div className="flex gap-2 ml-auto">
                <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Save"}</Button>
              </div>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Import/Export Dialog ─────────────────────────────────────────────────────
function BankImportExportDialog({
  open, onOpenChange, financialYear, companyId, rows,
}: {
  open: boolean; onOpenChange: (v: boolean) => void; financialYear: string;
  companyId: Id<"companies">;
  rows: { bankName: string; accountNumber?: string; date: string; narration?: string; chequeNo?: string; debit?: number; credit?: number; balance?: number; utrNo?: string; category?: string; remarks?: string }[];
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<typeof rows>([]);
  const [bankOverride, setBankOverride] = useState("");
  const [step, setStep] = useState<"idle" | "preview" | "done">("idle");
  const [importing, setImporting] = useState(false);
  const bulkCreate = useMutation(api.bankStatements.bulkCreate);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array", cellDates: false });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const raw = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "", raw: true }) as unknown[][];

        // Find header row
        let headerRowIdx = -1;
        let headerRow: string[] = [];
        for (let i = 0; i < Math.min(15, raw.length); i++) {
          const row = raw[i] as unknown[];
          const joined = row.map((c) => norm(c)).join("|");
          if (joined.includes("date") && (joined.includes("debit") || joined.includes("credit") || joined.includes("narration") || joined.includes("description"))) {
            headerRowIdx = i;
            headerRow = row.map((c) => String(c ?? ""));
            break;
          }
        }
        if (headerRowIdx === -1) {
          toast.error("Header row nahi mili — Date, Debit/Credit column hona chahiye");
          return;
        }

        const idx: Record<string, number> = {};
        headerRow.forEach((h, i) => { idx[norm(h)] = i; });
        const getCol = (keys: string[], row: unknown[]): unknown => {
          for (const k of keys) {
            if (idx[k] !== undefined && row[idx[k]] !== "" && row[idx[k]] !== undefined) return row[idx[k]];
          }
          return undefined;
        };

        const parsed: typeof rows = [];
        for (let i = headerRowIdx + 1; i < raw.length; i++) {
          const row = raw[i] as unknown[];
          const dateVal = getCol(["date", "txndate", "valuedate", "transactiondate"], row);
          const dateStr = parseDate(dateVal);
          if (!dateStr) continue;

          const debit = parseNum(getCol(["debit", "dr", "withdrawal", "withdrawalamount"], row));
          const credit = parseNum(getCol(["credit", "cr", "deposit", "depositamount"], row));
          if (debit === undefined && credit === undefined) continue;

          parsed.push({
            bankName: bankOverride || "Imported Bank",
            accountNumber: String(getCol(["accountno", "accountnumber", "acno"], row) ?? "").trim() || undefined,
            date: dateStr,
            narration: String(getCol(["narration", "description", "particulars", "remarks", "details"], row) ?? "").trim() || undefined,
            chequeNo: String(getCol(["chequeno", "chqno", "refno", "referenceno", "transactionid", "txnid"], row) ?? "").trim() || undefined,
            debit,
            credit,
            balance: parseNum(getCol(["balance", "closingbalance", "runningbalance", "availablebalance"], row)),
            utrNo: String(getCol(["utr", "utrno", "utrnumber"], row) ?? "").trim() || undefined,
            category: undefined,
            remarks: undefined,
          });
        }

        if (parsed.length === 0) { toast.error("Koi valid transaction nahi mili"); return; }
        setPreview(parsed);
        setStep("preview");
      } catch (err) {
        console.error(err);
        toast.error("File parse nahi hua");
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      const count = await bulkCreate({
        rows: preview.map((r) => ({ ...r, companyId, financialYear })),
      });
      toast.success(`${count} transactions import ho gaye!`);
      setStep("done");
    } catch {
      toast.error("Import failed");
    } finally {
      setImporting(false);
    }
  };

  const handleExport = () => {
    if (!rows.length) { toast.error("Koi data nahi hai export ke liye"); return; }
    const wsData: unknown[][] = [
      ["Date", "Bank Name", "Account No", "Narration", "Cheque/Ref No", "Debit (₹)", "Credit (₹)", "Balance (₹)", "UTR No", "Category", "Remarks"],
      ...rows.map((r) => [
        fmtDate(r.date), r.bankName, r.accountNumber ?? "",
        r.narration ?? "", r.chequeNo ?? "",
        r.debit ?? "", r.credit ?? "", r.balance ?? "",
        r.utrNo ?? "", r.category ?? "", r.remarks ?? "",
      ]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws["!cols"] = [{ wch: 12 }, { wch: 20 }, { wch: 16 }, { wch: 40 }, { wch: 16 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 20 }, { wch: 16 }, { wch: 20 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Bank Statement ${financialYear}`);
    XLSX.writeFile(wb, `Bank_Statement_${financialYear}.xlsx`);
    toast.success("Excel download ho raha hai!");
  };

  const handleClose = () => { setPreview([]); setStep("idle"); setBankOverride(""); onOpenChange(false); };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl w-[95vw] max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-5 pb-4 border-b">
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-primary" />
            Bank Statement — Import / Export
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Export */}
          <div className="border rounded-lg p-4 flex items-center justify-between">
            <div>
              <p className="font-semibold">Export to Excel</p>
              <p className="text-sm text-muted-foreground">{rows.length} transactions download karein</p>
            </div>
            <Button onClick={handleExport} className="cursor-pointer gap-2">
              <Download className="w-4 h-4" /> Download Excel
            </Button>
          </div>

          {/* Import */}
          <div className="border rounded-lg p-4 space-y-4">
            <p className="font-semibold">Import Bank Statement from Excel</p>
            <div className="flex gap-3 items-center">
              <Input
                placeholder="Bank Name (e.g. HDFC Bank)"
                className="h-10 max-w-xs"
                value={bankOverride}
                onChange={(e) => setBankOverride(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Import se pehle bank ka naam bharo</p>
            </div>

            {step === "idle" && (
              <div
                className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
                <p className="font-medium">Bank statement Excel ya CSV yahan upload karein</p>
                <p className="text-xs text-muted-foreground mt-1">HDFC, SBI, ICICI, Axis sab supported</p>
                <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFile} />
              </div>
            )}

            {step === "preview" && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-green-600 dark:text-green-400">{preview.length} transactions mili hain</p>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={() => { setPreview([]); setStep("idle"); }} className="cursor-pointer">Back</Button>
                    <Button size="sm" onClick={handleImport} disabled={importing} className="cursor-pointer gap-1.5">
                      {importing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      {importing ? "Import ho raha hai..." : `Import (${preview.length})`}
                    </Button>
                  </div>
                </div>
                <div className="overflow-auto max-h-56 border rounded-lg">
                  <table className="w-full text-xs border-collapse min-w-[700px]">
                    <thead className="sticky top-0 bg-muted">
                      <tr>
                        {["Date", "Bank", "Narration", "Cheque/Ref", "Debit", "Credit", "Balance", "UTR"].map(h => (
                          <th key={h} className="border border-border px-2 py-1.5 text-left">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {preview.slice(0, 50).map((r, i) => (
                        <tr key={i} className={i % 2 === 0 ? "bg-background" : "bg-muted/30"}>
                          <td className="border border-border px-2 py-1 whitespace-nowrap">{fmtDate(r.date)}</td>
                          <td className="border border-border px-2 py-1">{r.bankName}</td>
                          <td className="border border-border px-2 py-1 max-w-[200px] truncate">{r.narration ?? "-"}</td>
                          <td className="border border-border px-2 py-1">{r.chequeNo ?? "-"}</td>
                          <td className="border border-border px-2 py-1 text-right text-red-600">{r.debit ? fmt(r.debit) : "-"}</td>
                          <td className="border border-border px-2 py-1 text-right text-green-600">{r.credit ? fmt(r.credit) : "-"}</td>
                          <td className="border border-border px-2 py-1 text-right">{r.balance ? fmt(r.balance) : "-"}</td>
                          <td className="border border-border px-2 py-1">{r.utrNo ?? "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {preview.length > 50 && <p className="text-xs text-center text-muted-foreground py-2">... aur {preview.length - 50} rows</p>}
                </div>
              </div>
            )}

            {step === "done" && (
              <div className="flex flex-col items-center py-6 gap-3">
                <p className="font-semibold text-green-600">{preview.length} transactions import ho gaye!</p>
                <Button onClick={handleClose} className="cursor-pointer">Done</Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── Main Page ────────────────────────────────────────────────────────────────
function BankStatementInner() {
  const [fy, setFy] = useState("2026-27");
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>("");
  const [filterBank, setFilterBank] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [txOpen, setTxOpen] = useState(false);
  const [editId, setEditId] = useState<Id<"bankStatements"> | null>(null);
  const [importExportOpen, setImportExportOpen] = useState(false);
  const [manageBanksOpen, setManageBanksOpen] = useState(false);

  // Fetch companies
  const companies = useQuery(api.companies.list, {});

  // Auto-select first company
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      setSelectedCompanyId(companies[0]._id);
    }
  }, [companies, selectedCompanyId]);

  const companyId = selectedCompanyId as Id<"companies"> | "";
  const hasCompany = companyId !== "";

  const rows = useQuery(
    api.bankStatements.list,
    hasCompany
      ? {
          companyId: companyId as Id<"companies">,
          financialYear: fy,
          bankName: filterBank !== "all" ? filterBank : undefined,
          dateFrom: dateFrom || undefined,
          dateTo: dateTo || undefined,
        }
      : "skip"
  );
  const banks = useQuery(
    api.bankStatements.distinctBanks,
    hasCompany
      ? { companyId: companyId as Id<"companies">, financialYear: fy }
      : "skip"
  );
  const summaryData = useQuery(
    api.bankStatements.summary,
    hasCompany
      ? {
          companyId: companyId as Id<"companies">,
          financialYear: fy,
          bankName: filterBank !== "all" ? filterBank : undefined,
          dateFrom: dateFrom || undefined,
          dateTo: dateTo || undefined,
        }
      : "skip"
  );

  const isLoading = rows === undefined;
  const selectedCompany = companies?.find((c) => c._id === companyId);

  const handleDateFromChange = useCallback((v: string) => setDateFrom(v), []);
  const handleDateToChange = useCallback((v: string) => setDateTo(v), []);

  if (!companies) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (companies.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3">
        <Building2 className="w-12 h-12 text-muted-foreground opacity-30" />
        <p className="text-muted-foreground">Pehle company add karein</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full min-h-screen bg-background">
      {/* Header */}
      <div className="border-b px-4 py-3 bg-card">
        <div className="flex flex-col gap-3">
          {/* Top row: title + actions */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Landmark className="w-5 h-5 text-primary" />
              <div>
                <h1 className="font-bold text-base leading-tight">Bank Statement</h1>
                <p className="text-xs text-muted-foreground">{selectedCompany?.name ?? "Select Company"}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {hasCompany && (
                <>
                  <Button size="sm" variant="secondary" onClick={() => setManageBanksOpen(true)} className="h-8 text-xs cursor-pointer gap-1">
                    <Settings2 className="w-3.5 h-3.5" /> Banks
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setImportExportOpen(true)} className="h-8 text-xs cursor-pointer gap-1">
                    <Upload className="w-3.5 h-3.5" /> Import/Export
                  </Button>
                  <Button size="sm" onClick={() => { setEditId(null); setTxOpen(true); }} className="h-8 text-xs cursor-pointer gap-1">
                    <PlusCircle className="w-3.5 h-3.5" /> Add Transaction
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Filter row */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Company Select */}
            <Select value={selectedCompanyId} onValueChange={(v) => { setSelectedCompanyId(v); setFilterBank("all"); }}>
              <SelectTrigger className="w-52 h-8 text-xs">
                <SelectValue placeholder="Company Select Karein" />
              </SelectTrigger>
              <SelectContent>
                {companies.map((c) => (
                  <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Financial Year */}
            <Select value={fy} onValueChange={setFy}>
              <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {FINANCIAL_YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
              </SelectContent>
            </Select>

            {/* Bank Filter */}
            <Select value={filterBank} onValueChange={setFilterBank}>
              <SelectTrigger className="w-40 h-8 text-xs"><SelectValue placeholder="All Banks" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Banks</SelectItem>
                {banks?.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
              </SelectContent>
            </Select>

            {/* Date Range Filter with F2 */}
            <DateRangeFilter
              dateFrom={dateFrom}
              dateTo={dateTo}
              onDateFromChange={handleDateFromChange}
              onDateToChange={handleDateToChange}
            />
          </div>
        </div>
      </div>

      {/* Summary bar */}
      {summaryData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-border border-b">
          {[
            { label: "Total Credit", value: `₹${fmt(summaryData.totalCredit)}`, icon: TrendingUp, color: "text-green-600 dark:text-green-400" },
            { label: "Total Debit", value: `₹${fmt(summaryData.totalDebit)}`, icon: TrendingDown, color: "text-red-600 dark:text-red-400" },
            { label: "Latest Balance", value: `₹${fmt(summaryData.latestBalance)}`, icon: Wallet, color: "text-foreground" },
            { label: "Transactions", value: String(summaryData.txCount), icon: FileSpreadsheet, color: "text-muted-foreground" },
          ].map((s) => (
            <div key={s.label} className="bg-card px-4 py-2.5 flex items-center gap-3">
              <s.icon className={cn("w-5 h-5", s.color)} />
              <div>
                <div className={cn("text-sm font-bold", s.color)}>{s.value}</div>
                <div className="text-[10px] text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-[11px] border-collapse min-w-[900px]">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary text-primary-foreground">
              {["#", "Date", "Bank Name", "Account No", "Narration / Description", "Cheque/Ref No", "Debit (₹)", "Credit (₹)", "Balance (₹)", "UTR No", "Category", "Remarks"].map(h => (
                <th key={h} className="border border-primary/20 px-2 py-1.5 text-left whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading && Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>{Array.from({ length: 12 }).map((__, j) => (
                <td key={j} className="border border-border px-2 py-1"><Skeleton className="h-3 w-full" /></td>
              ))}</tr>
            ))}

            {!isLoading && rows?.length === 0 && (
              <tr>
                <td colSpan={12} className="text-center py-12 text-muted-foreground">
                  <Landmark className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>Koi transaction nahi mila. Import karein ya manually add karein.</p>
                </td>
              </tr>
            )}

            {!isLoading && rows?.map((row, idx) => (
              <tr
                key={row._id}
                className={cn(
                  "cursor-pointer transition-colors",
                  idx % 2 === 0 ? "bg-card hover:bg-muted/50" : "bg-muted/20 hover:bg-muted/40"
                )}
                onClick={() => { setEditId(row._id); setTxOpen(true); }}
              >
                <td className="border border-border px-2 py-1 text-muted-foreground">{idx + 1}</td>
                <td className="border border-border px-2 py-1 whitespace-nowrap font-medium">{fmtDate(row.date)}</td>
                <td className="border border-border px-2 py-1 font-semibold">{row.bankName}</td>
                <td className="border border-border px-2 py-1 font-mono text-[10px]">{row.accountNumber ?? "-"}</td>
                <td className="border border-border px-2 py-1 max-w-[220px] truncate">{row.narration ?? "-"}</td>
                <td className="border border-border px-2 py-1 font-mono text-[10px]">{row.chequeNo ?? "-"}</td>
                <td className="border border-border px-2 py-1 text-right text-red-600 dark:text-red-400 font-semibold">
                  {row.debit ? fmt(row.debit) : "-"}
                </td>
                <td className="border border-border px-2 py-1 text-right text-green-600 dark:text-green-400 font-semibold">
                  {row.credit ? fmt(row.credit) : "-"}
                </td>
                <td className="border border-border px-2 py-1 text-right font-bold">{row.balance ? fmt(row.balance) : "-"}</td>
                <td className="border border-border px-2 py-1 font-mono text-[10px]">{row.utrNo ?? "-"}</td>
                <td className="border border-border px-2 py-1">
                  {row.category ? (
                    <Badge variant="secondary" className="text-[9px] px-1 py-0">{row.category}</Badge>
                  ) : "-"}
                </td>
                <td className="border border-border px-2 py-1 text-muted-foreground">{row.remarks ?? "-"}</td>
              </tr>
            ))}
          </tbody>

          {/* Totals */}
          {summaryData && !isLoading && rows && rows.length > 0 && (
            <tfoot>
              <tr className="bg-primary/10 font-bold border-t-2 border-primary">
                <td colSpan={6} className="border border-border px-2 py-1.5 text-right text-xs">TOTAL →</td>
                <td className="border border-border px-2 py-1.5 text-right text-xs text-red-600">₹{fmt(summaryData.totalDebit)}</td>
                <td className="border border-border px-2 py-1.5 text-right text-xs text-green-600">₹{fmt(summaryData.totalCredit)}</td>
                <td className="border border-border px-2 py-1.5 text-right text-xs">₹{fmt(summaryData.latestBalance)}</td>
                <td colSpan={3} className="border border-border" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {hasCompany && (
        <>
          <TxDialog
            open={txOpen}
            onOpenChange={setTxOpen}
            editId={editId}
            financialYear={fy}
            defaultBank={filterBank !== "all" ? filterBank : ""}
            companyId={companyId as Id<"companies">}
          />
          <BankImportExportDialog
            open={importExportOpen}
            onOpenChange={setImportExportOpen}
            financialYear={fy}
            companyId={companyId as Id<"companies">}
            rows={rows ?? []}
          />
          <ManageBanksDialog
            open={manageBanksOpen}
            onOpenChange={setManageBanksOpen}
            companyId={companyId as Id<"companies">}
          />
        </>
      )}
    </div>
  );
}

export default function BankStatementPage() {
  return (
    <>
      <Unauthenticated><div className="flex items-center justify-center h-64"><SignInButton /></div></Unauthenticated>
      <Authenticated><BankStatementInner /></Authenticated>
    </>
  );
}
