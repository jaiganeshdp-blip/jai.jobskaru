import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Plus, Search, Trash2, Package, Eye, CheckCircle2, XCircle,
  Truck, PlusCircle, MinusCircle,
} from "lucide-react";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";

const STATUS_CONFIG = {
  pending: { label: "Pending", class: "bg-yellow-500/10 text-yellow-600" },
  approved: { label: "Approved", class: "bg-green-500/10 text-green-600" },
  rejected: { label: "Rejected", class: "bg-red-500/10 text-red-600" },
} as const;

const itemSchema = z.object({
  name: z.string().min(1, "Required"),
  quantity: z.coerce.number().min(0.01, "Required"),
  unit: z.string().min(1, "Required"),
  ratePerUnit: z.coerce.number().min(0, "Required"),
  totalAmount: z.coerce.number().min(0),
});

const schema = z.object({
  siteId: z.string().min(1, "Site required"),
  supplierId: z.string().min(1, "Supplier required"),
  deliveryDate: z.string().min(1, "Date required"),
  invoiceNumber: z.string().optional(),
  vehicleNumber: z.string().optional(),
  notes: z.string().optional(),
  items: z.array(itemSchema).min(1, "Add at least one item"),
});
type MaterialForm = z.infer<typeof schema>;

export default function Materials() {
  const navigate = useNavigate();
  const materials = useQuery(api.materials.list, {});
  const sites = useQuery(api.sites.list, {});
  const suppliers = useQuery(api.suppliers.list, {});
  const createMaterial = useMutation(api.materials.create);
  const approveMaterial = useMutation(api.materials.approve);
  const rejectMaterial = useMutation(api.materials.reject);
  const removeMaterial = useMutation(api.materials.remove);

  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterSiteId, setFilterSiteId] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [rejectDialogId, setRejectDialogId] = useState<string | null>(null);
  const [rejectNotes, setRejectNotes] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((m) => m._id)));
    }
  }
  function clearSelection() { setSelectedIds(new Set()); }

  async function handleBulkDelete() {
    setBulkDeleting(true);
    try {
      await Promise.all([...selectedIds].map((id) => removeMaterial({ id: id as Id<"materials"> })));
      toast.success(`Deleted ${selectedIds.size} material entr${selectedIds.size !== 1 ? "ies" : "y"}`);
      clearSelection();
    } catch { toast.error("Some deletes failed"); }
    finally { setBulkDeleting(false); }
  }

  const form = useForm<MaterialForm>({
    resolver: zodResolver(schema),
    defaultValues: {
      deliveryDate: new Date().toISOString().split("T")[0],
      items: [{ name: "", quantity: 0, unit: "nos", ratePerUnit: 0, totalAmount: 0 }],
    },
  });

  const { fields, append, remove: removeItem } = useFieldArray({
    control: form.control,
    name: "items",
  });

  const filtered = (materials ?? []).filter((m) => {
    const q = search.toLowerCase();
    const matchSearch =
      (m.siteName ?? "").toLowerCase().includes(q) ||
      (m.supplierName ?? "").toLowerCase().includes(q) ||
      (m.invoiceNumber ?? "").toLowerCase().includes(q) ||
      (m.vehicleNumber ?? "").toLowerCase().includes(q);
    const matchStatus = filterStatus === "all" || m.status === filterStatus;
    const matchSite = filterSiteId === "all" || m.siteId === filterSiteId;
    return matchSearch && matchStatus && matchSite;
  });

  const totalValue = filtered.reduce((s, m) => s + m.totalAmount, 0);
  const pendingCount = (materials ?? []).filter((m) => m.status === "pending").length;
  const approvedCount = (materials ?? []).filter((m) => m.status === "approved").length;

  // Auto-calculate total for each item row
  function recalcItem(index: number) {
    const qty = form.getValues(`items.${index}.quantity`);
    const rate = form.getValues(`items.${index}.ratePerUnit`);
    form.setValue(`items.${index}.totalAmount`, qty * rate);
  }

  async function onSubmit(data: MaterialForm) {
    try {
      await createMaterial({
        siteId: data.siteId as Id<"sites">,
        supplierId: data.supplierId as Id<"suppliers">,
        deliveryDate: data.deliveryDate,
        invoiceNumber: data.invoiceNumber || undefined,
        vehicleNumber: data.vehicleNumber || undefined,
        notes: data.notes || undefined,
        items: data.items.map((item) => ({
          name: item.name,
          quantity: item.quantity,
          unit: item.unit,
          ratePerUnit: item.ratePerUnit,
          totalAmount: item.totalAmount,
        })),
      });
      toast.success("Material delivery entry created");
      setDialogOpen(false);
      form.reset({
        deliveryDate: new Date().toISOString().split("T")[0],
        items: [{ name: "", quantity: 0, unit: "nos", ratePerUnit: 0, totalAmount: 0 }],
      });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Materials & Delivery</h1>
          <p className="text-muted-foreground text-sm">
            {materials ? `${materials.length} entries · ${pendingCount} pending approval · ${approvedCount} approved` : "Loading..."}
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> New Delivery Entry
        </Button>
      </div>

      {/* Summary cards */}
      {materials && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total Entries", value: materials.length, color: "text-foreground" },
            { label: "Pending Approval", value: pendingCount, color: "text-yellow-500" },
            { label: "Approved", value: approvedCount, color: "text-green-500" },
            {
              label: "Total Value",
              value: `₹${(materials.reduce((s, m) => s + m.totalAmount, 0) / 100000).toFixed(2)}L`,
              color: "text-orange-500",
            },
          ].map((s) => (
            <Card key={s.label} className="py-3">
              <CardContent className="px-4 py-0">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search site, supplier, invoice, vehicle..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-40 cursor-pointer">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterSiteId} onValueChange={setFilterSiteId}>
          <SelectTrigger className="w-full sm:w-48 cursor-pointer">
            <SelectValue placeholder="All Sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk delete bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        itemLabel="material entry"
        onDelete={handleBulkDelete}
        onClear={clearSelection}
      />

      {/* Table */}
      {!materials ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Package /></EmptyMedia>
            <EmptyTitle>No delivery entries found</EmptyTitle>
            <EmptyDescription>Log material deliveries to track site costs and supplier bills</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={() => setDialogOpen(true)} className="cursor-pointer">New Delivery Entry</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox
                      checked={filtered.length > 0 && selectedIds.size === filtered.length}
                      indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length}
                      onChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Delivery</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Site</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Supplier</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Items</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Amount</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((m) => {
                  const cfg = STATUS_CONFIG[m.status as keyof typeof STATUS_CONFIG];
                  return (
                    <tr key={m._id} className="hover:bg-muted/30 cursor-pointer" onClick={() => navigate(`/materials/${m._id}`)}>
                      <td className="px-4 py-3 w-10" onClick={(e) => e.stopPropagation()}>
                        <BulkCheckbox
                          checked={selectedIds.has(m._id)}
                          onChange={() => toggleSelect(m._id)}
                        />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                            <Truck className="w-4 h-4 text-orange-500" />
                          </div>
                          <div>
                            <p className="font-medium">{m.deliveryDate}</p>
                            <p className="text-xs text-muted-foreground">
                              {m.invoiceNumber ? `Inv: ${m.invoiceNumber}` : "No invoice"}
                              {m.vehicleNumber ? ` · ${m.vehicleNumber}` : ""}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell text-muted-foreground text-xs">{m.siteName ?? "—"}</td>
                      <td className="px-4 py-3 hidden md:table-cell text-muted-foreground text-xs">{m.supplierName ?? "—"}</td>
                      <td className="px-4 py-3 hidden lg:table-cell text-xs text-muted-foreground">
                        {m.items.length} item{m.items.length !== 1 ? "s" : ""}
                        <span className="ml-1 text-foreground/60">({m.items.map((i) => i.name).join(", ").slice(0, 30)}{m.items.map((i) => i.name).join(", ").length > 30 ? "…" : ""})</span>
                      </td>
                      <td className="px-4 py-3 text-right font-semibold">₹{m.totalAmount.toLocaleString("en-IN")}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cfg?.class ?? ""}`}>
                          {cfg?.label ?? m.status}
                        </span>
                      </td>
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          {m.status === "pending" && (
                            <>
                              <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-green-600 hover:text-green-600"
                                title="Approve"
                                onClick={async () => {
                                  try { await approveMaterial({ id: m._id as Id<"materials"> }); toast.success("Approved"); }
                                  catch { toast.error("Failed"); }
                                }}>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                              </Button>
                              <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-red-500 hover:text-red-500"
                                title="Reject"
                                onClick={() => { setRejectDialogId(m._id); setRejectNotes(""); }}>
                                <XCircle className="w-3.5 h-3.5" />
                              </Button>
                            </>
                          )}
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"
                            onClick={() => navigate(`/materials/${m._id}`)}>
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(m._id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 bg-muted/30 border-t border-border flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{filtered.length} entries</span>
            <span className="font-semibold">Total: ₹{totalValue.toLocaleString("en-IN")}</span>
          </div>
        </div>
      )}

      {/* New Delivery Entry Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Material Delivery Entry</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              {/* Header fields */}
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="siteId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Site *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger></FormControl>
                      <SelectContent>{sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="supplierId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supplier *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select supplier" /></SelectTrigger></FormControl>
                      <SelectContent>{suppliers?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="deliveryDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Delivery Date *</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="invoiceNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice / Bill No.</FormLabel>
                    <FormControl><Input placeholder="INV-001" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="vehicleNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vehicle Number</FormLabel>
                    <FormControl><Input placeholder="MH 01 AB 1234" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="notes" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl><Input placeholder="Any remarks..." {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Items table */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-sm font-semibold">Material Items *</Label>
                  <Button type="button" size="sm" variant="secondary" className="cursor-pointer"
                    onClick={() => append({ name: "", quantity: 0, unit: "nos", ratePerUnit: 0, totalAmount: 0 })}>
                    <PlusCircle className="w-3.5 h-3.5 mr-1" /> Add Item
                  </Button>
                </div>
                <div className="rounded-lg border border-border overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground">Item Name</th>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground w-20">Qty</th>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground w-24">Unit</th>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground w-28">Rate (₹)</th>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground w-28">Total (₹)</th>
                        <th className="w-10" />
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {fields.map((field, index) => (
                        <tr key={field.id}>
                          <td className="px-2 py-2">
                            <FormField control={form.control} name={`items.${index}.name`} render={({ field: f }) => (
                              <FormItem className="m-0">
                                <FormControl><Input placeholder="Cement / Steel / Sand..." {...f} className="h-8 text-xs" /></FormControl>
                                <FormMessage />
                              </FormItem>
                            )} />
                          </td>
                          <td className="px-2 py-2">
                            <FormField control={form.control} name={`items.${index}.quantity`} render={({ field: f }) => (
                              <FormItem className="m-0">
                                <FormControl>
                                  <Input type="number" step="0.01" {...f}
                                    onChange={(e) => { f.onChange(e); setTimeout(() => recalcItem(index), 0); }}
                                    className="h-8 text-xs" />
                                </FormControl>
                              </FormItem>
                            )} />
                          </td>
                          <td className="px-2 py-2">
                            <FormField control={form.control} name={`items.${index}.unit`} render={({ field: f }) => (
                              <FormItem className="m-0">
                                <Select onValueChange={f.onChange} value={f.value}>
                                  <FormControl>
                                    <SelectTrigger className="h-8 text-xs cursor-pointer"><SelectValue /></SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {["nos", "bags", "MT", "kg", "cft", "sqft", "rft", "ltr", "cum", "set"].map((u) => (
                                      <SelectItem key={u} value={u}>{u}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </FormItem>
                            )} />
                          </td>
                          <td className="px-2 py-2">
                            <FormField control={form.control} name={`items.${index}.ratePerUnit`} render={({ field: f }) => (
                              <FormItem className="m-0">
                                <FormControl>
                                  <Input type="number" step="0.01" {...f}
                                    onChange={(e) => { f.onChange(e); setTimeout(() => recalcItem(index), 0); }}
                                    className="h-8 text-xs" />
                                </FormControl>
                              </FormItem>
                            )} />
                          </td>
                          <td className="px-2 py-2">
                            <FormField control={form.control} name={`items.${index}.totalAmount`} render={({ field: f }) => (
                              <FormItem className="m-0">
                                <FormControl>
                                  <Input type="number" step="0.01" {...f} className="h-8 text-xs bg-muted/30" readOnly />
                                </FormControl>
                              </FormItem>
                            )} />
                          </td>
                          <td className="px-2 py-2">
                            {fields.length > 1 && (
                              <Button type="button" size="icon" variant="ghost"
                                className="w-7 h-7 cursor-pointer text-destructive hover:text-destructive"
                                onClick={() => removeItem(index)}>
                                <MinusCircle className="w-3.5 h-3.5" />
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-muted/30 border-t border-border">
                      <tr>
                        <td colSpan={4} className="px-3 py-2 text-right text-sm font-semibold text-muted-foreground">Grand Total:</td>
                        <td className="px-3 py-2 font-bold text-sm">
                          ₹{form.watch("items").reduce((s, i) => s + (i.totalAmount || 0), 0).toLocaleString("en-IN")}
                        </td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">Save Entry</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={!!rejectDialogId} onOpenChange={() => setRejectDialogId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Reject Delivery</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label>Reason (optional)</Label>
            <Textarea
              placeholder="Reason for rejection..."
              value={rejectNotes}
              onChange={(e) => setRejectNotes(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setRejectDialogId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!rejectDialogId) return;
              try {
                await rejectMaterial({ id: rejectDialogId as Id<"materials">, notes: rejectNotes || undefined });
                toast.success("Delivery rejected");
              } catch { toast.error("Failed"); }
              setRejectDialogId(null);
            }}>Reject</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Delivery Entry</DialogTitle></DialogHeader>
          <p className="text-muted-foreground text-sm">This will permanently delete this delivery record. This cannot be undone.</p>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteId) return;
              try { await removeMaterial({ id: deleteId as Id<"materials"> }); toast.success("Deleted"); }
              catch { toast.error("Failed"); }
              setDeleteId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
