import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { toast } from "sonner";
import { useRef, useState } from "react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  ArrowLeft, MapPin, Building2, Truck, FileText, CalendarDays,
  CheckCircle2, XCircle, User, Upload, Trash2, ImageIcon, FileIcon, ExternalLink,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const STATUS_CONFIG = {
  pending: { label: "Pending Approval", class: "bg-yellow-500/10 text-yellow-600 border border-yellow-200" },
  approved: { label: "Approved", class: "bg-green-500/10 text-green-600 border border-green-200" },
  rejected: { label: "Rejected", class: "bg-red-500/10 text-red-600 border border-red-200" },
} as const;

export default function MaterialDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const material = useQuery(
    api.materials.get,
    id ? { id: id as Id<"materials"> } : "skip"
  );
  const approveMaterial = useMutation(api.materials.approve);
  const rejectMaterial = useMutation(api.materials.reject);
  const generateUploadUrl = useMutation(api.materials.generateUploadUrl);
  const addBillFiles = useMutation(api.materials.addBillFiles);
  const removeBillFile = useMutation(api.materials.removeBillFile);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length || !id) return;
    setUploading(true);
    try {
      const uploaded: { storageId: Id<"_storage">; name: string; type: string }[] = [];
      for (const file of files) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });
        const { storageId } = await result.json() as { storageId: Id<"_storage"> };
        uploaded.push({ storageId, name: file.name, type: file.type });
      }
      await addBillFiles({ id: id as Id<"materials">, files: uploaded });
      toast.success(`${uploaded.length} file(s) uploaded`);
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  if (material === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-2 gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!material) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        <p>Material entry not found.</p>
        <Button className="mt-4 cursor-pointer" onClick={() => navigate("/materials")}>Back to Materials</Button>
      </div>
    );
  }

  const cfg = STATUS_CONFIG[material.status as keyof typeof STATUS_CONFIG];
  const billFiles = material.billFilesWithUrls ?? [];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4 flex-wrap">
        <Button variant="ghost" size="icon" className="cursor-pointer mt-1" onClick={() => navigate("/materials")}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center flex-shrink-0">
              <Truck className="w-6 h-6 text-orange-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Delivery — {material.deliveryDate}</h1>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${cfg?.class ?? ""}`}>
                  {cfg?.label ?? material.status}
                </span>
                {material.invoiceNumber && (
                  <span className="text-muted-foreground text-sm">Invoice: {material.invoiceNumber}</span>
                )}
                {material.vehicleNumber && (
                  <span className="text-muted-foreground text-sm">Vehicle: {material.vehicleNumber}</span>
                )}
              </div>
            </div>
          </div>
        </div>
        {material.status === "pending" && (
          <div className="flex gap-2">
            <Button variant="secondary" className="cursor-pointer text-red-600 hover:text-red-600"
              onClick={async () => {
                try { await rejectMaterial({ id: material._id as Id<"materials"> }); toast.success("Rejected"); navigate("/materials"); }
                catch { toast.error("Failed"); }
              }}>
              <XCircle className="w-4 h-4 mr-1" /> Reject
            </Button>
            <Button className="cursor-pointer"
              onClick={async () => {
                try { await approveMaterial({ id: material._id as Id<"materials"> }); toast.success("Approved!"); }
                catch { toast.error("Failed"); }
              }}>
              <CheckCircle2 className="w-4 h-4 mr-1" /> Approve
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Info */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">Delivery Info</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {material.site && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{material.site.name} — {material.site.city}</span>
                </div>
              )}
              {material.supplier && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{material.supplier.name}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span>Delivery Date: {material.deliveryDate}</span>
              </div>
              {material.invoiceNumber && (
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>Invoice: {material.invoiceNumber}</span>
                </div>
              )}
              {material.vehicleNumber && (
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>Vehicle: {material.vehicleNumber}</span>
                </div>
              )}
              {material.enteredByUser && (
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>Entered by: {material.enteredByUser.name ?? material.enteredByUser.email}</span>
                </div>
              )}
              {material.approvedByUser && (
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>
                    {material.status === "approved" ? "Approved" : "Rejected"} by: {material.approvedByUser.name ?? material.approvedByUser.email}
                  </span>
                </div>
              )}
              {material.notes && (
                <div className="pt-2 border-t border-border">
                  <p className="text-muted-foreground text-xs mb-1">Notes</p>
                  <p>{material.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Total */}
          <Card className="border-orange-200 bg-orange-500/5">
            <CardContent className="px-4 py-4 flex items-center justify-between">
              <span className="text-muted-foreground text-sm">Total Amount</span>
              <span className="text-2xl font-bold text-orange-600">₹{material.totalAmount.toLocaleString("en-IN")}</span>
            </CardContent>
          </Card>

          {/* Bill / Challan Files */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Bill / Challan Files</CardTitle>
                <Button
                  size="sm"
                  variant="secondary"
                  className="cursor-pointer h-7 text-xs"
                  disabled={uploading}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-3.5 h-3.5 mr-1" />
                  {uploading ? "Uploading..." : "Upload"}
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.pdf"
                  multiple
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {billFiles.length === 0 ? (
                <div
                  className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-orange-400 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">Click to upload bill photo or PDF</p>
                  <p className="text-xs text-muted-foreground mt-1">JPG, PNG, PDF supported</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {billFiles.map((f) => {
                    const isImage = f.type.startsWith("image/");
                    const isPdf = f.type === "application/pdf";
                    return (
                      <div key={f.storageId} className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted/30">
                        {isImage ? (
                          <button
                            className="w-10 h-10 rounded overflow-hidden flex-shrink-0 cursor-pointer"
                            onClick={() => setPreviewUrl(f.url ?? null)}
                          >
                            <img src={f.url ?? ""} alt={f.name} className="w-full h-full object-cover" />
                          </button>
                        ) : (
                          <div className="w-10 h-10 rounded bg-red-500/10 flex items-center justify-center flex-shrink-0">
                            {isPdf ? <FileText className="w-5 h-5 text-red-500" /> : <FileIcon className="w-5 h-5 text-muted-foreground" />}
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium truncate">{f.name}</p>
                          <p className="text-xs text-muted-foreground">{f.type}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          {f.url && (
                            <a
                              href={f.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 flex items-center justify-center rounded hover:bg-muted cursor-pointer"
                              title="Open"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            className="w-7 h-7 cursor-pointer text-destructive hover:text-destructive"
                            title="Delete"
                            onClick={async () => {
                              try {
                                await removeBillFile({
                                  id: material._id as Id<"materials">,
                                  storageId: f.storageId as Id<"_storage">,
                                });
                                toast.success("File deleted");
                              } catch {
                                toast.error("Failed to delete");
                              }
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                  <button
                    className="w-full text-xs text-muted-foreground border border-dashed border-border rounded-lg p-2 hover:border-orange-400 cursor-pointer transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    + Add more files
                  </button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Items table */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">
                Material Items ({material.items.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">#</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Item</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Qty</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Unit</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Rate (₹)</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Total (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {material.items.map((item, i) => (
                      <tr key={i} className="hover:bg-muted/20">
                        <td className="px-4 py-3 text-muted-foreground">{i + 1}</td>
                        <td className="px-4 py-3 font-medium">{item.name}</td>
                        <td className="px-4 py-3 text-right">{item.quantity}</td>
                        <td className="px-4 py-3 text-muted-foreground">{item.unit}</td>
                        <td className="px-4 py-3 text-right">₹{item.ratePerUnit.toLocaleString("en-IN")}</td>
                        <td className="px-4 py-3 text-right font-semibold">₹{item.totalAmount.toLocaleString("en-IN")}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-muted/30 border-t border-border">
                    <tr>
                      <td colSpan={5} className="px-4 py-3 text-right font-semibold">Grand Total</td>
                      <td className="px-4 py-3 text-right font-bold text-orange-600">
                        ₹{material.totalAmount.toLocaleString("en-IN")}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Image grid for quick preview of uploaded photos */}
          {billFiles.filter((f) => f.type.startsWith("image/")).length > 0 && (
            <Card className="mt-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" /> Bill / Challan Photos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {billFiles
                    .filter((f) => f.type.startsWith("image/"))
                    .map((f) => (
                      <button
                        key={f.storageId}
                        className="relative aspect-video rounded-lg overflow-hidden border border-border hover:opacity-90 cursor-pointer"
                        onClick={() => setPreviewUrl(f.url ?? null)}
                      >
                        <img src={f.url ?? ""} alt={f.name} className="w-full h-full object-cover" />
                      </button>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Lightbox */}
      {previewUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setPreviewUrl(null)}
        >
          <img
            src={previewUrl}
            alt="Preview"
            className="max-w-full max-h-full rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            className="absolute top-4 right-4 text-white text-2xl font-bold"
            onClick={() => setPreviewUrl(null)}
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
