import { useParams, Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  ArrowLeft, MapPin, Building2, Users, ClipboardList, Package, FileText,
  Calendar, User, AlertCircle, Plus, ShieldCheck, Pencil, Trash2, Phone, Clock,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { useState } from "react";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  planning: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  on_hold: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  completed: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
  draft: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  amended: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

function fmt(amount: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}

// Labour form schema
const labourSchema = z.object({
  name: z.string().min(1, "Naam zaroori hai"),
  mobile: z.string().optional(),
  aadhaarNumber: z.string().optional(),
  designation: z.string().optional(),
  dailyRate: z.coerce.number().min(1, "Daily rate zaroori hai"),
  joinDate: z.string().optional(),
  isSafetySupervisor: z.boolean().optional(),
  isSiteSupervisor: z.boolean().optional(),
  isSiteIncharge: z.boolean().optional(),
  workerCode: z.string().optional(),
});
type LabourForm = z.infer<typeof labourSchema>;

// GPS Geofence Tab component
function GPSGeofenceTab({ siteId, site }: { siteId: Id<"sites">; site: { latitude?: number; longitude?: number; geofenceRadius?: number; shiftStartTime?: string; shiftEndTime?: string; graceMinutes?: number; name: string } }) {
  const updateSiteGPS = useMutation(api.geofencing.updateSiteGPS);
  const updateShiftTimings = useMutation(api.geofencing.updateShiftTimings);
  const locationStatus = useQuery(api.geofencing.getSiteLocationStatus, { siteId });
  const [lat, setLat] = useState(site.latitude?.toString() ?? "");
  const [lng, setLng] = useState(site.longitude?.toString() ?? "");
  const [radius, setRadius] = useState(site.geofenceRadius?.toString() ?? "200");
  const [shiftStart, setShiftStart] = useState(site.shiftStartTime ?? "09:00");
  const [shiftEnd, setShiftEnd] = useState(site.shiftEndTime ?? "18:00");
  const [grace, setGrace] = useState(site.graceMinutes?.toString() ?? "15");
  const [saving, setSaving] = useState(false);
  const [savingShift, setSavingShift] = useState(false);

  const handleSaveGPS = async () => {
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    const geofenceRadius = parseInt(radius) || 200;

    if (isNaN(latitude) || isNaN(longitude)) {
      toast.error("Sahi latitude/longitude daalo");
      return;
    }
    setSaving(true);
    try {
      await updateSiteGPS({ siteId, latitude, longitude, geofenceRadius });
      toast.success("GPS coordinates save ho gaye!");
    } catch {
      toast.error("Save nahi ho paya");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveShiftTimings = async () => {
    setSavingShift(true);
    try {
      await updateShiftTimings({
        siteId,
        shiftStartTime: shiftStart,
        shiftEndTime: shiftEnd,
        graceMinutes: parseInt(grace) || 15,
      });
      toast.success("Shift timings save ho gaye!");
    } catch {
      toast.error("Save nahi ho paya");
    } finally {
      setSavingShift(false);
    }
  };

  const handleGetCurrentLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("GPS not available");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude.toFixed(6));
        setLng(pos.coords.longitude.toFixed(6));
        toast.success("Current location detect ho gayi!");
      },
      () => toast.error("Location detect nahi ho paya"),
      { enableHighAccuracy: true }
    );
  };

  return (
    <div className="space-y-6">
      {/* GPS Settings */}
      <div className="border border-border rounded-lg p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" /> Site Location (GPS)
        </h3>
        <p className="text-sm text-muted-foreground">
          Site ka GPS location set karo. Labour check-in kare tab pata chalega ki site pe hai ya nahi.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground">Latitude</label>
            <Input placeholder="18.5204" value={lat} onChange={(e) => setLat(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Longitude</label>
            <Input placeholder="73.8567" value={lng} onChange={(e) => setLng(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Geofence Radius (meters)</label>
            <Input type="number" placeholder="200" value={radius} onChange={(e) => setRadius(e.target.value)} />
          </div>
        </div>

        <div className="flex gap-3">
          <Button variant="secondary" onClick={handleGetCurrentLocation} className="cursor-pointer">
            <MapPin className="w-4 h-4 mr-1" /> Current Location Use Karo
          </Button>
          <Button onClick={handleSaveGPS} disabled={saving} className="cursor-pointer">
            {saving ? "Saving..." : "Save GPS Location"}
          </Button>
        </div>

        {site.latitude && site.longitude && (
          <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-3 text-sm">
            <span className="font-medium text-green-800 dark:text-green-300">Set hai:</span>{" "}
            <span className="text-green-700 dark:text-green-400">{site.latitude}, {site.longitude}</span>
            <span className="text-green-600 dark:text-green-500 ml-2">· Radius: {site.geofenceRadius ?? 200}m</span>
          </div>
        )}
      </div>

      {/* Shift Timings */}
      <div className="border border-border rounded-lg p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2">
          <Clock className="w-4 h-4 text-primary" /> Shift Timings
        </h3>
        <p className="text-sm text-muted-foreground">
          Site ka IN/OUT time set karo. Labour late aaye ya jaldi jaaye toh system automatically detect karega.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground">Shift Start (IN Time)</label>
            <Input type="time" value={shiftStart} onChange={(e) => setShiftStart(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Shift End (OUT Time)</label>
            <Input type="time" value={shiftEnd} onChange={(e) => setShiftEnd(e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Grace Period (minutes)</label>
            <Input type="number" placeholder="15" value={grace} onChange={(e) => setGrace(e.target.value)} />
          </div>
        </div>

        <Button onClick={handleSaveShiftTimings} disabled={savingShift} className="cursor-pointer">
          {savingShift ? "Saving..." : "Save Shift Timings"}
        </Button>

        {site.shiftStartTime && (
          <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-3 text-sm">
            <span className="font-medium text-blue-800 dark:text-blue-300">Current Shift:</span>{" "}
            <span className="text-blue-700 dark:text-blue-400">{site.shiftStartTime} - {site.shiftEndTime}</span>
            <span className="text-blue-600 dark:text-blue-500 ml-2">· Grace: {site.graceMinutes ?? 15} min</span>
          </div>
        )}
      </div>

      {/* Live Location Status with IN/OUT */}
      <div className="border border-border rounded-lg p-5 space-y-4">
        <h3 className="font-semibold flex items-center gap-2">
          <Users className="w-4 h-4 text-primary" /> Aaj Ka IN/OUT Status
        </h3>
        <p className="text-sm text-muted-foreground">Labour ne aaj IN/OUT punch kiya ya nahi, late hai ya on time.</p>

        {locationStatus === undefined ? (
          <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : locationStatus.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">Is site pe koi active labour nahi hai</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-muted-foreground">
                  <th className="text-left py-2 font-medium">Labour</th>
                  <th className="text-center py-2 font-medium">IN Time</th>
                  <th className="text-center py-2 font-medium">OUT Time</th>
                  <th className="text-center py-2 font-medium">Status</th>
                  <th className="text-center py-2 font-medium">Location</th>
                </tr>
              </thead>
              <tbody>
                {locationStatus.map(l => (
                  <tr key={l.labourerId} className="border-b last:border-0">
                    <td className="py-2">
                      <div>
                        <p className="font-medium text-foreground">{l.name}</p>
                        <p className="text-xs text-muted-foreground">{l.designation}</p>
                      </div>
                    </td>
                    <td className="py-2 text-center">
                      {l.inTime ? (
                        <span className="text-green-700 dark:text-green-400 font-medium">
                          {new Date(l.inTime).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="py-2 text-center">
                      {l.outTime ? (
                        <span className="text-red-700 dark:text-red-400 font-medium">
                          {new Date(l.outTime).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="py-2 text-center">
                      {l.inTime === null ? (
                        <Badge variant="secondary" className="text-xs">Not Checked In</Badge>
                      ) : l.isLate ? (
                        <Badge className="text-xs bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">{l.minutesLate} min late</Badge>
                      ) : (
                        <Badge className="text-xs bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">On Time</Badge>
                      )}
                    </td>
                    <td className="py-2 text-center">
                      {l.isWithinGeofence === null ? (
                        <span className="text-muted-foreground text-xs">—</span>
                      ) : l.isWithinGeofence ? (
                        <Badge className="text-xs bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">On Site</Badge>
                      ) : (
                        <Badge className="text-xs bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">{l.distanceFromSite}m away</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

type Tab = "overview" | "labour" | "gps";

export default function SiteDetail() {
  const { id } = useParams<{ id: string }>();
  const data = useQuery(api.sites.getDetail, id ? { id: id as Id<"sites"> } : "skip");
  const labourers = useQuery(api.labourers.list, {});
  const createLabourer = useMutation(api.labourers.create);
  const updateLabourer = useMutation(api.labourers.update);
  const removeLabourer = useMutation(api.labourers.remove);

  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [labourDialogOpen, setLabourDialogOpen] = useState(false);
  const [editLabourId, setEditLabourId] = useState<string | null>(null);
  const [deleteLabourId, setDeleteLabourId] = useState<string | null>(null);

  const form = useForm<LabourForm>({
    resolver: zodResolver(labourSchema),
    defaultValues: { name: "", dailyRate: 0 },
  });

  // Only labourers belonging to this site
  const siteLabourers = (labourers ?? []).filter((l) => l.siteId === id);
  const activeLabourers = siteLabourers.filter((l) => l.isActive);

  function openAddLabour() {
    setEditLabourId(null);
    form.reset({ name: "", dailyRate: 0 });
    setLabourDialogOpen(true);
  }

  function openEditLabour(l: (typeof siteLabourers)[number]) {
    setEditLabourId(l._id);
    form.reset({
      name: l.name,
      mobile: l.mobile ?? "",
      aadhaarNumber: l.aadhaarNumber ?? "",
      designation: l.designation ?? "",
      dailyRate: l.dailyRate,
      joinDate: l.joinDate ?? "",
      isSafetySupervisor: l.isSafetySupervisor ?? false,
      isSiteSupervisor: l.isSiteSupervisor ?? false,
      isSiteIncharge: (l as typeof l & { isSiteIncharge?: boolean }).isSiteIncharge ?? false,
      workerCode: l.workerCode ?? "",
    });
    setLabourDialogOpen(true);
  }

  async function onLabourSubmit(formData: LabourForm) {
    if (!id) return;
    try {
      const payload = {
        ...formData,
        siteId: id as Id<"sites">,
        contractorId: undefined,
        mobile: formData.mobile || undefined,
        designation: formData.designation || undefined,
        joinDate: formData.joinDate || undefined,
      };
      if (editLabourId) {
        await updateLabourer({ id: editLabourId as Id<"labourers">, ...payload });
        toast.success("Labour update ho gaya");
      } else {
        await createLabourer(payload);
        toast.success("Labour add ho gaya!");
      }
      setLabourDialogOpen(false);
    } catch {
      toast.error("Kuch gadbad ho gayi");
    }
  }

  if (data === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6 text-center space-y-2">
        <AlertCircle className="w-8 h-8 mx-auto text-muted-foreground" />
        <p className="text-muted-foreground">Site not found</p>
        <Link to="/sites"><Button variant="ghost" size="sm">Back to Sites</Button></Link>
      </div>
    );
  }

  const { site, company, client, siteIncharge, workOrderCount, totalWorkOrderValue, materialCount, totalMaterialValue, pendingMaterialCount, recentWorkOrders } = data;

  return (
    <div className="p-6 space-y-6">
      <Link to="/sites">
        <Button variant="ghost" size="sm" className="cursor-pointer gap-1 -ml-2">
          <ArrowLeft className="w-4 h-4" /> Sites
        </Button>
      </Link>

      {/* Hero Card */}
      <div className="rounded-xl bg-[oklch(0.14_0.025_250)] text-white p-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">{site.name}</h1>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-white/70">
              {company && (
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5" /> {company.name}
                </span>
              )}
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" /> {site.city}
              </span>
              {site.address && <span>{site.address}</span>}
              {siteIncharge && (
                <span className="flex items-center gap-1">
                  <User className="w-3.5 h-3.5" /> {siteIncharge.name ?? siteIncharge.email}
                </span>
              )}
            </div>
            {site.description && (
              <p className="mt-2 text-sm text-white/60">{site.description}</p>
            )}
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize self-start ${STATUS_COLORS[site.status]}`}>
            {site.status.replace("_", " ")}
          </span>
        </div>
        {(site.startDate || site.endDate) && (
          <div className="mt-4 flex items-center gap-2 text-sm text-white/60">
            <Calendar className="w-3.5 h-3.5" />
            {site.startDate ?? "—"} → {site.endDate ?? "Ongoing"}
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button
          onClick={() => setActiveTab("labour")}
          className="border border-border rounded-lg p-4 hover:bg-accent/50 transition-colors cursor-pointer text-left"
        >
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <Users className="w-3.5 h-3.5" /> Labour
          </div>
          <div className="text-2xl font-bold">{siteLabourers.length}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{activeLabourers.length} active</div>
        </button>
        <Link to={`/work-orders`}>
          <div className="border border-border rounded-lg p-4 hover:bg-accent/50 transition-colors cursor-pointer">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <ClipboardList className="w-3.5 h-3.5" /> Work Orders
            </div>
            <div className="text-2xl font-bold">{workOrderCount}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{fmt(totalWorkOrderValue)} total</div>
          </div>
        </Link>
        <Link to={`/materials`}>
          <div className="border border-border rounded-lg p-4 hover:bg-accent/50 transition-colors cursor-pointer">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Package className="w-3.5 h-3.5" /> Materials
            </div>
            <div className="text-2xl font-bold">{materialCount}</div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {fmt(totalMaterialValue)} · {pendingMaterialCount} pending
            </div>
          </div>
        </Link>
        <Link to={`/invoices`}>
          <div className="border border-border rounded-lg p-4 hover:bg-accent/50 transition-colors cursor-pointer">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <FileText className="w-3.5 h-3.5" /> Invoices
            </div>
            <div className="text-2xl font-bold">—</div>
            <div className="text-xs text-muted-foreground mt-0.5">View all</div>
          </div>
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        {(["overview", "labour", "gps"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium capitalize cursor-pointer transition-colors border-b-2 -mb-px
              ${activeTab === tab
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
          >
            {tab === "labour" ? `Labour (${siteLabourers.length})` : tab === "gps" ? "GPS Geofence" : "Overview"}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="border border-border rounded-lg p-4 space-y-3">
            <h3 className="font-semibold text-sm">Site Information</h3>
            {[
              { label: "Company", value: company?.name ?? "—" },
              { label: "Client", value: client?.name ?? "Not assigned" },
              { label: "Site Incharge", value: siteIncharge?.name ?? siteIncharge?.email ?? "Not assigned" },
              { label: "Status", value: site.status.replace("_", " ") },
              { label: "Start Date", value: site.startDate ?? "—" },
              { label: "End Date", value: site.endDate ?? "—" },
              { label: "Address", value: site.address ?? "—" },
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{row.label}</span>
                <span className="font-medium capitalize">{row.value}</span>
              </div>
            ))}
          </div>

          <div className="border border-border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">Recent Work Orders</h3>
              <Link to="/work-orders" className="text-xs text-primary cursor-pointer">View all</Link>
            </div>
            {recentWorkOrders.length === 0 ? (
              <p className="text-sm text-muted-foreground">No work orders yet</p>
            ) : (
              <div className="space-y-2">
                {recentWorkOrders.map((wo) => (
                  <div key={wo._id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div>
                      <div className="text-sm font-medium">{wo.orderNumber}</div>
                      <div className="text-xs text-muted-foreground truncate max-w-[200px]">{wo.description}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold">{fmt(wo.totalValue)}</div>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full capitalize ${STATUS_COLORS[wo.status] ?? ""}`}>
                        {wo.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Labour Tab */}
      {activeTab === "labour" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Is Site ka Labour</h3>
              <p className="text-xs text-muted-foreground">{siteLabourers.length} total · {activeLabourers.length} active</p>
            </div>
            <Button onClick={openAddLabour} className="cursor-pointer">
              <Plus className="w-4 h-4 mr-1" /> Labour Add Karo
            </Button>
          </div>

          {labourers === undefined ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
          ) : siteLabourers.length === 0 ? (
            <div className="border border-dashed border-border rounded-lg p-10 text-center space-y-3">
              <Users className="w-8 h-8 mx-auto text-muted-foreground" />
              <p className="text-muted-foreground text-sm">Is site pe abhi koi labour nahi hai</p>
              <Button onClick={openAddLabour} size="sm" className="cursor-pointer">
                <Plus className="w-4 h-4 mr-1" /> Pehla Labour Add Karo
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {siteLabourers.map((l) => (
                <div key={l._id} className="border border-border rounded-lg p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold text-sm">{l.name}</div>
                      {l.designation && <div className="text-xs text-muted-foreground">{l.designation}</div>}
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="w-7 h-7 cursor-pointer" onClick={() => openEditLabour(l)}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                      <Button size="icon" variant="ghost" className="w-7 h-7 cursor-pointer text-destructive hover:text-destructive" onClick={() => setDeleteLabourId(l._id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  {/* Role badges */}
                  <div className="flex flex-wrap gap-1">
                    {l.isActive ? (
                      <Badge className="text-[10px] px-1.5 py-0 bg-green-500/10 text-green-600 border-green-500/20">Active</Badge>
                    ) : (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-muted-foreground">Inactive</Badge>
                    )}
                    {l.isSafetySupervisor && (
                      <Badge className="text-[10px] px-1.5 py-0 bg-orange-500/10 text-orange-600 border-orange-500/20">
                        <ShieldCheck className="w-2.5 h-2.5 mr-0.5" /> Safety Sup.
                      </Badge>
                    )}
                    {l.isSiteSupervisor && (
                      <Badge className="text-[10px] px-1.5 py-0 bg-blue-500/10 text-blue-600 border-blue-500/20">
                        <Users className="w-2.5 h-2.5 mr-0.5" /> Site Sup.
                      </Badge>
                    )}
                    {(l as typeof l & { isSiteIncharge?: boolean }).isSiteIncharge && (
                      <Badge className="text-[10px] px-1.5 py-0 bg-purple-500/10 text-purple-600 border-purple-500/20">
                        Site Incharge
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t border-border">
                    <span>₹{l.dailyRate}/day</span>
                    {l.mobile && (
                      <span className="flex items-center gap-0.5">
                        <Phone className="w-3 h-3" /> {l.mobile}
                      </span>
                    )}
                    {l.workerCode && <span className="font-mono font-medium text-foreground">{l.workerCode}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* GPS Geofence Tab */}
      {activeTab === "gps" && (
        <GPSGeofenceTab siteId={id as Id<"sites">} site={site} />
      )}

      {/* Add/Edit Labour Dialog */}
      <Dialog open={labourDialogOpen} onOpenChange={setLabourDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editLabourId ? "Labour Edit Karo" : "Naya Labour Add Karo"}</DialogTitle>
            <p className="text-xs text-muted-foreground">Site: {site.name}</p>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onLabourSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Naam *</FormLabel>
                    <FormControl><Input placeholder="Ramesh Kumar" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="designation" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Designation</FormLabel>
                    <FormControl><Input placeholder="Mason / Helper / Welder" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="dailyRate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Daily Rate (₹) *</FormLabel>
                    <FormControl><Input type="number" placeholder="500" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile</FormLabel>
                    <FormControl><Input placeholder="9876543210" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="aadhaarNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aadhaar Number</FormLabel>
                    <FormControl><Input placeholder="XXXX XXXX XXXX" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="joinDate" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Join Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              {/* Safety Supervisor */}
              <FormField control={form.control} name="isSafetySupervisor" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-orange-500/30 bg-orange-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={(e) => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-orange-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <ShieldCheck className="w-4 h-4 text-orange-500" /> Safety Supervisor hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Is labour ko Safety Supervisor mark karo</p>
                  </div>
                </FormItem>
              )} />

              {/* Site Supervisor */}
              <FormField control={form.control} name="isSiteSupervisor" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-blue-500/30 bg-blue-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={(e) => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-blue-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <Users className="w-4 h-4 text-blue-500" /> Site Supervisor hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Hajri, Advance, Report karne ka portal access milega</p>
                  </div>
                </FormItem>
              )} />

              {/* Site Incharge */}
              <FormField control={form.control} name="isSiteIncharge" render={({ field }) => (
                <FormItem className="flex items-center gap-3 rounded-lg border border-purple-500/30 bg-purple-500/5 p-3">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value ?? false}
                      onChange={(e) => field.onChange(e.target.checked)}
                      className="w-4 h-4 accent-purple-500 cursor-pointer"
                    />
                  </FormControl>
                  <div>
                    <FormLabel className="cursor-pointer flex items-center gap-1.5 text-sm font-medium">
                      <ShieldCheck className="w-4 h-4 text-purple-500" /> Site Incharge hai?
                    </FormLabel>
                    <p className="text-xs text-muted-foreground">Poori site ka full management access milega</p>
                  </div>
                </FormItem>
              )} />

              {/* Worker Code */}
              <FormField control={form.control} name="workerCode" render={({ field }) => (
                <FormItem>
                  <FormLabel>Worker ID (Portal Login Code)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. S1234 (auto-generate hoga agar blank chodo)"
                      {...field}
                      onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                    />
                  </FormControl>
                  <p className="text-xs text-muted-foreground">Supervisor is code se portal mein login karega</p>
                  <FormMessage />
                </FormItem>
              )} />

              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setLabourDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editLabourId ? "Update Karo" : "Add Karo"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Labour Confirm */}
      <Dialog open={!!deleteLabourId} onOpenChange={() => setDeleteLabourId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Labour Delete Karo?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">Yeh labour record hamesha ke liye delete ho jayega.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteLabourId(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={async () => {
              if (!deleteLabourId) return;
              try {
                await removeLabourer({ id: deleteLabourId as Id<"labourers"> });
                toast.success("Labour delete ho gaya");
              } catch { toast.error("Delete nahi hua"); }
              setDeleteLabourId(null);
            }}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
