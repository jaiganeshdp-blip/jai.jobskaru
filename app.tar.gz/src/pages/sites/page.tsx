import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { Plus, Search, Eye, Pencil, Trash2, MapPin, UserPlus, HardHat, UserCheck } from "lucide-react";
import { Link } from "react-router-dom";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

// Keys are prefixed: "user:ID" for users table, "lab:ID" for labourers table
function parseKey(key: string): { type: "user" | "lab"; id: string } {
  const [type, ...rest] = key.split(":");
  return { type: type as "user" | "lab", id: rest.join(":") };
}

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  companyId: z.string().min(1, "Company is required"),
  clientId: z.string().optional(),
  city: z.string().min(1, "City is required"),
  address: z.string().optional(),
  siteInchargeKey: z.string().optional(),
  status: z.enum(["planning", "active", "on_hold", "completed"]),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  description: z.string().optional(),
});
type SiteForm = z.infer<typeof schema>;

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  planning: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  on_hold: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  completed: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
};

export default function Sites() {
  const sites = useQuery(api.sites.list, {});
  const companies = useQuery(api.companies.list, {});
  const clients = useQuery(api.clients.list, {});
  const users = useQuery(api.users.listUsers, {});
  const labourers = useQuery(api.labourers.list, {});
  const createSite = useMutation(api.sites.create);
  const updateSite = useMutation(api.sites.update);
  const removeSite = useMutation(api.sites.remove);
  const createClient = useMutation(api.clients.create);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Quick Add Client state
  const [clientDialogOpen, setClientDialogOpen] = useState(false);
  const [newClientName, setNewClientName] = useState("");
  const [newClientMobile, setNewClientMobile] = useState("");
  const [newClientCity, setNewClientCity] = useState("");
  const [addingClient, setAddingClient] = useState(false);

  // Multi-select supervisor keys (prefixed)
  const [selectedSupervisorKeys, setSelectedSupervisorKeys] = useState<string[]>([]);

  const form = useForm<SiteForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", companyId: "", city: "", status: "planning" },
  });

  // --- Eligible people ---
  // Site Incharge: users with site_incharge/super_admin role OR labourers with isSiteIncharge=true
  const inchargeUserOptions = (users ?? [])
    .filter((u) => u.role === "site_incharge" || u.role === "super_admin")
    .map((u) => ({ key: `user:${u._id}`, label: u.name ?? u.email ?? u._id, sub: u.role === "super_admin" ? "Admin" : "Site Incharge" }));

  const inchargeLabourerOptions = (labourers ?? [])
    .filter((l) => l.isSiteIncharge === true && l.isActive)
    .map((l) => ({ key: `lab:${l._id}`, label: l.name, sub: l.designation ?? "Site Incharge (Labour)" }));

  const allInchargeOptions = [...inchargeUserOptions, ...inchargeLabourerOptions];

  // Site Supervisors: users with site_supervisor/safety_supervisor role OR labourers with isSiteSupervisor/isSafetySupervisor=true
  const supervisorUserOptions = (users ?? [])
    .filter((u) => u.role === "site_supervisor" || u.role === "safety_supervisor")
    .map((u) => ({ key: `user:${u._id}`, label: u.name ?? u.email ?? u._id, sub: u.role?.replace(/_/g, " ") ?? "" }));

  const supervisorLabourerOptions = (labourers ?? [])
    .filter((l) => (l.isSiteSupervisor === true || l.isSafetySupervisor === true) && l.isActive)
    .map((l) => ({
      key: `lab:${l._id}`,
      label: l.name,
      sub: l.isSafetySupervisor ? "Safety Supervisor" : "Site Supervisor",
    }));

  const allSupervisorOptions = [...supervisorUserOptions, ...supervisorLabourerOptions];

  // Build name lookup for table display
  const userMap = Object.fromEntries((users ?? []).map((u) => [u._id, u.name ?? u.email ?? u._id]));
  const labourMap = Object.fromEntries((labourers ?? []).map((l) => [l._id, l.name]));

  function getInchargeName(site: { siteInchargeId?: string; siteInchargeLabourerId?: string }) {
    if (site.siteInchargeId) return userMap[site.siteInchargeId] ?? "—";
    if (site.siteInchargeLabourerId) return labourMap[site.siteInchargeLabourerId] ?? "—";
    return null;
  }

  function getSupervisorNames(site: { siteSupervisorIds?: string[]; siteSupervisorLabourerIds?: string[] }): string[] {
    const names: string[] = [];
    for (const id of site.siteSupervisorIds ?? []) names.push(userMap[id] ?? "—");
    for (const id of site.siteSupervisorLabourerIds ?? []) names.push(labourMap[id] ?? "—");
    return names;
  }

  const filtered = (sites ?? []).filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.city.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function toggleAll() {
    if (selectedIds.size === filtered.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(filtered.map((s) => s._id)));
  }

  function clearSelection() { setSelectedIds(new Set()); }

  function toggleSupervisorKey(key: string) {
    setSelectedSupervisorKeys((prev) =>
      prev.includes(key) ? prev.filter((x) => x !== key) : [...prev, key]
    );
  }

  function openCreate() {
    setEditId(null);
    setSelectedSupervisorKeys([]);
    form.reset({ name: "", companyId: "", city: "", status: "planning" });
    setDialogOpen(true);
  }

  function openEdit(site: (typeof filtered)[number]) {
    setEditId(site._id);
    // Rebuild supervisor keys from saved IDs
    const supKeys: string[] = [
      ...((site as { siteSupervisorIds?: string[] }).siteSupervisorIds ?? []).map((id) => `user:${id}`),
      ...((site as { siteSupervisorLabourerIds?: string[] }).siteSupervisorLabourerIds ?? []).map((id) => `lab:${id}`),
    ];
    setSelectedSupervisorKeys(supKeys);
    // Rebuild incharge key
    let inchargeKey = "";
    if ((site as { siteInchargeId?: string }).siteInchargeId) {
      inchargeKey = `user:${(site as { siteInchargeId?: string }).siteInchargeId}`;
    } else if ((site as { siteInchargeLabourerId?: string }).siteInchargeLabourerId) {
      inchargeKey = `lab:${(site as { siteInchargeLabourerId?: string }).siteInchargeLabourerId}`;
    }
    form.reset({
      name: site.name,
      companyId: site.companyId,
      clientId: site.clientId ?? "",
      city: site.city,
      address: site.address ?? "",
      siteInchargeKey: inchargeKey,
      status: site.status,
      startDate: site.startDate ?? "",
      endDate: site.endDate ?? "",
      description: site.description ?? "",
    });
    setDialogOpen(true);
  }

  async function handleAddClient() {
    if (!newClientName.trim() || !newClientMobile.trim()) {
      toast.error("Name and mobile are required");
      return;
    }
    setAddingClient(true);
    try {
      await createClient({ name: newClientName.trim(), mobile: newClientMobile.trim(), city: newClientCity.trim() || undefined });
      toast.success("Client added");
      setClientDialogOpen(false);
      setNewClientName(""); setNewClientMobile(""); setNewClientCity("");
    } catch { toast.error("Failed to add client"); }
    finally { setAddingClient(false); }
  }

  async function onSubmit(data: SiteForm) {
    try {
      // Parse incharge key
      let siteInchargeId: Id<"users"> | undefined;
      let siteInchargeLabourerId: Id<"labourers"> | undefined;
      if (data.siteInchargeKey && data.siteInchargeKey !== "none") {
        const { type, id } = parseKey(data.siteInchargeKey);
        if (type === "user") siteInchargeId = id as Id<"users">;
        else siteInchargeLabourerId = id as Id<"labourers">;
      }

      // Parse supervisor keys
      const siteSupervisorIds: Id<"users">[] = [];
      const siteSupervisorLabourerIds: Id<"labourers">[] = [];
      for (const key of selectedSupervisorKeys) {
        const { type, id } = parseKey(key);
        if (type === "user") siteSupervisorIds.push(id as Id<"users">);
        else siteSupervisorLabourerIds.push(id as Id<"labourers">);
      }

      const payload = {
        name: data.name,
        companyId: data.companyId as Id<"companies">,
        clientId: data.clientId ? (data.clientId as Id<"clients">) : undefined,
        city: data.city,
        address: data.address || undefined,
        siteInchargeId,
        siteInchargeLabourerId,
        siteSupervisorIds: siteSupervisorIds.length > 0 ? siteSupervisorIds : undefined,
        siteSupervisorLabourerIds: siteSupervisorLabourerIds.length > 0 ? siteSupervisorLabourerIds : undefined,
        status: data.status,
        startDate: data.startDate || undefined,
        endDate: data.endDate || undefined,
        description: data.description || undefined,
      };

      if (editId) {
        await updateSite({ id: editId as Id<"sites">, ...payload });
        toast.success("Site updated");
      } else {
        await createSite(payload);
        toast.success("Site added");
      }
      setDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    }
  }

  async function handleDelete(id: string) {
    try {
      await removeSite({ id: id as Id<"sites"> });
      toast.success("Site deleted");
      setDeleteConfirm(null);
    } catch { toast.error("Failed to delete"); }
  }

  const companyMap = Object.fromEntries((companies ?? []).map((c) => [c._id, c.name]));
  const statusCounts = (sites ?? []).reduce(
    (acc, s) => { acc[s.status] = (acc[s.status] ?? 0) + 1; return acc; },
    {} as Record<string, number>
  );

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Sites</h1>
          <p className="text-muted-foreground text-sm">Manage construction sites and projects</p>
        </div>
        <Button onClick={openCreate} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Site
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {(["all", "active", "planning", "on_hold", "completed"] as const).map((s) => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`px-3 py-1 rounded-full text-xs font-medium capitalize cursor-pointer transition-colors
              ${statusFilter === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
            {s === "all" ? `All (${sites?.length ?? 0})` : `${s.replace("_", " ")} (${statusCounts[s] ?? 0})`}
          </button>
        ))}
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search by name or city..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      <BulkDeleteBar
        selectedCount={selectedIds.size}
        onDelete={async () => {
          for (const id of selectedIds) await removeSite({ id: id as Id<"sites"> });
          toast.success(`Deleted ${selectedIds.size} site${selectedIds.size !== 1 ? "s" : ""}`);
          clearSelection();
        }}
        onClear={clearSelection}
        itemLabel="site"
      />

      {!sites ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><MapPin /></EmptyMedia>
            <EmptyTitle>No sites found</EmptyTitle>
            <EmptyDescription>{search || statusFilter !== "all" ? "Try adjusting your filters" : "Add your first construction site"}</EmptyDescription>
          </EmptyHeader>
          <EmptyContent><Button onClick={openCreate} size="sm" className="cursor-pointer">Add Site</Button></EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox checked={filtered.length > 0 && selectedIds.size === filtered.length}
                      indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length} onCheckedChange={toggleAll} />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Site Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Company</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">City</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Site Incharge</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden xl:table-cell">Supervisors</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((site) => {
                  const inchargeName = getInchargeName(site as { siteInchargeId?: string; siteInchargeLabourerId?: string });
                  const supervisorNames = getSupervisorNames(site as { siteSupervisorIds?: string[]; siteSupervisorLabourerIds?: string[] });
                  return (
                    <tr key={site._id} className="hover:bg-muted/30">
                      <td className="px-4 py-3 w-10" onClick={(e) => e.stopPropagation()}>
                        <BulkCheckbox checked={selectedIds.has(site._id)} onCheckedChange={() => toggleSelect(site._id)} />
                      </td>
                      <td className="px-4 py-3 font-medium">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${site.status === "active" ? "bg-green-500" : site.status === "planning" ? "bg-blue-500" : site.status === "on_hold" ? "bg-yellow-500" : "bg-gray-400"}`} />
                          <span className="truncate max-w-[160px]">{site.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{companyMap[site.companyId] ?? "—"}</td>
                      <td className="px-4 py-3 hidden sm:table-cell">{site.city}</td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        {inchargeName ? (
                          <div className="flex items-center gap-1.5">
                            <UserCheck className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                            <span className="text-sm truncate max-w-[120px]">{inchargeName}</span>
                          </div>
                        ) : <span className="text-muted-foreground text-xs">Not assigned</span>}
                      </td>
                      <td className="px-4 py-3 hidden xl:table-cell">
                        {supervisorNames.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {supervisorNames.slice(0, 2).map((name, i) => (
                              <Badge key={i} variant="secondary" className="text-xs gap-1 py-0">
                                <HardHat className="w-3 h-3" />{name}
                              </Badge>
                            ))}
                            {supervisorNames.length > 2 && <Badge variant="outline" className="text-xs py-0">+{supervisorNames.length - 2}</Badge>}
                          </div>
                        ) : <span className="text-muted-foreground text-xs">None</span>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${STATUS_COLORS[site.status]}`}>
                          {site.status.replace("_", " ")}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Link to={`/sites/${site._id}`}>
                            <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer"><Eye className="w-3.5 h-3.5" /></Button>
                          </Link>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(site)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive" onClick={() => setDeleteConfirm(site._id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Site" : "Add Site"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Site Name *</FormLabel>
                    <FormControl><Input placeholder="Tech Tower - Commercial Building" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="companyId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select company" /></SelectTrigger></FormControl>
                      <SelectContent>
                        {(companies ?? []).map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="clientId" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">No client</SelectItem>
                        {(clients ?? []).map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                        <div className="px-2 py-1.5 border-t mt-1">
                          <Button type="button" variant="ghost" size="sm"
                            className="w-full justify-start gap-2 cursor-pointer text-primary h-8"
                            onClick={() => setClientDialogOpen(true)}>
                            <UserPlus className="w-4 h-4" /> Add New Client
                          </Button>
                        </div>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="planning">Planning</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="on_hold">On Hold</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* ── Site Incharge ── users + labourers */}
                <FormField control={form.control} name="siteInchargeKey" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel className="flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-blue-500" />
                      Site Incharge
                    </FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ?? ""}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Assign site incharge..." /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">Not assigned</SelectItem>
                        {allInchargeOptions.length > 0 && (
                          <>
                            {inchargeUserOptions.length > 0 && (
                              <div className="px-2 py-1 text-xs text-muted-foreground font-medium">— Users —</div>
                            )}
                            {inchargeUserOptions.map((o) => (
                              <SelectItem key={o.key} value={o.key}>{o.label} · {o.sub}</SelectItem>
                            ))}
                            {inchargeLabourerOptions.length > 0 && (
                              <div className="px-2 py-1 text-xs text-muted-foreground font-medium border-t mt-1">— Labour (Site Incharge flag) —</div>
                            )}
                            {inchargeLabourerOptions.map((o) => (
                              <SelectItem key={o.key} value={o.key}>{o.label} · {o.sub}</SelectItem>
                            ))}
                          </>
                        )}
                        {allInchargeOptions.length === 0 && (
                          <div className="px-3 py-2 text-xs text-muted-foreground">
                            Koi eligible user/labour nahi. Labour mein &quot;Site Incharge&quot; flag ON karein.
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Puri site ka zimmedaar — attendance, expenses, reports</p>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* ── Site Supervisors ── checkboxes: users + labourers */}
                <div className="col-span-2 space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <HardHat className="w-4 h-4 text-orange-500" />
                    Site Supervisors
                  </label>
                  {allSupervisorOptions.length === 0 ? (
                    <div className="border border-dashed rounded-lg p-3 text-center text-xs text-muted-foreground space-y-1">
                      <p>Koi supervisor nahi mila.</p>
                      <p>Labour mein &quot;Site Supervisor&quot; ya &quot;Safety Supervisor&quot; flag ON karein, ya User Approvals se kisi ko approve karein.</p>
                    </div>
                  ) : (
                    <div className="border border-border rounded-lg divide-y divide-border max-h-52 overflow-y-auto">
                      {supervisorUserOptions.length > 0 && (
                        <div className="px-3 py-1.5 bg-muted/30">
                          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Users</p>
                        </div>
                      )}
                      {supervisorUserOptions.map((o) => (
                        <label key={o.key} className="flex items-center gap-2.5 cursor-pointer hover:bg-muted/40 px-3 py-2">
                          <input type="checkbox" checked={selectedSupervisorKeys.includes(o.key)}
                            onChange={() => toggleSupervisorKey(o.key)} className="accent-primary w-4 h-4 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{o.label}</p>
                            <p className="text-xs text-muted-foreground capitalize">{o.sub}</p>
                          </div>
                        </label>
                      ))}
                      {supervisorLabourerOptions.length > 0 && (
                        <div className="px-3 py-1.5 bg-muted/30">
                          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Labour</p>
                        </div>
                      )}
                      {supervisorLabourerOptions.map((o) => (
                        <label key={o.key} className="flex items-center gap-2.5 cursor-pointer hover:bg-muted/40 px-3 py-2">
                          <input type="checkbox" checked={selectedSupervisorKeys.includes(o.key)}
                            onChange={() => toggleSupervisorKey(o.key)} className="accent-primary w-4 h-4 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{o.label}</p>
                            <p className="text-xs text-muted-foreground">{o.sub}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  )}
                  {selectedSupervisorKeys.length > 0 && (
                    <p className="text-xs text-green-600 font-medium">
                      {selectedSupervisorKeys.length} supervisor{selectedSupervisorKeys.length !== 1 ? "s" : ""} selected
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">Roz ka kaam, labour, attendance dekhte hain</p>
                </div>

                <FormField control={form.control} name="city" render={({ field }) => (
                  <FormItem>
                    <FormLabel>City *</FormLabel>
                    <FormControl><Input placeholder="Mumbai" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Address</FormLabel>
                    <FormControl><Input placeholder="Plot 123, Andheri East" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="startDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="endDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Description</FormLabel>
                    <FormControl><Input placeholder="Brief description of the project..." {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Add Site"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Site?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete the site.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteConfirm(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" onClick={() => deleteConfirm && handleDelete(deleteConfirm)} className="cursor-pointer">Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Quick Add Client */}
      <Dialog open={clientDialogOpen} onOpenChange={setClientDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add New Client</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium mb-1 block">Client Name *</label>
              <Input placeholder="e.g. Raheja Corp" value={newClientName} onChange={(e) => setNewClientName(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Mobile *</label>
              <Input placeholder="e.g. 9876543210" value={newClientMobile} onChange={(e) => setNewClientMobile(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">City</label>
              <Input placeholder="e.g. Mumbai" value={newClientCity} onChange={(e) => setNewClientCity(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="mt-2">
            <Button variant="secondary" onClick={() => setClientDialogOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button onClick={handleAddClient} disabled={addingClient} className="cursor-pointer">
              {addingClient ? "Adding..." : "Add Client"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
