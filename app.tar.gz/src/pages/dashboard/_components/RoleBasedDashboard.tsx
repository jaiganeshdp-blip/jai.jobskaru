import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useNavigate, Link } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  FileText, IndianRupee, MapPin, CheckCircle, Clock,
  Briefcase, HardHat, CalendarCheck, TrendingUp, TrendingDown, Building2,
  UserCheck, ShieldCheck, AlertCircle, Users, BarChart3, Receipt,
  Truck, Eye, Activity,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth.ts";
import { useState } from "react";
import { toast } from "sonner";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { cn } from "@/lib/utils.ts";
import VendorDashboard from "./VendorDashboard.tsx";

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(0)}K`;
  return `₹${n}`;
}

// ---- Finance Dashboard (accounts_manager / billing_manager) ----
function FinanceDashboard({ role }: { role: string }) {
  const data = useQuery(api.roleDashboards.getFinanceDashboard);

  if (!data) return <div className="space-y-4 p-6">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;

  const INVOICE_STATUS_COLORS: Record<string, string> = {
    draft: "bg-gray-100 text-gray-600",
    sent: "bg-blue-100 text-blue-700",
    paid: "bg-green-100 text-green-700",
    overdue: "bg-red-100 text-red-700",
    cancelled: "bg-gray-100 text-gray-500",
  };
  const BILL_STATUS_COLORS: Record<string, string> = {
    received: "bg-amber-100 text-amber-700",
    verified: "bg-blue-100 text-blue-700",
    approved: "bg-purple-100 text-purple-700",
    paid: "bg-green-100 text-green-700",
    disputed: "bg-red-100 text-red-700",
  };

  const isAccountsManager = role === "accounts_manager";

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <IndianRupee className="w-6 h-6 text-emerald-500" />
          {isAccountsManager ? "Accounts Manager Dashboard" : "Billing Manager Dashboard"}
        </h1>
        <p className="text-muted-foreground text-sm mt-0.5">Financial overview of all sites</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <p className="text-xs text-muted-foreground font-medium">Total Invoiced</p>
            </div>
            <p className="text-2xl font-bold text-green-600">{formatINR(data.totalInvoiced)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <p className="text-xs text-muted-foreground font-medium">Received</p>
            </div>
            <p className="text-2xl font-bold text-emerald-600">{formatINR(data.totalReceived)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown className="w-4 h-4 text-red-500" />
              <p className="text-xs text-muted-foreground font-medium">Total Expenses</p>
            </div>
            <p className="text-2xl font-bold text-red-600">{formatINR(data.totalExpenses)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <AlertCircle className="w-4 h-4 text-amber-500" />
              <p className="text-xs text-muted-foreground font-medium">Pending Bills</p>
            </div>
            <p className="text-2xl font-bold text-amber-600">{data.pendingVendorBills}</p>
            <p className="text-xs text-muted-foreground">{formatINR(data.totalVendorBillAmount)} pending</p>
          </CardContent>
        </Card>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <MapPin className="w-5 h-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Active Sites</p>
              <p className="text-xl font-bold">{data.activeSitesCount}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Clock className="w-5 h-5 text-orange-500" />
            <div>
              <p className="text-xs text-muted-foreground">This Month Expenses</p>
              <p className="text-xl font-bold text-orange-600">{formatINR(data.thisMonthExpenses)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <BarChart3 className="w-5 h-5 text-purple-500" />
            <div>
              <p className="text-xs text-muted-foreground">Outstanding</p>
              <p className="text-xl font-bold text-purple-600">{formatINR(data.totalInvoiced - data.totalReceived)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Invoices */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2 justify-between">
              <span className="flex items-center gap-2"><Receipt className="w-4 h-4 text-emerald-500" /> Recent Invoices</span>
              <Link to="/invoices" className="text-xs text-muted-foreground hover:text-foreground">View all →</Link>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {data.recentInvoices.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No invoices yet</p>
            ) : (
              <div className="space-y-2">
                {data.recentInvoices.map(inv => (
                  <div key={inv._id} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                      <p className="text-sm font-medium">{inv.invoiceNumber}</p>
                      <p className="text-xs text-muted-foreground">{inv.clientName} · {inv.date}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{formatINR(inv.amount)}</span>
                      <Badge className={cn("text-xs", INVOICE_STATUS_COLORS[inv.status] ?? "")}>{inv.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Vendor Bills */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2 justify-between">
              <span className="flex items-center gap-2"><FileText className="w-4 h-4 text-amber-500" /> Vendor Bills</span>
              <Link to="/vendor-bills" className="text-xs text-muted-foreground hover:text-foreground">View all →</Link>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {data.recentVendorBills.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No vendor bills yet</p>
            ) : (
              <div className="space-y-2">
                {data.recentVendorBills.map(b => (
                  <div key={b._id} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                      <p className="text-sm font-medium">{b.billNumber}</p>
                      <p className="text-xs text-muted-foreground">{b.billDate}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{formatINR(b.totalAmount)}</span>
                      <Badge className={cn("text-xs", BILL_STATUS_COLORS[b.status] ?? "")}>{b.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: "Invoices", href: "/invoices", icon: Receipt, color: "text-emerald-600" },
              { label: "Vendor Bills", href: "/vendor-bills", icon: FileText, color: "text-amber-600" },
              { label: "Payments", href: "/payments", icon: IndianRupee, color: "text-blue-600" },
              { label: "Expenses", href: "/expenses", icon: TrendingDown, color: "text-red-600" },
              ...(isAccountsManager ? [
                { label: "Salary", href: "/salary", icon: Users, color: "text-purple-600" },
                { label: "Labour", href: "/labour", icon: HardHat, color: "text-orange-600" },
                { label: "Site P&L", href: "/site-pnl", icon: BarChart3, color: "text-rose-600" },
                { label: "Reports", href: "/reports", icon: Activity, color: "text-sky-600" },
              ] : [
                { label: "Purchase Orders", href: "/purchase-orders", icon: Truck, color: "text-sky-600" },
                { label: "Site P&L", href: "/site-pnl", icon: BarChart3, color: "text-rose-600" },
              ]),
            ].map((item) => (
              <Link key={item.href} to={item.href}
                className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent transition-colors cursor-pointer"
              >
                <item.icon className={cn("w-4 h-4 shrink-0", item.color)} />
                <span className="text-sm">{item.label}</span>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ---- Site Incharge Dashboard ----
function SiteInchargeDashboard() {
  const data = useQuery(api.roleDashboards.getSiteInchargeDashboard);
  const navigate = useNavigate();

  if (!data) return <div className="space-y-4 p-6">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;

  const STATUS_COLORS: Record<string, string> = {
    draft: "bg-gray-100 text-gray-600",
    active: "bg-green-100 text-green-700",
    completed: "bg-blue-100 text-blue-700",
    cancelled: "bg-red-100 text-red-700",
    amended: "bg-amber-100 text-amber-700",
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <UserCheck className="w-6 h-6 text-primary" />
          Site Incharge Dashboard
        </h1>
        {data.siteName ? (
          <p className="text-muted-foreground text-sm mt-0.5 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" /> {data.siteName}{data.siteCity ? `, ${data.siteCity}` : ""}
          </p>
        ) : (
          <div className="mt-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex gap-3 items-start">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-800 dark:text-amber-200">Site assign nahi hua</p>
              <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">Admin se request karein ki aapko site assign karein.</p>
            </div>
          </div>
        )}
      </div>

      {data.siteName && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground font-medium">Aaj Ki Hajri</p>
                <p className="text-2xl font-bold text-green-600 mt-1">{data.todayAttendance}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground font-medium">Total Labour</p>
                <p className="text-2xl font-bold mt-1">{data.totalLabour}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground font-medium">Active Work Orders</p>
                <p className="text-2xl font-bold text-purple-600 mt-1">{data.activeWorkOrders}</p>
                <p className="text-xs text-muted-foreground">{formatINR(data.totalWOValue)} value</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground font-medium">Is Mahine Kharch</p>
                <p className="text-2xl font-bold text-red-600 mt-1">{formatINR(data.thisMonthExpenses)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button onClick={() => navigate("/attendance")} className="cursor-pointer h-12 gap-2">
              <CalendarCheck className="w-4 h-4" /> Hajri Bharein
            </Button>
            <Button variant="secondary" onClick={() => navigate("/labour")} className="cursor-pointer h-12 gap-2">
              <HardHat className="w-4 h-4" /> Labour
            </Button>
            <Button variant="secondary" onClick={() => navigate("/site-diary")} className="cursor-pointer h-12 gap-2">
              <FileText className="w-4 h-4" /> Site Diary
            </Button>
            <Button variant="secondary" onClick={() => navigate("/work-orders")} className="cursor-pointer h-12 gap-2">
              <Briefcase className="w-4 h-4" /> Work Orders
            </Button>
          </div>

          {/* 7-day attendance bar chart */}
          {data.recentAttendance.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <CalendarCheck className="w-4 h-4 text-green-500" /> Last 7 Days Attendance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={data.recentAttendance.map(r => ({
                    date: r.date.slice(5),
                    count: r.count,
                  }))}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" name="Present" fill="#22c55e" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Recent Work Orders */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 justify-between">
                <span>Recent Work Orders</span>
                <Link to="/work-orders" className="text-xs text-muted-foreground hover:text-foreground">View all →</Link>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {data.recentWorkOrders.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Koi work order nahi</p>
              ) : (
                <div className="space-y-2">
                  {data.recentWorkOrders.map(w => (
                    <div key={w._id} className="flex items-center justify-between py-2 border-b last:border-0">
                      <p className="text-sm font-medium">{w.orderNumber}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">{formatINR(w.totalValue)}</span>
                        <Badge className={cn("text-xs", STATUS_COLORS[w.status] ?? "")}>{w.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

// ---- Viewer Dashboard ----
function ViewerDashboard() {
  const data = useQuery(api.roleDashboards.getViewerDashboard);

  if (!data) return <div className="space-y-4 p-6">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Eye className="w-6 h-6 text-sky-500" />
          Overview Dashboard
        </h1>
        <p className="text-muted-foreground text-sm mt-0.5">Read-only view of construction activity</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1"><MapPin className="w-4 h-4 text-green-500" /><p className="text-xs text-muted-foreground">Active Sites</p></div>
            <p className="text-2xl font-bold text-green-600">{data.activeSites}</p>
            <p className="text-xs text-muted-foreground">{data.totalSites} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1"><Users className="w-4 h-4 text-orange-500" /><p className="text-xs text-muted-foreground">Labour</p></div>
            <p className="text-2xl font-bold text-orange-600">{data.activeLabour}</p>
            <p className="text-xs text-muted-foreground">{data.totalLabour} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1"><FileText className="w-4 h-4 text-purple-500" /><p className="text-xs text-muted-foreground">Active Work Orders</p></div>
            <p className="text-2xl font-bold text-purple-600">{data.activeWorkOrders}</p>
            <p className="text-xs text-muted-foreground">{data.totalWorkOrders} total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1"><IndianRupee className="w-4 h-4 text-emerald-500" /><p className="text-xs text-muted-foreground">WO Value</p></div>
            <p className="text-2xl font-bold text-emerald-600">{formatINR(data.totalWOValue)}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2 justify-between">
            <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-green-500" /> Active Sites</span>
            <Link to="/sites" className="text-xs text-muted-foreground hover:text-foreground">View all →</Link>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {data.recentSites.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No active sites</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {data.recentSites.map(site => (
                <Link key={site._id} to={`/sites/${site._id}`} className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent transition-colors cursor-pointer">
                  <div className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
                  <div>
                    <p className="text-sm font-medium">{site.name}</p>
                    <p className="text-xs text-muted-foreground">{site.city}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---- Site Supervisor Dashboard ----
function SiteSupervisorDashboard() {
  const data = useQuery(api.roleDashboards.getSiteSupervisorDashboard);
  const navigate = useNavigate();

  if (!data) return <div className="space-y-4 p-6">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;

  const STATUS_COLORS: Record<string, string> = {
    draft: "bg-gray-100 text-gray-600",
    active: "bg-green-100 text-green-700",
    completed: "bg-blue-100 text-blue-700",
    cancelled: "bg-red-100 text-red-700",
    amended: "bg-amber-100 text-amber-700",
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <UserCheck className="w-6 h-6 text-primary" />
          Site Supervisor Dashboard
        </h1>
        {data.siteName && <p className="text-muted-foreground mt-0.5 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{data.siteName}</p>}
      </div>

      {!data.siteName ? (
        <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex gap-3 items-start">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800 dark:text-amber-200">Site assign nahi hua</p>
            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">Admin se request karein ki aapko site assign karein.</p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground font-medium">Aaj Ki Hajri</p><p className="text-2xl font-bold text-green-600 mt-1">{data.todayAttendance}</p></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground font-medium">Total Labour</p><p className="text-2xl font-bold mt-1">{data.totalLabour}</p></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground font-medium">Work Orders</p><p className="text-2xl font-bold mt-1">{data.recentWorkOrders.length}</p></CardContent></Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button onClick={() => navigate("/attendance")} className="cursor-pointer h-14 text-base gap-2">
              <CalendarCheck className="w-5 h-5" /> Hajri Bharein
            </Button>
            <Button variant="secondary" onClick={() => navigate("/labour")} className="cursor-pointer h-14 text-base gap-2">
              <HardHat className="w-5 h-5" /> Labour List
            </Button>
          </div>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">Recent Work Orders</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {data.recentWorkOrders.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Koi work order nahi</p>
              ) : (
                <div className="space-y-2">
                  {data.recentWorkOrders.map(w => (
                    <div key={w._id} className="flex items-center justify-between py-2 border-b last:border-0">
                      <p className="text-sm font-medium">{w.orderNumber}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">{formatINR(w.totalValue)}</span>
                        <Badge className={cn("text-xs", STATUS_COLORS[w.status] ?? "")}>{w.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

// ---- Labour Dashboard ----
function LabourDashboard() {
  const data = useQuery(api.roleDashboards.getLabourDashboard);
  const myCheckins = useQuery(api.geofencing.getMyCheckins);
  const checkIn = useMutation(api.geofencing.checkIn);
  const [isCheckingIn, setIsCheckingIn] = useState(false);
  const [locationStatus, setLocationStatus] = useState<{isWithinGeofence: boolean; distanceFromSite: number} | null>(null);

  const handleCheckIn = async () => {
    if (!("geolocation" in navigator)) {
      toast.error("Aapke phone mein GPS nahi hai");
      return;
    }
    setIsCheckingIn(true);
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0,
        });
      });
      const result = await checkIn({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });
      setLocationStatus({ isWithinGeofence: result.isWithinGeofence, distanceFromSite: result.distanceFromSite });
      if (result.isWithinGeofence) {
        toast.success("Site pe ho! Check-in ho gaya.");
      } else {
        toast.error(`Site se ${result.distanceFromSite}m door ho. Geofence: ${result.geofenceRadius}m`);
      }
    } catch (error) {
      if (error instanceof GeolocationPositionError) {
        if (error.code === 1) toast.error("Location permission deny hai. Settings mein allow karo.");
        else if (error.code === 2) toast.error("Location detect nahi ho paya. Bahar jaake try karo.");
        else toast.error("Location timeout. Dobara try karo.");
      } else {
        toast.error("Check-in mein error aaya. Dobara try karo.");
      }
    } finally {
      setIsCheckingIn(false);
    }
  };

  if (!data) return <div className="space-y-4 p-6">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <HardHat className="w-6 h-6 text-primary" />
          Mera Portal
        </h1>
        {data.name && <p className="text-muted-foreground mt-0.5">{data.name}</p>}
      </div>

      {!data.name ? (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 flex gap-3 items-start dark:bg-amber-950 dark:border-amber-800">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800 dark:text-amber-200">Record link nahi hua</p>
            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">Admin se request karein ki aapka record link karein.</p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CalendarCheck className="w-5 h-5 text-green-600" />
                  <div><p className="text-xs text-muted-foreground">Is Mahine Hajri</p><p className="text-xl font-bold">{data.thisMonthDays} din</p></div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <IndianRupee className="w-5 h-5 text-blue-600" />
                  <div><p className="text-xs text-muted-foreground">Daily Rate</p><p className="text-xl font-bold">₹{data.dailyRate?.toLocaleString("en-IN") ?? "—"}</p></div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-xs text-muted-foreground">Is Mahine Kamai</p>
                    <p className="text-xl font-bold">
                      ₹{data.dailyRate && data.thisMonthDays ? (data.dailyRate * data.thisMonthDays).toLocaleString("en-IN") : "—"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-red-500" />
                  <div><p className="text-xs text-muted-foreground">Is Mahine Advance</p><p className="text-xl font-bold">₹{data.totalAdvanceThisMonth.toLocaleString("en-IN")}</p></div>
                </div>
              </CardContent>
            </Card>
          </div>

          {data.siteName && (
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-sm">Site: <strong>{data.siteName}</strong></span>
                {data.workerCode && <Badge variant="outline">Worker ID: {data.workerCode}</Badge>}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <MapPin className="w-4 h-4" /> GPS Location Check-in
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={handleCheckIn} disabled={isCheckingIn} className="w-full cursor-pointer h-12 text-base gap-2">
                <MapPin className="w-5 h-5" />
                {isCheckingIn ? "Location detect ho raha hai..." : "Check-in Karo (GPS)"}
              </Button>
              {locationStatus && (
                <div className={`rounded-lg p-3 text-sm flex items-center gap-2 ${
                  locationStatus.isWithinGeofence
                    ? "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300"
                    : "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300"
                }`}>
                  {locationStatus.isWithinGeofence ? (
                    <><CheckCircle className="w-4 h-4" /> Site pe ho ({locationStatus.distanceFromSite}m)</>
                  ) : (
                    <><AlertCircle className="w-4 h-4" /> Site se door ({locationStatus.distanceFromSite}m)</>
                  )}
                </div>
              )}
              {myCheckins && myCheckins.length > 0 && (
                <div className="space-y-1 pt-2 border-t">
                  <p className="text-xs text-muted-foreground font-medium">Aaj ke Check-ins:</p>
                  {myCheckins.slice(0, 5).map((ci, i) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span>{new Date(ci.checkinTime).toLocaleTimeString("hi-IN", { hour: "2-digit", minute: "2-digit" })}</span>
                      <span className={ci.isWithinGeofence ? "text-green-600" : "text-red-500"}>
                        {ci.isWithinGeofence ? "On Site" : `${ci.distanceFromSite}m door`}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <IndianRupee className="w-4 h-4" /> Mahine Ki Salary History
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {data.monthlySalary.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Abhi koi salary record nahi hai</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-muted-foreground">
                        <th className="text-left py-2 font-medium">Mahina</th>
                        <th className="text-center py-2 font-medium">Hajri</th>
                        <th className="text-right py-2 font-medium">Salary</th>
                        <th className="text-right py-2 font-medium">Advance</th>
                        <th className="text-right py-2 font-medium">Net</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.monthlySalary.map(m => (
                        <tr key={m.month} className="border-b last:border-0">
                          <td className="py-2 font-medium">{m.monthLabel}</td>
                          <td className="py-2 text-center">{m.daysPresent}{m.halfDays > 0 ? ` + ${m.halfDays}½` : ""} din</td>
                          <td className="py-2 text-right text-green-600 font-medium">₹{m.calculatedSalary.toLocaleString("en-IN")}</td>
                          <td className="py-2 text-right text-red-500 font-medium">{m.totalAdvance > 0 ? `₹${m.totalAdvance.toLocaleString("en-IN")}` : "—"}</td>
                          <td className="py-2 text-right font-bold">₹{m.netPayable.toLocaleString("en-IN")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <Briefcase className="w-4 h-4" /> Advance History
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {data.advances.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Koi advance nahi liya abhi tak</p>
              ) : (
                <div className="space-y-2">
                  {data.advances.map((adv, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
                      <div>
                        <p className="text-sm font-medium">{adv.date}</p>
                        {adv.reason && <p className="text-xs text-muted-foreground">{adv.reason}</p>}
                      </div>
                      <span className="font-semibold text-red-500">₹{adv.amount.toLocaleString("en-IN")}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

// ---- Safety Supervisor ----
function SafetySupervisorPrompt() {
  return (
    <div className="p-6 space-y-5">
      <h1 className="text-2xl font-bold flex items-center gap-2">
        <ShieldCheck className="w-6 h-6 text-orange-500" />
        Safety Supervisor Portal
      </h1>
      <div className="bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800 rounded-xl p-5 flex gap-3 items-start">
        <ShieldCheck className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-orange-800 dark:text-orange-200">Aapka Portal Alag Hai</p>
          <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
            Safety Supervisor portal token-based link se khulta hai. Admin se apna portal link maangein.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Link to="/safety" className="flex items-center gap-3 p-4 rounded-xl border border-border hover:bg-accent transition-colors cursor-pointer">
          <ShieldCheck className="w-5 h-5 text-orange-500" />
          <div><p className="font-medium">Safety Reports</p><p className="text-xs text-muted-foreground">View & add safety reports</p></div>
        </Link>
        <Link to="/labour" className="flex items-center gap-3 p-4 rounded-xl border border-border hover:bg-accent transition-colors cursor-pointer">
          <Users className="w-5 h-5 text-orange-500" />
          <div><p className="font-medium">Labour List</p><p className="text-xs text-muted-foreground">View workers on site</p></div>
        </Link>
      </div>
    </div>
  );
}

// ---- Main Role Router ----
export default function RoleBasedDashboard() {
  const currentUser = useQuery(api.users.getCurrentUserQuery);

  if (currentUser === undefined) {
    return <div className="space-y-4 p-6">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;
  }

  const role = currentUser?.role;

  if (role === "contractor" || role === "supplier") return <VendorDashboard />;
  if (role === "site_supervisor") return <SiteSupervisorDashboard />;
  if (role === "site_incharge") return <SiteInchargeDashboard />;
  if (role === "labour") return <LabourDashboard />;
  if (role === "safety_supervisor") return <SafetySupervisorPrompt />;
  if (role === "accounts_manager" || role === "billing_manager") return <FinanceDashboard role={role} />;
  if (role === "viewer") return <ViewerDashboard />;

  // super_admin → handled by parent (shows full admin dashboard)
  return null;
}
