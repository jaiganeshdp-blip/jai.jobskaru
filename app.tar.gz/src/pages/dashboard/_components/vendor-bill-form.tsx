/**
 * Bill / Invoice form for authenticated vendor logins (contractor / supplier).
 * Uses the auth-scoped `myVendor` API — the vendor is resolved server-side from
 * the logged-in user, so no token or vendor id is needed or trusted from the client.
 */
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { AlertTriangle, FileSpreadsheet, CheckCircle2, Plus, ArrowLeft, Building2 } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type POItem = { name: string; quantity: number; unit: string; ratePerUnit: number; totalAmount: number };
type PO = {
  _id: Id<"purchaseOrders">;
  poNumber: string;
  siteName: string;
  companyName?: string;
  totalValue: number;
  status: string;
  items: POItem[];
};
type RAItem = {
  srNo: number; description: string; unit: string;
  orderQty: number; thisBillQty: number; ratePerUnit: number; thisBillAmount: number;
};

const fmt = (n: number) => `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

export function VendorBillForm({ onSuccess }: { onSuccess?: () => void }) {
  const [step, setStep] = useState<"list" | "form">("list");
  const [selectedPO, setSelectedPO] = useState<PO | null>(null);
  const [billType, setBillType] = useState<"ra" | "final">("ra");
  const [billNumber, setBillNumber] = useState("");
  const [billDate, setBillDate] = useState(new Date().toISOString().split("T")[0]);
  const [gstPercent, setGstPercent] = useState(18);
  const [retentionPercent, setRetentionPercent] = useState(0);
  const [notes, setNotes] = useState("");
  const [raItems, setRaItems] = useState<RAItem[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const pos = (useQuery(api.myVendor.getPurchaseOrders) ?? []) as PO[];
  const prevBills = useQuery(
    api.myVendor.getPrevBillsByPO,
    selectedPO ? { purchaseOrderId: selectedPO._id } : "skip",
  ) ?? [];
  const submitBill = useMutation(api.myVendor.submitBill);

  useEffect(() => {
    if (!selectedPO) { setRaItems([]); return; }
    setRaItems(selectedPO.items.map((item, i) => ({
      srNo: i + 1,
      description: item.name,
      unit: item.unit,
      orderQty: item.quantity,
      thisBillQty: 0,
      ratePerUnit: item.ratePerUnit,
      thisBillAmount: 0,
    })));
  }, [selectedPO?._id]);

  const prevQtyBySrNo: Record<number, number> = {};
  for (const b of prevBills) {
    for (const item of b.raBillItems ?? []) {
      prevQtyBySrNo[item.srNo] = (prevQtyBySrNo[item.srNo] ?? 0) + item.thisBillQty;
    }
  }

  const prevBilledTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
  const subtotal = raItems.reduce((s, i) => s + i.thisBillAmount, 0);
  const gstAmount = (subtotal * gstPercent) / 100;
  const grossTotal = subtotal + gstAmount;
  const retentionAmount = (grossTotal * retentionPercent) / 100;
  const balancePayable = grossTotal - retentionAmount;
  const cumulative = prevBilledTotal + subtotal;
  const poValue = selectedPO?.totalValue ?? 0;
  const isExceeding = cumulative > poValue;
  const raNumber = prevBills.length + 1;

  function updateItem(srNo: number, value: number) {
    setRaItems(prev => prev.map(item => {
      if (item.srNo !== srNo) return item;
      return { ...item, thisBillQty: value, thisBillAmount: value * item.ratePerUnit };
    }));
  }

  function resetForm() {
    setSubmitted(false);
    setStep("list");
    setSelectedPO(null);
    setBillNumber("");
    setRaItems([]);
    setNotes("");
    setRetentionPercent(0);
    setGstPercent(18);
  }

  async function handleSubmit() {
    if (!selectedPO || !billNumber || subtotal === 0) {
      toast.error("PO, Bill Number aur kam se kam ek item fill karein");
      return;
    }
    setSubmitting(true);
    try {
      const result = await submitBill({
        purchaseOrderId: selectedPO._id,
        billNumber,
        billDate,
        billType,
        raBillItems: raItems.filter(i => i.thisBillQty > 0),
        gstPercent,
        retentionPercent: retentionPercent || undefined,
        notes: notes || undefined,
      });
      if (result.warning) toast.warning(result.warning);
      else toast.success(`${billType === "final" ? "Final Bill" : `RA-${raNumber}`} submit ho gaya!`);
      setSubmitted(true);
      onSuccess?.();
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setSubmitting(false);
    }
  }

  /* ── SUCCESS ── */
  if (submitted) {
    return (
      <div className="text-center py-8 space-y-4">
        <CheckCircle2 className="mx-auto w-14 h-14 text-green-500" />
        <h3 className="font-bold text-xl">Bill Submit Ho Gaya!</h3>
        <p className="text-muted-foreground text-sm">Admin review karenge aur payment process karenge.</p>
        <Button variant="secondary" size="sm" onClick={resetForm} className="cursor-pointer">
          Nayi Bill Submit Karein
        </Button>
      </div>
    );
  }

  /* ── PO LIST ── */
  if (step === "list") {
    return (
      <div className="space-y-3">
        <p className="text-sm font-medium text-muted-foreground">Apna PO chunein aur bill submit karein</p>
        {pos.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <FileSpreadsheet className="mx-auto mb-2 opacity-50" size={32} />
            <p className="text-sm">Koi PO assign nahi hai</p>
          </div>
        ) : (
          <div className="space-y-2">
            {pos.map(po => (
              <Card key={po._id}>
                <CardContent className="p-4">
                  {po.companyName && po.companyName !== "—" && (
                    <div className="flex items-center gap-1.5 mb-2">
                      <Building2 size={13} className="text-amber-500" />
                      <span className="text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wide">{po.companyName}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-base">{po.poNumber}</div>
                      <div className="text-muted-foreground text-sm mt-0.5">{po.siteName}</div>
                      <div className="text-emerald-600 dark:text-emerald-400 font-semibold text-sm mt-0.5">{fmt(po.totalValue)}</div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => { setSelectedPO(po); setStep("form"); }}
                      className="cursor-pointer shrink-0 gap-1.5"
                    >
                      <Plus size={14} /> Bill Banao
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  /* ── BILL FORM ── */
  return (
    <div className="space-y-4">
      {/* Back + PO Info */}
      <div className="flex items-center gap-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={() => { setStep("list"); setSelectedPO(null); }}
          className="cursor-pointer gap-1.5"
        >
          <ArrowLeft size={14} /> Back
        </Button>
        <div className="flex-1 min-w-0">
          {selectedPO?.companyName && selectedPO.companyName !== "—" && (
            <div className="flex items-center gap-1 mb-0.5">
              <Building2 size={12} className="text-amber-500" />
              <span className="text-amber-600 dark:text-amber-400 text-xs font-bold">{selectedPO.companyName}</span>
            </div>
          )}
          <p className="text-sm font-bold truncate">{selectedPO?.poNumber} — {selectedPO?.siteName}</p>
        </div>
      </div>

      {/* PO Summary */}
      <div className="bg-muted rounded-xl p-4 grid grid-cols-3 gap-3">
        <div>
          <p className="text-muted-foreground text-xs mb-1">PO Value</p>
          <p className="font-extrabold text-base">{fmt(poValue)}</p>
        </div>
        <div>
          <p className="text-muted-foreground text-xs mb-1">Pehle Billed</p>
          <p className="text-orange-600 dark:text-orange-400 font-extrabold text-base">{fmt(prevBilledTotal)}</p>
        </div>
        <div>
          <p className="text-muted-foreground text-xs mb-1">Balance</p>
          <p className={`font-extrabold text-base ${isExceeding ? "text-red-500" : "text-green-600 dark:text-green-400"}`}>
            {fmt(Math.max(0, poValue - prevBilledTotal))}
          </p>
        </div>
      </div>

      {/* Previous bills */}
      {prevBills.length > 0 && (
        <div className="flex gap-2 flex-wrap items-center">
          <span className="text-muted-foreground text-xs font-semibold">Purane bills:</span>
          {prevBills.map(b => (
            <span key={b._id} className="bg-muted text-xs px-2 py-0.5 rounded font-bold border">
              {b.billType === "final" ? "Final" : `RA-${b.raNumber}`}
              <span className="text-muted-foreground ml-1">{fmt(b.subtotal)}</span>
            </span>
          ))}
        </div>
      )}

      {/* Bill Details */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-xs font-bold">Bill Type</Label>
          <Select value={billType} onValueChange={v => setBillType(v as "ra" | "final")}>
            <SelectTrigger className="h-10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ra">RA-{raNumber} (Running Account)</SelectItem>
              <SelectItem value="final">Final Bill</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-xs font-bold">Bill Number *</Label>
          <Input
            className="h-10"
            value={billNumber}
            onChange={e => setBillNumber(e.target.value)}
            placeholder={`RA-00${raNumber}`}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs font-bold">Bill Date *</Label>
          <Input
            type="date"
            className="h-10"
            value={billDate}
            onChange={e => setBillDate(e.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs font-bold">GST %</Label>
          <Input
            type="number"
            className="h-10"
            min={0} max={100}
            value={gstPercent}
            onChange={e => setGstPercent(Number(e.target.value) || 0)}
          />
        </div>
      </div>

      {/* Items Table */}
      {raItems.length > 0 && (
        <div className="space-y-2">
          <Label className="text-xs font-bold">Item-wise Quantity Bharein</Label>
          <div className="overflow-x-auto rounded-xl border">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-muted">
                  <th className="px-2 py-2.5 text-left border-r w-6">Sr</th>
                  <th className="px-2 py-2.5 text-left border-r">Item</th>
                  <th className="px-2 py-2.5 text-center border-r w-10">Unit</th>
                  <th className="px-2 py-2.5 text-right border-r w-14">PO Qty</th>
                  <th className="px-2 py-2.5 text-right border-r w-14">Prev</th>
                  <th className="px-2 py-2.5 text-right border-r w-14">Bal</th>
                  <th className="px-2 py-2.5 text-center border-r w-20 bg-primary text-primary-foreground">Is Bill Qty</th>
                  <th className="px-2 py-2.5 text-right border-r w-20">Rate</th>
                  <th className="px-2 py-2.5 text-right w-24">Amount</th>
                </tr>
              </thead>
              <tbody>
                {raItems.map(item => {
                  const prevQty = prevQtyBySrNo[item.srNo] ?? 0;
                  const bal = Math.max(0, item.orderQty - prevQty);
                  const isOver = item.thisBillQty > bal && bal > 0;
                  return (
                    <tr key={item.srNo} className="border-t">
                      <td className="px-2 py-2 text-muted-foreground border-r">{item.srNo}</td>
                      <td className="px-2 py-2 border-r max-w-[120px]">
                        <span className="block truncate font-semibold" title={item.description}>{item.description}</span>
                      </td>
                      <td className="px-2 py-2 text-center text-muted-foreground border-r">{item.unit}</td>
                      <td className="px-2 py-2 text-right border-r font-medium">{item.orderQty}</td>
                      <td className="px-2 py-2 text-right text-orange-600 dark:text-orange-400 border-r font-medium">{prevQty || "—"}</td>
                      <td className={`px-2 py-2 text-right border-r font-bold ${bal <= 0 ? "text-red-500" : "text-cyan-600 dark:text-cyan-400"}`}>{bal}</td>
                      <td className="px-2 py-2 border-r bg-primary/5">
                        <Input
                          type="number" min={0} step="0.01"
                          value={item.thisBillQty || ""}
                          placeholder="0"
                          onChange={e => updateItem(item.srNo, Number(e.target.value) || 0)}
                          className={`w-16 h-7 text-xs text-right font-bold ${isOver ? "border-red-500" : ""}`}
                        />
                        {isOver && <div className="text-[10px] text-red-500 font-bold text-right">Zyada!</div>}
                      </td>
                      <td className="px-2 py-2 text-right border-r text-muted-foreground">{fmt(item.ratePerUnit)}</td>
                      <td className={`px-2 py-2 text-right font-bold ${item.thisBillAmount > 0 ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"}`}>
                        {item.thisBillAmount > 0 ? fmt(item.thisBillAmount) : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 bg-muted">
                  <td colSpan={8} className="px-2 py-2.5 text-right border-r font-bold text-xs">Subtotal (GST se pehle)</td>
                  <td className="px-2 py-2.5 text-right text-emerald-600 dark:text-emerald-400 font-extrabold">{fmt(subtotal)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Bill Summary */}
      {subtotal > 0 && (
        <div className="rounded-xl border overflow-hidden">
          <div className="bg-muted px-4 py-2 font-bold text-xs uppercase tracking-wide">Bill Summary</div>
          <div className="divide-y text-sm">
            <div className="flex justify-between px-4 py-2.5">
              <span className="text-muted-foreground font-semibold">Subtotal</span>
              <span className="font-bold">{fmt(subtotal)}</span>
            </div>
            <div className="flex justify-between px-4 py-2.5">
              <span className="text-muted-foreground font-semibold">GST @ {gstPercent}%</span>
              <span className="font-bold text-amber-600 dark:text-amber-400">+ {fmt(gstAmount)}</span>
            </div>
            <div className="flex justify-between px-4 py-3 bg-muted">
              <span className="font-bold">Gross Total</span>
              <span className="font-extrabold">{fmt(grossTotal)}</span>
            </div>
            {retentionPercent > 0 && (
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-red-500 font-bold">(-) Retention @ {retentionPercent}%</span>
                <span className="text-red-500 font-bold">− {fmt(retentionAmount)}</span>
              </div>
            )}
            <div className="flex justify-between px-4 py-3 bg-emerald-600 text-white">
              <span className="font-bold">Balance Payable</span>
              <span className="font-extrabold text-base">{fmt(balancePayable)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Retention & Notes */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-xs font-bold">Retention % (0 agar nahi)</Label>
          <Input
            type="number"
            className="h-10"
            min={0} max={100}
            value={retentionPercent}
            onChange={e => setRetentionPercent(Number(e.target.value) || 0)}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs font-bold">Notes (optional)</Label>
          <Textarea
            rows={1}
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Remarks..."
          />
        </div>
      </div>

      {/* PO Exceed Warning */}
      {isExceeding && (
        <div className="flex gap-2 items-start bg-red-50 dark:bg-red-950 border border-red-300 dark:border-red-800 rounded-xl p-3 text-sm text-red-700 dark:text-red-300">
          <AlertTriangle size={15} className="shrink-0 mt-0.5" />
          <span>PO Value se ₹{(cumulative - poValue).toLocaleString("en-IN")} zyada hai! Admin se confirm karein.</span>
        </div>
      )}

      {/* Submit Buttons */}
      <div className="flex gap-3 pt-1">
        <Button
          variant="secondary"
          onClick={() => { setStep("list"); setSelectedPO(null); }}
          className="cursor-pointer"
        >
          Cancel
        </Button>
        <Button
          disabled={submitting || !billNumber || subtotal === 0}
          onClick={handleSubmit}
          className="flex-1 cursor-pointer gap-2"
        >
          <FileSpreadsheet size={15} />
          {submitting ? "Submit ho raha hai..." : `${billType === "final" ? "Final Bill" : `RA-${raNumber}`} Submit Karein`}
        </Button>
      </div>
    </div>
  );
}
