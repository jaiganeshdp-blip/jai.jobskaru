/**
 * Unified self-service dashboard for authenticated vendor logins
 * (role = contractor / supplier).
 *
 * Shows ONLY the logged-in vendor's own data — their POs, work orders,
 * bills/invoices and payments — all resolved server-side via the `myVendor` API.
 * The vendor can also create their own bill/invoice from here.
 */
import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  FileText, IndianRupee, Building2, Briefcase, Receipt,
  AlertCircle, Plus, X, TrendingUp, Wallet, ClipboardList,
} from "lucide-react";
import { cn } from "@/lib/utils.ts";
import { format } from "date-fns";
import { VendorBillForm } from "./vendor-bill-form.tsx";
import { VendorBillAttachments } from "./vendor-bill-attachments.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function fmtAmt(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(0)}K`;
  return `₹${n}`;
}

const BILL_STATUS_COLORS: Record<string, string> = {
  received: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
  verified: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
  approved: "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300",
  paid: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300",
  disputed: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300",
};

export default function VendorDashboard() {
  const [showBillForm, setShowBillForm] = useState(false);

  const profile = useQuery(api.myVendor.getProfile);
  const pos = useQuery(api.myVendor.getPurchaseOrders) ?? [];
  const workOrders = useQuery(api.myVendor.getWorkOrders) ?? [];
  const bills = useQuery(api.myVendor.getBills) ?? [];
  const payments = useQuery(api.myVendor.getPayments) ?? [];

  if (profile === undefined) {
    return <div className="space-y-4 p-6">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>;
  }

  // Not linked to a vendor record yet
  if (!profile) {
    return (
      <div className="p-6 space-y-5">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Briefcase className="w-6 h-6 text-primary" /> Vendor Portal
        </h1>
        <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-xl p-5 flex gap-3 items-start">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800 dark:text-amber-200">Aapka record link nahi hua</p>
            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
              Admin se request karein ki aapka contractor/supplier record aapke login se link karein. Uske baad aapki POs, bills aur payments yahan dikhengi.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const totalPOValue = pos.reduce((s, po) => s + po.totalValue, 0);
  const totalBilled = bills.reduce((s, b) => s + b.totalAmount, 0);
  const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
  const totalOutstanding = bills.reduce((s, b) => s + (b.totalAmount - b.paidAmount), 0);

  return (
    <div className="p-4 md:p-6 space-y-5 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center text-xl font-bold text-primary shrink-0">
          {profile.name.charAt(0)}
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{profile.name}</h1>
          <p className="text-muted-foreground text-sm">{profile.subtitle} · {profile.mobile}</p>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Building2 className="w-4 h-4 text-emerald-500" />
              <p className="text-xs text-muted-foreground font-semibold">PO Value</p>
            </div>
            <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{fmtAmt(totalPOValue)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{pos.length} POs</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-blue-500" />
              <p className="text-xs text-muted-foreground font-semibold">Total Billed</p>
            </div>
            <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{fmtAmt(totalBilled)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{bills.length} Bills</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Wallet className="w-4 h-4 text-green-500" />
              <p className="text-xs text-muted-foreground font-semibold">Paisa Mila</p>
            </div>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400">{fmtAmt(totalPaid)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{payments.length} payments</p>
          </CardContent>
        </Card>
        <Card className={totalOutstanding > 0 ? "border-orange-300 dark:border-orange-800" : ""}>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <IndianRupee className={cn("w-4 h-4", totalOutstanding > 0 ? "text-orange-500" : "text-muted-foreground")} />
              <p className="text-xs text-muted-foreground font-semibold">Baki Hai</p>
            </div>
            <p className={cn("text-2xl font-bold", totalOutstanding > 0 ? "text-orange-600 dark:text-orange-400" : "text-muted-foreground")}>
              {fmtAmt(totalOutstanding)}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">Outstanding</p>
          </CardContent>
        </Card>
      </div>

      {/* Create bill CTA / form */}
      {!showBillForm ? (
        pos.length > 0 && (
          <Button size="lg" onClick={() => setShowBillForm(true)} className="w-full md:w-auto cursor-pointer gap-2 h-12">
            <Plus className="w-5 h-5" /> Naya Bill / Invoice Banayein
          </Button>
        )
      ) : (
        <Card>
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base flex items-center gap-2">
              <Receipt className="w-4 h-4 text-primary" /> Naya Bill / Invoice
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setShowBillForm(false)} className="cursor-pointer h-8 w-8">
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <VendorBillForm onSuccess={() => setShowBillForm(false)} />
          </CardContent>
        </Card>
      )}

      {/* Purchase Orders */}
      {pos.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" /> Purchase Orders
              <span className="ml-auto text-xs font-bold bg-muted rounded-full px-2 py-0.5">{pos.length}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            {pos.map((po) => {
              const poBills = bills.filter((b) => b.purchaseOrderId === po._id);
              const poBilled = poBills.reduce((s, b) => s + b.totalAmount, 0);
              const progress = po.totalValue > 0 ? Math.min((poBilled / po.totalValue) * 100, 100) : 0;
              return (
                <div key={po._id} className="border rounded-xl p-4 space-y-3">
                  {po.companyName !== "—" && (
                    <div className="flex items-center gap-1.5">
                      <Building2 size={12} className="text-amber-500" />
                      <span className="text-amber-600 dark:text-amber-400 text-xs font-bold uppercase">{po.companyName}</span>
                    </div>
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-bold text-base">{po.poNumber}</p>
                      <p className="text-sm text-muted-foreground">{po.siteName}</p>
                      <p className="text-xs text-muted-foreground">{po.issueDate}</p>
                    </div>
                    <Badge variant="secondary" className="text-xs">{po.status}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-muted-foreground">PO Value</p>
                    <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">₹{po.totalValue.toLocaleString("en-IN")}</p>
                  </div>
                  {poBilled > 0 && (
                    <div>
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Billed: ₹{poBilled.toLocaleString("en-IN")}</span>
                        <span>{progress.toFixed(0)}%</span>
                      </div>
                      <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden">
                        <div className={cn("h-full rounded-full", progress >= 100 ? "bg-orange-500" : "bg-emerald-500")} style={{ width: `${progress}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Work Orders (contractors) */}
      {workOrders.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-purple-500" /> Work Orders
              <span className="ml-auto text-xs font-bold bg-muted rounded-full px-2 py-0.5">{workOrders.length}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            {workOrders.map((wo) => (
              <div key={wo._id} className="border rounded-xl p-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-bold">{wo.orderNumber}</p>
                    <p className="text-sm text-muted-foreground">{wo.siteName}</p>
                  </div>
                  <Badge variant="secondary" className="text-xs capitalize">{wo.status}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{wo.description}</p>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-muted-foreground">Work Order Value</p>
                  <p className="text-lg font-bold text-purple-600 dark:text-purple-400">₹{wo.totalValue.toLocaleString("en-IN")}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Bills / Invoices */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Receipt className="w-4 h-4 text-orange-500" /> Meri Bills / Invoices
            <span className="ml-auto text-xs font-bold bg-muted rounded-full px-2 py-0.5">{bills.length}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {bills.length === 0 ? (
            <div className="text-center py-8">
              <Receipt size={36} className="mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-muted-foreground text-sm">Koi bill nahi abhi tak</p>
              {pos.length > 0 && !showBillForm && (
                <Button size="sm" className="mt-3 cursor-pointer gap-1.5" onClick={() => setShowBillForm(true)}>
                  <Plus size={14} /> Pehla Bill Banayein
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {bills.map((b) => {
                const outstanding = b.totalAmount - b.paidAmount;
                return (
                  <div key={b._id} className="border rounded-xl p-4">
                    {b.companyName !== "—" && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <Building2 size={12} className="text-amber-500 shrink-0" />
                        <span className="text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wide">{b.companyName}</span>
                      </div>
                    )}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="font-bold">{b.billNumber}</span>
                          {b.billType === "ra" && <Badge variant="secondary" className="text-xs">RA-{b.raNumber}</Badge>}
                          {b.billType === "final" && <Badge variant="secondary" className="text-xs">Final</Badge>}
                          <Badge className={cn("text-xs", BILL_STATUS_COLORS[b.status] ?? "")}>{b.status.toUpperCase()}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{b.siteName}</p>
                        <p className="text-xs text-muted-foreground">{b.billDate}{b.poNumber ? ` · PO: ${b.poNumber}` : ""}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-lg font-bold">₹{b.totalAmount.toLocaleString("en-IN")}</p>
                        {outstanding > 0 ? (
                          <p className="text-xs text-orange-500 font-bold">₹{outstanding.toLocaleString("en-IN")} baki</p>
                        ) : b.paidAmount > 0 ? (
                          <p className="text-xs text-green-500 font-bold">Paid ✓</p>
                        ) : null}
                      </div>
                    </div>
                    <VendorBillAttachments billId={b._id as Id<"vendorBills">} />
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payments */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <IndianRupee className="w-4 h-4 text-green-500" /> Payments Mila
            {totalPaid > 0 && <span className="ml-auto text-green-600 dark:text-green-400 text-sm font-bold">{fmtAmt(totalPaid)}</span>}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {payments.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-6">Abhi koi payment nahi mila</p>
          ) : (
            <div className="space-y-2">
              {payments.map((p) => (
                <div key={p._id} className="flex justify-between items-center border rounded-xl px-4 py-3">
                  <div>
                    <p className="font-bold text-green-600 dark:text-green-400">₹{p.amount.toLocaleString("en-IN")}</p>
                    <p className="text-xs text-muted-foreground">
                      {(() => { try { return format(new Date(p.date.includes("T") ? p.date : p.date + "T00:00:00"), "dd MMM yyyy"); } catch { return p.date; } })()}
                      {p.mode ? ` · ${p.mode.toUpperCase()}` : ""}
                    </p>
                  </div>
                  {p.referenceNumber && (
                    <p className="text-xs font-semibold bg-muted border px-2 py-1 rounded">{p.referenceNumber}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
