/**
 * Attachment upload/view for authenticated vendor bills (contractor / supplier).
 * Uses the auth-scoped `myVendor` API — vendor resolved server-side, no token needed.
 */
import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Paperclip, Upload, Eye, FileText, Image as ImageIcon,
  FileSpreadsheet, Loader2, X, Download,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Attachment = {
  storageId: string;
  url: string | null;
  fileName: string;
  fileType: string;
};

const ACCEPT =
  "image/*,.pdf,.xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

function fileIcon(fileType: string) {
  if (fileType.startsWith("image/")) return <ImageIcon size={14} className="text-blue-500" />;
  if (fileType === "application/pdf") return <FileText size={14} className="text-red-500" />;
  return <FileSpreadsheet size={14} className="text-green-500" />;
}

function isImage(fileType: string) {
  return fileType.startsWith("image/");
}
function isPDF(fileType: string) {
  return fileType === "application/pdf";
}

function FileViewer({ attachment, onClose }: { attachment: Attachment; onClose: () => void }) {
  if (!attachment.url) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col" onClick={onClose}>
      <div
        className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-700 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 min-w-0">
          {fileIcon(attachment.fileType)}
          <span className="text-white text-sm font-semibold truncate max-w-[220px]">{attachment.fileName}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <a
            href={attachment.url}
            download={attachment.fileName}
            className="flex items-center gap-1 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg cursor-pointer"
            onClick={(e) => e.stopPropagation()}
          >
            <Download size={13} /> Download
          </a>
          <button onClick={onClose} className="p-1.5 rounded-lg bg-red-800 hover:bg-red-700 text-white cursor-pointer">
            <X size={16} />
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-auto flex items-center justify-center p-4" onClick={(e) => e.stopPropagation()}>
        {isPDF(attachment.fileType) && (
          <iframe src={attachment.url} className="w-full h-full border-0" title={attachment.fileName} style={{ minHeight: "calc(100vh - 60px)" }} />
        )}
        {isImage(attachment.fileType) && (
          <img src={attachment.url} alt={attachment.fileName} className="max-w-full object-contain rounded shadow-2xl" />
        )}
        {!isPDF(attachment.fileType) && !isImage(attachment.fileType) && (
          <div className="text-center space-y-4">
            <FileSpreadsheet size={64} className="mx-auto text-green-400" />
            <p className="text-white text-lg font-bold">{attachment.fileName}</p>
            <a
              href={attachment.url}
              download={attachment.fileName}
              className="inline-flex items-center gap-2 bg-green-700 hover:bg-green-600 text-white font-bold px-5 py-3 rounded-xl cursor-pointer"
            >
              <Download size={16} /> Download
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

export function VendorBillAttachments({ billId }: { billId: Id<"vendorBills"> }) {
  const [uploading, setUploading] = useState(false);
  const [viewer, setViewer] = useState<Attachment | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.myVendor.generateBillUploadUrl);
  const addBillAttachment = useMutation(api.myVendor.addBillAttachment);
  const attachments = (useQuery(api.myVendor.getBillAttachmentUrls, { billId }) ?? []) as Attachment[];

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl({});
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!res.ok) throw new Error("Upload failed");
      const { storageId } = (await res.json()) as { storageId: string };
      await addBillAttachment({
        billId,
        storageId: storageId as Id<"_storage">,
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
      });
      toast.success("File upload ho gaya!");
    } catch {
      toast.error("Upload fail hua, dobara try karein");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <>
      {viewer && <FileViewer attachment={viewer} onClose={() => setViewer(null)} />}

      <div className="mt-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-muted-foreground text-xs font-semibold flex items-center gap-1">
            <Paperclip size={12} /> Documents ({attachments.length})
          </span>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="cursor-pointer gap-1.5 h-8"
          >
            {uploading ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
            {uploading ? "Upload ho raha hai..." : "Photo / PDF / Excel"}
          </Button>
          <input ref={fileInputRef} type="file" accept={ACCEPT} className="hidden" onChange={handleFileChange} />
        </div>

        {attachments.length > 0 && (
          <div className="space-y-1.5">
            {attachments.map((a) => (
              <div key={a.storageId} className="flex items-center gap-2 bg-muted border rounded-lg px-3 py-2">
                {fileIcon(a.fileType)}
                <span className="flex-1 text-xs font-medium truncate">{a.fileName}</span>
                {a.url && (
                  <Button size="sm" variant="secondary" onClick={() => setViewer(a)} className="cursor-pointer gap-1 h-7">
                    <Eye size={11} /> Dekho
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
