import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Building2, MapPin, Users, Truck, HardHat,
  FileText, TrendingUp, TrendingDown, IndianRupee,
  UserCheck, Activity, Handshake,
} from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils.ts";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  PieChart, Pie, Cell,
} from "recharts";
import RoleBasedDashboard from "./_components/RoleBasedDashboard.tsx";

const CATEGORY_COLORS: Record<string, string> = {
  materials: "#3b82f6",
  labour_salary: "#f59e0b",
  contractor_bill: "#8b5cf6",
  transport: "#06b6d4",
  food_snacks: "#10b981",
  water: "#6366f1",
  equipment: "#f97316",
  misc: "#94a3b8",
};

const CATEGORY_LABELS: Record<string, string> = {
  materials: "Materials",
  labour_salary: "Labour Salary",
  contractor_bill: "Contractor",
  transport: "Transport",
  food_snacks: "Food",
  water: "Water",
  equipment: "Equipment",
  misc: "Misc",
};

function StatCard({
  title, value, sub, icon: Icon, href, color = "text-primary", trend,
}: {
  title: string;
  value: string | number;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  href?: string;
  color?: string;
  trend?: "up" | "down" | "neutral";
}) {
  const inner = (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center bg-muted", color.replace("text-", "bg-").replace("-500", "-100").replace("-600", "-100"))}>
          <Icon className={cn("w-4 h-4", color)} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-1 mt-1">
          {trend === "up" && <TrendingUp className="w-3 h-3 text-green-500" />}
          {trend === "down" && <TrendingDown className="w-3 h-3 text-red-500" />}
          <span className="text-xs text-muted-foreground">{sub}</span>
        </div>
      </CardContent>
    </Card>
  );
  if (href) return <Link to={href}>{inner}</Link>;
  return inner;
}

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(0)}K`;
  return `₹${n}`;
}

export default function Dashboard() {
  const currentUser = useQuery(api.users.getCurrentUserQuery);
  // Skip stats query until user is loaded to prevent unnecessary errors
  const stats = useQuery(api.dashboard.stats, currentUser ? {} : "skip");

  // Non-super_admin roles → show their dedicated role dashboard
  const role = currentUser?.role;
  if (currentUser !== undefined && role && role !== "super_admin") {
    return <RoleBasedDashboard />;
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground text-sm">Overview of all construction activity</p>
      </div>

      {/* Stats Grid */}
      {!stats ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <StatCard title="Companies" value={stats.counts.companies} sub="Registered" icon={Building2} href="/companies" color="text-blue-600" />
          <StatCard title="Sites" value={stats.counts.sites} sub={`${stats.counts.activeSites} active`} icon={MapPin} href="/sites" color="text-green-600" trend="up" />
          <StatCard title="Labour" value={stats.counts.labourers} sub={`${stats.counts.activeLabourers} active`} icon={Users} href="/labour" color="text-orange-600" />
          <StatCard title="Work Orders" value={stats.counts.workOrders} sub={`${stats.counts.activeWorkOrders} active`} icon={FileText} href="/work-orders" color="text-purple-600" />
          <StatCard title="Clients" value={stats.counts.clients} sub="Registered" icon={UserCheck} href="/clients" color="text-indigo-600" />
          <StatCard title="Suppliers" value={stats.counts.suppliers} sub="Active" icon={Truck} href="/suppliers" color="text-sky-600" />
          <StatCard title="Contractors" value={stats.counts.contractors} sub="Labour contractors" icon={HardHat} href="/contractors" color="text-yellow-600" />
          <StatCard title="Partners" value={stats.counts.partners} sub="Profit share partners" icon={Handshake} href="/partners" color="text-rose-600" />
        </div>
      )}

      {/* Financial Summary + Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Financial KPIs */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <IndianRupee className="w-4 h-4 text-emerald-500" /> Financial Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!stats ? (
              <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
            ) : (
              <>
                <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/30 flex justify-between items-center">
                  <div>
                    <p className="text-xs text-muted-foreground">Work Order Value</p>
                    <p className="text-lg font-bold text-green-700">{formatINR(stats.financials.totalWOValue)}</p>
                  </div>
                  <TrendingUp className="w-5 h-5 text-green-500" />
                </div>
                <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/30 flex justify-between items-center">
                  <div>
                    <p className="text-xs text-muted-foreground">Total Expenses</p>
                    <p className="text-lg font-bold text-red-700">{formatINR(stats.financials.totalExpenses)}</p>
                  </div>
                  <TrendingDown className="w-5 h-5 text-red-500" />
                </div>
                <div className={cn(
                  "p-3 rounded-lg flex justify-between items-center",
                  stats.financials.netProfit >= 0
                    ? "bg-emerald-50 dark:bg-emerald-950/30"
                    : "bg-red-50 dark:bg-red-950/30"
                )}>
                  <div>
                    <p className="text-xs text-muted-foreground">Net Profit / Loss</p>
                    <p className={cn("text-lg font-bold", stats.financials.netProfit >= 0 ? "text-emerald-700" : "text-red-700")}>
                      {formatINR(Math.abs(stats.financials.netProfit))}
                      {stats.financials.netProfit < 0 ? " (Loss)" : ""}
                    </p>
                  </div>
                  <Activity className="w-5 h-5 text-emerald-500" />
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Monthly Bar Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-500" /> Revenue vs Expenses (6 months)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!stats ? (
              <Skeleton className="h-48 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={stats.monthlyData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}K`} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(value: number) => formatINR(value)} />
                  <Legend />
                  <Bar dataKey="revenue" name="WO Value" fill="#10b981" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Expense Breakdown + Active Sites */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Expense pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Expense Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {!stats ? (
              <Skeleton className="h-48 w-full" />
            ) : Object.keys(stats.categoryTotals).length === 0 ? (
              <div className="text-muted-foreground text-sm text-center py-8">No expenses recorded yet</div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <ResponsiveContainer width={160} height={160}>
                  <PieChart>
                    <Pie data={Object.entries(stats.categoryTotals).map(([k, v]) => ({ name: CATEGORY_LABELS[k] ?? k, value: v }))} cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2} dataKey="value">
                      {Object.keys(stats.categoryTotals).map((key, i) => (
                        <Cell key={i} fill={CATEGORY_COLORS[key] ?? "#94a3b8"} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number) => formatINR(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1">
                  {Object.entries(stats.categoryTotals).map(([key, val]) => (
                    <div key={key} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: CATEGORY_COLORS[key] ?? "#94a3b8" }} />
                        <span className="text-muted-foreground">{CATEGORY_LABELS[key] ?? key}</span>
                      </div>
                      <span className="font-medium">{formatINR(val)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Sites */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="w-4 h-4 text-green-500" /> Active Sites
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!stats ? (
              <Skeleton className="h-48 w-full" />
            ) : stats.recentSites.length === 0 ? (
              <div className="text-muted-foreground text-sm text-center py-8">No active sites</div>
            ) : (
              <div className="space-y-2">
                {stats.recentSites.map((site) => (
                  <Link key={site._id} to={`/sites/${site._id}`} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent transition-colors cursor-pointer">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <div>
                        <p className="text-sm font-medium">{site.name}</p>
                        <p className="text-xs text-muted-foreground">{site.city}</p>
                      </div>
                    </div>
                    <Badge variant="default" className="text-xs">Active</Badge>
                  </Link>
                ))}
                <Link to="/sites" className="flex items-center justify-center p-2 text-xs text-muted-foreground hover:text-foreground transition-colors">
                  View all sites →
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Partners Section */}
      {stats && Object.keys(stats.partnersByCompany).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Handshake className="w-4 h-4 text-rose-500" /> Partners — Company Wise
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.entries(stats.partnersByCompany).map(([key, p]) => (
                <div key={key} className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-muted-foreground shrink-0" />
                    <div>
                      <p className="text-sm font-semibold">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.count} partner{p.count !== 1 ? "s" : ""}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs font-bold text-rose-600">
                    {p.totalShare}% share
                  </Badge>
                </div>
              ))}
            </div>
            <Link to="/partners" className="flex items-center justify-center mt-3 p-2 text-xs text-muted-foreground hover:text-foreground transition-colors">
              Manage Partners →
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: "Add Company", href: "/companies", icon: Building2, color: "text-blue-600" },
              { label: "New Site", href: "/sites", icon: MapPin, color: "text-green-600" },
              { label: "Add Labour", href: "/labour", icon: Users, color: "text-orange-600" },
              { label: "New Work Order", href: "/work-orders", icon: FileText, color: "text-purple-600" },
              { label: "Add Supplier", href: "/suppliers", icon: Truck, color: "text-sky-600" },
              { label: "New Invoice", href: "/invoices", icon: IndianRupee, color: "text-emerald-600" },
              { label: "Salary Sheet", href: "/salary", icon: IndianRupee, color: "text-yellow-600" },
              { label: "Site P&L", href: "/site-pnl", icon: Activity, color: "text-rose-600" },
            ].map((item) => (
              <Link key={item.href} to={item.href}
                className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent transition-colors cursor-pointer"
              >
                <item.icon className={cn("w-4 h-4 shrink-0", item.color)} />
                <span className="text-sm">{item.label}</span>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
