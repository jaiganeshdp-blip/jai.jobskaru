import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { Plus, FileText, ShoppingCart } from "lucide-react";
import { BillLineItemsEditor, type BillLineItem } from "./bill-line-items-editor.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const schema = z.object({
  billNumber: z.string().min(1, "Bill number required"),
  siteId: z.string().min(1, "Site required"),
  companyId: z.string().min(1, "Company required"),
  vendorType: z.enum(["supplier", "contractor"]),
  supplierId: z.string().optional(),
  contractorId: z.string().optional(),
  billDate: z.string().min(1, "Bill date required"),
  dueDate: z.string().optional(),
  subtotal: z.coerce.number().min(0),
  gstPercent: z.coerce.number().min(0).max(100),
  description: z.string().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type LinkedOrderType =
  | { type: "workOrder"; id: string; number: string; description: string; totalValue: number; items?: undefined }
  | { type: "purchaseOrder"; id: string; number: string; description: string; totalValue: number; items: Array<{ name: string; quantity: number; unit: string; ratePerUnit: number; totalAmount: number }> }
  | null;

export function CreateBillDialog() {
  const [open, setOpen] = useState(false);
  const [linkedOrder, setLinkedOrder] = useState<LinkedOrderType>(null);
  const [lineItems, setLineItems] = useState<BillLineItem[]>([]);

  const createBill = useMutation(api.vendorBills.create);
  const sites = useQuery(api.sites.list, {}) ?? [];
  const suppliers = useQuery(api.suppliers.list, {}) ?? [];
  const contractors = useQuery(api.contractors.list, {}) ?? [];
  const companies = useQuery(api.companies.list, {}) ?? [];
  const workOrders = useQuery(api.workOrders.list, {}) ?? [];
  const purchaseOrders = useQuery(api.purchaseOrders.list, {}) ?? [];

  const { register, handleSubmit, watch, setValue, reset, formState: { errors, isSubmitting } } =
    useForm<FormValues>({
      resolver: zodResolver(schema),
      defaultValues: { vendorType: "supplier", gstPercent: 18, subtotal: 0, billDate: new Date().toISOString().split("T")[0] },
    });

  const vendorType = watch("vendorType");
  const contractorId = watch("contractorId");
  const supplierId = watch("supplierId");
  const hasLineItems = lineItems.length > 0;
  const lineItemsSubtotal = lineItems.reduce((s, i) => s + (i.amount || 0), 0);
  const subtotal = hasLineItems ? lineItemsSubtotal : (Number(watch("subtotal") ?? 0) || 0);
  const gstPercent = Number(watch("gstPercent") ?? 0) || 0;
  const gstAmount = (subtotal * gstPercent) / 100;
  const total = subtotal + gstAmount;

  // For contractor: show all active/draft work orders
  const filteredWorkOrders = workOrders.filter((wo) => wo.status === "active" || wo.status === "draft");
  // For supplier: filter POs by selected supplier
  const supplierPOs = purchaseOrders.filter(
    (po) => supplierId && po.supplierId === supplierId
  );

  // Reset linked order when vendor changes
  useEffect(() => {
    setLinkedOrder(null);
  }, [contractorId, supplierId, vendorType]);

  function handleSelectWorkOrder(woId: string) {
    const wo = workOrders.find((w) => w._id === woId);
    if (!wo) return;
    setLinkedOrder({ type: "workOrder", id: woId, number: wo.orderNumber, description: wo.description, totalValue: wo.totalValue });
    setValue("subtotal", wo.totalValue);
    setValue("description", wo.description);
  }

  function handleSelectPO(poId: string) {
    const po = purchaseOrders.find((p) => p._id === poId);
    if (!po) return;
    setLinkedOrder({ type: "purchaseOrder", id: poId, number: po.poNumber, description: `PO: ${po.poNumber}`, totalValue: po.totalValue, items: po.items });
    setValue("subtotal", po.totalValue);
    setValue("description", `Purchase Order: ${po.poNumber}`);
  }

  const onSubmit = async (data: FormValues) => {
    try {
      await createBill({
        billNumber: data.billNumber,
        siteId: data.siteId as Id<"sites">,
        companyId: data.companyId as Id<"companies">,
        vendorType: data.vendorType,
        supplierId: data.supplierId as Id<"suppliers"> | undefined,
        contractorId: data.contractorId as Id<"contractors"> | undefined,
        purchaseOrderId: linkedOrder?.type === "purchaseOrder" ? linkedOrder.id as Id<"purchaseOrders"> : undefined,
        workOrderId: linkedOrder?.type === "workOrder" ? linkedOrder.id as Id<"workOrders"> : undefined,
        billDate: data.billDate,
        dueDate: data.dueDate || undefined,
        lineItems: hasLineItems ? lineItems : undefined,
        subtotal: hasLineItems ? lineItemsSubtotal : data.subtotal,
        gstPercent: data.gstPercent,
        description: data.description || undefined,
        notes: data.notes || undefined,
      });
      toast.success("Bill create ho gaya!");
      reset();
      setLinkedOrder(null);
      setLineItems([]);
      setOpen(false);
    } catch {
      toast.error("Bill create nahi hua, dobara try karein");
    }
  };

  const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-1" /> Add Bill
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Vendor Bill Banayein</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">

          {/* Bill Number + Date */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>Bill Number *</Label>
              <Input {...register("billNumber")} placeholder="BILL-001" />
              {errors.billNumber && <p className="text-xs text-destructive">{errors.billNumber.message}</p>}
            </div>
            <div className="space-y-1">
              <Label>Bill Date *</Label>
              <Input type="date" {...register("billDate")} />
            </div>
          </div>

          {/* Site + Company */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>Site *</Label>
              <Select onValueChange={(v) => setValue("siteId", v)}>
                <SelectTrigger><SelectValue placeholder="Site chunen" /></SelectTrigger>
                <SelectContent>
                  {sites.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
              {errors.siteId && <p className="text-xs text-destructive">{errors.siteId.message}</p>}
            </div>
            <div className="space-y-1">
              <Label>Company *</Label>
              <Select onValueChange={(v) => setValue("companyId", v)}>
                <SelectTrigger><SelectValue placeholder="Company chunen" /></SelectTrigger>
                <SelectContent>
                  {companies.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
              {errors.companyId && <p className="text-xs text-destructive">{errors.companyId.message}</p>}
            </div>
          </div>

          {/* Vendor Type */}
          <div className="space-y-1">
            <Label>Vendor Type *</Label>
            <Select
              defaultValue="supplier"
              onValueChange={(v) => {
                setValue("vendorType", v as "supplier" | "contractor");
                setValue("supplierId", undefined);
                setValue("contractorId", undefined);
              }}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="supplier">Supplier (Material)</SelectItem>
                <SelectItem value="contractor">Contractor (Work)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Vendor Selection */}
          {vendorType === "supplier" ? (
            <div className="space-y-1">
              <Label>Supplier *</Label>
              <Select onValueChange={(v) => setValue("supplierId", v)}>
                <SelectTrigger><SelectValue placeholder="Supplier chunen" /></SelectTrigger>
                <SelectContent>
                  {suppliers.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div className="space-y-1">
              <Label>Contractor *</Label>
              <Select onValueChange={(v) => setValue("contractorId", v)}>
                <SelectTrigger><SelectValue placeholder="Contractor chunen" /></SelectTrigger>
                <SelectContent>
                  {contractors.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Link to Work Order / PO */}
          {vendorType === "contractor" && contractorId && (
            <div className="space-y-2 rounded-lg border border-border p-3 bg-muted/30">
              <div className="flex items-center gap-2 text-sm font-medium">
                <FileText size={14} />
                Work Order se Link Karein (optional)
              </div>
              {filteredWorkOrders.length === 0 ? (
                <p className="text-xs text-muted-foreground">Koi active work order nahi mila.</p>
              ) : (
                <div className="space-y-2">
                  <Select onValueChange={handleSelectWorkOrder}>
                    <SelectTrigger><SelectValue placeholder="Work Order chunen..." /></SelectTrigger>
                    <SelectContent>
                      {filteredWorkOrders.map((wo) => (
                        <SelectItem key={wo._id} value={wo._id}>
                          {wo.orderNumber} — {fmt(wo.totalValue)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {linkedOrder?.type === "workOrder" && (
                    <div className="bg-green-50 border border-green-200 rounded-md p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-green-800">{linkedOrder.number}</span>
                        <Badge className="bg-green-100 text-green-700 text-xs">Work Order</Badge>
                      </div>
                      <p className="text-xs text-green-700">{linkedOrder.description}</p>
                      <div className="flex items-center justify-between border-t border-green-200 pt-2">
                        <span className="text-xs text-green-700 font-medium">Work Order Value</span>
                        <span className="text-sm font-bold text-green-800">{fmt(linkedOrder.totalValue)}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {vendorType === "supplier" && supplierId && (
            <div className="space-y-2 rounded-lg border border-border p-3 bg-muted/30">
              <div className="flex items-center gap-2 text-sm font-medium">
                <ShoppingCart size={14} />
                Purchase Order se Link Karein (optional)
              </div>
              {supplierPOs.length === 0 ? (
                <p className="text-xs text-muted-foreground">Is supplier ka koi purchase order nahi mila.</p>
              ) : (
                <div className="space-y-2">
                  <Select onValueChange={handleSelectPO}>
                    <SelectTrigger><SelectValue placeholder="Purchase Order chunen..." /></SelectTrigger>
                    <SelectContent>
                      {supplierPOs.map((po) => (
                        <SelectItem key={po._id} value={po._id}>
                          {po.poNumber} — {fmt(po.totalValue)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {linkedOrder?.type === "purchaseOrder" && linkedOrder.items && (
                    <div className="bg-blue-50 border border-blue-200 rounded-md p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-blue-800">{linkedOrder.number}</span>
                        <Badge className="bg-blue-100 text-blue-700 text-xs">Purchase Order</Badge>
                      </div>
                      {/* Items table */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-blue-200 text-blue-700">
                              <th className="text-left py-1 pr-2">Item</th>
                              <th className="text-right py-1 pr-2">Qty</th>
                              <th className="text-right py-1 pr-2">Unit</th>
                              <th className="text-right py-1 pr-2">Rate</th>
                              <th className="text-right py-1">Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            {linkedOrder.items.map((item, i) => (
                              <tr key={i} className="border-b border-blue-100 text-blue-800">
                                <td className="py-1 pr-2 font-medium">{item.name}</td>
                                <td className="text-right py-1 pr-2">{item.quantity}</td>
                                <td className="text-right py-1 pr-2">{item.unit}</td>
                                <td className="text-right py-1 pr-2">{fmt(item.ratePerUnit)}</td>
                                <td className="text-right py-1 font-semibold">{fmt(item.totalAmount)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="flex items-center justify-between border-t border-blue-200 pt-2">
                        <span className="text-xs text-blue-700 font-medium">PO Total</span>
                        <span className="text-sm font-bold text-blue-800">{fmt(linkedOrder.totalValue)}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <Separator />

          {/* Description */}
          <div className="space-y-1">
            <Label>Description</Label>
            <Input {...register("description")} placeholder="Kaam ya material ka description" />
          </div>

          {/* Line items */}
          <BillLineItemsEditor items={lineItems} onChange={setLineItems} />

          {/* Amounts */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label>Subtotal (₹) *</Label>
              {hasLineItems ? (
                <>
                  <Input readOnly value={lineItemsSubtotal.toFixed(2)} className="bg-muted" />
                  <p className="text-[11px] text-muted-foreground">Items se auto</p>
                </>
              ) : (
                <Input type="number" step="0.01" {...register("subtotal")} />
              )}
            </div>
            <div className="space-y-1">
              <Label>GST %</Label>
              <Input type="number" step="0.01" {...register("gstPercent")} />
            </div>
            <div className="space-y-1">
              <Label>Total (₹)</Label>
              <Input value={total.toFixed(2)} readOnly className="bg-muted font-semibold" />
            </div>
          </div>

          {/* Due Date + Notes */}
          <div className="space-y-1">
            <Label>Due Date</Label>
            <Input type="date" {...register("dueDate")} />
          </div>

          <div className="space-y-1">
            <Label>Notes</Label>
            <Textarea {...register("notes")} placeholder="Additional notes..." rows={2} />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => { reset(); setLinkedOrder(null); setLineItems([]); setOpen(false); }}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Create ho raha hai..." : "Create Bill"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
