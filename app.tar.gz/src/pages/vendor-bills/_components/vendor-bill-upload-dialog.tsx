/**
 * Vendor Bills Excel Upload Dialog
 * Parses an Excel file, resolves site/company/vendor IDs, previews rows, then bulk-imports.
 */
import { useState, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Upload, FileSpreadsheet, CheckCircle2, AlertTriangle, X } from "lucide-react";
import { toast } from "sonner";
import { parseVendorBillsExcel, type ParsedBillRow } from "../_lib/excel-utils.ts";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Props = { open: boolean; onClose: () => void };

export function VendorBillUploadDialog({ open, onClose }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<ParsedBillRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [done, setDone] = useState(false);

  const sites = useQuery(api.sites.list, {}) ?? [];
  const companies = useQuery(api.companies.list, {}) ?? [];
  const suppliers = useQuery(api.suppliers.list, {}) ?? [];
  const contractors = useQuery(api.contractors.list, {}) ?? [];

  const createBill = useMutation(api.vendorBills.create);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const parsed = await parseVendorBillsExcel(file);
      setRows(parsed);
      setDone(false);
    } catch {
      toast.error("Excel file padhne mein error. Sahi format ka file choose karein.");
    }
    // reset input
    e.target.value = "";
  };

  const validRows = rows.filter((r) => r.errors.length === 0);
  const errorRows = rows.filter((r) => r.errors.length > 0);

  const resolveIds = (row: ParsedBillRow): {
    siteId: Id<"sites"> | null;
    companyId: Id<"companies"> | null;
    supplierId: Id<"suppliers"> | undefined;
    contractorId: Id<"contractors"> | undefined;
  } => {
    const siteName = row.siteName.toLowerCase();
    const site = sites.find(
      (s) => s.name.toLowerCase().includes(siteName) || siteName.includes(s.name.toLowerCase())
    );
    const company = companies[0]; // default to first company
    const vendorName = row.vendorName.toLowerCase();
    let supplierId: Id<"suppliers"> | undefined = undefined;
    let contractorId: Id<"contractors"> | undefined = undefined;
    if (row.vendorType === "supplier") {
      const s = suppliers.find((x) => x.name.toLowerCase().includes(vendorName) || vendorName.includes(x.name.toLowerCase()));
      supplierId = s?._id;
    } else {
      const c = contractors.find((x) => x.name.toLowerCase().includes(vendorName) || vendorName.includes(x.name.toLowerCase()));
      contractorId = c?._id;
    }
    return {
      siteId: site?._id ?? null,
      companyId: company?._id ?? null,
      supplierId,
      contractorId,
    };
  };

  const handleImport = async () => {
    if (validRows.length === 0) return;
    setImporting(true);
    let success = 0;
    let failed = 0;
    for (const row of validRows) {
      const { siteId, companyId, supplierId, contractorId } = resolveIds(row);
      if (!siteId || !companyId) {
        failed++;
        continue;
      }
      try {
        await createBill({
          billNumber: row.billNumber,
          siteId,
          companyId,
          vendorType: (row.vendorType === "supplier" ? "supplier" : "contractor") as "supplier" | "contractor",
          supplierId,
          contractorId,
          billDate: row.billDate,
          dueDate: row.dueDate,
          subtotal: row.subtotal,
          gstPercent: row.gstPercent,
          description: row.description || undefined,
          notes: row.notes || undefined,
        });
        success++;
      } catch {
        failed++;
      }
    }
    setImporting(false);
    setDone(true);
    if (success > 0) toast.success(`${success} bill${success > 1 ? "s" : ""} successfully import kiye gaye!`);
    if (failed > 0) toast.error(`${failed} bill${failed > 1 ? "s" : ""} import nahi ho sake. Site/Company match nahi mili.`);
  };

  const handleClose = () => {
    setRows([]);
    setDone(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-green-600" />
            Excel se Bills Upload Karen
          </DialogTitle>
        </DialogHeader>

        {/* Upload area */}
        <div
          className="border-2 border-dashed border-muted-foreground/30 rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-muted/30 transition-colors"
          onClick={() => fileRef.current?.click()}
        >
          <Upload className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
          <p className="font-semibold text-sm">Excel file yahan click karke choose karein</p>
          <p className="text-xs text-muted-foreground mt-1">
            .xlsx / .xls format — "Upload Template" sheet ka format follow karein
          </p>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={handleFile}
          />
        </div>

        {rows.length > 0 && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="flex gap-3 flex-wrap">
              <Badge className="bg-slate-700 text-white gap-1 text-sm px-3 py-1">
                Total Rows: {rows.length}
              </Badge>
              <Badge className="bg-green-600 text-white gap-1 text-sm px-3 py-1">
                <CheckCircle2 className="w-3 h-3" /> Ready: {validRows.length}
              </Badge>
              {errorRows.length > 0 && (
                <Badge className="bg-red-600 text-white gap-1 text-sm px-3 py-1">
                  <AlertTriangle className="w-3 h-3" /> Errors: {errorRows.length}
                </Badge>
              )}
            </div>

            {/* Preview Table */}
            <div className="overflow-x-auto rounded-lg border">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-slate-800 text-white">
                    <th className="px-3 py-2 text-left whitespace-nowrap">Row</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Bill No.</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Date</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Vendor</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Site</th>
                    <th className="px-3 py-2 text-right whitespace-nowrap">Total (₹)</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Status</th>
                    <th className="px-3 py-2 text-left whitespace-nowrap">Errors</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr
                      key={i}
                      className={row.errors.length > 0 ? "bg-red-50 dark:bg-red-900/20" : "bg-green-50/30 dark:bg-green-900/10"}
                    >
                      <td className="px-3 py-2 font-mono">{row.rowIndex}</td>
                      <td className="px-3 py-2 font-semibold">{row.billNumber || "—"}</td>
                      <td className="px-3 py-2 whitespace-nowrap">{row.billDate || "—"}</td>
                      <td className="px-3 py-2 whitespace-nowrap">{row.vendorName || "—"}</td>
                      <td className="px-3 py-2 whitespace-nowrap">{row.siteName || "—"}</td>
                      <td className="px-3 py-2 text-right font-mono">
                        {row.totalAmount > 0 ? row.totalAmount.toLocaleString("en-IN") : "—"}
                      </td>
                      <td className="px-3 py-2 capitalize">{row.status}</td>
                      <td className="px-3 py-2">
                        {row.errors.length > 0 ? (
                          <span className="text-red-600 font-medium flex items-center gap-1">
                            <X className="w-3 h-3" /> {row.errors.join(", ")}
                          </span>
                        ) : (
                          <span className="text-green-600 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> OK
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {done ? (
              <div className="flex justify-center">
                <Button onClick={handleClose} className="gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Done — Page Close Karein
                </Button>
              </div>
            ) : (
              <div className="flex gap-3 justify-end">
                <Button variant="ghost" onClick={handleClose} className="cursor-pointer">
                  Cancel
                </Button>
                <Button
                  onClick={handleImport}
                  disabled={validRows.length === 0 || importing}
                  className="gap-2 cursor-pointer bg-green-700 hover:bg-green-800 text-white"
                >
                  <Upload className="w-4 h-4" />
                  {importing ? "Import ho raha hai..." : `${validRows.length} Bills Import Karen`}
                </Button>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
