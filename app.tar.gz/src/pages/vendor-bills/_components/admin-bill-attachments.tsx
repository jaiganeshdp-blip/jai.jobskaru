/**
 * Admin-side viewer for vendor bill attachments (photos, PDFs, Excel).
 * Shows files uploaded by vendors from their portal.
 */
import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import {
  Eye, FileText, Image as ImageIcon, FileSpreadsheet, Paperclip,
  X, Download, ZoomIn, ZoomOut, ChevronLeft, ChevronRight,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Attachment = {
  storageId: string;
  url: string | null;
  fileName: string;
  fileType: string;
  fileSize: number;
  uploadedAt: string;
};

function fileIcon(fileType: string) {
  if (fileType.startsWith("image/")) return <ImageIcon size={13} className="text-blue-500 shrink-0" />;
  if (fileType === "application/pdf") return <FileText size={13} className="text-red-500 shrink-0" />;
  return <FileSpreadsheet size={13} className="text-green-500 shrink-0" />;
}
function fileLabel(fileType: string) {
  if (fileType.startsWith("image/")) return "Photo";
  if (fileType === "application/pdf") return "PDF";
  return "Excel";
}
function isImage(ft: string) { return ft.startsWith("image/"); }
function isPDF(ft: string) { return ft === "application/pdf"; }

function FileViewer({
  attachments, startIndex, onClose,
}: { attachments: Attachment[]; startIndex: number; onClose: () => void }) {
  const [idx, setIdx] = useState(startIndex);
  const [imgZoom, setImgZoom] = useState(1);
  const current = attachments[idx];
  if (!current?.url) return null;
  const canPrev = idx > 0;
  const canNext = idx < attachments.length - 1;
  function go(d: number) { setIdx((i) => i + d); setImgZoom(1); }

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col" onClick={onClose}>
      <div
        className="flex items-center justify-between px-4 py-3 bg-gray-900 border-b border-gray-700 shrink-0"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 min-w-0">
          {fileIcon(current.fileType)}
          <span className="text-white text-sm font-semibold truncate max-w-[260px]">{current.fileName}</span>
          <span className="text-gray-400 text-xs shrink-0">({idx + 1}/{attachments.length})</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {isImage(current.fileType) && (
            <>
              <button onClick={() => setImgZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1.5 rounded bg-gray-700 hover:bg-gray-600 text-white cursor-pointer">
                <ZoomOut size={14} />
              </button>
              <span className="text-gray-300 text-xs w-10 text-center font-mono">{Math.round(imgZoom * 100)}%</span>
              <button onClick={() => setImgZoom((z) => Math.min(4, z + 0.25))}
                className="p-1.5 rounded bg-gray-700 hover:bg-gray-600 text-white cursor-pointer">
                <ZoomIn size={14} />
              </button>
            </>
          )}
          <a href={current.url} download={current.fileName} onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded cursor-pointer">
            <Download size={13} /> Download
          </a>
          <button onClick={onClose} className="p-1.5 rounded bg-red-700 hover:bg-red-600 text-white cursor-pointer">
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto flex items-center justify-center relative" onClick={(e) => e.stopPropagation()}>
        {isPDF(current.fileType) && (
          <iframe src={current.url} className="w-full h-full border-0" title={current.fileName}
            style={{ minHeight: "calc(100vh - 56px)" }} />
        )}
        {isImage(current.fileType) && (
          <div className="overflow-auto w-full h-full flex items-center justify-center p-4">
            <img src={current.url} alt={current.fileName}
              style={{ transform: `scale(${imgZoom})`, transformOrigin: "center", transition: "transform 0.2s" }}
              className="max-w-full object-contain rounded shadow-2xl" />
          </div>
        )}
        {!isPDF(current.fileType) && !isImage(current.fileType) && (
          <div className="text-center space-y-4 p-8">
            <FileSpreadsheet size={64} className="mx-auto text-green-400" />
            <p className="text-white text-lg font-bold">{current.fileName}</p>
            <p className="text-gray-400 text-sm">Excel file browser mein preview nahi hota.</p>
            <a href={current.url} download={current.fileName}
              className="inline-flex items-center gap-2 bg-green-700 hover:bg-green-600 text-white font-bold px-5 py-3 rounded-xl cursor-pointer">
              <Download size={16} /> Excel Download Karein
            </a>
          </div>
        )}
        {canPrev && (
          <button onClick={() => go(-1)}
            className="absolute left-3 top-1/2 -translate-y-1/2 bg-gray-800/80 hover:bg-gray-700 text-white p-2 rounded-full cursor-pointer shadow-xl">
            <ChevronLeft size={22} />
          </button>
        )}
        {canNext && (
          <button onClick={() => go(1)}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-gray-800/80 hover:bg-gray-700 text-white p-2 rounded-full cursor-pointer shadow-xl">
            <ChevronRight size={22} />
          </button>
        )}
      </div>
    </div>
  );
}

type Props = { billId: Id<"vendorBills"> };

export function AdminBillAttachments({ billId }: Props) {
  const [viewerIdx, setViewerIdx] = useState<number | null>(null);
  const attachments = (useQuery(api.vendorBills.getAttachmentUrls, { billId }) ?? []) as Attachment[];

  if (attachments.length === 0) return null;

  return (
    <>
      {viewerIdx !== null && (
        <FileViewer attachments={attachments} startIndex={viewerIdx} onClose={() => setViewerIdx(null)} />
      )}
      <div className="mt-3 pt-3 border-t border-border">
        <p className="text-xs text-muted-foreground font-semibold flex items-center gap-1 mb-2">
          <Paperclip size={12} /> Vendor ke uploaded documents ({attachments.length})
        </p>
        <div className="flex flex-wrap gap-2">
          {attachments.map((a, i) => (
            <button
              key={a.storageId}
              onClick={() => setViewerIdx(i)}
              className="flex items-center gap-1.5 bg-muted hover:bg-muted/80 border border-border rounded-lg px-3 py-1.5 text-xs font-medium cursor-pointer transition-colors"
            >
              {fileIcon(a.fileType)}
              <span className="truncate max-w-[140px]">{a.fileName}</span>
              <span className="text-muted-foreground shrink-0">{fileLabel(a.fileType)}</span>
              <Eye size={11} className="text-primary shrink-0" />
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
