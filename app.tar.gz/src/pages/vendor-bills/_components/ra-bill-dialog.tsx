import { useState, useEffect } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { AlertTriangle, FileSpreadsheet } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type RAItem = {
  srNo: number;
  description: string;
  unit: string;
  orderQty: number;
  thisBillQty: number;
  ratePerUnit: number;
  thisBillAmount: number;
};

type POItem = {
  name: string;
  quantity: number;
  unit: string;
  ratePerUnit: number;
  totalAmount: number;
};

export function RABillDialog() {
  const [open, setOpen] = useState(false);
  const [selectedPOId, setSelectedPOId] = useState<Id<"purchaseOrders"> | "">("");
  const [billType, setBillType] = useState<"ra" | "final">("ra");
  const [billNumber, setBillNumber] = useState("");
  const [billDate, setBillDate] = useState(new Date().toISOString().split("T")[0]);
  const [dueDate, setDueDate] = useState("");
  const [gstPercent, setGstPercent] = useState(18);
  const [retentionPercent, setRetentionPercent] = useState(5);
  const [notes, setNotes] = useState("");
  const [raItems, setRaItems] = useState<RAItem[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const createRABill = useMutation(api.vendorBills.createRABill);
  const purchaseOrders = useQuery(api.purchaseOrders.list, {}) ?? [];
  const prevBills = useQuery(
    api.vendorBills.listByPO,
    selectedPOId ? { purchaseOrderId: selectedPOId } : "skip"
  ) ?? [];

  const selectedPO = purchaseOrders.find((p) => p._id === selectedPOId);

  // Pre-populate items from PO when selected
  useEffect(() => {
    if (!selectedPO) { setRaItems([]); return; }
    const poItems: POItem[] = selectedPO.items ?? [];
    setRaItems(poItems.map((item, i) => ({
      srNo: i + 1,
      description: item.name,
      unit: item.unit,
      orderQty: item.quantity,
      thisBillQty: 0,
      ratePerUnit: item.ratePerUnit,
      thisBillAmount: 0,
    })));
  }, [selectedPOId]);

  // Per-item previous billed qty
  const prevQtyBySrNo: Record<number, number> = {};
  for (const bill of prevBills) {
    for (const item of bill.raBillItems ?? []) {
      prevQtyBySrNo[item.srNo] = (prevQtyBySrNo[item.srNo] ?? 0) + item.thisBillQty;
    }
  }

  // ---- Calculations ----
  const prevBilledTotal = prevBills.reduce((s, b) => s + b.subtotal, 0);
  const subtotal = raItems.reduce((s, i) => s + i.thisBillAmount, 0);
  const gstAmount = (subtotal * gstPercent) / 100;
  const grossTotal = subtotal + gstAmount;              // Bill amount before retention
  const retentionAmount = (grossTotal * retentionPercent) / 100;
  const balancePayable = grossTotal - retentionAmount;  // Net payable this bill
  const cumulative = prevBilledTotal + subtotal;
  const poValue = selectedPO?.totalValue ?? 0;
  const exceedsByAmount = cumulative - poValue;
  const isExceeding = exceedsByAmount > 0;
  const raNumber = prevBills.length + 1;

  function updateItem(srNo: number, value: number) {
    setRaItems((prev) =>
      prev.map((item) => {
        if (item.srNo !== srNo) return item;
        return { ...item, thisBillQty: value, thisBillAmount: value * item.ratePerUnit };
      })
    );
  }

  const fmt = (n: number) => `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

  async function handleSubmit() {
    if (!selectedPOId || !billNumber || !billDate || !selectedPO) {
      toast.error("PO, Bill Number aur Date zaroori hain");
      return;
    }
    if (subtotal === 0) {
      toast.error("Kam se kam ek item ki quantity daalni hogi");
      return;
    }
    setSubmitting(true);
    try {
      const result = await createRABill({
        billNumber,
        billDate,
        dueDate: dueDate || undefined,
        siteId: selectedPO.siteId as Id<"sites">,
        companyId: selectedPO.companyId as Id<"companies">,
        vendorType: selectedPO.supplierId ? "supplier" : "contractor",
        supplierId: selectedPO.supplierId as Id<"suppliers"> | undefined,
        contractorId: selectedPO.contractorId as Id<"contractors"> | undefined,
        purchaseOrderId: selectedPOId,
        billType,
        raBillItems: raItems.filter((i) => i.thisBillQty > 0),
        gstPercent,
        retentionPercent: retentionPercent || undefined,
        notes: notes || undefined,
      });
      if (result.warning) {
        toast.warning(result.warning);
      } else {
        toast.success(`${billType === "final" ? "Final Bill" : `RA-${raNumber}`} create ho gaya!`);
      }
      resetForm();
      setOpen(false);
    } catch (e) {
      toast.error("Error: " + String(e));
    } finally {
      setSubmitting(false);
    }
  }

  function resetForm() {
    setSelectedPOId("");
    setBillNumber("");
    setBillDate(new Date().toISOString().split("T")[0]);
    setDueDate("");
    setGstPercent(18);
    setRetentionPercent(5);
    setNotes("");
    setRaItems([]);
    setBillType("ra");
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
      <DialogTrigger asChild>
        <Button size="sm" variant="secondary" className="gap-2 cursor-pointer">
          <FileSpreadsheet size={14} /> RA / Final Bill
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[94vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet size={18} /> Running Account (RA) Bill
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5">

          {/* PO + Bill Type */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>Purchase Order *</Label>
              <Select value={selectedPOId} onValueChange={(v) => setSelectedPOId(v as Id<"purchaseOrders">)}>
                <SelectTrigger><SelectValue placeholder="PO chunen..." /></SelectTrigger>
                <SelectContent>
                  {purchaseOrders.map((po) => (
                    <SelectItem key={po._id} value={po._id}>
                      {po.poNumber} — {po.supplierName} — {fmt(po.totalValue)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Bill Type *</Label>
              <Select value={billType} onValueChange={(v) => setBillType(v as "ra" | "final")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ra">RA-{raNumber} (Running Account)</SelectItem>
                  <SelectItem value="final">Final Bill</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* PO Summary */}
          {selectedPO && (
            <div className="rounded-lg border bg-muted/30 p-3 grid grid-cols-4 gap-3 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">PO Number</p>
                <p className="font-semibold">{selectedPO.poNumber}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Vendor</p>
                <p className="font-semibold">{selectedPO.supplierName}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">PO Value</p>
                <p className="font-bold text-primary">{fmt(poValue)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pehle Billed ({prevBills.length} bills)</p>
                <p className="font-bold text-orange-600">{fmt(prevBilledTotal)}</p>
              </div>
            </div>
          )}

          {/* Previous bills history */}
          {prevBills.length > 0 && (
            <div className="flex gap-2 flex-wrap items-center">
              <span className="text-xs text-muted-foreground">Purane bills:</span>
              {prevBills.map((b) => (
                <Badge key={b._id} variant="secondary" className="text-xs gap-1">
                  {b.billType === "final" ? "Final" : `RA-${b.raNumber}`}
                  <span className="text-muted-foreground ml-1">{fmt(b.subtotal)}</span>
                </Badge>
              ))}
            </div>
          )}

          {/* Bill Number, Date, Due Date */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label>Bill Number *</Label>
              <Input value={billNumber} onChange={(e) => setBillNumber(e.target.value)} placeholder={`RA-00${raNumber}`} />
            </div>
            <div className="space-y-1">
              <Label>Bill Date *</Label>
              <Input type="date" value={billDate} onChange={(e) => setBillDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Due Date</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
          </div>

          {/* Items Table */}
          {raItems.length > 0 && (
            <div className="space-y-2">
              <Label>Item-wise Bill Quantity Bharein</Label>
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-muted text-muted-foreground">
                      <th className="px-2 py-2 text-left border-r font-semibold w-8">Sr</th>
                      <th className="px-2 py-2 text-left border-r font-semibold">Description</th>
                      <th className="px-2 py-2 text-center border-r font-semibold w-14">Unit</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-20">Order<br/>Qty</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-20 text-orange-600">Last Bill<br/>Qty</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-20">Total Bill<br/>Qty</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-20 text-blue-700">Balance<br/>Qty</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-24 bg-blue-50 text-blue-800">This Bill<br/>Qty ✎</th>
                      <th className="px-2 py-2 text-right border-r font-semibold w-24">Rate<br/>(₹)</th>
                      <th className="px-2 py-2 text-right font-semibold w-28 bg-green-50 text-green-800">This Bill<br/>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {raItems.map((item) => {
                      const prevQty = prevQtyBySrNo[item.srNo] ?? 0;
                      const totalBillQty = prevQty + item.thisBillQty;
                      const balanceQty = Math.max(0, item.orderQty - prevQty);
                      const isOver = item.thisBillQty > balanceQty && balanceQty > 0;
                      return (
                        <tr key={item.srNo} className="border-t hover:bg-muted/20">
                          <td className="px-2 py-2 text-muted-foreground border-r">{item.srNo}</td>
                          <td className="px-2 py-2 font-medium border-r max-w-[200px]">
                            <span title={item.description} className="block truncate">{item.description}</span>
                          </td>
                          <td className="px-2 py-2 text-center text-muted-foreground border-r">{item.unit}</td>
                          <td className="px-2 py-2 text-right border-r">{item.orderQty}</td>
                          <td className="px-2 py-2 text-right text-orange-600 border-r">{prevQty || "—"}</td>
                          <td className="px-2 py-2 text-right border-r">{totalBillQty || "—"}</td>
                          <td className={`px-2 py-2 text-right border-r font-semibold ${balanceQty <= 0 ? "text-red-500" : "text-blue-700"}`}>
                            {balanceQty}
                          </td>
                          <td className="px-2 py-2 bg-blue-50/50 border-r">
                            <div className="flex flex-col items-end gap-0.5">
                              <Input
                                type="number"
                                min={0}
                                step="0.01"
                                value={item.thisBillQty || ""}
                                placeholder="0"
                                onChange={(e) => updateItem(item.srNo, Number(e.target.value) || 0)}
                                className={`w-20 h-7 text-xs text-right ${isOver ? "border-red-500 bg-red-50" : "border-blue-300"}`}
                              />
                              {isOver && <span className="text-[10px] text-red-500">Balance se zyada!</span>}
                            </div>
                          </td>
                          <td className="px-2 py-2 text-right border-r font-medium">{fmt(item.ratePerUnit)}</td>
                          <td className={`px-2 py-2 text-right font-bold bg-green-50/50 ${item.thisBillAmount > 0 ? "text-green-700" : "text-muted-foreground"}`}>
                            {item.thisBillAmount > 0 ? fmt(item.thisBillAmount) : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 bg-muted/50 font-semibold">
                      <td colSpan={9} className="px-2 py-2 text-right border-r">Subtotal (Before GST)</td>
                      <td className="px-2 py-2 text-right text-green-700">{fmt(subtotal)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* GST + Retention + Summary */}
          {selectedPO && raItems.length > 0 && (
            <div className="grid grid-cols-2 gap-5">
              {/* Left: Settings */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label>GST %</Label>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      step="0.01"
                      value={gstPercent}
                      onChange={(e) => setGstPercent(Number(e.target.value) || 0)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>Retention %</Label>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      step="0.01"
                      value={retentionPercent}
                      onChange={(e) => setRetentionPercent(Number(e.target.value) || 0)}
                    />
                    <p className="text-xs text-muted-foreground">0 enter karein agar retention nahi hai</p>
                  </div>
                </div>
                <div className="space-y-1">
                  <Label>Notes (optional)</Label>
                  <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Koi remarks..." />
                </div>
              </div>

              {/* Right: Bill Summary */}
              <div className="rounded-lg border overflow-hidden text-sm">
                <div className="bg-muted px-3 py-2 font-semibold text-xs uppercase tracking-wide">
                  Bill Summary
                </div>
                <div className="divide-y">
                  <div className="flex justify-between px-3 py-2">
                    <span className="text-muted-foreground">Subtotal (Work Done)</span>
                    <span className="font-medium">{fmt(subtotal)}</span>
                  </div>
                  <div className="flex justify-between px-3 py-2">
                    <span className="text-muted-foreground">GST @ {gstPercent}%</span>
                    <span className="font-medium">+ {fmt(gstAmount)}</span>
                  </div>
                  <div className="flex justify-between px-3 py-2 bg-muted/30">
                    <span className="font-semibold">Gross Bill Amount</span>
                    <span className="font-bold">{fmt(grossTotal)}</span>
                  </div>
                  {retentionPercent > 0 && (
                    <div className="flex justify-between px-3 py-2 text-red-700">
                      <span className="font-medium">(-) Retention @ {retentionPercent}%</span>
                      <span className="font-semibold">− {fmt(retentionAmount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between px-3 py-2.5 bg-primary/5">
                    <span className="font-bold text-primary">Balance Payable</span>
                    <span className="font-bold text-primary text-base">{fmt(balancePayable)}</span>
                  </div>
                </div>
                <Separator />
                <div className="px-3 py-2 bg-muted/20 space-y-1 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>PO Value</span>
                    <span className="font-medium text-foreground">{fmt(poValue)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cumulative Billed (excl. GST)</span>
                    <span className={`font-semibold ${isExceeding ? "text-red-600" : "text-green-700"}`}>
                      {fmt(cumulative)} / {fmt(poValue)}
                    </span>
                  </div>
                  {poValue > 0 && (
                    <div className="w-full bg-muted rounded-full h-1.5 mt-1">
                      <div
                        className={`h-1.5 rounded-full ${isExceeding ? "bg-red-500" : "bg-green-500"}`}
                        style={{ width: `${Math.min(100, (cumulative / poValue) * 100)}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* PO Exceed Warning */}
          {isExceeding && (
            <div className="flex gap-2 items-start bg-red-50 border border-red-300 rounded-lg p-3 text-sm text-red-700">
              <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">PO Value se {fmt(exceedsByAmount)} zyada hai!</p>
                <p className="text-xs mt-0.5">Bill save ho jayega lekin PO amendment karni hogi. Quantity kam karein ya PO amend karein.</p>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => { resetForm(); setOpen(false); }}>Cancel</Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !selectedPOId || !billNumber || subtotal === 0}
              className="gap-2"
            >
              <FileSpreadsheet size={14} />
              {submitting ? "Save ho raha hai..." : `${billType === "final" ? "Final Bill" : `RA-${raNumber}`} Save Karein`}
            </Button>
          </div>

        </div>
      </DialogContent>
    </Dialog>
  );
}
