import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Plus, Trash2 } from "lucide-react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";

export type BillLineItem = {
  description: string;
  unit: string;
  quantity: number;
  ratePerUnit: number;
  amount: number;
};

type BillLineItemsEditorProps = {
  items: BillLineItem[];
  onChange: (items: BillLineItem[]) => void;
};

const UNIT_OPTIONS = ["nos", "sqft", "sqm", "rmt", "cum", "kg", "ton", "bag", "ltr", "job", "lumpsum"];

const EMPTY_ITEM: BillLineItem = { description: "", unit: "nos", quantity: 1, ratePerUnit: 0, amount: 0 };

/**
 * Editable table of invoice/bill line items.
 * Each row: description, unit, quantity, rate — amount auto-calculates (qty × rate).
 * Items can be picked from the Item Master catalog to prefill unit + rate.
 */
export function BillLineItemsEditor({ items, onChange }: BillLineItemsEditorProps) {
  const catalog = useQuery(api.catalogItems.list, { activeOnly: true }) ?? [];

  const updateItem = (index: number, patch: Partial<BillLineItem>) => {
    const next = items.map((it, i) => {
      if (i !== index) return it;
      const merged = { ...it, ...patch };
      merged.amount = Math.round((merged.quantity || 0) * (merged.ratePerUnit || 0) * 100) / 100;
      return merged;
    });
    onChange(next);
  };

  // When description matches a catalog item, auto-fill unit + rate (if rate not set).
  const applyCatalogMatch = (index: number, description: string) => {
    const match = catalog.find((c) => c.name.toLowerCase() === description.trim().toLowerCase());
    if (match) {
      const current = items[index];
      updateItem(index, {
        description: match.name,
        unit: match.defaultUnit,
        ratePerUnit: current.ratePerUnit > 0 ? current.ratePerUnit : match.defaultRate,
      });
    } else {
      updateItem(index, { description });
    }
  };

  const addItem = () => onChange([...items, { ...EMPTY_ITEM }]);
  const addFromCatalog = (catalogId: string) => {
    const match = catalog.find((c) => c._id === catalogId);
    if (!match) return;
    onChange([...items, {
      description: match.name,
      unit: match.defaultUnit,
      quantity: 1,
      ratePerUnit: match.defaultRate,
      amount: match.defaultRate,
    }]);
  };
  const removeItem = (index: number) => onChange(items.filter((_, i) => i !== index));

  const subtotal = items.reduce((s, i) => s + (i.amount || 0), 0);

  return (
    <div className="space-y-2 rounded-lg border border-border p-3 bg-muted/20">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <Label className="text-sm font-semibold">Bill Items</Label>
        <div className="flex items-center gap-2">
          {catalog.length > 0 && (
            <select
              className="h-7 rounded-md border border-input bg-background px-2 text-xs cursor-pointer max-w-[180px]"
              value=""
              onChange={(e) => { if (e.target.value) addFromCatalog(e.target.value); }}
            >
              <option value="">+ Catalog se add karein</option>
              {catalog.map((c) => (
                <option key={c._id} value={c._id}>{c.name} ({c.defaultUnit} · ₹{c.defaultRate})</option>
              ))}
            </select>
          )}
          <Button type="button" size="sm" variant="secondary" className="gap-1 h-7 cursor-pointer" onClick={addItem}>
            <Plus className="w-3 h-3" /> Item Add
          </Button>
        </div>
      </div>

      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground py-2">
          Koi item nahi. "Item Add" par click karke items daalein (item, unit, qty, rate), ya "Catalog se add karein" se ready item chunein. Ya neeche direct subtotal bhi daal sakte hain.
        </p>
      ) : (
        <div className="space-y-2">
          {/* Header (desktop) */}
          <div className="hidden md:grid grid-cols-[1fr_80px_70px_90px_100px_32px] gap-2 px-1 text-[11px] font-semibold text-muted-foreground">
            <span>Item / Description</span>
            <span>Unit</span>
            <span className="text-right">Qty</span>
            <span className="text-right">Rate ₹</span>
            <span className="text-right">Amount ₹</span>
            <span />
          </div>

          {items.map((item, index) => (
            <div
              key={index}
              className="grid grid-cols-2 md:grid-cols-[1fr_80px_70px_90px_100px_32px] gap-2 items-center border-b border-border/60 pb-2 md:pb-0 md:border-0"
            >
              <Input
                className="col-span-2 md:col-span-1 h-8 text-sm"
                placeholder="Item / kaam ka naam"
                list="catalog-item-names"
                value={item.description}
                onChange={(e) => applyCatalogMatch(index, e.target.value)}
              />
              <select
                className="h-8 rounded-md border border-input bg-background px-2 text-sm cursor-pointer"
                value={item.unit}
                onChange={(e) => updateItem(index, { unit: e.target.value })}
              >
                {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
              </select>
              <Input
                type="number"
                step="0.01"
                className="h-8 text-sm text-right"
                placeholder="Qty"
                value={item.quantity || ""}
                onChange={(e) => updateItem(index, { quantity: Number(e.target.value) || 0 })}
              />
              <Input
                type="number"
                step="0.01"
                className="h-8 text-sm text-right"
                placeholder="Rate"
                value={item.ratePerUnit || ""}
                onChange={(e) => updateItem(index, { ratePerUnit: Number(e.target.value) || 0 })}
              />
              <Input
                readOnly
                className="h-8 text-sm text-right bg-muted font-semibold"
                value={item.amount.toLocaleString("en-IN")}
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-destructive cursor-pointer"
                onClick={() => removeItem(index)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}

          {/* Shared datalist of catalog item names for autocomplete */}
          <datalist id="catalog-item-names">
            {catalog.map((c) => <option key={c._id} value={c.name} />)}
          </datalist>

          <div className="flex justify-end items-center gap-2 pt-1 text-sm">
            <span className="text-muted-foreground">Items Subtotal:</span>
            <span className="font-bold">₹{subtotal.toLocaleString("en-IN")}</span>
          </div>
        </div>
      )}
    </div>
  );
}
