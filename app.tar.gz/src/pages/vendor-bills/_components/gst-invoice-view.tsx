/**
 * GST Invoice View — matches the JAI GANESH INTERIOR TAX Invoice format.
 * Red company header, colored table header, bank details, GST declaration.
 * Supports print/download and file attachments (PDF, photo, Excel).
 */
import { useRef, useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Printer, Upload, Trash2, FileText, ImageIcon, FileSpreadsheet, Eye, Download } from "lucide-react";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { downloadInvoiceExcel } from "../_lib/invoice-excel.ts";

type Props = {
  billId: Id<"vendorBills">;
  open: boolean;
  onClose: () => void;
};

function numberToWords(num: number): string {
  if (num === 0) return "Zero Rupees Only";
  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  function cvt(n: number): string {
    if (n === 0) return "";
    if (n < 20) return ones[n] + " ";
    if (n < 100) return tens[Math.floor(n / 10)] + " " + ones[n % 10] + " ";
    return ones[Math.floor(n / 100)] + " Hundred " + cvt(n % 100);
  }
  const r = Math.floor(num);
  const p = Math.round((num - r) * 100);
  let result = "";
  const cr = Math.floor(r / 10000000);
  const lk = Math.floor((r % 10000000) / 100000);
  const th = Math.floor((r % 100000) / 1000);
  const rest = r % 1000;
  if (cr > 0) result += cvt(cr) + "Crore ";
  if (lk > 0) result += cvt(lk) + "Lakh ";
  if (th > 0) result += cvt(th) + "Thousand ";
  if (rest > 0) result += cvt(rest);
  result = result.trim() + " Rupees";
  if (p > 0) result += " and " + cvt(p).trim() + " Paise";
  return result + " Only";
}

function fmt(n: number) {
  return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fileIcon(type: string) {
  if (type.startsWith("image/")) return <ImageIcon className="w-4 h-4 text-blue-500" />;
  if (type === "application/pdf") return <FileText className="w-4 h-4 text-red-500" />;
  return <FileSpreadsheet className="w-4 h-4 text-green-600" />;
}

function formatBytes(b: number) {
  if (b < 1024) return b + " B";
  if (b < 1048576) return (b / 1024).toFixed(1) + " KB";
  return (b / 1048576).toFixed(1) + " MB";
}

export function GSTInvoiceView({ billId, open, onClose }: Props) {
  const printRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const bill = useQuery(api.vendorBills.get, { id: billId });
  const prevBills = useQuery(
    api.vendorBills.listByPO,
    bill?.purchaseOrderId ? { purchaseOrderId: bill.purchaseOrderId } : "skip"
  ) ?? [];
  const attachments = useQuery(api.vendorBills.getAttachmentUrls, { billId }) ?? [];

  const generateUploadUrl = useMutation(api.vendorBills.generateAttachmentUploadUrl);
  const addAttachment = useMutation(api.vendorBills.addAttachment);
  const removeAttachment = useMutation(api.vendorBills.removeAttachment);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl();
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await res.json() as { storageId: Id<"_storage"> };
      await addAttachment({
        billId,
        storageId,
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
      });
      toast.success(`${file.name} upload ho gaya!`);
    } catch {
      toast.error("File upload nahi ho saka. Dobara try karein.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const handleRemove = async (storageId: string) => {
    try {
      await removeAttachment({ billId, storageId: storageId as Id<"_storage"> });
      toast.success("File delete ho gaya");
    } catch {
      toast.error("Delete nahi ho saka");
    }
  };

  function handleExcelDownload() {
    if (!bill) return;
    const vendorEx = bill.supplier ?? bill.contractor;
    const siteEx = bill.site;
    const poEx = bill.po;
    const prevQtyMap: Record<number, number> = {};
    for (const b of prevBills) {
      if (b._id === billId) continue;
      if ((b.raNumber ?? 0) >= (bill.raNumber ?? 999)) continue;
      for (const item of b.raBillItems ?? []) {
        prevQtyMap[item.srNo] = (prevQtyMap[item.srNo] ?? 0) + item.thisBillQty;
      }
    }
    downloadInvoiceExcel({
      companyName: vendorEx?.name ?? "—",
      companyAddress: [(vendorEx as { address?: string } | null)?.address, (vendorEx as { city?: string } | null)?.city].filter(Boolean).join(", "),
      companyMobile: (vendorEx as { mobile?: string } | null)?.mobile ?? "—",
      companyGst: (vendorEx as { gstNumber?: string } | null)?.gstNumber ?? "—",
      companyPan: (vendorEx as { panNumber?: string } | null)?.panNumber ?? "—",
      bankName: (vendorEx as { bankName?: string } | null)?.bankName ?? "",
      accountNumber: (vendorEx as { accountNumber?: string } | null)?.accountNumber ?? "",
      ifscCode: (vendorEx as { ifscCode?: string } | null)?.ifscCode ?? "",
      billNumber: bill.billNumber,
      billDate: bill.billDate
        ? new Date(bill.billDate).toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" })
        : "—",
      poNumber: poEx?.poNumber ?? "—",
      poDate: poEx?.issueDate
        ? new Date(poEx.issueDate).toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" })
        : "—",
      location: siteEx?.city ?? "—",
      billToName: siteEx?.name ?? "—",
      billToAddress: (siteEx as { address?: string } | null)?.address ?? "",
      billToGstin: (bill.supplier as { gstNumber?: string } | null)?.gstNumber ?? "—",
      caseId: poEx?.poNumber ?? "—",
      workPeriod: bill.billDate
        ? new Date(bill.billDate).toLocaleDateString("en-IN", { month: "long", year: "numeric" }).toUpperCase()
        : "",
      descriptionOfWork: bill.description ?? siteEx?.name ?? "—",
      items: bill.raBillItems ?? [],
      prevQtyBySrNo: prevQtyMap,
      subtotal: bill.subtotal,
      gstPercent: bill.gstPercent,
      sgstAmount: bill.gstAmount / 2,
      cgstAmount: bill.gstAmount / 2,
      totalAmount: bill.totalAmount,
      retentionPercent: bill.retentionPercent,
      retentionAmount: bill.retentionAmount,
      balancePayable: bill.balancePayable ?? bill.totalAmount,
    });
    toast.success("Excel download shuru ho gaya!");
  }

  function handlePrint() {
    if (!printRef.current) return;
    const content = printRef.current.innerHTML;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`
      <html>
        <head>
          <title>TAX Invoice - ${bill?.billNumber ?? ""}</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
            body { padding: 16px; background: #fff; color: #000; font-size: 11px; }
            table { border-collapse: collapse; width: 100%; }
            td, th { border: 1px solid #555; padding: 3px 5px; font-size: 10px; }
            .red-header { background: #cc0000; color: #fff; font-size: 26px; font-weight: bold; padding: 8px 12px; }
            .mob-row { color: #cc0000; font-size: 11px; text-align: right; }
            .addr-row { color: #cc0000; font-size: 10px; text-align: center; padding: 3px; border-top: 1px solid #cc0000; border-bottom: 1px solid #cc0000; }
            .invoice-title { text-align: center; font-size: 14px; font-weight: bold; border: 2px solid #000; padding: 5px; background: #fff; }
            .items-header th { background: #4caf50; color: #000; font-weight: bold; text-align: center; font-size: 10px; }
            .items-header-yellow th { background: #ffff00; color: #000; font-weight: bold; text-align: center; font-size: 10px; }
            .bank-header td { background: #4caf50; color: #000; font-weight: bold; text-align: center; font-size: 12px; }
            .amount-words { color: #0000cc; font-style: italic; }
            .case-id { color: #cc6600; font-weight: bold; font-size: 12px; }
            .work-period { color: #000; background: #ffff00; font-weight: bold; font-size: 11px; }
            @media print { body { padding: 8px; } }
          </style>
        </head>
        <body>${content}</body>
      </html>
    `);
    w.document.close();
    w.focus();
    w.print();
    w.close();
  }

  if (!bill) return null;

  const vendor = bill.supplier ?? bill.contractor;
  const site = bill.site;
  const po = bill.po;

  // Build previous qty map
  const prevQtyBySrNo: Record<number, number> = {};
  for (const b of prevBills) {
    if (b._id === billId) continue;
    if ((b.raNumber ?? 0) >= (bill.raNumber ?? 999)) continue;
    for (const item of b.raBillItems ?? []) {
      prevQtyBySrNo[item.srNo] = (prevQtyBySrNo[item.srNo] ?? 0) + item.thisBillQty;
    }
  }

  const raItems = bill.raBillItems ?? [];
  // Normalize regular line items into the same shape as RA items for display
  const lineItems = (bill.lineItems ?? []).map((li, i) => ({
    srNo: i + 1,
    description: li.description,
    unit: li.unit,
    thisBillQty: li.quantity,
    ratePerUnit: li.ratePerUnit,
    thisBillAmount: li.amount,
  }));
  const items = raItems.length > 0 ? raItems : lineItems;
  const subtotal = bill.subtotal;
  const gstPercent = bill.gstPercent;
  const gstAmount = bill.gstAmount;
  const totalAmount = bill.totalAmount;
  const retentionAmount = bill.retentionAmount ?? 0;
  const balancePayable = bill.balancePayable ?? totalAmount;
  const halfGst = gstPercent / 2;
  const sgstAmount = gstAmount / 2;
  const cgstAmount = gstAmount / 2;

  const billDateFmt = bill.billDate
    ? new Date(bill.billDate).toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" })
    : "—";
  const poDateFmt = po?.issueDate
    ? new Date(po.issueDate).toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" })
    : "—";

  const vendorGst = (vendor as { gstNumber?: string } | null)?.gstNumber ?? "—";
  const vendorPan = (vendor as { panNumber?: string } | null)?.panNumber ?? "—";
  const vendorAddress = (vendor as { address?: string } | null)?.address ?? "";
  const vendorCity = (vendor as { city?: string } | null)?.city ?? "";
  const vendorMobile = (vendor as { mobile?: string } | null)?.mobile ?? "";
  const vendorBankName = (vendor as { bankName?: string } | null)?.bankName ?? "";
  const vendorAccount = (vendor as { accountNumber?: string } | null)?.accountNumber ?? "";
  const vendorIfsc = (vendor as { ifscCode?: string } | null)?.ifscCode ?? "";
  const vendorFullAddr = [vendorAddress, vendorCity].filter(Boolean).join(", ");

  // Company = the vendor (supplier/contractor) — their header at top
  const companyName = vendor?.name ?? "—";
  const workPeriod = bill.billDate
    ? new Date(bill.billDate).toLocaleDateString("en-IN", { month: "long", year: "numeric" }).toUpperCase()
    : "";

  // Bill to party = the site owner / client company
  const billToName = site?.name ?? "—";
  const billToAddress = (site as { address?: string } | null)?.address ?? "";
  const billToCity = (site as { city?: string } | null)?.city ?? "";

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent
        className="max-w-5xl max-h-[95vh] overflow-y-auto"
        style={{ background: "#fff", color: "#000" }}
      >
        <DialogHeader>
          <DialogTitle
            className="flex items-center justify-between"
            style={{ color: "#000", background: "#fff" }}
          >
            <span>TAX Invoice Preview</span>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleExcelDownload} className="gap-2 cursor-pointer bg-green-700 hover:bg-green-800 text-white">
                <Download size={14} /> Excel
              </Button>
              <Button size="sm" onClick={handlePrint} className="gap-2 cursor-pointer bg-red-600 hover:bg-red-700 text-white">
                <Printer size={14} /> Print / PDF
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        {/* ─── INVOICE BODY (printable) ─────────────────────────────── */}
        <div
          ref={printRef}
          style={{
            fontFamily: "Arial, sans-serif",
            fontSize: "11px",
            color: "#000",
            background: "#fff",
            border: "1px solid #aaa",
            padding: "0",
          }}
        >
          {/* ── COMPANY HEADER ── */}
          <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: 0 }}>
            <tbody>
              <tr>
                {/* Logo placeholder */}
                <td style={{ width: "80px", border: "1px solid #cc0000", padding: "6px", textAlign: "center", verticalAlign: "middle" }}>
                  <div style={{
                    width: "60px", height: "60px", border: "2px solid #cc0000",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    borderRadius: "8px", margin: "auto", background: "#fff3f3"
                  }}>
                    <span style={{ color: "#cc0000", fontWeight: "bold", fontSize: "20px" }}>
                      {companyName.slice(0, 2).toUpperCase()}
                    </span>
                  </div>
                </td>
                {/* Company name */}
                <td style={{ border: "1px solid #cc0000", padding: "8px 12px", verticalAlign: "middle" }}>
                  <div className="red-header" style={{
                    color: "#cc0000", fontSize: "26px", fontWeight: "bold",
                    textTransform: "uppercase", letterSpacing: "1px"
                  }}>
                    {companyName}
                  </div>
                </td>
                {/* Mobile */}
                <td style={{ border: "1px solid #cc0000", padding: "6px 10px", textAlign: "right", verticalAlign: "top", width: "200px" }}>
                  <div style={{ color: "#cc0000", fontWeight: "bold", fontSize: "11px" }}>
                    MOB: {vendorMobile || "—"}
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={3} style={{ borderLeft: "1px solid #cc0000", borderRight: "1px solid #cc0000", borderBottom: "1px solid #cc0000", padding: "3px 8px", textAlign: "center" }}>
                  <span style={{ color: "#cc0000", fontSize: "10px" }}>
                    {vendorFullAddr || "Address not set"}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>

          <div style={{ height: "6px" }} />

          {/* ── TAX INVOICE TITLE ── */}
          <div style={{
            textAlign: "center", fontSize: "14px", fontWeight: "bold",
            border: "2px solid #000", padding: "5px", background: "#fff",
            marginBottom: "4px"
          }}>
            TAX Invoice
          </div>

          {/* ── TOP HEADER: Invoice No, PO, Date, Location, GST, PAN ── */}
          <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
            <tbody>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 6px", width: "22%" }}><strong>Gst Invoice No.:</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", width: "22%" }}>{bill.billNumber}</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", width: "12%", textAlign: "right" }}><strong>PO. NO</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", color: "#0000cc", width: "16%" }}>{po?.poNumber ?? "—"}</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", width: "12%" }}><strong>PO. NO</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{po?.poNumber ?? "—"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>Date of Gst Invoice:</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{billDateFmt}</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", textAlign: "right" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>PO. DATE</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{poDateFmt}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>Reverse Charge (Y/N):</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>NO</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", textAlign: "right" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>Location</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{billToCity || site?.city || "—"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>State:</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>Maharashtra</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", textAlign: "right" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>Code</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>27</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>GST NO</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{vendorGst}</td>
                <td style={{ border: "1px solid #888", padding: "3px 6px", textAlign: "right" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}><strong>PAN NO</strong></td>
                <td style={{ border: "1px solid #888", padding: "3px 6px" }}>{vendorPan}</td>
              </tr>
            </tbody>
          </table>

          {/* ── BILL TO PARTY ── */}
          <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
            <tbody>
              <tr>
                <td colSpan={2} style={{ border: "1px solid #888", padding: "3px 8px", fontWeight: "bold", textAlign: "center", background: "#f9f9f9" }}>
                  Bill to Party
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "6px 8px", width: "60%", verticalAlign: "top" }}>
                  <div style={{ fontWeight: "bold", fontSize: "13px", textTransform: "uppercase" }}>
                    {billToName}
                  </div>
                  {billToAddress && <div style={{ marginTop: "2px", fontSize: "10px" }}>{billToAddress}</div>}
                  {billToCity && <div style={{ fontSize: "10px" }}>{billToCity}</div>}
                  <div style={{ marginTop: "4px", fontSize: "10px" }}>
                    <strong>GSTIN/Unique ID:</strong>{" "}
                    {(bill.supplier as { gstNumber?: string } | null)?.gstNumber ?? "—"}
                  </div>
                  <div style={{ marginTop: "6px", borderTop: "1px solid #ccc", paddingTop: "4px", fontSize: "10px" }}>
                    <strong>Place of Supply/Services:</strong><br />
                    State: Maharashtra &nbsp;&nbsp; Code 27
                  </div>
                </td>
                <td style={{ border: "1px solid #888", padding: "6px 8px", verticalAlign: "top" }}>
                  <div style={{ fontWeight: "bold", color: "#cc6600", fontSize: "11px" }}>Case ID:</div>
                  <div style={{ fontSize: "13px", fontWeight: "bold", color: "#cc6600" }}>
                    {po?.poNumber ?? "—"}
                  </div>
                  <div style={{ marginTop: "8px" }}>
                    <span style={{ background: "#ffff00", fontWeight: "bold", padding: "2px 6px", fontSize: "11px" }}>
                      work period: -{workPeriod}
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={2} style={{ border: "1px solid #888", padding: "3px 8px", fontSize: "10px" }}>
                  <strong>Description of Work/Supply:</strong>{" "}
                  {bill.description ?? site?.name ?? "—"}
                  {bill.billType === "ra" && ` — RA-${bill.raNumber ?? ""}`}
                  {po?.poNumber && ` — PO: ${po.poNumber}`}
                  {bill.contractorId ? " (Portal)" : ""}
                </td>
              </tr>
            </tbody>
          </table>

          {/* ── ITEMS TABLE ── */}
          <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
            <thead>
              {/* Green header row */}
              <tr style={{ background: "#4caf50" }}>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "4%" }}>S. No</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "5%" }}>ITME</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "7%" }}>HSN/SAC</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "28%" }}>Description of Work</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "9%" }}>Previous<br />BILL QTY</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "9%" }}>Present bill<br />Qty</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "9%" }}>Cumulative<br />Bill Qty</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "8%" }}>Rate</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "6%" }}>Unit</th>
                <th style={{ border: "1px solid #555", padding: "4px 4px", textAlign: "center", fontSize: "10px", width: "15%" }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, idx) => {
                const prevQty = prevQtyBySrNo[item.srNo] ?? 0;
                const cumQty = prevQty + item.thisBillQty;
                return (
                  <tr key={item.srNo} style={{ background: idx % 2 === 0 ? "#fff" : "#f9fff9" }}>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "center" }}>{idx + 1}</td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "center" }}>{(idx + 1) * 10}</td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "center" }}>—</td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", fontSize: "10px" }}>{item.description}</td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "right" }}>
                      {prevQty > 0 ? fmt(prevQty) : "0.000"}
                    </td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "right" }}>
                      {fmt(item.thisBillQty)}
                    </td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "right" }}>
                      {fmt(cumQty)}
                    </td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "right" }}>
                      {fmt(item.ratePerUnit)}
                    </td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "center" }}>{item.unit}</td>
                    <td style={{ border: "1px solid #ccc", padding: "3px 4px", textAlign: "right", fontWeight: "bold" }}>
                      {fmt(item.thisBillAmount)}
                    </td>
                  </tr>
                );
              })}
              {items.length === 0 && (
                <tr>
                  <td colSpan={10} style={{ border: "1px solid #ccc", padding: "8px", textAlign: "center", color: "#888" }}>
                    No items — Regular Bill
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* ── TAX BREAKDOWN ── */}
          <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
            <tbody>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", width: "70%", textAlign: "right" }}>
                  <strong>Total Amount before Tax</strong>
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontWeight: "bold" }}>
                  {fmt(subtotal)}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>
                  Add: SGST {halfGst}%
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>
                  {fmt(sgstAmount)}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>
                  Add: CGST {halfGst}%
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>
                  {fmt(cgstAmount)}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>
                  Add: IGST 18%
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right" }}>-</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontWeight: "bold", background: "#fffde7" }}>
                  <strong>Total Amount after Tax</strong>
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontWeight: "bold", background: "#fffde7", fontSize: "13px" }}>
                  {fmt(totalAmount)}
                </td>
              </tr>
              {retentionAmount > 0 && (
                <>
                  <tr>
                    <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", color: "#c0392b" }}>
                      (-) Retention @ {bill.retentionPercent}%
                    </td>
                    <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", color: "#c0392b" }}>
                      − {fmt(retentionAmount)}
                    </td>
                  </tr>
                  <tr>
                    <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontWeight: "bold", background: "#e8f5e9" }}>
                      <strong>Balance Payable</strong>
                    </td>
                    <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontWeight: "bold", background: "#e8f5e9", fontSize: "13px" }}>
                      {fmt(balancePayable)}
                    </td>
                  </tr>
                </>
              )}
              <tr>
                <td style={{ border: "1px solid #888", padding: "3px 8px", textAlign: "right", fontSize: "10px" }}>
                  GST on Reverse C
                </td>
                <td style={{ border: "1px solid #888", padding: "3px 8px" }}></td>
              </tr>
            </tbody>
          </table>

          {/* ── AMOUNT IN WORDS ── */}
          <div style={{ border: "1px solid #888", padding: "4px 8px", marginBottom: "3px", fontSize: "11px" }}>
            <strong>Amount in words: </strong>
            <span style={{ color: "#0000cc", fontStyle: "italic" }}>
              {numberToWords(balancePayable > 0 ? balancePayable : totalAmount)}
            </span>
          </div>

          {/* ── GST DECLARATION ── */}
          <div style={{ border: "1px solid #888", padding: "4px 8px", fontSize: "9px", color: "#444", marginBottom: "3px" }}>
            <strong>GST DECLERATION:</strong><br />
            {'" V We hereby certify that my/our registration certificate under the GST Act 2017 is in force on the date on which the sale of goods specified in this tax invoice is made by me/us and that the transaction of sale covered by this tax invoice has been effected by me/us and it shall be accountable later in the turnover of sales while filing of return and the due tax, if any, payable on the sale has been paid and shall be paid"'}
          </div>

          {/* ── BANK DETAILS ── */}
          {(vendorBankName || vendorAccount || vendorIfsc) && (
            <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
              <tbody>
                <tr>
                  <td colSpan={2} style={{ border: "1px solid #555", padding: "4px 8px", background: "#4caf50", fontWeight: "bold", textAlign: "center", fontSize: "12px" }}>
                    BANK DETAILS
                  </td>
                </tr>
                <tr>
                  <td style={{ border: "1px solid #888", padding: "3px 8px", width: "50%" }}>
                    <strong>NAME :</strong> {companyName}
                  </td>
                  <td style={{ border: "1px solid #888", padding: "3px 8px" }} rowSpan={4}>
                    {/* Signature area */}
                    <div style={{ textAlign: "center", paddingTop: "20px", fontSize: "10px", color: "#555" }}>
                      Authorised Signatory
                    </div>
                  </td>
                </tr>
                <tr>
                  <td style={{ border: "1px solid #888", padding: "3px 8px" }}>
                    <strong>ACCOUNT NO :</strong> {vendorAccount || "—"}
                  </td>
                </tr>
                <tr>
                  <td style={{ border: "1px solid #888", padding: "3px 8px" }}>
                    <strong>IFSC CODE :</strong> {vendorIfsc || "—"}
                  </td>
                </tr>
                <tr>
                  <td style={{ border: "1px solid #888", padding: "3px 8px" }}>
                    <strong>Branch :</strong> {vendorBankName || "—"}
                  </td>
                </tr>
              </tbody>
            </table>
          )}

          {/* ── SIGNATURE ROW (if no bank details) ── */}
          {!(vendorBankName || vendorAccount || vendorIfsc) && (
            <table style={{ borderCollapse: "collapse", width: "100%", marginBottom: "3px" }}>
              <tbody>
                <tr>
                  <td style={{ border: "1px solid #888", padding: "8px", width: "50%", height: "50px", verticalAlign: "bottom", fontSize: "10px" }}>
                    Prepared by: _______________
                  </td>
                  <td style={{ border: "1px solid #888", padding: "8px", width: "50%", height: "50px", verticalAlign: "bottom", textAlign: "right", fontSize: "10px" }}>
                    Authorised Signatory for {companyName}
                  </td>
                </tr>
              </tbody>
            </table>
          )}

          <div style={{ fontSize: "9px", color: "#888", textAlign: "center", padding: "3px" }}>
            Subject to MUMBAI Jurisdiction Only.
          </div>
        </div>
        {/* ─── END INVOICE BODY ─────────────────────────────── */}

        {/* ─── ATTACHMENTS SECTION (not printed) ─────────────── */}
        <div className="mt-4 border rounded-xl p-4 space-y-3" style={{ background: "#f8fafc" }}>
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Bill Attachments — PDF / Photo / Excel Upload
            </h3>
            <Button
              size="sm"
              className="gap-1.5 cursor-pointer bg-green-700 hover:bg-green-800 text-white text-xs"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
            >
              <Upload className="w-3 h-3" />
              {uploading ? "Upload ho raha hai..." : "File Upload Karen"}
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*,application/pdf,.xlsx,.xls,.csv"
              className="hidden"
              onChange={handleUpload}
            />
          </div>

          <p className="text-xs text-slate-500">
            Bill ki photo, PDF copy, ya Excel sheet yahan upload karein. Sab files secure save hoti hain.
          </p>

          {attachments.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-lg">
              Koi attachment nahi hai. Upar button se file upload karein.
            </div>
          ) : (
            <div className="space-y-2">
              {attachments.map((att) => (
                <div
                  key={att.storageId}
                  className="flex items-center gap-3 p-2.5 bg-white rounded-lg border border-slate-200"
                >
                  {fileIcon(att.fileType)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">{att.fileName}</p>
                    <p className="text-xs text-slate-400">
                      {formatBytes(att.fileSize)} &bull; {new Date(att.uploadedAt).toLocaleDateString("en-IN")}
                    </p>
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    {att.url && (
                      <Badge
                        className="cursor-pointer gap-1 text-xs bg-blue-50 text-blue-700 hover:bg-blue-100 border-0"
                        onClick={() => window.open(att.url!, "_blank")}
                      >
                        <Eye className="w-3 h-3" /> View
                      </Badge>
                    )}
                    <Badge
                      className="cursor-pointer gap-1 text-xs bg-red-50 text-red-600 hover:bg-red-100 border-0"
                      onClick={() => handleRemove(att.storageId)}
                    >
                      <Trash2 className="w-3 h-3" /> Delete
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
