import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { BillLineItemsEditor, type BillLineItem } from "./bill-line-items-editor.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const schema = z.object({
  billNumber: z.string().min(1, "Bill number required"),
  siteId: z.string().min(1, "Site required"),
  companyId: z.string().min(1, "Company required"),
  vendorType: z.enum(["supplier", "contractor"]),
  supplierId: z.string().optional(),
  contractorId: z.string().optional(),
  billDate: z.string().min(1, "Bill date required"),
  dueDate: z.string().optional(),
  subtotal: z.coerce.number().min(0),
  gstPercent: z.coerce.number().min(0).max(100),
  description: z.string().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type EditBillDialogProps = {
  billId: Id<"vendorBills">;
  open: boolean;
  onClose: () => void;
};

export function EditBillDialog({ billId, open, onClose }: EditBillDialogProps) {
  const [lineItems, setLineItems] = useState<BillLineItem[]>([]);
  const updateBill = useMutation(api.vendorBills.update);
  const bill = useQuery(api.vendorBills.get, { id: billId });
  const sites = useQuery(api.sites.list, {}) ?? [];
  const suppliers = useQuery(api.suppliers.list, {}) ?? [];
  const contractors = useQuery(api.contractors.list, {}) ?? [];
  const companies = useQuery(api.companies.list, {}) ?? [];

  const { register, handleSubmit, watch, setValue, reset, formState: { errors, isSubmitting } } =
    useForm<FormValues>({
      resolver: zodResolver(schema),
      defaultValues: { vendorType: "supplier", gstPercent: 18, subtotal: 0 },
    });

  // Load current bill values into the form
  useEffect(() => {
    if (!bill) return;
    reset({
      billNumber: bill.billNumber,
      siteId: bill.siteId,
      companyId: bill.companyId,
      vendorType: bill.vendorType,
      supplierId: bill.supplierId ?? undefined,
      contractorId: bill.contractorId ?? undefined,
      billDate: bill.billDate,
      dueDate: bill.dueDate ?? undefined,
      subtotal: bill.subtotal,
      gstPercent: bill.gstPercent,
      description: bill.description ?? undefined,
      notes: bill.notes ?? undefined,
    });
    setLineItems(bill.lineItems ?? []);
  }, [bill, reset]);

  const vendorType = watch("vendorType");
  const siteId = watch("siteId");
  const companyId = watch("companyId");
  const supplierId = watch("supplierId");
  const contractorId = watch("contractorId");
  const hasLineItems = lineItems.length > 0;
  const lineItemsSubtotal = lineItems.reduce((s, i) => s + (i.amount || 0), 0);
  const subtotal = hasLineItems ? lineItemsSubtotal : (Number(watch("subtotal") ?? 0) || 0);
  const gstPercent = Number(watch("gstPercent") ?? 0) || 0;
  const total = subtotal + (subtotal * gstPercent) / 100;

  const isRABill = bill?.billType === "ra" || bill?.billType === "final";

  const onSubmit = async (data: FormValues) => {
    try {
      await updateBill({
        id: billId,
        billNumber: data.billNumber,
        siteId: data.siteId as Id<"sites">,
        companyId: data.companyId as Id<"companies">,
        vendorType: data.vendorType,
        supplierId: data.vendorType === "supplier" ? (data.supplierId as Id<"suppliers"> | undefined) : undefined,
        contractorId: data.vendorType === "contractor" ? (data.contractorId as Id<"contractors"> | undefined) : undefined,
        billDate: data.billDate,
        dueDate: data.dueDate || undefined,
        lineItems: isRABill ? undefined : (hasLineItems ? lineItems : undefined),
        subtotal: hasLineItems ? lineItemsSubtotal : data.subtotal,
        gstPercent: data.gstPercent,
        description: data.description || undefined,
        notes: data.notes || undefined,
      });
      toast.success("Bill update ho gaya!");
      onClose();
    } catch {
      toast.error("Update nahi hua, dobara try karein");
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bill / Invoice Edit Karein</DialogTitle>
        </DialogHeader>

        {bill === undefined ? (
          <p className="text-sm text-muted-foreground py-8 text-center">Loading...</p>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {isRABill && (
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/40 p-3 text-xs text-amber-700 dark:text-amber-400">
                Yeh RA/Final bill hai. Yahan basic details edit ho sakti hain; item-wise amount recalc nahi hoga.
              </div>
            )}

            {/* Bill Number + Date */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Bill Number *</Label>
                <Input {...register("billNumber")} placeholder="BILL-001" />
                {errors.billNumber && <p className="text-xs text-destructive">{errors.billNumber.message}</p>}
              </div>
              <div className="space-y-1">
                <Label>Bill Date *</Label>
                <Input type="date" {...register("billDate")} />
              </div>
            </div>

            {/* Site + Company */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Site *</Label>
                <Select value={siteId} onValueChange={(val) => setValue("siteId", val)}>
                  <SelectTrigger><SelectValue placeholder="Site chunen" /></SelectTrigger>
                  <SelectContent>
                    {sites.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {errors.siteId && <p className="text-xs text-destructive">{errors.siteId.message}</p>}
              </div>
              <div className="space-y-1">
                <Label>Company *</Label>
                <Select value={companyId} onValueChange={(val) => setValue("companyId", val)}>
                  <SelectTrigger><SelectValue placeholder="Company chunen" /></SelectTrigger>
                  <SelectContent>
                    {companies.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {errors.companyId && <p className="text-xs text-destructive">{errors.companyId.message}</p>}
              </div>
            </div>

            {/* Vendor Type */}
            <div className="space-y-1">
              <Label>Vendor Type *</Label>
              <Select
                value={vendorType}
                onValueChange={(val) => {
                  setValue("vendorType", val as "supplier" | "contractor");
                }}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="supplier">Supplier (Material)</SelectItem>
                  <SelectItem value="contractor">Contractor (Work)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Vendor Selection */}
            {vendorType === "supplier" ? (
              <div className="space-y-1">
                <Label>Supplier</Label>
                <Select value={supplierId} onValueChange={(val) => setValue("supplierId", val)}>
                  <SelectTrigger><SelectValue placeholder="Supplier chunen" /></SelectTrigger>
                  <SelectContent>
                    {suppliers.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="space-y-1">
                <Label>Contractor</Label>
                <Select value={contractorId} onValueChange={(val) => setValue("contractorId", val)}>
                  <SelectTrigger><SelectValue placeholder="Contractor chunen" /></SelectTrigger>
                  <SelectContent>
                    {contractors.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}

            <Separator />

            {/* Description */}
            <div className="space-y-1">
              <Label>Description</Label>
              <Input {...register("description")} placeholder="Kaam ya material ka description" />
            </div>

            {/* Line items (regular bills only) */}
            {!isRABill && <BillLineItemsEditor items={lineItems} onChange={setLineItems} />}

            {/* Amounts */}
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label>Subtotal (₹) *</Label>
                {hasLineItems || isRABill ? (
                  <>
                    <Input readOnly value={subtotal.toFixed(2)} className="bg-muted" />
                    <p className="text-[11px] text-muted-foreground">{isRABill ? "RA items se" : "Items se auto"}</p>
                  </>
                ) : (
                  <Input type="number" step="0.01" {...register("subtotal")} />
                )}
              </div>
              <div className="space-y-1">
                <Label>GST %</Label>
                <Input type="number" step="0.01" {...register("gstPercent")} />
              </div>
              <div className="space-y-1">
                <Label>Total (₹)</Label>
                <Input value={total.toFixed(2)} readOnly className="bg-muted font-semibold" />
              </div>
            </div>

            {/* Due Date + Notes */}
            <div className="space-y-1">
              <Label>Due Date</Label>
              <Input type="date" {...register("dueDate")} />
            </div>

            <div className="space-y-1">
              <Label>Notes</Label>
              <Textarea {...register("notes")} placeholder="Additional notes..." rows={2} />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Save ho raha hai..." : "Save Changes"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
