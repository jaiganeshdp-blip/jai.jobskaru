import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { toast } from "sonner";
import { CreateBillDialog } from "./_components/create-bill-dialog.tsx";
import { RABillDialog } from "./_components/ra-bill-dialog.tsx";
import { RecordPaymentDialog } from "./_components/record-payment-dialog.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { Receipt, IndianRupee, AlertCircle, CheckCircle2, Clock, Search, FileText, BellRing, Download, Upload, Pencil } from "lucide-react";
import { GSTInvoiceView } from "./_components/gst-invoice-view.tsx";
import { AdminBillAttachments } from "./_components/admin-bill-attachments.tsx";
import { EditBillDialog } from "./_components/edit-bill-dialog.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar } from "@/components/bulk-delete-bar.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { downloadVendorBillsExcel } from "./_lib/excel-utils.ts";
import { VendorBillUploadDialog } from "./_components/vendor-bill-upload-dialog.tsx";

const STATUS_COLORS: Record<string, string> = {
  received: "bg-blue-500/15 text-blue-600",
  verified: "bg-yellow-500/15 text-yellow-600",
  approved: "bg-purple-500/15 text-purple-600",
  paid: "bg-green-500/15 text-green-600",
  disputed: "bg-red-500/15 text-red-600",
};

const STATUS_LABELS: Record<string, string> = {
  received: "Received",
  verified: "Verified",
  approved: "Approved",
  paid: "Paid",
  disputed: "Disputed",
};

const NEXT_STATUS: Record<string, string> = {
  received: "verified",
  verified: "approved",
  approved: "paid",
};

function VendorBillsInner() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentTarget, setPaymentTarget] = useState<{ id: Id<"vendorBills">; outstanding: number } | null>(null);
  const [invoiceViewId, setInvoiceViewId] = useState<Id<"vendorBills"> | null>(null);
  const [editBillId, setEditBillId] = useState<Id<"vendorBills"> | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [uploadOpen, setUploadOpen] = useState(false);
  const updateStatus = useMutation(api.vendorBills.updateStatus);
  const removeBill = useMutation(api.vendorBills.remove);

  const bills = useQuery(api.vendorBills.list, {
    status: statusFilter !== "all" ? statusFilter : undefined,
  }) ?? undefined;

  // Bills pending admin review (newly submitted by contractors/suppliers)
  const pendingBills = useQuery(api.vendorBills.list, { status: "received" }) ?? [];

  const summary = useQuery(api.vendorBills.summary, {});

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());

  const filtered = (bills ?? []).filter((b) => {
    const vendorName = (b.supplierName ?? b.contractorName ?? "").toLowerCase();
    const billNum = b.billNumber.toLowerCase();
    const q = search.toLowerCase();
    return vendorName.includes(q) || billNum.includes(q);
  });

  const allFilteredSelected = filtered.length > 0 && filtered.every((b) => selectedIds.has(b._id));
  const toggleAll = () => {
    if (allFilteredSelected) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((b) => next.delete(b._id));
        return next;
      });
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((b) => next.add(b._id));
        return next;
      });
    }
  };

  const handleBulkDelete = async () => {
    const ids = Array.from(selectedIds);
    await Promise.all(ids.map((id) => removeBill({ id: id as Id<"vendorBills"> })));
    toast.success(`Deleted ${ids.length} bill${ids.length !== 1 ? "s" : ""}`);
    clearSelection();
  };

  const handleAdvanceStatus = async (id: Id<"vendorBills">, currentStatus: string) => {
    const next = NEXT_STATUS[currentStatus];
    if (!next) return;
    try {
      await updateStatus({ id, status: next as "verified" | "approved" | "paid" });
      toast.success(`Bill marked as ${STATUS_LABELS[next]}`);
    } catch {
      toast.error("Failed to update status");
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Vendor Bills</h1>
          <p className="text-sm text-muted-foreground">Track bills from suppliers and contractors</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            onClick={() => downloadVendorBillsExcel(filtered.length > 0 ? filtered : (bills ?? []))}
          >
            <Download className="w-4 h-4" /> Excel Download
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="gap-1.5 cursor-pointer"
            onClick={() => setUploadOpen(true)}
          >
            <Upload className="w-4 h-4" /> Excel Upload
          </Button>
          <RABillDialog />
          <CreateBillDialog />
        </div>
      </div>

      {/* Pending Approval Alert Banner */}
      {pendingBills.length > 0 && (
        <div
          className="flex items-center gap-3 p-4 rounded-lg bg-amber-500/10 border border-amber-500/40 cursor-pointer hover:bg-amber-500/20 transition-colors"
          onClick={() => setStatusFilter("received")}
        >
          <BellRing className="w-5 h-5 text-amber-500 shrink-0 animate-bounce" />
          <div className="flex-1">
            <p className="font-bold text-amber-700 dark:text-amber-400">
              {pendingBills.length} Bill{pendingBills.length > 1 ? "s" : ""} Pending Approval
            </p>
            <p className="text-xs text-amber-600 dark:text-amber-500 mt-0.5">
              {pendingBills.map((b) => `${b.billNumber} – ${b.supplierName ?? b.contractorName ?? "—"}`).join(" | ")}
            </p>
          </div>
          <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-white text-xs cursor-pointer shrink-0">
            Review Now
          </Button>
        </div>
      )}

      {/* Summary Cards */}
      {summary ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-1 pt-4 px-4">
              <CardTitle className="text-xs text-muted-foreground font-normal">Total Bills</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="flex items-center gap-1">
                <Receipt className="w-4 h-4 text-muted-foreground" />
                <span className="text-2xl font-bold">{summary.totalBills}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-1 pt-4 px-4">
              <CardTitle className="text-xs text-muted-foreground font-normal">Total Billed</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="flex items-center gap-1">
                <IndianRupee className="w-4 h-4 text-muted-foreground" />
                <span className="text-2xl font-bold">
                  {(summary.totalAmount / 100000).toFixed(1)}L
                </span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-1 pt-4 px-4">
              <CardTitle className="text-xs text-muted-foreground font-normal">Paid</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="flex items-center gap-1 text-green-600">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-2xl font-bold">
                  {(summary.paidAmount / 100000).toFixed(1)}L
                </span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-1 pt-4 px-4">
              <CardTitle className="text-xs text-muted-foreground font-normal">Outstanding</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <div className="flex items-center gap-1 text-orange-600">
                <AlertCircle className="w-4 h-4" />
                <span className="text-2xl font-bold">
                  {(summary.outstandingAmount / 100000).toFixed(1)}L
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search by vendor or bill number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="received">Received</SelectItem>
            <SelectItem value="verified">Verified</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="disputed">Disputed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bills List */}
      {bills === undefined ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Receipt /></EmptyMedia>
            <EmptyTitle>No vendor bills</EmptyTitle>
            <EmptyDescription>Add your first vendor bill to start tracking</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <CreateBillDialog />
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-3">
          <BulkDeleteBar
            selectedCount={selectedIds.size}
            itemLabel="bill"
            onDelete={handleBulkDelete}
            onClear={clearSelection}
          />
          {/* Select All row */}
          <div className="flex items-center gap-3 px-1 py-1">
            <Checkbox
              checked={allFilteredSelected}
              onCheckedChange={toggleAll}
              id="select-all-bills"
            />
            <label htmlFor="select-all-bills" className="text-sm text-muted-foreground cursor-pointer select-none">
              Select all ({filtered.length})
            </label>
          </div>
          {filtered.map((bill) => {
            const outstanding = bill.totalAmount - bill.paidAmount;
            const paidPct = bill.totalAmount > 0 ? (bill.paidAmount / bill.totalAmount) * 100 : 0;
            return (
              <Card key={bill._id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <Checkbox
                        checked={selectedIds.has(bill._id)}
                        onCheckedChange={() => toggleSelect(bill._id)}
                        onClick={(e) => e.stopPropagation()}
                        className="mt-1 shrink-0"
                      />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{bill.billNumber}</span>
                        {bill.billType === "ra" && <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">RA-{bill.raNumber}</Badge>}
                        {bill.billType === "final" && <Badge className="bg-purple-100 text-purple-700 border-0 text-xs">Final Bill</Badge>}
                        <Badge className={STATUS_COLORS[bill.status] + " border-0 text-xs"}>
                          {STATUS_LABELS[bill.status]}
                        </Badge>
                        <Badge variant="outline" className="text-xs capitalize">
                          {bill.vendorType}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        {bill.supplierName ?? bill.contractorName ?? "—"} &bull; {bill.siteName ?? "—"}
                      </p>
                      {bill.description && (
                        <p className="text-xs text-muted-foreground truncate">{bill.description}</p>
                      )}
                      {/* Payment progress */}
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500 rounded-full transition-all"
                            style={{ width: `${paidPct}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {paidPct.toFixed(0)}% paid
                        </span>
                      </div>
                    </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="text-right">
                        <p className="font-bold">₹{bill.totalAmount.toLocaleString("en-IN")}</p>
                        {outstanding > 0 && (
                          <p className="text-xs text-orange-600">
                            ₹{outstanding.toLocaleString("en-IN")} due
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          className="text-xs h-7 cursor-pointer gap-1"
                          onClick={() => setInvoiceViewId(bill._id)}
                        >
                          <FileText className="w-3 h-3" /> Invoice
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="text-xs h-7 cursor-pointer gap-1"
                          onClick={() => setEditBillId(bill._id)}
                        >
                          <Pencil className="w-3 h-3" /> Edit
                        </Button>
                        {NEXT_STATUS[bill.status] && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs h-7 cursor-pointer"
                            onClick={() => handleAdvanceStatus(bill._id, bill.status)}
                          >
                            <Clock className="w-3 h-3 mr-1" />
                            Mark {STATUS_LABELS[NEXT_STATUS[bill.status]]}
                          </Button>
                        )}
                        {bill.status !== "paid" && outstanding > 0 && (
                          <Button
                            size="sm"
                            className="text-xs h-7 cursor-pointer"
                            onClick={() => setPaymentTarget({ id: bill._id, outstanding })}
                          >
                            Pay
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Bill Date: {bill.billDate}
                    {bill.dueDate && ` · Due: ${bill.dueDate}`}
                  </p>
                  {/* Vendor uploaded attachments — photos, PDFs, challans */}
                  <AdminBillAttachments billId={bill._id} />
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {uploadOpen && (
        <VendorBillUploadDialog open={uploadOpen} onClose={() => setUploadOpen(false)} />
      )}

      {invoiceViewId && (
        <GSTInvoiceView
          billId={invoiceViewId}
          open={true}
          onClose={() => setInvoiceViewId(null)}
        />
      )}

      {editBillId && (
        <EditBillDialog
          billId={editBillId}
          open={true}
          onClose={() => setEditBillId(null)}
        />
      )}

      {paymentTarget && (
        <RecordPaymentDialog
          billId={paymentTarget.id}
          outstanding={paymentTarget.outstanding}
          open={true}
          onClose={() => setPaymentTarget(null)}
        />
      )}
    </div>
  );
}

export default function VendorBillsPage() {
  return (
    <Authenticated>
      <VendorBillsInner />
    </Authenticated>
  );
}
