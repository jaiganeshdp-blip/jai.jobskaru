/**
 * Excel Upload / Download utilities for Vendor Bills
 */
import * as XLSX from "xlsx";

export type BillExcelRow = {
  "Bill Number": string;
  "Bill Date": string;
  "Due Date": string;
  "Bill Type": string;
  "Vendor Type": string;
  "Vendor Name": string;
  "Site Name": string;
  "PO Number": string;
  "Description": string;
  "Subtotal (₹)": number;
  "GST %": number;
  "GST Amount (₹)": number;
  "Total Amount (₹)": number;
  "Retention %": number | string;
  "Retention Amount (₹)": number | string;
  "Balance Payable (₹)": number;
  "Paid Amount (₹)": number;
  "Outstanding (₹)": number;
  "Status": string;
  "Notes": string;
};

type BillData = {
  _id: string;
  billNumber: string;
  billDate: string;
  dueDate?: string;
  billType?: string;
  vendorType: string;
  supplierName?: string;
  contractorName?: string;
  siteName?: string;
  poNumber?: string;
  description?: string;
  subtotal: number;
  gstPercent: number;
  gstAmount: number;
  totalAmount: number;
  retentionPercent?: number;
  retentionAmount?: number;
  balancePayable?: number;
  paidAmount: number;
  status: string;
  notes?: string;
};

export function downloadVendorBillsExcel(bills: BillData[]) {
  const rows: BillExcelRow[] = bills.map((b) => ({
    "Bill Number": b.billNumber,
    "Bill Date": b.billDate,
    "Due Date": b.dueDate ?? "",
    "Bill Type": b.billType ?? "regular",
    "Vendor Type": b.vendorType,
    "Vendor Name": b.supplierName ?? b.contractorName ?? "—",
    "Site Name": b.siteName ?? "—",
    "PO Number": b.poNumber ?? "—",
    "Description": b.description ?? "",
    "Subtotal (₹)": b.subtotal,
    "GST %": b.gstPercent,
    "GST Amount (₹)": b.gstAmount,
    "Total Amount (₹)": b.totalAmount,
    "Retention %": b.retentionPercent ?? "",
    "Retention Amount (₹)": b.retentionAmount ?? "",
    "Balance Payable (₹)": b.balancePayable ?? b.totalAmount,
    "Paid Amount (₹)": b.paidAmount,
    "Outstanding (₹)": b.totalAmount - b.paidAmount,
    "Status": b.status,
    "Notes": b.notes ?? "",
  }));

  const ws = XLSX.utils.json_to_sheet(rows);

  // Column widths
  ws["!cols"] = [
    { wch: 14 }, // Bill Number
    { wch: 12 }, // Bill Date
    { wch: 12 }, // Due Date
    { wch: 10 }, // Bill Type
    { wch: 12 }, // Vendor Type
    { wch: 22 }, // Vendor Name
    { wch: 20 }, // Site Name
    { wch: 14 }, // PO Number
    { wch: 30 }, // Description
    { wch: 14 }, // Subtotal
    { wch: 8 },  // GST %
    { wch: 14 }, // GST Amount
    { wch: 16 }, // Total Amount
    { wch: 12 }, // Retention %
    { wch: 18 }, // Retention Amount
    { wch: 18 }, // Balance Payable
    { wch: 14 }, // Paid Amount
    { wch: 14 }, // Outstanding
    { wch: 12 }, // Status
    { wch: 30 }, // Notes
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Vendor Bills");

  // Add a separate "Template" sheet for upload reference
  const templateRows = [{
    "Bill Number": "RA-03",
    "Bill Date": "2026-06-01",
    "Due Date": "2026-06-30",
    "Bill Type": "ra / final / regular",
    "Vendor Type": "contractor / supplier",
    "Vendor Name": "Vendor Name",
    "Site Name": "Site Name",
    "PO Number": "PO-1234",
    "Description": "Work description",
    "Subtotal (₹)": 100000,
    "GST %": 18,
    "GST Amount (₹)": 18000,
    "Total Amount (₹)": 118000,
    "Retention %": 5,
    "Retention Amount (₹)": 5000,
    "Balance Payable (₹)": 113000,
    "Paid Amount (₹)": 0,
    "Outstanding (₹)": 118000,
    "Status": "received / verified / approved / paid",
    "Notes": "Optional notes",
  }];
  const tws = XLSX.utils.json_to_sheet(templateRows);
  tws["!cols"] = ws["!cols"];
  XLSX.utils.book_append_sheet(wb, tws, "Upload Template");

  const date = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `Vendor_Bills_${date}.xlsx`);
}

export type ParsedBillRow = {
  billNumber: string;
  billDate: string;
  dueDate?: string;
  billType: string;
  vendorType: string;
  vendorName: string;
  siteName: string;
  poNumber: string;
  description: string;
  subtotal: number;
  gstPercent: number;
  gstAmount: number;
  totalAmount: number;
  retentionPercent?: number;
  retentionAmount?: number;
  balancePayable: number;
  paidAmount: number;
  status: string;
  notes: string;
  rowIndex: number;
  errors: string[];
};

export function parseVendorBillsExcel(file: File): Promise<ParsedBillRow[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const wb = XLSX.read(data, { type: "binary" });
        // Use the first sheet (Vendor Bills or first available)
        const sheetName = wb.SheetNames.find(n => n !== "Upload Template") ?? wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws);

        const parsed: ParsedBillRow[] = rows.map((row, idx) => {
          const errors: string[] = [];
          const get = (keys: string[]): string => {
            for (const k of keys) {
              const val = row[k];
              if (val !== undefined && val !== null && String(val).trim() !== "") return String(val).trim();
            }
            return "";
          };
          const getNum = (keys: string[]): number => {
            const v = get(keys);
            const n = parseFloat(v.replace(/,/g, ""));
            return isNaN(n) ? 0 : n;
          };

          const billNumber = get(["Bill Number", "bill_number", "BILL NUMBER", "BillNumber"]);
          const billDate = get(["Bill Date", "bill_date", "BILL DATE", "BillDate", "Date"]);
          const dueDate = get(["Due Date", "due_date", "DueDate"]) || undefined;
          const billType = get(["Bill Type", "bill_type", "BillType"]) || "regular";
          const vendorType = get(["Vendor Type", "vendor_type", "VendorType"]) || "contractor";
          const vendorName = get(["Vendor Name", "vendor_name", "VendorName", "Contractor", "Supplier"]);
          const siteName = get(["Site Name", "site_name", "SiteName", "Site"]);
          const poNumber = get(["PO Number", "po_number", "PONumber", "PO No"]);
          const description = get(["Description", "description", "Desc"]);
          const subtotal = getNum(["Subtotal (₹)", "Subtotal", "subtotal", "Sub Total"]);
          const gstPercent = getNum(["GST %", "GST%", "gst_percent", "GSTPercent"]);
          const gstAmount = getNum(["GST Amount (₹)", "GST Amount", "gst_amount"]);
          const totalAmount = getNum(["Total Amount (₹)", "Total Amount", "total_amount", "Total"]);
          const retPct = getNum(["Retention %", "Retention%", "retention_percent"]);
          const retAmt = getNum(["Retention Amount (₹)", "Retention Amount", "retention_amount"]);
          const balancePayable = getNum(["Balance Payable (₹)", "Balance Payable", "balance_payable"]) || totalAmount;
          const paidAmount = getNum(["Paid Amount (₹)", "Paid Amount", "paid_amount"]);
          const status = get(["Status", "status"]) || "received";
          const notes = get(["Notes", "notes", "Remarks"]);

          if (!billNumber) errors.push("Bill Number missing");
          if (!billDate) errors.push("Bill Date missing");
          if (!vendorName) errors.push("Vendor Name missing");
          if (totalAmount <= 0) errors.push("Total Amount must be > 0");

          return {
            billNumber, billDate, dueDate, billType, vendorType, vendorName,
            siteName, poNumber, description, subtotal, gstPercent, gstAmount,
            totalAmount, retentionPercent: retPct || undefined,
            retentionAmount: retAmt || undefined, balancePayable, paidAmount,
            status, notes, rowIndex: idx + 2, errors,
          };
        });

        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsBinaryString(file);
  });
}
