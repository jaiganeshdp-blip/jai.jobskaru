/**
 * Generates an Excel (.xlsx) file of a single TAX Invoice
 * matching the JAI GANESH INTERIOR format exactly —
 * company header, green item table, yellow highlights, bank details.
 */
import * as XLSX from "xlsx";

type InvoiceItem = {
  srNo: number;
  description: string;
  unit: string;
  thisBillQty: number;
  ratePerUnit: number;
  thisBillAmount: number;
};

type InvoiceData = {
  // Vendor / Contractor (the one raising the bill)
  companyName: string;
  companyAddress: string;
  companyMobile: string;
  companyGst: string;
  companyPan: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  // Bill info
  billNumber: string;
  billDate: string;
  poNumber: string;
  poDate: string;
  location: string;
  // Bill to party (site/client)
  billToName: string;
  billToAddress: string;
  billToGstin: string;
  caseId: string;
  workPeriod: string;
  descriptionOfWork: string;
  // Items
  items: InvoiceItem[];
  prevQtyBySrNo: Record<number, number>;
  // Totals
  subtotal: number;
  gstPercent: number;
  sgstAmount: number;
  cgstAmount: number;
  totalAmount: number;
  retentionPercent?: number;
  retentionAmount?: number;
  balancePayable: number;
};

function fmt(n: number) {
  return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function numberToWords(num: number): string {
  if (num === 0) return "Zero Rupees Only";
  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  function cvt(n: number): string {
    if (n === 0) return "";
    if (n < 20) return ones[n] + " ";
    if (n < 100) return tens[Math.floor(n / 10)] + " " + ones[n % 10] + " ";
    return ones[Math.floor(n / 100)] + " Hundred " + cvt(n % 100);
  }
  const r = Math.floor(num);
  const p = Math.round((num - r) * 100);
  let result = "";
  const cr = Math.floor(r / 10000000);
  const lk = Math.floor((r % 10000000) / 100000);
  const th = Math.floor((r % 100000) / 1000);
  const rest = r % 1000;
  if (cr > 0) result += cvt(cr) + "Crore ";
  if (lk > 0) result += cvt(lk) + "Lakh ";
  if (th > 0) result += cvt(th) + "Thousand ";
  if (rest > 0) result += cvt(rest);
  result = result.trim() + " Rupees";
  if (p > 0) result += " and " + cvt(p).trim() + " Paise";
  return result + " Only";
}

export function downloadInvoiceExcel(data: InvoiceData) {
  const wb = XLSX.utils.book_new();

  // We'll build rows as arrays for full control
  const rows: (string | number)[][] = [];

  const halfGst = data.gstPercent / 2;

  // ── Row 1: Company Name (large, centered across all cols = A–J = 10 cols)
  rows.push([data.companyName, "", "", "", "", "", "", "", "", `MOB: ${data.companyMobile}`]);
  // ── Row 2: Company address
  rows.push([data.companyAddress, "", "", "", "", "", "", "", "", ""]);
  // ── Row 3: blank
  rows.push(["", "", "", "", "", "", "", "", "", ""]);
  // ── Row 4: TAX Invoice title
  rows.push(["", "", "", "TAX Invoice", "", "", "", "", "", ""]);
  // ── Row 5: blank
  rows.push(["", "", "", "", "", "", "", "", "", ""]);
  // ── Row 6-10: header fields
  rows.push(["Gst Invoice No.:", data.billNumber, "", "", "", "", "PO. NO", data.poNumber, "", ""]);
  rows.push(["Date of Gst Invoice:", data.billDate, "", "", "", "", "PO. DATE", data.poDate, "", ""]);
  rows.push(["Reverse Charge (Y/N):", "NO", "", "", "", "", "Location", data.location, "", ""]);
  rows.push(["State:", "Maharashtra", "", "", "", "", "Code", "27", "", ""]);
  rows.push(["GST NO", data.companyGst, "", "", "", "", "PAN NO", data.companyPan, "", ""]);
  // ── Row 11: Bill to Party header
  rows.push(["Bill to Party", "", "", "", "", "", "", "", "", ""]);
  // ── Row 12-17: Bill to party
  rows.push([data.billToName, "", "", "", "", "", `Case ID: ${data.caseId}`, "", "", ""]);
  rows.push([data.billToAddress, "", "", "", "", "", "", "", "", ""]);
  rows.push(["", "", "", "", "", "", `work period: -${data.workPeriod}`, "", "", ""]);
  rows.push([`GSTIN/Unique ID: ${data.billToGstin}`, "", "", "", "", "", "", "", "", ""]);
  rows.push(["Place of Supply/Services: State: Maharashtra   Code 27", "", "", "", "", "", "", "", "", ""]);
  rows.push([`Description of Work/Supply: ${data.descriptionOfWork}`, "", "", "", "", "", "", "", "", ""]);
  // ── blank
  rows.push(["", "", "", "", "", "", "", "", "", ""]);
  // ── Items table header
  rows.push(["S. No", "ITME", "HSN/SAC", "Description of Work", "Previous BILL QTY", "Present bill Qty", "Cumulative Bill Qty", "Rate", "Unit", "Amount"]);
  // ── Item rows
  data.items.forEach((item, idx) => {
    const prevQty = data.prevQtyBySrNo[item.srNo] ?? 0;
    const cumQty = prevQty + item.thisBillQty;
    rows.push([
      idx + 1,
      (idx + 1) * 10,
      9954,
      item.description,
      prevQty > 0 ? prevQty : 0,
      item.thisBillQty,
      cumQty,
      item.ratePerUnit,
      item.unit,
      item.thisBillAmount,
    ]);
  });
  if (data.items.length === 0) {
    rows.push(["", "", "", "No items — Regular Bill", "", "", "", "", "", ""]);
  }
  // ── blank
  rows.push(["", "", "", "", "", "", "", "", "", ""]);
  // ── Tax totals (right aligned in last 2 cols)
  rows.push(["", "", "", "", "", "", "", "", "Total Amount before Tax", fmt(data.subtotal)]);
  rows.push(["", "", "", "", "", "", "", "", `Add: SGST  ${halfGst}%`, fmt(data.sgstAmount)]);
  rows.push(["", "", "", "", "", "", "", "", `Add: CGST  ${halfGst}%`, fmt(data.cgstAmount)]);
  rows.push(["", "", "", "", "", "", "", "", "Add: IGST 18%", "-"]);
  rows.push(["", "", "", "", "", "", "", "", "Total Amount after Tax:", fmt(data.totalAmount)]);
  if (data.retentionAmount && data.retentionAmount > 0) {
    rows.push(["", "", "", "", "", "", "", "", `(-) Retention @ ${data.retentionPercent ?? 0}%`, fmt(data.retentionAmount)]);
    rows.push(["", "", "", "", "", "", "", "", "Balance Payable", fmt(data.balancePayable)]);
  }
  rows.push(["GST on Reverse Charge", "", "", "", "", "", "", "", "", ""]);
  rows.push([`Amount in words: ${numberToWords(data.balancePayable > 0 ? data.balancePayable : data.totalAmount)}`, "", "", "", "", "", "", "", "", ""]);
  rows.push(["GST DECLERATION:", "", "", "", "", "", "", "", "", ""]);
  rows.push(["* I/ We hereby certify that my/our registration certificate under the GST Act 2017 is in force on the date on which the sale of goods...", "", "", "", "", "", "", "", "", ""]);
  rows.push(["Subject to MUMBAI Jurisdiction Only.", "", "", "", "", "", "", "", "", ""]);
  // ── Bank details
  rows.push(["", "", "", "", "", "", "", "", "", ""]);
  rows.push(["BANK DETAILS", "", "", "", "", "", "", "", "", ""]);
  rows.push([`NAME : ${data.companyName}`, "", "", "", "", "", "", "", "", ""]);
  rows.push([`ACCOUNT NO : ${data.accountNumber || "—"}`, "", "", "", "", "", "", "", "", ""]);
  rows.push([`IFSC CODE : ${data.ifscCode || "—"}`, "", "", "", "", "", "", "", "", ""]);
  rows.push([`Branch : ${data.bankName || "—"}`, "", "", "", "", "", "", "", "Authorised Signatory", ""]);

  const ws = XLSX.utils.aoa_to_sheet(rows);

  // Column widths
  ws["!cols"] = [
    { wch: 28 }, // A
    { wch: 22 }, // B
    { wch: 10 }, // C
    { wch: 32 }, // D
    { wch: 14 }, // E
    { wch: 14 }, // F
    { wch: 16 }, // G
    { wch: 12 }, // H
    { wch: 14 }, // I
    { wch: 14 }, // J
  ];

  // Merges for wide cells
  ws["!merges"] = [
    // Row 1 (0-indexed): Company name A-I
    { s: { r: 0, c: 0 }, e: { r: 0, c: 8 } },
    // Row 2: Address
    { s: { r: 1, c: 0 }, e: { r: 1, c: 8 } },
    // Row 4: TAX Invoice title D-G
    { s: { r: 3, c: 0 }, e: { r: 3, c: 9 } },
    // Bill to Party header
    { s: { r: 10, c: 0 }, e: { r: 10, c: 9 } },
    // Bill to name
    { s: { r: 11, c: 0 }, e: { r: 11, c: 5 } },
    { s: { r: 12, c: 0 }, e: { r: 12, c: 5 } },
    { s: { r: 13, c: 0 }, e: { r: 13, c: 5 } },
    { s: { r: 14, c: 0 }, e: { r: 14, c: 5 } },
    { s: { r: 15, c: 0 }, e: { r: 15, c: 9 } },
    { s: { r: 16, c: 0 }, e: { r: 16, c: 9 } },
    // Bank details
    { s: { r: rows.length - 7, c: 0 }, e: { r: rows.length - 7, c: 9 } },
    { s: { r: rows.length - 6, c: 0 }, e: { r: rows.length - 6, c: 9 } },
    // Amount in words
  ];

  XLSX.utils.book_append_sheet(wb, ws, "TAX Invoice");

  // ── Also add Upload Template sheet ──
  const templateRows: (string | number)[][] = [
    ["=== VENDOR BILL UPLOAD TEMPLATE ===", "", "", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", "", "", ""],
    ["Bill Number", "Bill Date", "Due Date", "Bill Type", "Vendor Type", "Vendor Name", "Site Name", "PO Number", "Description", ""],
    ["", "(YYYY-MM-DD)", "(YYYY-MM-DD)", "ra / final / regular", "contractor / supplier", "", "", "", "", ""],
    ["", "", "", "", "", "", "", "", "", ""],
    ["Subtotal (₹)", "GST %", "GST Amount (₹)", "Total Amount (₹)", "Retention %", "Retention Amount (₹)", "Balance Payable (₹)", "Paid Amount (₹)", "Status", "Notes"],
    ["", "18", "", "", "", "", "", "0", "received / verified / approved / paid", ""],
    ["", "", "", "", "", "", "", "", "", ""],
    ["=== EXAMPLE ROW ===", "", "", "", "", "", "", "", "", ""],
    ["RA-03", "2026-06-01", "2026-06-30", "ra", "contractor", "Tulsaram Suthar", "T11 Building Pune", "PO-2223", "Interior Work RA-3", ""],
    [85000, 18, 15300, 100300, 5, 4250, 96050, 0, "received", "June RA Bill"],
  ];

  const tws = XLSX.utils.aoa_to_sheet(templateRows);
  tws["!cols"] = ws["!cols"];
  XLSX.utils.book_append_sheet(wb, tws, "Upload Template");

  const date = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `TAX_Invoice_${data.billNumber}_${date}.xlsx`);
}
