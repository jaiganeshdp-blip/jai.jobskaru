import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Authenticated } from "convex/react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { toast } from "sonner";
import { Plus, ArrowDownLeft, ArrowUpRight, Trash2, Banknote } from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar } from "@/components/bulk-delete-bar.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";

function formatINR(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

type PayMode = "cash" | "cheque" | "neft" | "rtgs" | "upi" | "other";

function AddPaymentDialog({ onClose }: { onClose: () => void }) {
  const sites = useQuery(api.sites.list, {});
  const suppliers = useQuery(api.suppliers.list, {});
  const contractors = useQuery(api.contractors.list, {});
  const recordToSupplier = useMutation(api.payments.recordToSupplier);
  const recordToContractor = useMutation(api.payments.recordToContractor);

  const [siteId, setSiteId] = useState("");
  const [payTo, setPayTo] = useState<"supplier" | "contractor">("supplier");
  const [partyId, setPartyId] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [mode, setMode] = useState<PayMode>("neft");
  const [ref, setRef] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!siteId || !partyId || !amount) return toast.error("Fill all required fields");
    setSaving(true);
    try {
      if (payTo === "supplier") {
        await recordToSupplier({
          siteId: siteId as Id<"sites">,
          supplierId: partyId as Id<"suppliers">,
          amount: parseFloat(amount),
          date, mode, referenceNumber: ref || undefined, notes: notes || undefined,
        });
      } else {
        await recordToContractor({
          siteId: siteId as Id<"sites">,
          contractorId: partyId as Id<"contractors">,
          amount: parseFloat(amount),
          date, mode, referenceNumber: ref || undefined, notes: notes || undefined,
        });
      }
      toast.success("Payment recorded");
      onClose();
    } catch {
      toast.error("Failed to record payment");
    } finally {
      setSaving(false);
    }
  };

  const parties = payTo === "supplier" ? (suppliers ?? []) : (contractors ?? []);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Record Outgoing Payment</DialogTitle></DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Site</Label>
              <Select value={siteId} onValueChange={setSiteId}>
                <SelectTrigger><SelectValue placeholder="Select site" /></SelectTrigger>
                <SelectContent>
                  {(sites ?? []).map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Pay To</Label>
              <Select value={payTo} onValueChange={(v) => { setPayTo(v as typeof payTo); setPartyId(""); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="supplier">Supplier</SelectItem>
                  <SelectItem value="contractor">Contractor</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1 col-span-2">
              <Label>{payTo === "supplier" ? "Supplier" : "Contractor"}</Label>
              <Select value={partyId} onValueChange={setPartyId}>
                <SelectTrigger><SelectValue placeholder={`Select ${payTo}`} /></SelectTrigger>
                <SelectContent>
                  {parties.map((p) => <SelectItem key={p._id} value={p._id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Amount (₹)</Label>
              <Input type="number" min="1" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Payment Mode</Label>
              <Select value={mode} onValueChange={(v) => setMode(v as PayMode)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["cash", "cheque", "neft", "rtgs", "upi", "other"].map((m) => (
                    <SelectItem key={m} value={m}>{m.toUpperCase()}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Reference No.</Label>
              <Input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Optional" />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Notes</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving..." : "Record Payment"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PaymentsPageInner() {
  const payments = useQuery(api.payments.list, {});
  const remove = useMutation(api.payments.remove);
  const [typeFilter, setTypeFilter] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const filtered = (payments ?? []).filter((p) =>
    typeFilter === "all" || p.type === typeFilter
  );

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());
  const allFilteredSelected = filtered.length > 0 && filtered.every((p) => selectedIds.has(p._id));
  const toggleAll = () => {
    if (allFilteredSelected) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((p) => next.delete(p._id));
        return next;
      });
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((p) => next.add(p._id));
        return next;
      });
    }
  };
  const handleBulkDelete = async () => {
    const ids = Array.from(selectedIds);
    await Promise.all(ids.map((id) => remove({ id: id as Id<"payments"> })));
    toast.success(`Deleted ${ids.length} payment${ids.length !== 1 ? "s" : ""}`);
    clearSelection();
  };

  const totalIn = (payments ?? []).filter((p) => p.type === "received").reduce((s, p) => s + p.amount, 0);
  const totalOut = (payments ?? []).filter((p) => p.type === "paid").reduce((s, p) => s + p.amount, 0);

  if (!payments) return (
    <div className="p-6 space-y-4">
      {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Payments Ledger</h1>
          <p className="text-muted-foreground text-sm mt-1">All incoming and outgoing payments</p>
        </div>
        <Button onClick={() => setAddOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" /> Record Payment
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <ArrowDownLeft className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Received</p>
                <p className="text-lg font-bold text-green-400">{formatINR(totalIn)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-500/10">
                <ArrowUpRight className="h-5 w-5 text-red-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Paid Out</p>
                <p className="text-lg font-bold text-red-400">{formatINR(totalOut)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Banknote className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Net Balance</p>
                <p className={`text-lg font-bold ${totalIn - totalOut >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {formatINR(totalIn - totalOut)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex gap-3">
        {[
          { val: "all", label: "All" },
          { val: "received", label: "Received" },
          { val: "paid", label: "Paid Out" },
        ].map(({ val, label }) => (
          <button
            key={val}
            onClick={() => setTypeFilter(val)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors cursor-pointer ${typeFilter === val ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Bulk Delete Bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        itemLabel="payment"
        onDelete={handleBulkDelete}
        onClear={clearSelection}
      />

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground text-sm">No payments found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 w-10">
                      <Checkbox
                        checked={allFilteredSelected}
                        onCheckedChange={toggleAll}
                      />
                    </th>
                    <th className="text-left px-4 py-3">Date</th>
                    <th className="text-left px-4 py-3">Type</th>
                    <th className="text-left px-4 py-3">Site</th>
                    <th className="text-left px-4 py-3">Party</th>
                    <th className="text-right px-4 py-3">Amount</th>
                    <th className="text-left px-4 py-3">Mode</th>
                    <th className="text-left px-4 py-3">Reference</th>
                    <th className="text-left px-4 py-3">Recorded By</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p) => (
                    <tr key={p._id} className="border-t border-border/50 hover:bg-muted/20">
                      <td className="px-4 py-3">
                        <Checkbox
                          checked={selectedIds.has(p._id)}
                          onCheckedChange={() => toggleSelect(p._id)}
                        />
                      </td>
                      <td className="px-4 py-3">{new Date(p.date).toLocaleDateString("en-IN")}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          {p.type === "received"
                            ? <ArrowDownLeft className="h-3.5 w-3.5 text-green-400" />
                            : <ArrowUpRight className="h-3.5 w-3.5 text-red-400" />
                          }
                          <span className={p.type === "received" ? "text-green-400" : "text-red-400"}>
                            {p.type === "received" ? "Received" : "Paid"}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{p.siteName}</td>
                      <td className="px-4 py-3">{p.partyName}</td>
                      <td className={`px-4 py-3 text-right font-semibold ${p.type === "received" ? "text-green-400" : "text-red-400"}`}>
                        {p.type === "received" ? "+" : "-"}{formatINR(p.amount)}
                      </td>
                      <td className="px-4 py-3 uppercase text-muted-foreground text-xs">{p.mode}</td>
                      <td className="px-4 py-3 text-muted-foreground">{p.referenceNumber || "—"}</td>
                      <td className="px-4 py-3 text-muted-foreground">{p.recordedByName}</td>
                      <td className="px-4 py-3">
                        <Button size="sm" variant="ghost"
                          onClick={async () => {
                            try { await remove({ id: p._id }); toast.success("Deleted"); }
                            catch { toast.error("Cannot delete"); }
                          }}>
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {addOpen && <AddPaymentDialog onClose={() => setAddOpen(false)} />}
    </div>
  );
}

export default function PaymentsPage() {
  return (
    <Authenticated>
      <PaymentsPageInner />
    </Authenticated>
  );
}
