import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Authenticated } from "convex/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import { BulkDeleteBar } from "@/components/bulk-delete-bar.tsx";
import {
  Wallet, Plus, Pencil, Trash2, Utensils, Droplets, Truck,
  Fuel, Wrench, ShieldCheck, Zap, Home, MoreHorizontal,
  TrendingUp, TrendingDown, Filter,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type ExpenseCategory =
  | "food" | "water" | "transport" | "diesel"
  | "tools" | "safety" | "electricity" | "rent" | "miscellaneous";

type PaymentMode = "cash" | "upi" | "other";

const CATEGORIES: { value: ExpenseCategory; label: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
  { value: "food", label: "Food", icon: Utensils, color: "text-orange-500 bg-orange-500/10" },
  { value: "water", label: "Water", icon: Droplets, color: "text-blue-500 bg-blue-500/10" },
  { value: "transport", label: "Transport", icon: Truck, color: "text-purple-500 bg-purple-500/10" },
  { value: "diesel", label: "Diesel", icon: Fuel, color: "text-yellow-600 bg-yellow-500/10" },
  { value: "tools", label: "Tools", icon: Wrench, color: "text-gray-600 bg-gray-500/10" },
  { value: "safety", label: "Safety", icon: ShieldCheck, color: "text-green-600 bg-green-500/10" },
  { value: "electricity", label: "Electricity", icon: Zap, color: "text-amber-500 bg-amber-500/10" },
  { value: "rent", label: "Rent", icon: Home, color: "text-teal-600 bg-teal-500/10" },
  { value: "miscellaneous", label: "Misc", icon: MoreHorizontal, color: "text-muted-foreground bg-muted" },
];

function getCategoryMeta(cat: string) {
  return CATEGORIES.find((c) => c.value === cat) ?? CATEGORIES[8];
}

type ExpenseRow = {
  _id: Id<"expenses">;
  siteId: Id<"sites">;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  paymentMode: PaymentMode;
  notes?: string;
  siteName: string;
  enteredByName: string;
};

type FormState = {
  siteId: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: string;
  paymentMode: PaymentMode;
  notes: string;
};

const EMPTY_FORM: FormState = {
  siteId: "",
  date: new Date().toISOString().split("T")[0],
  category: "food",
  description: "",
  amount: "",
  paymentMode: "cash",
  notes: "",
};

function ExpensesInner() {
  const sites = useQuery(api.sites.list, {});
  const [filterSite, setFilterSite] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const expenses = useQuery(api.expenses.list, {
    siteId: filterSite !== "all" ? (filterSite as Id<"sites">) : undefined,
    category: filterCategory !== "all" ? filterCategory : undefined,
    fromDate: fromDate || undefined,
    toDate: toDate || undefined,
  }) as ExpenseRow[] | undefined;

  const createExpense = useMutation(api.expenses.create);
  const updateExpense = useMutation(api.expenses.update);
  const removeExpense = useMutation(api.expenses.remove);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<Id<"expenses"> | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<Id<"expenses"> | null>(null);

  // Bulk selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }

  function toggleAll() {
    if (!expenses) return;
    if (selectedIds.size === expenses.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(expenses.map((e) => e._id)));
    }
  }

  function clearSelection() {
    setSelectedIds(new Set());
  }

  function openAdd() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEdit(e: ExpenseRow) {
    setEditingId(e._id);
    setForm({
      siteId: e.siteId,
      date: e.date,
      category: e.category,
      description: e.description,
      amount: e.amount.toString(),
      paymentMode: e.paymentMode,
      notes: e.notes ?? "",
    });
    setDialogOpen(true);
  }

  async function handleSubmit() {
    if (!form.siteId || !form.date || !form.description.trim() || !form.amount) {
      toast.error("Please fill in all required fields");
      return;
    }
    const amt = parseFloat(form.amount);
    if (isNaN(amt) || amt <= 0) { toast.error("Enter a valid amount"); return; }
    setSubmitting(true);
    try {
      if (editingId) {
        await updateExpense({
          id: editingId,
          date: form.date,
          category: form.category,
          description: form.description.trim(),
          amount: amt,
          paymentMode: form.paymentMode,
          notes: form.notes.trim() || undefined,
        });
        toast.success("Expense updated");
      } else {
        await createExpense({
          siteId: form.siteId as Id<"sites">,
          date: form.date,
          category: form.category,
          description: form.description.trim(),
          amount: amt,
          paymentMode: form.paymentMode,
          notes: form.notes.trim() || undefined,
        });
        toast.success("Expense added");
      }
      setDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteId) return;
    try {
      await removeExpense({ id: deleteId });
      toast.success("Expense deleted");
      setDeleteId(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  async function handleBulkDelete() {
    for (const id of selectedIds) {
      await removeExpense({ id: id as Id<"expenses"> });
    }
    clearSelection();
  }

  // Compute summary from current filtered results
  const total = expenses?.reduce((s, e) => s + e.amount, 0) ?? 0;
  const byCategory: Record<string, number> = {};
  for (const e of expenses ?? []) {
    byCategory[e.category] = (byCategory[e.category] ?? 0) + e.amount;
  }
  const topCategory = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];

  const thisMonthStr = new Date().toISOString().slice(0, 7);
  const thisMonthTotal = expenses?.filter((e) => e.date.startsWith(thisMonthStr)).reduce((s, e) => s + e.amount, 0) ?? 0;

  const allSelected = !!expenses && expenses.length > 0 && selectedIds.size === expenses.length;
  const someSelected = selectedIds.size > 0 && !allSelected;

  return (
    <div className="p-4 md:p-6 space-y-5 md:space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Expenses</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Track site-level petty cash and operational expenses</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" className="cursor-pointer" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="w-4 h-4 mr-1.5" /> Filters
          </Button>
          {/* Desktop add button — hidden on mobile (FAB used instead) */}
          <Button className="cursor-pointer hidden sm:flex" onClick={openAdd}>
            <Plus className="w-4 h-4 mr-1.5" /> Add Expense
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <Wallet className="w-9 h-9 text-blue-500 bg-blue-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Total Expenses</p>
              <p className="font-bold text-lg">₹{total.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <TrendingUp className="w-9 h-9 text-orange-500 bg-orange-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">This Month</p>
              <p className="font-bold text-lg">₹{thisMonthTotal.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <TrendingDown className="w-9 h-9 text-purple-500 bg-purple-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Entries</p>
              <p className="font-bold text-lg">{expenses?.length ?? 0}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            {topCategory ? (() => {
              const meta = getCategoryMeta(topCategory[0]);
              const Icon = meta.icon;
              return <>
                <Icon className={`w-9 h-9 rounded-lg p-2 flex-shrink-0 ${meta.color}`} />
                <div>
                  <p className="text-xs text-muted-foreground">Top Category</p>
                  <p className="font-bold text-base capitalize">{meta.label}</p>
                  <p className="text-xs text-muted-foreground">₹{topCategory[1].toLocaleString("en-IN")}</p>
                </div>
              </>;
            })() : (
              <>
                <MoreHorizontal className="w-9 h-9 text-muted-foreground bg-muted rounded-lg p-2 flex-shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">Top Category</p>
                  <p className="font-bold text-base">—</p>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown Chips */}
      {Object.keys(byCategory).length > 0 && (
        <div className="flex flex-wrap gap-2">
          {Object.entries(byCategory)
            .sort((a, b) => b[1] - a[1])
            .map(([cat, amt]) => {
              const meta = getCategoryMeta(cat);
              const Icon = meta.icon;
              return (
                <div key={cat} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${meta.color}`}>
                  <Icon className="w-3.5 h-3.5" />
                  {meta.label}: ₹{amt.toLocaleString("en-IN")}
                </div>
              );
            })}
        </div>
      )}

      {/* Filters */}
      {showFilters && (
        <Card>
          <CardContent className="px-4 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Site</Label>
                <Select value={filterSite} onValueChange={setFilterSite}>
                  <SelectTrigger className="cursor-pointer h-8 text-sm"><SelectValue placeholder="All sites" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sites</SelectItem>
                    {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Category</Label>
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="cursor-pointer h-8 text-sm"><SelectValue placeholder="All categories" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">From Date</Label>
                <Input type="date" className="h-8 text-sm" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">To Date</Label>
                <Input type="date" className="h-8 text-sm" value={toDate} onChange={(e) => setToDate(e.target.value)} />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bulk Delete Bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        onDelete={handleBulkDelete}
        onClear={clearSelection}
        itemLabel="expense"
      />

      {/* Expense List */}
      {expenses === undefined ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
        </div>
      ) : expenses.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Wallet /></EmptyMedia>
            <EmptyTitle>No expenses found</EmptyTitle>
            <EmptyDescription>Add daily site expenses like food, diesel, transport, and more</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={openAdd}><Plus className="w-4 h-4 mr-1" /> Add Expense</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <Card>
          <CardContent className="p-0">
            {/* Select All header */}
            <div className="px-4 py-2.5 border-b border-border flex items-center gap-2">
              <input
                type="checkbox"
                className="cursor-pointer w-4 h-4 accent-primary"
                checked={allSelected}
                ref={(el) => { if (el) el.indeterminate = someSelected; }}
                onChange={toggleAll}
                id="select-all-expenses"
              />
              <label htmlFor="select-all-expenses" className="text-sm text-muted-foreground cursor-pointer select-none">
                Select All
              </label>
            </div>
            <div className="divide-y divide-border">
              {expenses.map((e) => {
                const meta = getCategoryMeta(e.category);
                const Icon = meta.icon;
                const isSelected = selectedIds.has(e._id);
                return (
                  <div
                    key={e._id}
                    className={`px-4 py-3 flex items-center gap-3 hover:bg-muted/30 transition-colors ${isSelected ? "bg-muted/40" : ""}`}
                  >
                    <input
                      type="checkbox"
                      className="cursor-pointer w-4 h-4 flex-shrink-0 accent-primary"
                      checked={isSelected}
                      onChange={() => toggleSelect(e._id)}
                    />
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${meta.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm truncate">{e.description}</p>
                        <Badge variant="secondary" className="text-xs px-1.5 py-0">{meta.label}</Badge>
                        <Badge variant="outline" className="text-xs px-1.5 py-0 uppercase">{e.paymentMode}</Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground flex-wrap">
                        <span>{e.siteName}</span>
                        <span>{e.date}</span>
                        <span>by {e.enteredByName}</span>
                        {e.notes && <span className="truncate max-w-[200px]">{e.notes}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <p className="font-bold text-base">₹{e.amount.toLocaleString("en-IN")}</p>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-7 w-7 cursor-pointer" onClick={() => openEdit(e)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 cursor-pointer text-destructive hover:text-destructive" onClick={() => setDeleteId(e._id)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Expense" : "Add Expense"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {!editingId && (
              <div className="space-y-1.5">
                <Label>Site *</Label>
                <Select value={form.siteId} onValueChange={(v) => setForm({ ...form, siteId: v })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger>
                  <SelectContent>
                    {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Date *</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Amount (₹) *</Label>
                <Input type="number" placeholder="0" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Category *</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as ExpenseCategory })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Payment Mode *</Label>
                <Select value={form.paymentMode} onValueChange={(v) => setForm({ ...form, paymentMode: v as PaymentMode })}>
                  <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description *</Label>
              <Input placeholder="e.g. Lunch for 20 workers, Diesel for generator..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea placeholder="Optional additional notes..." rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={submitting} onClick={() => void handleSubmit()}>
              {submitting ? "Saving..." : editingId ? "Update" : "Add Expense"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Expense?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This action cannot be undone.</p>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={() => void handleDelete()}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mobile FAB — quick add expense */}
      <button
        onClick={openAdd}
        className="fixed bottom-20 right-5 z-20 sm:hidden w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        aria-label="Add Expense"
      >
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
}

export default function ExpensesPage() {
  return (
    <Authenticated>
      <ExpensesInner />
    </Authenticated>
  );
}
