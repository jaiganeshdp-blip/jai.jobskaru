import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import { Authenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import {
  ShoppingCart, Plus, Eye, Trash2, Filter, Package,
  CheckCircle2, Clock, TruckIcon, XCircle, SendHorizonal,
  IndianRupee,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";

type POStatus = "draft" | "sent" | "partially_received" | "closed" | "cancelled";

const STATUS_META: Record<POStatus, { label: string; color: string; icon: React.ComponentType<{ className?: string }> }> = {
  draft: { label: "Draft", color: "bg-muted text-muted-foreground", icon: Clock },
  sent: { label: "Sent", color: "bg-blue-500/10 text-blue-600", icon: SendHorizonal },
  partially_received: { label: "Partial", color: "bg-orange-500/10 text-orange-600", icon: TruckIcon },
  closed: { label: "Closed", color: "bg-green-500/10 text-green-600", icon: CheckCircle2 },
  cancelled: { label: "Cancelled", color: "bg-red-500/10 text-red-600", icon: XCircle },
};

type POItem = { name: string; quantity: number; unit: string; ratePerUnit: number; totalAmount: number };

const UNITS = ["bag", "kg", "ton", "litre", "piece", "sqft", "sqm", "rft", "set", "nos", "truck", "load", "other"];
const EMPTY_ITEM: POItem = { name: "", quantity: 0, unit: "bag", ratePerUnit: 0, totalAmount: 0 };

function ItemRow({
  item,
  index,
  onChange,
  onRemove,
  canRemove,
}: {
  item: POItem;
  index: number;
  onChange: (i: number, field: keyof POItem, val: string | number) => void;
  onRemove: (i: number) => void;
  canRemove: boolean;
}) {
  return (
    <div className="grid grid-cols-12 gap-2 items-end">
      <div className="col-span-4 space-y-1">
        {index === 0 && <Label className="text-xs">Material Name *</Label>}
        <Input
          placeholder="e.g. Cement 53 Grade"
          value={item.name}
          onChange={(e) => onChange(index, "name", e.target.value)}
        />
      </div>
      <div className="col-span-2 space-y-1">
        {index === 0 && <Label className="text-xs">Qty *</Label>}
        <Input
          type="number"
          placeholder="0"
          value={item.quantity || ""}
          onChange={(e) => onChange(index, "quantity", parseFloat(e.target.value) || 0)}
        />
      </div>
      <div className="col-span-2 space-y-1">
        {index === 0 && <Label className="text-xs">Unit</Label>}
        <Select value={item.unit} onValueChange={(v) => onChange(index, "unit", v)}>
          <SelectTrigger className="cursor-pointer h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            {UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="col-span-2 space-y-1">
        {index === 0 && <Label className="text-xs">Rate (₹)</Label>}
        <Input
          type="number"
          placeholder="0"
          value={item.ratePerUnit || ""}
          onChange={(e) => onChange(index, "ratePerUnit", parseFloat(e.target.value) || 0)}
        />
      </div>
      <div className="col-span-1 space-y-1">
        {index === 0 && <Label className="text-xs">Total</Label>}
        <div className="h-9 flex items-center text-sm font-medium text-muted-foreground">
          ₹{(item.quantity * item.ratePerUnit).toLocaleString("en-IN")}
        </div>
      </div>
      <div className="col-span-1 flex justify-end pb-0.5">
        {canRemove && (
          <Button variant="ghost" size="icon" className="h-9 w-9 cursor-pointer text-destructive" onClick={() => onRemove(index)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        )}
      </div>
    </div>
  );
}

function PurchaseOrdersInner() {
  const navigate = useNavigate();
  const sites = useQuery(api.sites.list, {});
  const suppliers = useQuery(api.suppliers.list, {});
  const companies = useQuery(api.companies.list, {});
  const [filterSite, setFilterSite] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [search, setSearch] = useState("");

  const pos = useQuery(api.purchaseOrders.list, {
    siteId: filterSite !== "all" ? (filterSite as Id<"sites">) : undefined,
    status: filterStatus !== "all" ? filterStatus : undefined,
  });

  const createPO = useMutation(api.purchaseOrders.create);
  const removePO = useMutation(api.purchaseOrders.remove);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<Id<"purchaseOrders"> | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((p) => p._id)));
    }
  }
  function clearSelection() { setSelectedIds(new Set()); }

  async function handleBulkDelete() {
    setBulkDeleting(true);
    try {
      await Promise.all([...selectedIds].map((id) => removePO({ id: id as Id<"purchaseOrders"> })));
      toast.success(`Deleted ${selectedIds.size} purchase order${selectedIds.size !== 1 ? "s" : ""}`);
      clearSelection();
    } catch { toast.error("Some deletes failed"); }
    finally { setBulkDeleting(false); }
  }

  const [form, setForm] = useState({
    poNumber: "",
    siteId: "",
    supplierId: "",
    companyId: "",
    workOrderId: "",
    issueDate: new Date().toISOString().split("T")[0],
    expectedDeliveryDate: "",
    terms: "",
    notes: "",
  });
  const [items, setItems] = useState<POItem[]>([{ ...EMPTY_ITEM }]);

  function setField(field: string, val: string) {
    setForm((f) => ({ ...f, [field]: val }));
  }

  function updateItem(i: number, field: keyof POItem, val: string | number) {
    setItems((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: val };
      if (field === "quantity" || field === "ratePerUnit") {
        next[i].totalAmount = next[i].quantity * next[i].ratePerUnit;
      }
      return next;
    });
  }

  function addItem() {
    setItems((prev) => [...prev, { ...EMPTY_ITEM }]);
  }

  function removeItem(i: number) {
    setItems((prev) => prev.filter((_, idx) => idx !== i));
  }

  const totalValue = items.reduce((s, it) => s + it.quantity * it.ratePerUnit, 0);

  async function handleCreate() {
    if (!form.poNumber.trim() || !form.siteId || !form.supplierId || !form.companyId) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (items.some((it) => !it.name.trim() || it.quantity <= 0)) {
      toast.error("All items need a name and quantity > 0");
      return;
    }
    setSubmitting(true);
    try {
      const id = await createPO({
        poNumber: form.poNumber.trim(),
        siteId: form.siteId as Id<"sites">,
        supplierId: form.supplierId as Id<"suppliers">,
        companyId: form.companyId as Id<"companies">,
        workOrderId: form.workOrderId ? (form.workOrderId as Id<"workOrders">) : undefined,
        status: "draft",
        issueDate: form.issueDate,
        expectedDeliveryDate: form.expectedDeliveryDate || undefined,
        items: items.map((it) => ({ ...it, totalAmount: it.quantity * it.ratePerUnit })),
        totalValue,
        terms: form.terms.trim() || undefined,
        notes: form.notes.trim() || undefined,
      });
      toast.success("Purchase order created");
      setDialogOpen(false);
      navigate(`/purchase-orders/${id}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteId) return;
    try {
      await removePO({ id: deleteId });
      toast.success("Purchase order deleted");
      setDeleteId(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  const filtered = (pos ?? []).filter(
    (p) =>
      !search ||
      p.poNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(search.toLowerCase()) ||
      p.siteName.toLowerCase().includes(search.toLowerCase())
  );

  // Summary totals
  const totalPOs = filtered.length;
  const totalValue2 = filtered.reduce((s, p) => s + p.totalValue, 0);
  const openPOs = filtered.filter((p) => p.status === "draft" || p.status === "sent" || p.status === "partially_received").length;
  const closedPOs = filtered.filter((p) => p.status === "closed").length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Purchase Orders</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Manage POs to suppliers linked to work orders</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" className="cursor-pointer" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="w-4 h-4 mr-1.5" /> Filters
          </Button>
          <Button className="cursor-pointer" onClick={() => { setForm({ poNumber: "", siteId: "", supplierId: "", companyId: "", workOrderId: "", issueDate: new Date().toISOString().split("T")[0], expectedDeliveryDate: "", terms: "", notes: "" }); setItems([{ ...EMPTY_ITEM }]); setDialogOpen(true); }}>
            <Plus className="w-4 h-4 mr-1.5" /> New PO
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total POs", value: totalPOs, icon: ShoppingCart, color: "text-blue-500 bg-blue-500/10" },
          { label: "Total Value", value: `₹${(totalValue2 / 100000).toFixed(2)}L`, icon: IndianRupee, color: "text-green-500 bg-green-500/10" },
          { label: "Open", value: openPOs, icon: Clock, color: "text-orange-500 bg-orange-500/10" },
          { label: "Closed", value: closedPOs, icon: CheckCircle2, color: "text-emerald-500 bg-emerald-500/10" },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="px-4 py-4 flex items-center gap-3">
              <s.icon className={`w-9 h-9 rounded-lg p-2 flex-shrink-0 ${s.color}`} />
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="font-bold text-lg">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Search + Filters */}
      <div className="flex gap-2 flex-wrap">
        <Input
          className="max-w-xs"
          placeholder="Search PO number, supplier, site..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {showFilters && (
        <Card>
          <CardContent className="px-4 py-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Site</Label>
                <Select value={filterSite} onValueChange={setFilterSite}>
                  <SelectTrigger className="cursor-pointer h-8 text-sm"><SelectValue placeholder="All sites" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sites</SelectItem>
                    {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Status</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="cursor-pointer h-8 text-sm"><SelectValue placeholder="All statuses" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {Object.entries(STATUS_META).map(([v, m]) => <SelectItem key={v} value={v}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bulk delete bar */}
      <BulkDeleteBar
        selectedCount={selectedIds.size}
        itemLabel="purchase order"
        onDelete={handleBulkDelete}
        onClear={clearSelection}
      />

      {/* PO List */}
      {pos === undefined ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><ShoppingCart /></EmptyMedia>
            <EmptyTitle>No purchase orders</EmptyTitle>
            <EmptyDescription>Create your first PO to start ordering materials from suppliers</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="w-4 h-4 mr-1" /> New PO</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="px-4 py-3 w-10">
                      <BulkCheckbox
                        checked={filtered.length > 0 && selectedIds.size === filtered.length}
                        indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length}
                        onChange={toggleAll}
                      />
                    </th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">PO Number</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Supplier</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Site</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Date</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground">Value</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground">Items</th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map((po) => {
                    const meta = STATUS_META[po.status as POStatus];
                    const Icon = meta.icon;
                    return (
                      <tr key={po._id} className="hover:bg-muted/30 cursor-pointer" onClick={() => navigate(`/purchase-orders/${po._id}`)}>
                        <td className="px-4 py-3 w-10" onClick={(e) => e.stopPropagation()}>
                          <BulkCheckbox
                            checked={selectedIds.has(po._id)}
                            onChange={() => toggleSelect(po._id)}
                          />
                        </td>
                        <td className="px-4 py-3 font-medium">{po.poNumber}</td>
                        <td className="px-4 py-3 text-muted-foreground">{po.supplierName}</td>
                        <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{po.siteName}</td>
                        <td className="px-4 py-3 text-muted-foreground">{po.issueDate}</td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${meta.color}`}>
                            <Icon className="w-3 h-3" /> {meta.label}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-semibold">₹{po.totalValue.toLocaleString("en-IN")}</td>
                        <td className="px-4 py-3 text-right text-muted-foreground">{po.items.length} item{po.items.length !== 1 ? "s" : ""}</td>
                        <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7 cursor-pointer" onClick={() => navigate(`/purchase-orders/${po._id}`)}>
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 cursor-pointer text-destructive" onClick={() => setDeleteId(po._id)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create PO Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Purchase Order</DialogTitle></DialogHeader>
          <div className="space-y-5">
            {/* Basic info */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>PO Number *</Label>
                <Input placeholder="PO-2024-001" value={form.poNumber} onChange={(e) => setField("poNumber", e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Issue Date *</Label>
                <Input type="date" value={form.issueDate} onChange={(e) => setField("issueDate", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Site *</Label>
                <Select value={form.siteId} onValueChange={(v) => setField("siteId", v)}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select site" /></SelectTrigger>
                  <SelectContent>
                    {sites?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Company *</Label>
                <Select value={form.companyId} onValueChange={(v) => setField("companyId", v)}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select company" /></SelectTrigger>
                  <SelectContent>
                    {companies?.map((c) => <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Supplier *</Label>
                <Select value={form.supplierId} onValueChange={(v) => setField("supplierId", v)}>
                  <SelectTrigger className="cursor-pointer"><SelectValue placeholder="Select supplier" /></SelectTrigger>
                  <SelectContent>
                    {suppliers?.map((s) => <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Expected Delivery</Label>
                <Input type="date" value={form.expectedDeliveryDate} onChange={(e) => setField("expectedDeliveryDate", e.target.value)} />
              </div>
            </div>

            {/* Items */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-sm font-semibold">Items *</Label>
                <Button variant="secondary" size="sm" className="cursor-pointer" onClick={addItem}>
                  <Plus className="w-3.5 h-3.5 mr-1" /> Add Item
                </Button>
              </div>
              <div className="space-y-2">
                {items.map((item, i) => (
                  <ItemRow key={i} item={item} index={i} onChange={updateItem} onRemove={removeItem} canRemove={items.length > 1} />
                ))}
              </div>
              <div className="flex justify-end mt-3 text-sm font-semibold">
                Total: ₹{totalValue.toLocaleString("en-IN")}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Terms & Conditions</Label>
              <Textarea placeholder="Payment terms, delivery terms..." rows={2} value={form.terms} onChange={(e) => setField("terms", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea placeholder="Additional notes..." rows={2} value={form.notes} onChange={(e) => setField("notes", e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={submitting} onClick={() => void handleCreate()}>
              {submitting ? "Creating..." : "Create PO"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Purchase Order?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will also delete all associated receipts. This cannot be undone.</p>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" className="cursor-pointer" onClick={() => void handleDelete()}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function PurchaseOrdersPage() {
  return (
    <Authenticated>
      <PurchaseOrdersInner />
    </Authenticated>
  );
}
