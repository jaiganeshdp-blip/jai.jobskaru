import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { Authenticated } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import {
  ArrowLeft, ShoppingCart, Building2, MapPin, CalendarDays,
  Truck, CheckCircle2, Clock, XCircle, SendHorizonal,
  Package, ClipboardList, Plus, IndianRupee,
} from "lucide-react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type POStatus = "draft" | "sent" | "partially_received" | "closed" | "cancelled";

const STATUS_META: Record<POStatus, { label: string; color: string; icon: React.ComponentType<{ className?: string }> }> = {
  draft: { label: "Draft", color: "bg-muted text-muted-foreground", icon: Clock },
  sent: { label: "Sent to Supplier", color: "bg-blue-500/10 text-blue-600", icon: SendHorizonal },
  partially_received: { label: "Partially Received", color: "bg-orange-500/10 text-orange-600", icon: Truck },
  closed: { label: "Closed / Fulfilled", color: "bg-green-500/10 text-green-600", icon: CheckCircle2 },
  cancelled: { label: "Cancelled", color: "bg-red-500/10 text-red-600", icon: XCircle },
};

function DetailInner() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const poId = id as Id<"purchaseOrders">;

  const detail = useQuery(api.purchaseOrders.getDetail, id ? { id: poId } : "skip");
  const updateStatus = useMutation(api.purchaseOrders.updateStatus);
  const recordReceipt = useMutation(api.purchaseOrders.recordReceipt);

  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState<POStatus>("draft");

  const [receiptOpen, setReceiptOpen] = useState(false);
  const [receiptDate, setReceiptDate] = useState(new Date().toISOString().split("T")[0]);
  const [receiptNotes, setReceiptNotes] = useState("");
  const [receiptQtys, setReceiptQtys] = useState<Record<number, string>>({});
  const [receiptSubmitting, setReceiptSubmitting] = useState(false);

  if (detail === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!detail) {
    return <div className="p-6 text-muted-foreground">Purchase order not found.</div>;
  }

  const { po, site, supplier, company, workOrder, receipts, receivedQtyByItem } = detail;
  const meta = STATUS_META[po.status as POStatus];
  const StatusIcon = meta.icon;

  async function changeStatus() {
    try {
      await updateStatus({ id: poId, status: newStatus });
      toast.success("Status updated");
      setStatusDialogOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  }

  async function submitReceipt() {
    const receivedItems = Object.entries(receiptQtys)
      .map(([idx, qty]) => ({ itemIndex: parseInt(idx), receivedQuantity: parseFloat(qty) || 0 }))
      .filter((ri) => ri.receivedQuantity > 0);

    if (receivedItems.length === 0) {
      toast.error("Enter received quantity for at least one item");
      return;
    }
    setReceiptSubmitting(true);
    try {
      await recordReceipt({
        purchaseOrderId: poId,
        receivedDate: receiptDate,
        receivedItems,
        notes: receiptNotes.trim() || undefined,
      });
      toast.success("Receipt recorded");
      setReceiptOpen(false);
      setReceiptQtys({});
      setReceiptNotes("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setReceiptSubmitting(false);
    }
  }

  const totalReceived = po.items.reduce((s, _, idx) => s + (receivedQtyByItem[idx] ?? 0) * po.items[idx].ratePerUnit, 0);
  const totalPending = po.totalValue - totalReceived;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4 flex-wrap">
        <Button variant="ghost" size="icon" className="cursor-pointer mt-1" onClick={() => navigate("/purchase-orders")}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <ShoppingCart className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{po.poNumber}</h1>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${meta.color}`}>
                  <StatusIcon className="w-3 h-3" /> {meta.label}
                </span>
                <span className="text-muted-foreground text-sm">{receipts.length} receipt{receipts.length !== 1 ? "s" : ""}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="secondary" className="cursor-pointer" onClick={() => { setNewStatus(po.status as POStatus); setStatusDialogOpen(true); }}>
            Change Status
          </Button>
          {po.status !== "closed" && po.status !== "cancelled" && (
            <Button className="cursor-pointer" onClick={() => { setReceiptQtys({}); setReceiptOpen(true); }}>
              <Package className="w-4 h-4 mr-1.5" /> Record Receipt
            </Button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <IndianRupee className="w-9 h-9 text-blue-500 bg-blue-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">PO Value</p>
              <p className="font-bold text-lg">₹{po.totalValue.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <CheckCircle2 className="w-9 h-9 text-green-500 bg-green-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Received Value</p>
              <p className="font-bold text-lg text-green-600">₹{totalReceived.toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <Clock className="w-9 h-9 text-orange-500 bg-orange-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Pending Value</p>
              <p className="font-bold text-lg text-orange-600">₹{Math.max(0, totalPending).toLocaleString("en-IN")}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="px-4 py-4 flex items-center gap-3">
            <ClipboardList className="w-9 h-9 text-purple-500 bg-purple-500/10 rounded-lg p-2 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Items</p>
              <p className="font-bold text-lg">{po.items.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Details */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">PO Details</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {site && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{site.name}</span>
                </div>
              )}
              {supplier && (
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{supplier.name}</span>
                </div>
              )}
              {company && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{company.name}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span>Issued: {po.issueDate}</span>
              </div>
              {po.expectedDeliveryDate && (
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>Expected: {po.expectedDeliveryDate}</span>
                </div>
              )}
              {workOrder && (
                <div className="flex items-center gap-2">
                  <ClipboardList className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>WO: {workOrder.orderNumber}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {po.terms && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Terms & Conditions</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">{po.terms}</p>
              </CardContent>
            </Card>
          )}

          {po.notes && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Notes</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">{po.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right: Items table + Receipt history */}
        <div className="lg:col-span-2 space-y-4">
          {/* Items table with receipt progress */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Package className="w-4 h-4" /> Order Items & Receipt Status
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40 border-b border-border">
                    <tr>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Material</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Ordered</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Received</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Pending</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Rate</th>
                      <th className="text-right px-4 py-3 font-medium text-muted-foreground">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {po.items.map((item, idx) => {
                      const received = receivedQtyByItem[idx] ?? 0;
                      const pending = Math.max(0, item.quantity - received);
                      const pct = item.quantity > 0 ? Math.min((received / item.quantity) * 100, 100) : 0;
                      return (
                        <tr key={idx} className="hover:bg-muted/20">
                          <td className="px-4 py-3">
                            <div className="font-medium">{item.name}</div>
                            <div className="w-full mt-1">
                              <Progress value={pct} className="h-1.5" />
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right text-muted-foreground">{item.quantity} {item.unit}</td>
                          <td className="px-4 py-3 text-right text-green-600 font-medium">{received} {item.unit}</td>
                          <td className="px-4 py-3 text-right">
                            {pending > 0
                              ? <span className="text-orange-500">{pending} {item.unit}</span>
                              : <Badge className="bg-green-500/10 text-green-600 border-0 text-xs">Done</Badge>
                            }
                          </td>
                          <td className="px-4 py-3 text-right text-muted-foreground">₹{item.ratePerUnit.toLocaleString("en-IN")}</td>
                          <td className="px-4 py-3 text-right font-semibold">₹{item.totalAmount.toLocaleString("en-IN")}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="bg-muted/30 border-t border-border">
                    <tr>
                      <td colSpan={5} className="px-4 py-3 text-right font-semibold">Total</td>
                      <td className="px-4 py-3 text-right font-bold">₹{po.totalValue.toLocaleString("en-IN")}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Receipt History */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <ClipboardList className="w-4 h-4" /> Receipt History
                </CardTitle>
                <Badge variant="secondary">{receipts.length} receipt{receipts.length !== 1 ? "s" : ""}</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {receipts.length === 0 ? (
                <div className="px-4 py-8 text-center">
                  <Truck className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-40" />
                  <p className="text-muted-foreground text-sm">No receipts recorded yet</p>
                  <p className="text-xs text-muted-foreground mt-1">Click "Record Receipt" when materials arrive</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {receipts.map((r) => (
                    <div key={r._id} className="px-4 py-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{r.receivedDate}</span>
                        <span className="text-xs text-muted-foreground">by {r.receivedByName}</span>
                      </div>
                      <div className="space-y-1">
                        {r.receivedItems.map((ri) => (
                          <div key={ri.itemIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                            <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                            <span>{po.items[ri.itemIndex]?.name ?? `Item ${ri.itemIndex + 1}`}: </span>
                            <span className="font-medium text-foreground">{ri.receivedQuantity} {po.items[ri.itemIndex]?.unit ?? ""}</span>
                          </div>
                        ))}
                      </div>
                      {r.notes && <p className="text-xs text-muted-foreground mt-1">{r.notes}</p>}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Change Status Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Change PO Status</DialogTitle></DialogHeader>
          <Select value={newStatus} onValueChange={(v) => setNewStatus(v as POStatus)}>
            <SelectTrigger className="cursor-pointer"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(STATUS_META).map(([v, m]) => (
                <SelectItem key={v} value={v}>{m.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setStatusDialogOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" onClick={() => void changeStatus()}>Update</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Record Receipt Dialog */}
      <Dialog open={receiptOpen} onOpenChange={setReceiptOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Record Material Receipt</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Received Date *</Label>
              <Input type="date" value={receiptDate} onChange={(e) => setReceiptDate(e.target.value)} />
            </div>
            <div>
              <Label className="mb-2 block">Received Quantities</Label>
              <div className="space-y-2">
                {po.items.map((item, idx) => {
                  const alreadyReceived = receivedQtyByItem[idx] ?? 0;
                  const remaining = Math.max(0, item.quantity - alreadyReceived);
                  return (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Ordered: {item.quantity} {item.unit} | Received: {alreadyReceived} | Remaining: {remaining}
                        </p>
                      </div>
                      <div className="w-28 flex-shrink-0">
                        <Input
                          type="number"
                          placeholder="0"
                          max={remaining}
                          value={receiptQtys[idx] ?? ""}
                          onChange={(e) => setReceiptQtys((q) => ({ ...q, [idx]: e.target.value }))}
                          className="h-8 text-sm"
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-8 flex-shrink-0">{item.unit}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea placeholder="Delivery notes, vehicle number, driver..." rows={2} value={receiptNotes} onChange={(e) => setReceiptNotes(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setReceiptOpen(false)}>Cancel</Button>
            <Button className="cursor-pointer" disabled={receiptSubmitting} onClick={() => void submitReceipt()}>
              <Plus className="w-4 h-4 mr-1" />
              {receiptSubmitting ? "Saving..." : "Record Receipt"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function PurchaseOrderDetail() {
  return (
    <Authenticated>
      <DetailInner />
    </Authenticated>
  );
}
