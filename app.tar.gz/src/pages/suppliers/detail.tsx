import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { useState } from "react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  ArrowLeft, Phone, Mail, MapPin, FileText, Truck,
  Package, CreditCard, Link as LinkIcon, AlertCircle, Building2,
  ImageIcon, FileIcon, ExternalLink, X, ShoppingCart,
} from "lucide-react";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function fmt(amount: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}

const MATERIAL_STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  approved: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  rejected: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

function copyPortalLink(token: string) {
  const url = `${window.location.origin}/portal/supplier?token=${token}`;
  void navigator.clipboard.writeText(url);
  toast.success("Portal link copied!");
}

export default function SupplierDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const data = useQuery(api.suppliers.getDetail, id ? { id: id as Id<"suppliers"> } : "skip");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"info" | "pos" | "files">("info");

  // Fetch POs for this supplier
  const pos = useQuery(
    api.purchaseOrders.list,
    id ? { supplierId: id as Id<"suppliers"> } : "skip"
  ) ?? [];

  if (data === undefined) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6 text-center space-y-2">
        <AlertCircle className="w-8 h-8 mx-auto text-muted-foreground" />
        <p className="text-muted-foreground">Supplier not found</p>
        <Link to="/suppliers"><Button variant="ghost" size="sm">Back to Suppliers</Button></Link>
      </div>
    );
  }

  const {
    supplier, materialCount, totalMaterialValue, pendingMaterialCount,
    approvedMaterialCount, totalPaid, totalOutstanding, recentMaterials, recentPayments,
    billFiles, challanPhotos,
  } = data;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <Link to="/suppliers">
          <Button variant="ghost" size="sm" className="cursor-pointer gap-1 -ml-2">
            <ArrowLeft className="w-4 h-4" /> Suppliers
          </Button>
        </Link>
        {supplier.portalToken && (
          <Button variant="secondary" size="sm" className="cursor-pointer gap-2" onClick={() => copyPortalLink(supplier.portalToken!)}>
            <LinkIcon className="w-3.5 h-3.5" /> Copy Portal Link
          </Button>
        )}
      </div>

      {/* Hero */}
      <div className="rounded-xl bg-[oklch(0.14_0.025_250)] text-white p-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Truck className="w-5 h-5 text-blue-400" />
              </div>
              <h1 className="text-3xl font-bold">{supplier.name}</h1>
            </div>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-white/70">
              {supplier.mobile && <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {supplier.mobile}</span>}
              {supplier.email && <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {supplier.email}</span>}
              {supplier.gstNumber && <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" /> GST: {supplier.gstNumber}</span>}
              {supplier.city && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {supplier.city}</span>}
            </div>
            {(supplier.materialCategories ?? []).length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-3">
                {(supplier.materialCategories ?? []).map((cat) => (
                  <Badge key={cat} variant="secondary" className="bg-white/10 text-white/80 text-xs">{cat}</Badge>
                ))}
              </div>
            )}
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold self-start ${supplier.isActive ? "bg-green-500/20 text-green-300" : "bg-gray-500/20 text-gray-300"}`}>
            {supplier.isActive ? "Active" : "Inactive"}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <Package className="w-3.5 h-3.5" /> Deliveries
          </div>
          <div className="text-2xl font-bold">{materialCount}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{approvedMaterialCount} approved · {pendingMaterialCount} pending</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <Building2 className="w-3.5 h-3.5" /> Total Billed
          </div>
          <div className="text-2xl font-bold">{fmt(totalMaterialValue)}</div>
          <div className="text-xs text-muted-foreground mt-0.5">across all sites</div>
        </div>
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            <CreditCard className="w-3.5 h-3.5" /> Paid
          </div>
          <div className="text-2xl font-bold text-green-600 dark:text-green-400">{fmt(totalPaid)}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{recentPayments.length} payments</div>
        </div>
        <div className={`border rounded-lg p-4 ${totalOutstanding > 0 ? "border-orange-300 bg-orange-50 dark:border-orange-700 dark:bg-orange-900/10" : "border-border"}`}>
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
            Outstanding
          </div>
          <div className={`text-2xl font-bold ${totalOutstanding > 0 ? "text-orange-600 dark:text-orange-400" : "text-green-600 dark:text-green-400"}`}>
            {fmt(totalOutstanding)}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">balance due</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border pb-0">
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors cursor-pointer ${activeTab === "info" ? "border-orange-500 text-orange-500" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setActiveTab("info")}
        >
          Info & History
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${activeTab === "pos" ? "border-orange-500 text-orange-500" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setActiveTab("pos")}
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          Purchase Orders
          {pos.length > 0 && (
            <span className="bg-blue-500 text-white text-xs rounded-full px-1.5 py-0.5 min-w-[18px] text-center">
              {pos.length}
            </span>
          )}
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${activeTab === "files" ? "border-orange-500 text-orange-500" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setActiveTab("files")}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          Bills & Challan Photos
          {(billFiles.length + challanPhotos.length) > 0 && (
            <span className="bg-orange-500 text-white text-xs rounded-full px-1.5 py-0.5 min-w-[18px] text-center">
              {billFiles.length + challanPhotos.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === "info" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Supplier Info */}
          <div className="space-y-4">
            <div className="border border-border rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-sm">Supplier Information</h3>
              {[
                { label: "GST Number", value: supplier.gstNumber ?? "—" },
                { label: "PAN Number", value: supplier.panNumber ?? "—" },
                { label: "Address", value: supplier.address ?? "—" },
              ].map((row) => (
                <div key={row.label} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{row.label}</span>
                  <span className="font-medium text-right max-w-[200px]">{row.value}</span>
                </div>
              ))}
            </div>
            {(supplier.bankName || supplier.accountNumber) && (
              <div className="border border-border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Bank Details</h3>
                {[
                  { label: "Bank", value: supplier.bankName ?? "—" },
                  { label: "Account", value: supplier.accountNumber ?? "—" },
                  { label: "IFSC", value: supplier.ifscCode ?? "—" },
                ].map((row) => (
                  <div key={row.label} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{row.label}</span>
                    <span className="font-medium font-mono">{row.value}</span>
                  </div>
                ))}
              </div>
            )}
            {/* Recent Payments */}
            <div className="border border-border rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-sm">Recent Payments</h3>
              {recentPayments.length === 0 ? (
                <p className="text-sm text-muted-foreground">No payments recorded yet</p>
              ) : (
                <div className="space-y-2">
                  {recentPayments.map((p) => (
                    <div key={p._id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <div>
                        <div className="text-sm font-medium">{fmt(p.amount)}</div>
                        <div className="text-xs text-muted-foreground">
                          {p.date} · {p.mode === "bill_payment" ? "Bill Payment" : p.mode.toUpperCase()}
                        </div>
                        {p.description && (
                          <div className="text-xs text-muted-foreground/70">{p.description}</div>
                        )}
                      </div>
                      {p.referenceNumber && (
                        <span className="text-xs text-muted-foreground font-mono">{p.referenceNumber}</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Deliveries */}
          <div className="border border-border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">Recent Deliveries</h3>
              <Link to="/materials" className="text-xs text-primary cursor-pointer">View all</Link>
            </div>
            {recentMaterials.length === 0 ? (
              <p className="text-sm text-muted-foreground">No deliveries recorded yet</p>
            ) : (
              <div className="space-y-2">
                {recentMaterials.map((m) => (
                  <div key={m._id} className="flex items-start justify-between py-2 border-b border-border last:border-0 cursor-pointer hover:bg-muted/30 rounded px-1"
                    onClick={() => navigate(`/materials/${m._id}`)}>
                    <div>
                      <div className="text-sm font-medium">{m.siteName}</div>
                      <div className="text-xs text-muted-foreground">{m.deliveryDate}</div>
                      {m.invoiceNumber && <div className="text-xs text-muted-foreground">Inv: {m.invoiceNumber}</div>}
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold">{fmt(m.totalAmount)}</div>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full capitalize ${MATERIAL_STATUS_COLORS[m.status] ?? ""}`}>
                        {m.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "pos" && (
        <div className="space-y-3">
          {pos.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <ShoppingCart className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm font-medium">Koi Purchase Order nahi hai</p>
              <p className="text-xs mt-1">Admin jab PO issue karega, yahan dikhega</p>
            </div>
          ) : (
            pos.map((po) => {
              const statusColor =
                po.status === "closed" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" :
                po.status === "cancelled" ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" :
                po.status === "sent" ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400" :
                po.status === "partially_received" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" :
                "bg-muted text-muted-foreground";
              const statusLabel =
                po.status === "sent" ? "Bheja Gaya" :
                po.status === "closed" ? "Complete" :
                po.status === "cancelled" ? "Cancel" :
                po.status === "partially_received" ? "Part Received" :
                po.status === "draft" ? "Draft" :
                po.status ?? "—";
              const receivedValue = po.receiptCount > 0 ? 0 : 0; // receipts tracked separately
              const pendingValue = po.totalValue - receivedValue;
              return (
                <Link key={po._id} to={`/purchase-orders/${po._id}`}
                  className="block border border-border rounded-xl p-4 hover:bg-muted/30 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <ShoppingCart className="w-4 h-4 text-blue-500 shrink-0" />
                        <span className="font-bold text-base">{po.poNumber}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${statusColor}`}>{statusLabel}</span>
                      </div>
                      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-1">
                        {po.siteName && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{po.siteName}</span>}
                        {po.companyName && <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{po.companyName}</span>}
                        {po.issueDate && <span>Issued: {po.issueDate}</span>}
                        {po.expectedDeliveryDate && <span>Due: {po.expectedDeliveryDate}</span>}
                      </div>
                      <div className="mt-2 text-xs text-muted-foreground">
                        {po.items.length} item{po.items.length !== 1 ? "s" : ""}
                        {po.items.length > 0 && (
                          <span className="ml-2 text-foreground/60">
                            {po.items.map((i) => `${i.name} (${i.quantity} ${i.unit})`).join(", ")}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0 space-y-1">
                      <p className="text-lg font-bold">{fmt(po.totalValue)}</p>
                      {receivedValue > 0 && (
                        <p className="text-xs text-green-600 dark:text-green-400">Received: {fmt(receivedValue)}</p>
                      )}
                      {pendingValue > 0 && po.status !== "closed" && po.status !== "cancelled" && (
                        <p className="text-xs text-orange-500">Pending: {fmt(pendingValue)}</p>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })
          )}
          {pos.length > 0 && (
            <div className="text-center pt-2">
              <Link to="/purchase-orders" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                Saare Purchase Orders dekhein →
              </Link>
            </div>
          )}
        </div>
      )}

      {activeTab === "files" && (
        <div className="space-y-6">
          {/* Bill Files (Materials) */}
          {billFiles.length > 0 && (
            <div>
              <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-orange-500" />
                Material Bill Files ({billFiles.length})
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {billFiles.map((f) => {
                  const isImage = f.type.startsWith("image/");
                  const isPdf = f.type === "application/pdf";
                  return (
                    <div key={f.storageId} className="border border-border rounded-lg overflow-hidden group relative">
                      {isImage ? (
                        <button
                          className="w-full aspect-square cursor-pointer"
                          onClick={() => setPreviewUrl(f.url ?? null)}
                        >
                          <img src={f.url ?? ""} alt={f.name} className="w-full h-full object-cover" />
                        </button>
                      ) : (
                        <div className="w-full aspect-square bg-red-500/5 flex flex-col items-center justify-center gap-2">
                          {isPdf ? <FileText className="w-8 h-8 text-red-500" /> : <FileIcon className="w-8 h-8 text-muted-foreground" />}
                          <span className="text-xs text-muted-foreground px-2 text-center">PDF</span>
                        </div>
                      )}
                      <div className="p-2 border-t border-border bg-muted/20">
                        <p className="text-xs font-medium truncate">{f.name}</p>
                        <p className="text-xs text-muted-foreground">{f.deliveryDate}</p>
                        {f.invoiceNumber && <p className="text-xs text-muted-foreground truncate">Inv: {f.invoiceNumber}</p>}
                      </div>
                      {f.url && (
                        <a
                          href={f.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="absolute top-1 right-1 w-6 h-6 bg-black/50 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          title="Open file"
                        >
                          <ExternalLink className="w-3 h-3 text-white" />
                        </a>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Challan Photos */}
          {challanPhotos.length > 0 && (
            <div>
              <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-blue-500" />
                Delivery Challan Photos ({challanPhotos.length})
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {challanPhotos.map((p) => (
                  <div key={p.storageId} className="border border-border rounded-lg overflow-hidden group relative">
                    <button
                      className="w-full aspect-square cursor-pointer"
                      onClick={() => setPreviewUrl(p.url ?? null)}
                    >
                      <img src={p.url ?? ""} alt={p.materialType} className="w-full h-full object-cover" />
                    </button>
                    <div className="p-2 border-t border-border bg-muted/20">
                      <p className="text-xs font-medium truncate">{p.materialType}</p>
                      <p className="text-xs text-muted-foreground">{p.deliveryDate}</p>
                    </div>
                    {p.url && (
                      <a
                        href={p.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="absolute top-1 right-1 w-6 h-6 bg-black/50 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Open photo"
                      >
                        <ExternalLink className="w-3 h-3 text-white" />
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {billFiles.length === 0 && challanPhotos.length === 0 && (
            <div className="text-center py-16 text-muted-foreground">
              <ImageIcon className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No bills or challan photos uploaded yet</p>
              <p className="text-xs mt-1">Upload bill photos from Materials &amp; Delivery entries</p>
            </div>
          )}
        </div>
      )}

      {/* Lightbox */}
      {previewUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setPreviewUrl(null)}
        >
          <button
            className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 cursor-pointer"
            onClick={() => setPreviewUrl(null)}
          >
            <X className="w-4 h-4" />
          </button>
          <img
            src={previewUrl}
            alt="Preview"
            className="max-w-full max-h-full rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
