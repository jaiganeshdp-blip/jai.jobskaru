import { toast } from "sonner";
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { BulkDeleteBar, BulkCheckbox } from "@/components/bulk-delete-bar.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog.tsx";
import { Plus, Search, Pencil, Trash2, Truck, Link as LinkIcon, Eye } from "lucide-react";
import { WhatsAppButton } from "@/components/whatsapp-button.tsx";
import { Link } from "react-router-dom";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

const MATERIAL_CATEGORIES = [
  "Cement", "Steel", "Sand", "Aggregate", "Bricks", "Tiles",
  "Plumbing", "Electrical", "Paint", "Glass", "Wood", "Other",
];

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  mobile: z.string().min(10, "Valid mobile required"),
  email: z.string().email().optional().or(z.literal("")),
  gstNumber: z.string().optional(),
  panNumber: z.string().optional(),
  city: z.string().optional(),
  address: z.string().optional(),
  bankName: z.string().optional(),
  accountNumber: z.string().optional(),
  ifscCode: z.string().optional(),
  materialCategories: z.array(z.string()).optional(),
});
type SupplierForm = z.infer<typeof schema>;

function copyPortalLink(token: string) {
  const url = `${window.location.origin}/portal/supplier?token=${token}`;
  void navigator.clipboard.writeText(url);
  toast.success("Portal link copied!");
}

export default function Suppliers() {
  const suppliers = useQuery(api.suppliers.list, {});
  const createSupplier = useMutation(api.suppliers.create);
  const updateSupplier = useMutation(api.suppliers.update);
  const removeSupplier = useMutation(api.suppliers.remove);

  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); } else { next.add(id); }
      return next;
    });
  }

  function toggleAll() {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((s) => s._id)));
    }
  }

  function clearSelection() {
    setSelectedIds(new Set());
  }

  const form = useForm<SupplierForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", mobile: "", materialCategories: [] },
  });

  const filtered = (suppliers ?? []).filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      (s.city ?? "").toLowerCase().includes(search.toLowerCase()) ||
      (s.gstNumber ?? "").toLowerCase().includes(search.toLowerCase())
  );

  function openCreate() {
    setEditId(null);
    setSelectedCategories([]);
    form.reset({ name: "", mobile: "", materialCategories: [] });
    setDialogOpen(true);
  }

  function openEdit(s: (typeof filtered)[number]) {
    setEditId(s._id);
    const cats = s.materialCategories ?? [];
    setSelectedCategories(cats);
    form.reset({
      name: s.name,
      mobile: s.mobile,
      email: s.email ?? "",
      gstNumber: s.gstNumber ?? "",
      panNumber: s.panNumber ?? "",
      city: s.city ?? "",
      address: s.address ?? "",
      bankName: s.bankName ?? "",
      accountNumber: s.accountNumber ?? "",
      ifscCode: s.ifscCode ?? "",
      materialCategories: cats,
    });
    setDialogOpen(true);
  }

  function toggleCategory(cat: string) {
    const next = selectedCategories.includes(cat)
      ? selectedCategories.filter((c) => c !== cat)
      : [...selectedCategories, cat];
    setSelectedCategories(next);
    form.setValue("materialCategories", next);
  }

  async function onSubmit(data: SupplierForm) {
    try {
      const payload = {
        ...data,
        email: data.email || undefined,
        gstNumber: data.gstNumber || undefined,
        panNumber: data.panNumber || undefined,
        city: data.city || undefined,
        address: data.address || undefined,
        bankName: data.bankName || undefined,
        accountNumber: data.accountNumber || undefined,
        ifscCode: data.ifscCode || undefined,
        materialCategories: selectedCategories.length > 0 ? selectedCategories : undefined,
      };
      if (editId) {
        await updateSupplier({ id: editId as Id<"suppliers">, ...payload });
        toast.success("Supplier updated");
      } else {
        await createSupplier(payload);
        toast.success("Supplier added — portal link generated!");
      }
      setDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    }
  }

  async function handleDelete(id: string) {
    try {
      await removeSupplier({ id: id as Id<"suppliers"> });
      toast.success("Supplier deleted");
      setDeleteConfirm(null);
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Suppliers</h1>
          <p className="text-muted-foreground text-sm">
            Material suppliers &amp; shopkeepers — each gets a private portal link
          </p>
        </div>
        <Button onClick={openCreate} className="cursor-pointer">
          <Plus className="w-4 h-4 mr-1" /> Add Supplier
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, city or GST..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <BulkDeleteBar
        selectedCount={selectedIds.size}
        onDelete={async () => {
          await Promise.all(
            Array.from(selectedIds).map((id) =>
              removeSupplier({ id: id as Id<"suppliers"> })
            )
          );
          clearSelection();
        }}
        onClear={clearSelection}
        itemLabel="supplier"
      />

      {!suppliers ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Truck /></EmptyMedia>
            <EmptyTitle>No suppliers found</EmptyTitle>
            <EmptyDescription>{search ? "Try adjusting your search" : "Add your first material supplier"}</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={openCreate} size="sm" className="cursor-pointer">Add Supplier</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <BulkCheckbox
                      checked={filtered.length > 0 && selectedIds.size === filtered.length}
                      indeterminate={selectedIds.size > 0 && selectedIds.size < filtered.length}
                      onCheckedChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Supplier Name</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Mobile</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">GST</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">City</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">Categories</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((s) => (
                  <tr key={s._id} className="hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <BulkCheckbox
                        checked={selectedIds.has(s._id)}
                        onCheckedChange={() => toggleSelect(s._id)}
                      />
                    </td>
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                          <Truck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <span className="truncate max-w-[150px]">{s.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <div className="flex items-center gap-1">
                        <span>{s.mobile}</span>
                        <WhatsAppButton mobile={s.mobile} />
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{s.gstNumber ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground hidden lg:table-cell">{s.city ?? "—"}</td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <div className="flex flex-wrap gap-1">
                        {(s.materialCategories ?? []).slice(0, 2).map((cat) => (
                          <Badge key={cat} variant="secondary" className="text-xs px-1.5 py-0">{cat}</Badge>
                        ))}
                        {(s.materialCategories ?? []).length > 2 && (
                          <Badge variant="secondary" className="text-xs px-1.5 py-0">+{(s.materialCategories ?? []).length - 2}</Badge>
                        )}
                        {!(s.materialCategories ?? []).length && <span className="text-muted-foreground">—</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${s.isActive ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-gray-100 text-gray-600"}`}>
                        {s.isActive ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link to={`/suppliers/${s._id}`}>
                          <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" title="View details">
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                        </Link>
                        {s.portalToken && (
                          <Button
                            size="icon" variant="ghost"
                            className="w-8 h-8 cursor-pointer"
                            title="Copy portal link"
                            onClick={() => copyPortalLink(s.portalToken!)}
                          >
                            <LinkIcon className="w-3.5 h-3.5 text-blue-500" />
                          </Button>
                        )}
                        <Button size="icon" variant="ghost" className="w-8 h-8 cursor-pointer" onClick={() => openEdit(s)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="icon" variant="ghost"
                          className="w-8 h-8 cursor-pointer text-destructive hover:text-destructive"
                          onClick={() => setDeleteConfirm(s._id)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Supplier" : "Add Supplier"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Supplier / Shop Name *</FormLabel>
                    <FormControl><Input placeholder="Shree Steel Works" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="mobile" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile *</FormLabel>
                    <FormControl><Input placeholder="9876543210" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl><Input placeholder="supplier@example.com" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="gstNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>GST Number</FormLabel>
                    <FormControl><Input placeholder="27ABCDE1234F1Z5" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="panNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>PAN Number</FormLabel>
                    <FormControl><Input placeholder="ABCDE1234F" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="city" render={({ field }) => (
                  <FormItem>
                    <FormLabel>City</FormLabel>
                    <FormControl><Input placeholder="Pune" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl><Input placeholder="Shop 12, Market Road" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                {/* Material Categories */}
                <FormItem className="col-span-2">
                  <FormLabel>Material Categories</FormLabel>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {MATERIAL_CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => toggleCategory(cat)}
                        className={`px-3 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors border
                          ${selectedCategories.includes(cat)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-muted text-muted-foreground border-border hover:bg-muted/60"
                          }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </FormItem>

                {/* Bank Details */}
                <div className="col-span-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Bank Details</p>
                </div>
                <FormField control={form.control} name="bankName" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bank Name</FormLabel>
                    <FormControl><Input placeholder="SBI" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="accountNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Number</FormLabel>
                    <FormControl><Input placeholder="1234567890" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="ifscCode" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>IFSC Code</FormLabel>
                    <FormControl><Input placeholder="SBIN0001234" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} className="cursor-pointer">Cancel</Button>
                <Button type="submit" className="cursor-pointer">{editId ? "Update" : "Add Supplier"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Supplier?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently delete the supplier record.</p>
          <DialogFooter className="gap-2">
            <Button variant="secondary" onClick={() => setDeleteConfirm(null)} className="cursor-pointer">Cancel</Button>
            <Button variant="destructive" onClick={() => deleteConfirm && handleDelete(deleteConfirm)} className="cursor-pointer">Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
