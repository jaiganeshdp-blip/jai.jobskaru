import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Authenticated } from "convex/react";
import {
  Package,
  CheckCircle2,
  XCircle,
  Clock,
  Truck,
  AlertTriangle,
  Eye,
  Filter,
} from "lucide-react";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type RequestDoc = {
  _id: Id<"materialRequests">;
  _creationTime: number;
  siteId: Id<"sites">;
  requestedByLabourerId: Id<"labourers">;
  itemName: string;
  quantity: number;
  unit: string;
  urgency: "low" | "medium" | "high";
  notes?: string;
  photoStorageId?: string;
  status: "requested" | "po_issued" | "delivered" | "rejected";
  assignedSupplierId?: Id<"suppliers">;
  purchaseOrderId?: Id<"purchaseOrders">;
  adminNote?: string;
  supervisorName: string;
  siteName: string;
  supplierName?: string;
  supplierMobile?: string;
  poNumber?: string;
  poExpectedDelivery?: string;
  poTotalValue?: number;
  photoUrl?: string | null;
};

function urgencyBadge(u: string) {
  if (u === "high") return <Badge className="bg-red-500/15 text-red-600 border-red-500/30">High</Badge>;
  if (u === "medium") return <Badge className="bg-orange-500/15 text-orange-600 border-orange-500/30">Medium</Badge>;
  return <Badge className="bg-green-500/15 text-green-600 border-green-500/30">Low</Badge>;
}

function statusBadge(s: string) {
  if (s === "requested") return <Badge className="bg-yellow-500/15 text-yellow-600 border-yellow-500/30"><Clock className="w-3 h-3 mr-1" />Requested</Badge>;
  if (s === "po_issued") return <Badge className="bg-blue-500/15 text-blue-600 border-blue-500/30"><CheckCircle2 className="w-3 h-3 mr-1" />PO Issued</Badge>;
  if (s === "delivered") return <Badge className="bg-green-500/15 text-green-600 border-green-500/30"><Truck className="w-3 h-3 mr-1" />Delivered</Badge>;
  if (s === "rejected") return <Badge className="bg-red-500/15 text-red-600 border-red-500/30"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
  return <Badge variant="outline">{s}</Badge>;
}

function ReviewDialog({
  req,
  onClose,
}: {
  req: RequestDoc;
  onClose: () => void;
}) {
  const suppliers = useQuery(api.suppliers.list, {});
  const issuePO = useMutation(api.supervisorPortal.issuePOForRequest);
  const rejectRequest = useMutation(api.supervisorPortal.rejectMaterialRequest);
  const markDelivered = useMutation(api.supervisorPortal.markDelivered);

  const [supplierId, setSupplierId] = useState<string>(req.assignedSupplierId ?? "");
  const [ratePerUnit, setRatePerUnit] = useState<string>("");
  const [expectedDelivery, setExpectedDelivery] = useState<string>("");
  const [adminNote, setAdminNote] = useState(req.adminNote ?? "");
  const [saving, setSaving] = useState(false);

  const totalValue = parseFloat(ratePerUnit || "0") * req.quantity;

  const handleIssuePO = async () => {
    if (!supplierId) { toast.error("Supplier chunein pehle"); return; }
    const rate = parseFloat(ratePerUnit);
    if (!rate || rate <= 0) { toast.error("Rate per unit daalo"); return; }
    setSaving(true);
    try {
      await issuePO({
        requestId: req._id,
        supplierId: supplierId as Id<"suppliers">,
        ratePerUnit: rate,
        expectedDeliveryDate: expectedDelivery || undefined,
        adminNote: adminNote || undefined,
      });
      toast.success("PO create ho gaya aur supplier assign kar diya!");
      onClose();
    } catch {
      toast.error("PO create karne mein error");
    } finally {
      setSaving(false);
    }
  };

  const handleReject = async () => {
    setSaving(true);
    try {
      await rejectRequest({ requestId: req._id, adminNote: adminNote || undefined });
      toast.success("Request reject ho gayi");
      onClose();
    } catch {
      toast.error("Reject nahi hua");
    } finally {
      setSaving(false);
    }
  };

  const handleMarkDelivered = async () => {
    setSaving(true);
    try {
      await markDelivered({ requestId: req._id });
      toast.success("Delivered mark ho gaya!");
      onClose();
    } catch {
      toast.error("Update nahi hua");
    } finally {
      setSaving(false);
    }
  };

  const activeSuppliers = suppliers?.filter((s) => s.isActive) ?? [];

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle>Material Request Review</DialogTitle>
        <DialogDescription>{req.siteName} • {req.supervisorName}</DialogDescription>
      </DialogHeader>

      <div className="space-y-4 py-1">
        {/* Request details */}
        <div className="bg-muted/40 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-base">{req.itemName}</span>
            {urgencyBadge(req.urgency)}
          </div>
          <p className="text-sm text-muted-foreground">
            {req.quantity} {req.unit}
          </p>
          {req.notes && <p className="text-sm">{req.notes}</p>}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{statusBadge(req.status)}</span>
            <span>{new Date(req._creationTime).toLocaleDateString("en-IN")}</span>
          </div>
        </div>

        {/* Photo */}
        {req.photoUrl && (
          <div>
            <Label className="text-xs text-muted-foreground mb-1 block">Photo</Label>
            <a href={req.photoUrl} target="_blank" rel="noreferrer">
              <img src={req.photoUrl} alt="request" className="w-full max-h-48 object-cover rounded-lg border" />
            </a>
          </div>
        )}

        {/* PO issued info */}
        {req.status === "po_issued" && req.supplierName && (
          <div className="bg-blue-50 dark:bg-blue-950/30 rounded-lg p-3 space-y-1">
            <p className="font-semibold text-blue-700 dark:text-blue-400 text-sm">PO Issued</p>
            {req.poNumber && <p className="text-xs text-blue-600">PO No: <span className="font-mono font-medium">{req.poNumber}</span></p>}
            <p className="text-xs text-blue-600">Supplier: <span className="font-medium">{req.supplierName}</span> {req.supplierMobile && `• ${req.supplierMobile}`}</p>
            {req.poExpectedDelivery && <p className="text-xs text-blue-600">Expected Delivery: {req.poExpectedDelivery}</p>}
            {req.poTotalValue !== undefined && <p className="text-xs text-blue-600">PO Value: ₹{req.poTotalValue.toLocaleString("en-IN")}</p>}
          </div>
        )}

        {/* Supplier assignment — only for new requests */}
        {req.status === "requested" && (
          <>
            <div className="space-y-2">
              <Label>Supplier Assign Karo</Label>
              <Select value={supplierId} onValueChange={setSupplierId}>
                <SelectTrigger>
                  <SelectValue placeholder="Supplier chunein..." />
                </SelectTrigger>
                <SelectContent>
                  {activeSuppliers.map((s) => (
                    <SelectItem key={s._id} value={s._id}>
                      {s.name} {s.mobile ? `• ${s.mobile}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Rate per {req.unit} (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step={0.01}
                  placeholder="0"
                  value={ratePerUnit}
                  onChange={(e) => setRatePerUnit(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Total Value</Label>
                <div className="h-10 flex items-center px-3 rounded-md border bg-muted text-sm font-semibold text-primary">
                  ₹{totalValue.toLocaleString("en-IN")}
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Expected Delivery Date</Label>
              <Input
                type="date"
                value={expectedDelivery}
                onChange={(e) => setExpectedDelivery(e.target.value)}
              />
            </div>
          </>
        )}

        {/* Admin note */}
        {req.status !== "delivered" && (
          <div className="space-y-2">
            <Label>Admin Note (optional)</Label>
            <Textarea
              placeholder="Supplier contact, delivery time, any instructions..."
              value={adminNote}
              onChange={(e) => setAdminNote(e.target.value)}
              rows={2}
            />
          </div>
        )}
      </div>

      <DialogFooter className="flex-wrap gap-2">
        {req.status === "requested" && (
          <>
            <Button variant="destructive" onClick={handleReject} disabled={saving} className="cursor-pointer">
              Reject
            </Button>
            <Button onClick={handleIssuePO} disabled={saving || !supplierId || !ratePerUnit} className="cursor-pointer">
              Issue PO
            </Button>
          </>
        )}
        {req.status === "po_issued" && (
          <Button onClick={handleMarkDelivered} disabled={saving} className="cursor-pointer">
            <Truck className="w-4 h-4 mr-1" />
            Mark Delivered
          </Button>
        )}
        {(req.status === "delivered" || req.status === "rejected") && (
          <Button variant="secondary" onClick={onClose} className="cursor-pointer">Close</Button>
        )}
      </DialogFooter>
    </DialogContent>
  );
}

function MaterialRequestsInner() {
  const sites = useQuery(api.sites.list, {});
  const [filterSite, setFilterSite] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [selected, setSelected] = useState<RequestDoc | null>(null);

  const requests = useQuery(api.supervisorPortal.listMaterialRequests, {
    siteId: filterSite !== "all" ? (filterSite as Id<"sites">) : undefined,
    status: filterStatus !== "all" ? filterStatus : undefined,
  }) as RequestDoc[] | undefined;

  const counts = {
    requested: requests?.filter((r) => r.status === "requested").length ?? 0,
    po_issued: requests?.filter((r) => r.status === "po_issued").length ?? 0,
    delivered: requests?.filter((r) => r.status === "delivered").length ?? 0,
    rejected: requests?.filter((r) => r.status === "rejected").length ?? 0,
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Material Requests</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Supervisor ke requests review karo, supplier assign karo aur PO issue karo</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Pending", value: counts.requested, color: "text-yellow-600", bg: "bg-yellow-500/10" },
          { label: "PO Issued", value: counts.po_issued, color: "text-blue-600", bg: "bg-blue-500/10" },
          { label: "Delivered", value: counts.delivered, color: "text-green-600", bg: "bg-green-500/10" },
          { label: "Rejected", value: counts.rejected, color: "text-red-600", bg: "bg-red-500/10" },
        ].map((c) => (
          <div key={c.label} className={`${c.bg} rounded-lg p-3 text-center`}>
            <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{c.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <Filter className="w-4 h-4 text-muted-foreground" />
        <Select value={filterSite} onValueChange={setFilterSite}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="All Sites" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sites</SelectItem>
            {sites?.map((s) => (
              <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="requested">Requested</SelectItem>
            <SelectItem value="po_issued">PO Issued</SelectItem>
            <SelectItem value="delivered">Delivered</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      {requests === undefined ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}
        </div>
      ) : requests.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Package /></EmptyMedia>
            <EmptyTitle>Koi Material Request Nahi</EmptyTitle>
            <EmptyDescription>Supervisor ke request yahan dikhenge</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="space-y-3">
          {requests.map((req) => (
            <Card key={req._id} className="py-0 hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  {/* Urgency indicator */}
                  <div className={`w-1 self-stretch rounded-full flex-shrink-0 ${
                    req.urgency === "high" ? "bg-red-500" :
                    req.urgency === "medium" ? "bg-orange-400" : "bg-green-400"
                  }`} />

                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <p className="font-semibold">{req.itemName}</p>
                        <p className="text-sm text-muted-foreground">
                          {req.quantity} {req.unit} • {req.siteName} • {req.supervisorName}
                        </p>
                      </div>
                      <div className="flex gap-1.5 flex-wrap">
                        {urgencyBadge(req.urgency)}
                        {statusBadge(req.status)}
                      </div>
                    </div>

                    {req.notes && (
                      <p className="text-sm text-muted-foreground line-clamp-1">{req.notes}</p>
                    )}

                    {req.status === "po_issued" && req.supplierName && (
                      <p className="text-xs text-blue-600 dark:text-blue-400">
                        Supplier: {req.supplierName} {req.supplierMobile ? `• ${req.supplierMobile}` : ""}
                      </p>
                    )}

                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">
                        {new Date(req._creationTime).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                      </p>
                      {req.status !== "delivered" && req.status !== "rejected" ? (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => setSelected(req)}
                          className="cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 mr-1" />
                          Review
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setSelected(req)}
                          className="cursor-pointer text-muted-foreground"
                        >
                          <Eye className="w-3.5 h-3.5 mr-1" />
                          View
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Review dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        {selected && (
          <ReviewDialog req={selected} onClose={() => setSelected(null)} />
        )}
      </Dialog>
    </div>
  );
}

export default function MaterialRequestsPage() {
  return (
    <Authenticated>
      <MaterialRequestsInner />
    </Authenticated>
  );
}
