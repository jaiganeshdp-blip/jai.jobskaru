import { useEffect, useRef, useState, useCallback } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion, AnimatePresence } from "motion/react";
import { MapPin, Building2, HardHat } from "lucide-react";

const DEFAULT_IDLE_MS = 5 * 60 * 1000; // 5 minutes

type Slide = {
  _id: string;
  title: string;
  subtitle?: string;
  imageUrl?: string;
  siteName?: string;
  city?: string;
  company?: string;
};

function ScreensaverDisplay({
  slides,
  transitionSecs,
  theme,
  onDismiss,
}: {
  slides: Slide[];
  transitionSecs: number;
  theme: "dark" | "light" | "blur";
  onDismiss: () => void;
}) {
  const [index, setIndex] = useState(0);
  const [tick, setTick] = useState(0);

  // Cycle slides
  useEffect(() => {
    if (slides.length === 0) return;
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length);
      setTick((t) => t + 1);
    }, transitionSecs * 1000);
    return () => clearInterval(id);
  }, [slides.length, transitionSecs]);

  // Dismiss on any interaction
  useEffect(() => {
    const handler = () => onDismiss();
    window.addEventListener("click", handler);
    window.addEventListener("keydown", handler);
    window.addEventListener("mousemove", handler);
    window.addEventListener("touchstart", handler);
    return () => {
      window.removeEventListener("click", handler);
      window.removeEventListener("keydown", handler);
      window.removeEventListener("mousemove", handler);
      window.removeEventListener("touchstart", handler);
    };
  }, [onDismiss]);

  const slide = slides[index] ?? slides[0];
  if (!slide) return null;

  const bgClass = theme === "light" ? "bg-white text-gray-900" : "bg-[oklch(0.08_0.02_250)] text-white";

  return (
    <div className={`fixed inset-0 z-[9999] flex flex-col overflow-hidden ${bgClass}`}>
      {/* Background image */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tick}
          initial={{ opacity: 0, scale: 1.06 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 1.2, ease: [0.25, 0.1, 0.25, 1] as const }}
          className="absolute inset-0"
        >
          {slide.imageUrl ? (
            <>
              <img
                src={slide.imageUrl}
                alt={slide.title}
                className="w-full h-full object-cover"
              />
              {/* Overlay */}
              <div
                className={`absolute inset-0 ${
                  theme === "blur"
                    ? "backdrop-blur-sm bg-black/40"
                    : theme === "dark"
                    ? "bg-gradient-to-t from-black/80 via-black/30 to-black/10"
                    : "bg-gradient-to-t from-white/70 via-white/20 to-transparent"
                }`}
              />
            </>
          ) : (
            /* No image — geometric background */
            <div className="w-full h-full bg-[oklch(0.1_0.03_250)] relative overflow-hidden">
              <div className="absolute inset-0 opacity-10">
                {Array.from({ length: 6 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute border border-primary rounded-full"
                    style={{
                      width: `${200 + i * 120}px`,
                      height: `${200 + i * 120}px`,
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%,-50%)",
                    }}
                    animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
                    transition={{
                      duration: 20 + i * 5,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  />
                ))}
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <HardHat className="w-32 h-32 text-primary/30" />
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Top: Logo + date time */}
      <motion.div
        className="relative z-10 flex items-center justify-between px-10 pt-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
            <HardHat className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-bold text-lg leading-none">JAI SITE MANAGER ERP</div>
            <div className="text-xs opacity-60">Site Management Platform</div>
          </div>
        </div>
        <LiveClock dim={theme === "light"} />
      </motion.div>

      {/* Bottom: Slide info */}
      <div className="relative z-10 mt-auto px-10 pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={`info-${tick}`}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] as const }}
          >
            <div className="flex flex-wrap gap-3 mb-4">
              {slide.company && (
                <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm border border-white/20 px-3 py-1 rounded-full text-xs">
                  <Building2 className="w-3 h-3" />
                  {slide.company}
                </div>
              )}
              {slide.city && (
                <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm border border-white/20 px-3 py-1 rounded-full text-xs">
                  <MapPin className="w-3 h-3" />
                  {slide.city}
                </div>
              )}
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-tight drop-shadow-lg">
              {slide.title}
            </h1>
            {slide.subtitle && (
              <p className="text-xl opacity-70 mt-3 max-w-2xl">{slide.subtitle}</p>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Slide dots */}
        {slides.length > 1 && (
          <div className="flex gap-2 mt-6">
            {slides.map((_, i) => (
              <motion.div
                key={i}
                className="h-1.5 rounded-full bg-white/40"
                animate={{ width: i === index ? 32 : 8, opacity: i === index ? 1 : 0.4 }}
                transition={{ duration: 0.4 }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Dismiss hint */}
      <motion.div
        className="absolute bottom-4 right-8 text-xs opacity-40 z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.4 }}
        transition={{ delay: 2 }}
      >
        Press any key or click to dismiss
      </motion.div>
    </div>
  );
}

function LiveClock({ dim }: { dim: boolean }) {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div className={`text-right ${dim ? "text-gray-700" : "text-white/80"}`}>
      <div className="text-3xl font-light tabular-nums">
        {time.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
      </div>
      <div className="text-xs opacity-60">
        {time.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
      </div>
    </div>
  );
}

export function Screensaver() {
  const [active, setActive] = useState(false);
  const idleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const rawSlides = useQuery(api.screensaver.getSlides, {});
  const settings = useQuery(api.screensaver.getSettings, {});
  const companies = useQuery(api.companies.list, {});
  const sites = useQuery(api.sites.list, {});

  const idleMs = (settings?.idleMinutes ?? 5) * 60 * 1000;
  const transitionSecs = settings?.transitionSeconds ?? 6;
  const theme = (settings?.theme ?? "dark") as "dark" | "light" | "blur";

  // Build enriched slides with site/company data
  const slides: Slide[] = (rawSlides ?? []).map((s) => {
    const site = sites?.find((st) => st._id === s.siteId);
    const company = site ? companies?.find((c) => c._id === site.companyId) : undefined;
    return {
      _id: s._id,
      title: s.title,
      subtitle: s.subtitle,
      imageUrl: s.imageUrl,
      siteName: site?.name,
      city: site?.city,
      company: company?.name,
    };
  });

  // If no slides configured, build default slides from sites
  const displaySlides: Slide[] =
    slides.length > 0
      ? slides
      : (sites ?? []).map((site) => {
          const company = companies?.find((c) => c._id === site.companyId);
          return {
            _id: site._id,
            title: site.name,
            subtitle: `${site.city}${company ? " · " + company.name : ""}`,
            city: site.city,
            company: company?.name,
          };
        });

  const resetTimer = useCallback(() => {
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => setActive(true), idleMs);
  }, [idleMs]);

  useEffect(() => {
    if (displaySlides.length === 0) return;
    const events = ["mousemove", "keydown", "click", "scroll", "touchstart"];
    events.forEach((e) => window.addEventListener(e, resetTimer, { passive: true }));
    resetTimer();
    return () => {
      events.forEach((e) => window.removeEventListener(e, resetTimer));
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [resetTimer, displaySlides.length]);

  if (!active || displaySlides.length === 0) return null;

  return (
    <ScreensaverDisplay
      slides={displaySlides}
      transitionSecs={transitionSecs}
      theme={theme}
      onDismiss={() => {
        setActive(false);
        resetTimer();
      }}
    />
  );
}
