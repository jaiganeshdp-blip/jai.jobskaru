import { useState } from "react";
import { Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";

interface BulkDeleteBarProps {
  selectedCount: number;
  itemLabel: string;
  onDelete: () => Promise<void>;
  onClear: () => void;
}

export function BulkDeleteBar({ selectedCount, itemLabel, onDelete, onClear }: BulkDeleteBarProps) {
  const [deleting, setDeleting] = useState(false);

  if (selectedCount === 0) return null;

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await onDelete();
    } finally {
      setDeleting(false);
    }
  };

  const label = selectedCount === 1 ? `1 ${itemLabel}` : `${selectedCount} ${itemLabel}s`;

  return (
    <div className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-lg bg-destructive/10 border border-destructive/30">
      <span className="text-sm font-medium text-destructive">
        {label} selected
      </span>
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          variant="ghost"
          className="h-7 px-2 text-muted-foreground hover:text-foreground"
          onClick={onClear}
          disabled={deleting}
        >
          <X className="h-3.5 w-3.5 mr-1" /> Clear
        </Button>
        <Button
          size="sm"
          className="h-7 bg-destructive text-destructive-foreground hover:bg-destructive/90 gap-1.5"
          onClick={handleDelete}
          disabled={deleting}
        >
          <Trash2 className="h-3.5 w-3.5" />
          {deleting ? "Deleting..." : `Delete ${label}`}
        </Button>
      </div>
    </div>
  );
}

interface BulkCheckboxProps {
  checked: boolean;
  indeterminate?: boolean;
  /** Called when checked state changes */
  onChange?: (checked: boolean) => void;
  /** Alias for onChange, for compatibility with existing pages */
  onCheckedChange?: () => void;
  onClick?: (e: React.MouseEvent) => void;
}

export function BulkCheckbox({ checked, indeterminate, onChange, onCheckedChange, onClick }: BulkCheckboxProps) {
  return (
    <input
      ref={(el) => { if (el) el.indeterminate = indeterminate ?? false; }}
      type="checkbox"
      className="w-4 h-4 cursor-pointer accent-primary"
      checked={checked}
      onChange={(e) => {
        onChange?.(e.target.checked);
        onCheckedChange?.();
      }}
      onClick={onClick}
    />
  );
}
