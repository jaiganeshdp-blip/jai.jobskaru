import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button.tsx";
import { Download, X, Share, ArrowUp } from "lucide-react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export default function PwaInstallBanner() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const [showIosSteps, setShowIosSteps] = useState(false);
  const dismissed = useRef(false);

  useEffect(() => {
    // Already installed as PWA
    if (window.matchMedia("(display-mode: standalone)").matches) return;

    // Dismissed recently (7 days)
    const lastDismissed = localStorage.getItem("pwa-install-dismissed");
    if (lastDismissed && Date.now() - Number(lastDismissed) < 7 * 24 * 60 * 60 * 1000) return;

    const ua = navigator.userAgent;
    const iosDevice = /iPad|iPhone|iPod/.test(ua) && !("MSStream" in window);
    if (iosDevice) {
      setIsIos(true);
      setShowBanner(true);
      return;
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      if (!dismissed.current) setShowBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") setShowBanner(false);
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    dismissed.current = true;
    setShowBanner(false);
    setShowIosSteps(false);
    localStorage.setItem("pwa-install-dismissed", String(Date.now()));
  };

  if (!showBanner) return null;

  // iOS: detailed steps popup
  if (isIos && showIosSteps) {
    return (
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4">
        <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm p-5 space-y-4 animate-in slide-in-from-bottom-4 fade-in duration-300">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base">Install JAI ERP on iPhone</h3>
            <button onClick={handleDismiss} className="cursor-pointer p-1 rounded-md hover:bg-muted">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">1</div>
              <div>
                <p className="text-sm font-medium">Safari mein kholein</p>
                <p className="text-xs text-muted-foreground">Site jaiaainath.com Safari browser mein open karein</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">2</div>
              <div className="flex items-start gap-2">
                <div>
                  <p className="text-sm font-medium">Share button tap karein</p>
                  <p className="text-xs text-muted-foreground">Screen ke neeche <strong>Share</strong> icon <span className="inline-flex items-center gap-0.5">(<Share className="w-3 h-3 inline" /><ArrowUp className="w-3 h-3 inline" />)</span> tap karein</p>
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">3</div>
              <div>
                <p className="text-sm font-medium">&quot;Add to Home Screen&quot; select karein</p>
                <p className="text-xs text-muted-foreground">Menu mein scroll karke <strong>Add to Home Screen</strong> tap karein, phir <strong>Add</strong></p>
              </div>
            </div>
          </div>
          <Button className="w-full cursor-pointer" onClick={handleDismiss}>
            Samajh gaya, band karein
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md animate-in slide-in-from-bottom-4 fade-in duration-300">
      <div className="bg-card border border-border rounded-xl shadow-lg p-4 flex items-center gap-3">
        <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Download className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-foreground">Install JAI ERP App</p>
          {isIos ? (
            <p className="text-xs text-muted-foreground mt-0.5">iPhone pe install karein</p>
          ) : (
            <p className="text-xs text-muted-foreground mt-0.5">Install for quick access anytime</p>
          )}
        </div>
        {isIos ? (
          <Button size="sm" onClick={() => setShowIosSteps(true)} className="cursor-pointer flex-shrink-0">
            Kaise karein?
          </Button>
        ) : (
          <Button size="sm" onClick={handleInstall} className="cursor-pointer flex-shrink-0">
            Install
          </Button>
        )}
        <button
          onClick={handleDismiss}
          className="cursor-pointer flex-shrink-0 p-1 rounded-md hover:bg-muted transition-colors"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>
    </div>
  );
}
