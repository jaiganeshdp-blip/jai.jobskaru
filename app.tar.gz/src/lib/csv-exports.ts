import Papa from "papaparse";

function triggerDownload(csvString: string, filename: string) {
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─── Attendance CSV ────────────────────────────────────────────────────────────

export type AttendanceRow = {
  date: string;
  labourerName: string;
  designation?: string;
  contractorName?: string;
  status: string;
  overtimeHours?: number;
  siteName: string;
};

export function downloadAttendanceCSV(rows: AttendanceRow[], label: string) {
  const mapped = rows.map((r) => ({
    Date: r.date,
    "Labourer Name": r.labourerName,
    Designation: r.designation ?? "",
    Contractor: r.contractorName ?? "",
    Status: r.status,
    "Overtime Hours": r.overtimeHours ?? 0,
    Site: r.siteName,
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `attendance-${label}-${new Date().toISOString().split("T")[0]}.csv`);
}

// ─── Expenses CSV ──────────────────────────────────────────────────────────────

export type ExpenseRow = {
  date: string;
  category: string;
  description: string;
  amount: number;
  paymentMode: string;
  siteName: string;
  enteredByName: string;
  notes?: string;
};

export function downloadExpensesCSV(rows: ExpenseRow[], label: string) {
  const mapped = rows.map((r) => ({
    Date: r.date,
    Category: r.category,
    Description: r.description,
    "Amount (Rs.)": r.amount,
    "Payment Mode": r.paymentMode,
    Site: r.siteName,
    "Entered By": r.enteredByName,
    Notes: r.notes ?? "",
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `expenses-${label}-${new Date().toISOString().split("T")[0]}.csv`);
}

// ─── Payments Ledger CSV ───────────────────────────────────────────────────────

export type PaymentLedgerRow = {
  date: string;
  type: string;
  amount: number;
  mode: string;
  referenceNumber?: string;
  siteName: string;
  clientName?: string;
  supplierName?: string;
  contractorName?: string;
  notes?: string;
};

export function downloadPaymentLedgerCSV(rows: PaymentLedgerRow[], label: string) {
  const mapped = rows.map((r) => ({
    Date: r.date,
    Type: r.type === "received" ? "Received from Client" : "Paid to Vendor",
    "Amount (Rs.)": r.amount,
    Mode: r.mode.toUpperCase(),
    Reference: r.referenceNumber ?? "",
    Site: r.siteName,
    Client: r.clientName ?? "",
    Supplier: r.supplierName ?? "",
    Contractor: r.contractorName ?? "",
    Notes: r.notes ?? "",
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `payment-ledger-${label}-${new Date().toISOString().split("T")[0]}.csv`);
}

// ─── Salary CSV ────────────────────────────────────────────────────────────────

export type SalaryCsvRow = {
  labourerName: string;
  designation?: string;
  contractorName?: string;
  daysWorked: number;
  halfDays: number;
  dailyRate: number;
  grossAmount: number;
  deductions: number;
  netAmount: number;
  paymentMode?: string;
};

export function downloadSalaryCSV(rows: SalaryCsvRow[], siteName: string, month: string) {
  const mapped = rows.map((r) => ({
    Name: r.labourerName,
    Designation: r.designation ?? "",
    Contractor: r.contractorName ?? "",
    "Days Worked": r.daysWorked,
    "Half Days": r.halfDays,
    "Daily Rate (Rs.)": r.dailyRate,
    "Gross (Rs.)": r.grossAmount,
    "Deductions (Rs.)": r.deductions,
    "Net Pay (Rs.)": r.netAmount,
    "Payment Mode": r.paymentMode ?? "",
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `salary-${siteName.replace(/\s+/g, "-")}-${month}.csv`);
}

// ─── Purchase Register CSV ─────────────────────────────────────────────────────

export type PurchaseRegisterRow = {
  billDate: string;
  vendorName: string;
  vendorType: string;
  billNo: string;
  description: string;
  unit: string;
  quantity: number;
  ratePerUnit: number;
  amount: number;
  gstPercent: number;
  siteName?: string;
  ourCompanyName: string;
};

export function downloadPurchaseRegisterCSV(rows: PurchaseRegisterRow[], company: string, fy: string) {
  const mapped = rows.map((r) => ({
    "Bill Date": r.billDate,
    Vendor: r.vendorName,
    "Vendor Type": r.vendorType === "supplier" ? "Supplier" : "Contractor",
    "Bill No": r.billNo,
    "Item / Description": r.description,
    Unit: r.unit,
    Quantity: r.quantity,
    "Rate (Rs.)": r.ratePerUnit,
    "Amount (Rs.)": r.amount,
    "GST %": r.gstPercent,
    Site: r.siteName ?? "",
    Company: r.ourCompanyName,
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `purchase-register-${company.replace(/\s+/g, "-")}-${fy}.csv`);
}

// ─── Sale Register CSV ─────────────────────────────────────────────────────────

export type SaleRegisterRow = {
  issueDate: string;
  clientName: string;
  invoiceNumber: string;
  description: string;
  unit: string;
  quantity: number;
  rate: number;
  amount: number;
  taxPercent: number;
  status: string;
  siteName: string;
};

export function downloadSaleRegisterCSV(rows: SaleRegisterRow[], label: string) {
  const mapped = rows.map((r) => ({
    Date: r.issueDate,
    Client: r.clientName,
    "Invoice No": r.invoiceNumber,
    "Item / Description": r.description,
    Unit: r.unit,
    Quantity: r.quantity,
    "Rate (Rs.)": r.rate,
    "Amount (Rs.)": r.amount,
    "Tax %": r.taxPercent,
    Status: r.status,
    Site: r.siteName,
  }));
  const csv = Papa.unparse(mapped);
  triggerDownload(csv, `sale-register-${label}-${new Date().toISOString().split("T")[0]}.csv`);
}
