import jsPDF from "jspdf";
import autoTablePlugin from "jspdf-autotable";

// Extend jsPDF type to include autoTable added by the plugin
interface JsPDFWithAutoTable extends jsPDF {
  lastAutoTable: { finalY: number };
}

function autoTable(doc: jsPDF, options: Record<string, unknown>) {
  autoTablePlugin(doc, options);
}

const BRAND = "JAI SITE MANAGER ERP";
const PRIMARY: [number, number, number] = [30, 64, 175]; // blue-800
const HEADER_BG: [number, number, number] = [248, 250, 252]; // slate-50

function addHeader(doc: jsPDF, title: string, subtitle?: string) {
  // Brand bar
  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, 210, 16, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.text(BRAND, 14, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, 196, 10, { align: "right" });

  // Title
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text(title, 14, 28);
  if (subtitle) {
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 116, 139);
    doc.text(subtitle, 14, 35);
  }

  // Divider
  doc.setDrawColor(...PRIMARY);
  doc.setLineWidth(0.5);
  doc.line(14, 39, 196, 39);
}

function addFooter(doc: jsPDF) {
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text(`Page ${i} of ${pageCount}`, 196, 290, { align: "right" });
    doc.text(BRAND, 14, 290);
  }
}

function fmt(n: number) {
  return "Rs." + n.toLocaleString("en-IN");
}

// ─── SALARY SHEET PDF ────────────────────────────────────────────────────────

export type SalarySheetEntry = {
  labourerName: string;
  designation?: string;
  contractorName?: string;
  daysWorked: number;
  halfDays: number;
  dailyRate: number;
  grossAmount: number;
  deductions: number;
  netAmount: number;
  paymentMode?: string;
};

export type SalarySheetData = {
  siteName: string;
  siteCity: string;
  month: string;
  status: string;
  preparedByName: string;
  approvedByName?: string;
  totalAmount: number;
  entries: SalarySheetEntry[];
};

export function downloadSalarySheetPDF(data: SalarySheetData) {
  const doc = new jsPDF({ orientation: "landscape" });
  const monthLabel = new Date(`${data.month}-01`).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric",
  });

  // Header
  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, 297, 16, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.text(BRAND, 14, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, 283, 10, { align: "right" });

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("SALARY REGISTER", 14, 28);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(`${data.siteName}, ${data.siteCity}  ·  ${monthLabel}`, 14, 35);

  // Meta info boxes
  const metaItems = [
    ["Site", data.siteName],
    ["Month", monthLabel],
    ["Status", data.status.toUpperCase()],
    ["Prepared By", data.preparedByName],
    ["Approved By", data.approvedByName ?? "—"],
    ["Total Payable", fmt(data.totalAmount)],
  ];
  let mx = 14;
  const mw = 45;
  doc.setDrawColor(220, 220, 220);
  doc.setFontSize(7);
  for (const [label, value] of metaItems) {
    doc.setFillColor(...HEADER_BG);
    doc.roundedRect(mx, 42, mw, 14, 1, 1, "FD");
    doc.setTextColor(120, 120, 120);
    doc.text(label, mx + 2, 48);
    doc.setTextColor(30, 41, 59);
    doc.setFont("helvetica", "bold");
    doc.text(String(value), mx + 2, 54);
    doc.setFont("helvetica", "normal");
    mx += mw + 2;
  }

  // Table
  const totalGross = data.entries.reduce((s, e) => s + e.grossAmount, 0);
  const totalDeductions = data.entries.reduce((s, e) => s + e.deductions, 0);

  autoTable(doc, {
    startY: 62,
    head: [["#", "Name", "Designation", "Contractor", "Days", "½ Days", "Rate/Day", "Gross", "Deductions", "Net Pay", "Mode"]],
    body: data.entries.map((e, i) => [
      String(i + 1),
      e.labourerName,
      e.designation ?? "—",
      e.contractorName ?? "—",
      String(e.daysWorked),
      String(e.halfDays),
      fmt(e.dailyRate),
      fmt(e.grossAmount),
      e.deductions > 0 ? fmt(e.deductions) : "—",
      fmt(e.netAmount),
      e.paymentMode?.toUpperCase() ?? "—",
    ]),
    foot: [[
      "", "TOTAL", "", "", "", "", "",
      fmt(totalGross),
      fmt(totalDeductions),
      fmt(data.totalAmount),
      "",
    ]],
    headStyles: { fillColor: PRIMARY, textColor: 255, fontSize: 8, fontStyle: "bold" },
    footStyles: { fillColor: [240, 253, 244], textColor: [22, 101, 52], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { cellWidth: 8, halign: "center" },
      4: { halign: "right" },
      5: { halign: "right" },
      6: { halign: "right" },
      7: { halign: "right" },
      8: { halign: "right" },
      9: { halign: "right", textColor: [22, 101, 52], fontStyle: "bold" },
    },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  addFooter(doc);
  doc.save(`salary-${data.siteName.replace(/\s+/g, "-")}-${data.month}.pdf`);
}

// ─── INVOICE PDF ──────────────────────────────────────────────────────────────

export type InvoiceLineItem = {
  description: string;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
};

export type InvoiceData = {
  invoiceNumber: string;
  issueDate: string;
  dueDate?: string;
  status: string;
  clientName: string;
  clientMobile?: string;
  clientGst?: string;
  siteName: string;
  siteCity: string;
  workOrderNumber?: string;
  items: InvoiceLineItem[];
  subtotal: number;
  taxPercent: number;
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  notes?: string;
};

export function downloadInvoicePDF(data: InvoiceData) {
  const doc = new jsPDF();
  addHeader(doc, `INVOICE — ${data.invoiceNumber}`, `${data.siteName}, ${data.siteCity}`);

  const startY = 44;

  // Bill to + Invoice info
  doc.setFillColor(...HEADER_BG);
  doc.roundedRect(14, startY, 88, 36, 2, 2, "F");
  doc.roundedRect(108, startY, 88, 36, 2, 2, "F");

  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text("BILL TO", 18, startY + 7);
  doc.setTextColor(30, 41, 59);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(data.clientName, 18, startY + 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  if (data.clientMobile) doc.text(`Mobile: ${data.clientMobile}`, 18, startY + 21);
  if (data.clientGst) doc.text(`GST: ${data.clientGst}`, 18, startY + 27);

  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text("INVOICE DETAILS", 112, startY + 7);
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);
  doc.text(`Invoice No: ${data.invoiceNumber}`, 112, startY + 14);
  doc.text(`Issue Date: ${new Date(data.issueDate).toLocaleDateString("en-IN")}`, 112, startY + 20);
  if (data.dueDate) doc.text(`Due Date: ${new Date(data.dueDate).toLocaleDateString("en-IN")}`, 112, startY + 26);
  if (data.workOrderNumber) doc.text(`WO Ref: ${data.workOrderNumber}`, 112, startY + 32);

  const statusColor = data.status === "paid" ? [22, 163, 74] : data.status === "overdue" ? [220, 38, 38] : [59, 130, 246];
  doc.setFillColor(...(statusColor as [number, number, number]));
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.roundedRect(168, startY + 8, 28, 8, 1, 1, "F");
  doc.text(data.status.toUpperCase(), 182, startY + 14, { align: "center" });
  doc.setFont("helvetica", "normal");

  // Items table
  autoTable(doc, {
    startY: startY + 42,
    head: [["#", "Description", "Qty", "Unit", "Rate (Rs.)", "Amount (Rs.)"]],
    body: data.items.map((item, i) => [
      String(i + 1),
      item.description,
      String(item.quantity),
      item.unit,
      fmt(item.rate),
      fmt(item.amount),
    ]),
    headStyles: { fillColor: PRIMARY, textColor: 255, fontSize: 9, fontStyle: "bold" },
    bodyStyles: { fontSize: 9 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      2: { halign: "right", cellWidth: 20 },
      3: { cellWidth: 20 },
      4: { halign: "right", cellWidth: 30 },
      5: { halign: "right", cellWidth: 35 },
    },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  // Totals box
  const finalY = (doc as JsPDFWithAutoTable).lastAutoTable.finalY + 6;
  doc.setFillColor(...HEADER_BG);
  doc.roundedRect(120, finalY, 76, 36, 2, 2, "F");

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text("Subtotal:", 124, finalY + 9);
  doc.text(`GST (${data.taxPercent}%):`, 124, finalY + 18);
  doc.setTextColor(30, 41, 59);
  doc.setFont("helvetica", "bold");
  doc.text("TOTAL:", 124, finalY + 28);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 41, 59);
  doc.text(fmt(data.subtotal), 192, finalY + 9, { align: "right" });
  doc.text(fmt(data.taxAmount), 192, finalY + 18, { align: "right" });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...PRIMARY);
  doc.text(fmt(data.totalAmount), 192, finalY + 28, { align: "right" });

  // Payment status
  const paidY = finalY + 44;
  const outstanding = data.totalAmount - data.paidAmount;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setFillColor(240, 253, 244);
  doc.roundedRect(14, paidY, 60, 18, 2, 2, "F");
  doc.setTextColor(22, 101, 52);
  doc.text(`Paid: ${fmt(data.paidAmount)}`, 18, paidY + 7);
  doc.text(`Outstanding: ${fmt(outstanding)}`, 18, paidY + 13);

  if (data.notes) {
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(8);
    doc.text("Notes:", 14, paidY + 26);
    doc.setTextColor(30, 41, 59);
    const lines = doc.splitTextToSize(data.notes, 180);
    doc.text(lines, 14, paidY + 32);
  }

  addFooter(doc);
  doc.save(`invoice-${data.invoiceNumber}.pdf`);
}

// ─── SITE SUMMARY PDF ─────────────────────────────────────────────────────────

export type SiteSummaryData = {
  siteName: string;
  siteCity: string;
  companyName: string;
  status: string;
  startDate?: string;
  endDate?: string;
  woValue: number;
  totalCost: number;
  grossProfit: number;
  margin: number;
  received: number;
  outstanding: number;
  expenseTotal: number;
  billTotal: number;
  salaryTotal: number;
};

export function downloadSiteSummaryPDF(data: SiteSummaryData) {
  const doc = new jsPDF();
  addHeader(doc, `SITE SUMMARY REPORT`, `${data.siteName} · ${data.siteCity}`);

  const startY = 44;
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);

  // Key metrics grid
  const metrics = [
    { label: "Site", value: data.siteName },
    { label: "Company", value: data.companyName },
    { label: "Status", value: data.status.toUpperCase() },
    { label: "City", value: data.siteCity },
    { label: "Start Date", value: data.startDate ?? "—" },
    { label: "End Date", value: data.endDate ?? "—" },
  ];

  let mx = 14;
  const mw = 58;
  for (let i = 0; i < metrics.length; i++) {
    const row = Math.floor(i / 3);
    const col = i % 3;
    const bx = 14 + col * (mw + 5);
    const by = startY + row * 18;
    doc.setFillColor(...HEADER_BG);
    doc.roundedRect(bx, by, mw, 14, 1, 1, "F");
    doc.setTextColor(100, 116, 139);
    doc.setFont("helvetica", "normal");
    doc.text(metrics[i].label, bx + 3, by + 5);
    doc.setTextColor(30, 41, 59);
    doc.setFont("helvetica", "bold");
    doc.text(String(metrics[i].value), bx + 3, by + 11);
    doc.setFont("helvetica", "normal");
    mx += mw + 5;
  }

  // Financial summary table
  autoTable(doc, {
    startY: startY + 40,
    head: [["Financial Metric", "Amount (Rs.)"]],
    body: [
      ["Work Order Value", fmt(data.woValue)],
      ["Total Expenses (petty cash)", fmt(data.expenseTotal)],
      ["Vendor Bills", fmt(data.billTotal)],
      ["Salary Paid", fmt(data.salaryTotal)],
      ["Total Cost", fmt(data.totalCost)],
      ["Gross Profit", fmt(data.grossProfit)],
      ["Margin %", `${data.margin}%`],
      ["Amount Received from Client", fmt(data.received)],
      ["Outstanding from Client", fmt(data.outstanding)],
    ],
    headStyles: { fillColor: PRIMARY, textColor: 255, fontSize: 9, fontStyle: "bold" },
    bodyStyles: { fontSize: 9 },
    columnStyles: {
      0: { cellWidth: 120 },
      1: { halign: "right", fontStyle: "bold" },
    },
    didParseCell: (data: { row: { index: number }; column: { index: number }; cell: { styles: { textColor: unknown } } }) => {
      const specialRows = [4, 5, 7, 8];
      if (specialRows.includes(data.row.index) && data.column.index === 1) {
        data.cell.styles.textColor = data.row.index === 5 ? [22, 101, 52] :
          data.row.index === 8 ? [220, 38, 38] : [30, 41, 59];
      }
    },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  addFooter(doc);
  doc.save(`site-summary-${data.siteName.replace(/\s+/g, "-")}.pdf`);
}

// ─── PURCHASE REGISTER PDF ────────────────────────────────────────────────────

export type PurchaseRegisterPdfRow = {
  billDate: string;
  vendorName: string;
  vendorType: string;
  billNo: string;
  description: string;
  unit: string;
  quantity: number;
  ratePerUnit: number;
  amount: number;
};

export function downloadPurchaseRegisterPDF(
  rows: PurchaseRegisterPdfRow[],
  company: string,
  fy: string,
  totalQty: number,
  totalAmount: number,
) {
  const doc = new jsPDF({ orientation: "landscape" });

  // Header bar
  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, 297, 16, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.text(BRAND, 14, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, 283, 10, { align: "right" });

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(15);
  doc.setFont("helvetica", "bold");
  doc.text("PURCHASE REGISTER", 14, 28);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(`${company}  ·  FY ${fy}  ·  ${rows.length} items`, 14, 35);

  const ORANGE: [number, number, number] = [194, 65, 12];

  autoTable(doc, {
    startY: 42,
    head: [["#", "Bill Date", "Vendor", "Bill No", "Item / Description", "Unit", "Qty", "Rate (Rs.)", "Amount (Rs.)"]],
    body: rows.map((r, i) => [
      String(i + 1),
      r.billDate ? r.billDate.split("T")[0].split("-").reverse().join("-") : "-",
      `${r.vendorName} [${r.vendorType === "supplier" ? "SUP" : "CON"}]`,
      r.billNo,
      r.description,
      r.unit,
      String(r.quantity),
      fmt(r.ratePerUnit),
      fmt(r.amount),
    ]),
    foot: [["", "", "", "", "", "TOTAL", fmt(totalQty), "", fmt(totalAmount)]],
    headStyles: { fillColor: ORANGE, textColor: 255, fontSize: 8, fontStyle: "bold" },
    footStyles: { fillColor: [255, 237, 213], textColor: [154, 52, 18], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    alternateRowStyles: { fillColor: [255, 247, 237] },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      1: { cellWidth: 22 },
      6: { halign: "right" },
      7: { halign: "right" },
      8: { halign: "right", fontStyle: "bold" },
    },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  addFooter(doc);
  doc.save(`purchase-register-${company.replace(/\s+/g, "-")}-${fy}.pdf`);
}

// ─── SALE REGISTER PDF ────────────────────────────────────────────────────────

export type SaleRegisterPdfRow = {
  issueDate: string;
  clientName: string;
  invoiceNumber: string;
  description: string;
  unit: string;
  quantity: number;
  rate: number;
  amount: number;
  siteName: string;
};

export function downloadSaleRegisterPDF(
  rows: SaleRegisterPdfRow[],
  label: string,
  totalQty: number,
  totalAmount: number,
) {
  const doc = new jsPDF({ orientation: "landscape" });

  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, 297, 16, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.text(BRAND, 14, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-IN")}`, 283, 10, { align: "right" });

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(15);
  doc.setFont("helvetica", "bold");
  doc.text("SALE REGISTER", 14, 28);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(`${label}  ·  ${rows.length} items`, 14, 35);

  const GREEN: [number, number, number] = [4, 120, 87];

  autoTable(doc, {
    startY: 42,
    head: [["#", "Date", "Client", "Invoice No", "Item / Description", "Unit", "Qty", "Rate (Rs.)", "Amount (Rs.)", "Site"]],
    body: rows.map((r, i) => [
      String(i + 1),
      r.issueDate ? r.issueDate.split("T")[0].split("-").reverse().join("-") : "-",
      r.clientName,
      r.invoiceNumber,
      r.description,
      r.unit,
      String(r.quantity),
      fmt(r.rate),
      fmt(r.amount),
      r.siteName,
    ]),
    foot: [["", "", "", "", "", "TOTAL", fmt(totalQty), "", fmt(totalAmount), ""]],
    headStyles: { fillColor: GREEN, textColor: 255, fontSize: 8, fontStyle: "bold" },
    footStyles: { fillColor: [209, 250, 229], textColor: [6, 95, 70], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    alternateRowStyles: { fillColor: [236, 253, 245] },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      1: { cellWidth: 22 },
      6: { halign: "right" },
      7: { halign: "right" },
      8: { halign: "right", fontStyle: "bold" },
    },
    margin: { left: 14, right: 14 },
    theme: "striped",
  });

  addFooter(doc);
  doc.save(`sale-register-${label.replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.pdf`);
}
