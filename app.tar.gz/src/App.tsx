import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import NotFound from "./pages/NotFound.tsx";
import AppLayout from "./pages/layout.tsx";
import Dashboard from "./pages/dashboard/page.tsx";
import Companies from "./pages/companies/page.tsx";
import CompanyDetail from "./pages/companies/detail.tsx";
import Sites from "./pages/sites/page.tsx";
import SiteDetail from "./pages/sites/detail.tsx";
import Clients from "./pages/clients/page.tsx";
import ClientDetail from "./pages/clients/detail.tsx";
import Suppliers from "./pages/suppliers/page.tsx";
import SupplierDetail from "./pages/suppliers/detail.tsx";
import Contractors from "./pages/contractors/page.tsx";
import ContractorDetail from "./pages/contractors/detail.tsx";
import Labour from "./pages/labour/page.tsx";
import LabourDetail from "./pages/labour/detail.tsx";
import AttendancePage from "./pages/attendance/page.tsx";
import WorkOrders from "./pages/work-orders/page.tsx";
import WorkOrderDetail from "./pages/work-orders/detail.tsx";
import BillingDashboard from "./pages/billing-dashboard/page.tsx";
import IncomingInvoices from "./pages/incoming-invoices/page.tsx";
import SalePurchaseRegister from "./pages/sale-purchase-register/page.tsx";
import ItemMaster from "./pages/item-master/page.tsx";
import Materials from "./pages/materials/page.tsx";
import MaterialDetail from "./pages/materials/detail.tsx";
import SalarySheets from "./pages/salary/page.tsx";
import SalaryDetail from "./pages/salary/detail.tsx";
import Invoices from "./pages/invoices/page.tsx";
import InvoiceDetail from "./pages/invoices/detail.tsx";
import Payments from "./pages/payments/page.tsx";
import Expenses from "./pages/expenses/page.tsx";
import PurchaseOrders from "./pages/purchase-orders/page.tsx";
import PurchaseOrderDetail from "./pages/purchase-orders/detail.tsx";
import VendorBills from "./pages/vendor-bills/page.tsx";
import SiteDiary from "./pages/site-diary/page.tsx";
import Notifications from "./pages/notifications/page.tsx";
import Users from "./pages/users/page.tsx";
import Index from "./pages/Index.tsx";
import ScreensaverAdmin from "./pages/screensaver-admin/page.tsx";
import SitePnL from "./pages/site-pnl/page.tsx";
import SeedData from "./pages/seed-data/page.tsx";
import Analytics from "./pages/analytics/page.tsx";
import Reports from "./pages/reports/page.tsx";
import DeliveryChallans from "./pages/delivery-challans/page.tsx";
import BackupPage from "./pages/backup/page.tsx";
// Portal pages (no auth required — token-based)
import LabourPortal from "./pages/portal/labour/page.tsx";
import SupplierPortal from "./pages/portal/supplier/page.tsx";
import ContractorPortal from "./pages/portal/contractor/page.tsx";

import PartnersPage from "./pages/partners/page.tsx";
import LabourCorrections from "./pages/labour-corrections/page.tsx";
import SafetySupervisorPortal from "./pages/portal/safety-supervisor/page.tsx";
import SupervisorPortal from "./pages/portal/supervisor/page.tsx";
import SafetyPage from "./pages/safety/page.tsx";
import MaterialRequests from "./pages/material-requests/page.tsx";
import SuperAdminDashboard from "./pages/super-admin/page.tsx";
import HelpPage from "./pages/help/page.tsx";
import BOQPage from "./pages/boq/page.tsx";
import BOQComparePage from "./pages/boq/compare.tsx";
import BOQVendorPortal from "./pages/portal/boq-vendor/page.tsx";
import PortalAccessPage from "./pages/portal-access/page.tsx";
import GstInvoiceTrackingPage from "./pages/gst-invoice-tracking/page.tsx";
import GstSummaryPage from "./pages/gst-summary/page.tsx";
import BankStatementPage from "./pages/bank-statement/page.tsx";
import RegisterPage from "./pages/register/page.tsx";
import UserApprovalsPage from "./pages/user-approvals/page.tsx";
import LabourRegisterPage from "./pages/labour-register/page.tsx";
import LabourForm2Page from "./pages/labour-register/form2/page.tsx";
import ProfileForm2Page from "./pages/profile-form2/page.tsx";

import { useServiceWorker } from "@/hooks/use-service-worker.ts";
import PwaInstallBanner from "@/components/pwa-install-banner.tsx";

export default function App() {
  useServiceWorker();
  return (
    <DefaultProviders>
      <BrowserRouter>
        <PwaInstallBanner />
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/" element={<Index />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/labour-register" element={<LabourRegisterPage />} />
          <Route path="/labour-register/form2" element={<LabourForm2Page />} />
          <Route path="/profile-form2" element={<ProfileForm2Page />} />
          {/* Public portal routes — no layout wrapper */}
          <Route path="/portal/labour" element={<LabourPortal />} />
          <Route path="/portal/safety-supervisor" element={<SafetySupervisorPortal />} />
          <Route path="/portal/boq-vendor" element={<BOQVendorPortal />} />
          <Route path="/portal/supervisor" element={<SupervisorPortal />} />
          <Route path="/portal/supplier" element={<SupplierPortal />} />
          <Route path="/portal/contractor" element={<ContractorPortal />} />
          <Route element={<AppLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/companies" element={<Companies />} />
            <Route path="/companies/:id" element={<CompanyDetail />} />
            <Route path="/sites" element={<Sites />} />
            <Route path="/sites/:id" element={<SiteDetail />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/clients/:id" element={<ClientDetail />} />
            <Route path="/suppliers" element={<Suppliers />} />
            <Route path="/suppliers/:id" element={<SupplierDetail />} />
            <Route path="/contractors" element={<Contractors />} />
            <Route path="/contractors/:id" element={<ContractorDetail />} />
            <Route path="/labour" element={<Labour />} />
            <Route path="/labour/:id" element={<LabourDetail />} />
            <Route path="/attendance" element={<AttendancePage />} />
            <Route path="/work-orders" element={<WorkOrders />} />
            <Route path="/work-orders/:id" element={<WorkOrderDetail />} />
            <Route path="/billing-dashboard" element={<BillingDashboard />} />
            <Route path="/incoming-invoices" element={<IncomingInvoices />} />
            <Route path="/sale-purchase-register" element={<SalePurchaseRegister />} />
            <Route path="/item-master" element={<ItemMaster />} />
            <Route path="/materials" element={<Materials />} />
            <Route path="/materials/:id" element={<MaterialDetail />} />
            <Route path="/salary" element={<SalarySheets />} />
            <Route path="/salary/:id" element={<SalaryDetail />} />
            <Route path="/invoices" element={<Invoices />} />
            <Route path="/invoices/:id" element={<InvoiceDetail />} />
            <Route path="/payments" element={<Payments />} />
            <Route path="/expenses" element={<Expenses />} />
            <Route path="/purchase-orders" element={<PurchaseOrders />} />
            <Route path="/purchase-orders/:id" element={<PurchaseOrderDetail />} />
            <Route path="/vendor-bills" element={<VendorBills />} />
            <Route path="/site-diary" element={<SiteDiary />} />
            <Route path="/delivery-challans" element={<DeliveryChallans />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/users" element={<Users />} />
            <Route path="/screensaver-admin" element={<ScreensaverAdmin />} />
            <Route path="/site-pnl" element={<SitePnL />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/seed-data" element={<SeedData />} />
            <Route path="/partners" element={<PartnersPage />} />
            <Route path="/backup" element={<BackupPage />} />
            <Route path="/labour-corrections" element={<LabourCorrections />} />
            <Route path="/safety" element={<SafetyPage />} />
            <Route path="/material-requests" element={<MaterialRequests />} />
            <Route path="/super-admin" element={<SuperAdminDashboard />} />
            <Route path="/help" element={<HelpPage />} />
            <Route path="/boq" element={<BOQPage />} />
            <Route path="/boq/:id/compare" element={<BOQComparePage />} />
            <Route path="/portal-access" element={<PortalAccessPage />} />
            <Route path="/gst-invoice-tracking" element={<GstInvoiceTrackingPage />} />
            <Route path="/gst-summary" element={<GstSummaryPage />} />
            <Route path="/bank-statement" element={<BankStatementPage />} />
            <Route path="/user-approvals" element={<UserApprovalsPage />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
